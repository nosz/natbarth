param([string]$Root, [int]$Port = 8100)
# Kleiner lokaler Webserver, damit relative Links zwischen den Seiten funktionieren.
$Root = (Resolve-Path $Root).Path
$types = @{ ".html" = "text/html; charset=utf-8"; ".htm" = "text/html; charset=utf-8"; ".css" = "text/css"; ".js" = "text/javascript"; ".json" = "application/json"; ".md" = "text/plain; charset=utf-8"; ".png" = "image/png"; ".svg" = "image/svg+xml" }
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$Port/")
$l.Start()
while ($l.IsListening) {
  $c = $l.GetContext()
  $p = [Uri]::UnescapeDataString($c.Request.Url.LocalPath.TrimStart('/'))
  if ($p -eq '') { $p = 'firma.htm' }
  $f = [IO.Path]::GetFullPath((Join-Path $Root $p))
  if ((Test-Path $f -PathType Leaf) -and $f.StartsWith($Root)) {
    $b = [IO.File]::ReadAllBytes($f)
    $t = $types[[IO.Path]::GetExtension($f).ToLower()]
    if (-not $t) { $t = "application/octet-stream" }
    $c.Response.ContentType = $t
    $c.Response.OutputStream.Write($b, 0, $b.Length)
  } else { $c.Response.StatusCode = 404 }
  $c.Response.Close()
}
