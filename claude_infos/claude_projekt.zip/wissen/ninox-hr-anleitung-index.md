# Index: Ninox HR Anleitung (Forum)

Kategorie: https://forum.ninox.de/category/ninox-hr-anleitung (Blättern mit `?pg=2` bis `?pg=5`, nicht `?page=`)
Stand: 2026-10-26, rund 114 Beiträge. Aus Listenauszügen zusammengestellt (WebFetch-Zusammenfassungen), nicht aus den Artikeln selbst. Vor Verwendung im Einzelfall den Beitrag öffnen. „Platzhalter“ = laut Liste noch kein Artikel.
Disclaimer der Doku: https://forum.ninox.de/t/p8ykgd9/02-disclaimer

## Seite 1 (https://forum.ninox.de/category/ninox-hr-anleitung)
Vollständige Beitrags-URLs für Seite 1 liegen noch nicht vor (nur gekürzte Pfade). Titel:
00 Inhaltsverzeichnis, 01 Einführung, 02 Disclaimer, 03 Wichtig: Ninox Bearbeitungsmodus, 04 Schnellstart, 04.01 Mitarbeitende einladen und Zugang erteilen, 04.02 Schnellstart: Für Lohnabrechnungen, 04.03 Schnellstart: Für Mitarbeiter, 04.04 Schnellstart: Für HR Management (Platzhalter), 05 Die Navigationsleiste, 05.01 Startseite, 05.02 Kalender, 05.03 Zeiterfassung, 05.04 Mitarbeitende, 05.05 Lohnbuchhaltung, 05.06 Berichte, 05.07 Dokumenten-Cloud, 05.08 Einstellungen, 06 Die Einrichtung, 06.01 Installation, 06.02 Der Einrichtungsassistent, 06.03 Rollen erstellen und zuweisen, 06.04 Unternehmensdaten, 06.05 Feiertagskalender, 06.05.01 Feiertage hinzufügen.

## Seite 2 (?pg=2)
- 06.06 Standorte: https://forum.ninox.de/t/35ykg7k/06-06-standorte
- 06.06.01 Mehreren Mitarbeitenden einen Standort zuweisen: https://forum.ninox.de/t/y4yk0wj/06-06-01-mehreren-mitarbeitenden-einen-standort-zuweisen
- 06.07 Arbeitszeitmodelle: https://forum.ninox.de/t/q6ykg71/06-07-arbeitszeitmodelle
- 06.07.01 Vollzeit Referenz: https://forum.ninox.de/t/h7ykg7p/06-07-01-vollzeit-referenz
- 06.07.02 Zeiterfassung aktivieren: https://forum.ninox.de/t/p8ykg7g/06-07-02-zeiterfassung-aktivieren
- 06.07.03 Mehreren Mitarbeitenden ein Arbeitszeitmodell zuweisen: https://forum.ninox.de/t/g9yksfb/06-07-03-mehreren-mitarbeitenden-ein-arbeitszeitmodell-zuweisen
- 06.08 Abteilungen: https://forum.ninox.de/t/83ykb1v/06-08-abteilungen
- 06.09 Teams: https://forum.ninox.de/t/y4ykbpq/06-09-teams
- 06.10 Kostenstellen: https://forum.ninox.de/t/35ykbph/06-10-kostenstellen
- 06.11 Genehmigungsworkflows: https://forum.ninox.de/t/h7ykbp3/06-11-genehmigungsworkflows
- 06.11.01 Genehmigungsworkflows duplizieren: https://forum.ninox.de/t/60ykbp6/06-11-01-genehmigungsworkflows-duplizieren
- 06.12 Abwesenheitsarten: https://forum.ninox.de/t/m1ykbpm/06-12-abwesenheitsarten
- 06.12.01 Abwesenheitskontingente: https://forum.ninox.de/t/y4ykbpz/06-12-01-abwesenheitskontingente
- 06.12.01.01 Negative Abwesenheitskontingente verhindern: https://forum.ninox.de/t/q6ykbpf/06-12-01-01-negative-abwesenheitskontingente-verhindern
- 06.12.01.02 Mehreren Mitarbeitenden ein Abwesenheitskontingent zuweisen: https://forum.ninox.de/t/q6yksmc/06-12-01-02-mehreren-mitarbeitenden-ein-abwesenheitskontingent-zuweisen
- 06.13 Dokumentenkategorien: https://forum.ninox.de/t/h7ykbpd/06-13-dokumentenkategorien
- 07 Import von Daten und Dokumenten: https://forum.ninox.de/t/p8ykbpw/07-import-von-daten-und-dokumenten
- 07.01 Templates herunterladen: https://forum.ninox.de/t/g9ykbpn/07-01-templates-herunterladen
- 07.02 Datenimport: https://forum.ninox.de/t/60ykbp7/07-02-datenimport
- 07.02.01 Import: Stammdaten: https://forum.ninox.de/t/m1ykbps/07-02-01-import-stammdaten
- 07.02.02 Import: Zeiterfassung: https://forum.ninox.de/t/x2ykbp0/07-02-02-import-zeiterfassung
- 07.02.03 Import: Abwesenheiten: https://forum.ninox.de/t/y4ykbpc/07-02-03-import-abwesenheiten
- 07.02.04 Import: Wiederkehrende Vergütungen: https://forum.ninox.de/t/q6ykbp4/07-02-04-import-wiederkehrende-vergutungen
- 07.02.05 Import: Einmalige Vergütungen: https://forum.ninox.de/t/h7ykbp9/07-02-05-import-einmalige-vergutungen
- 07.02.06 Import: Gehalt: https://forum.ninox.de/t/p8ykbpv/07-02-06-import-gehalt

## Seite 3 (?pg=3)
- 07.03 Dokumentenimport: https://forum.ninox.de/t/g9ykbgq/07-03-dokumentenimport
- 08 Benachrichtigungen: https://forum.ninox.de/t/60ykbgh/08-benachrichtigungen
- 08.01 SMTP Einrichtung: https://forum.ninox.de/t/m1ykbgy/08-01-smtp-einrichtung
- 08.02 Standard-Email für Benachrichtigungen: https://forum.ninox.de/t/83ykbgx/08-02-standard-email-fur-benachrichtigungen
- 09 Organigramm: https://forum.ninox.de/t/y4ykbg8/09-organigramm
- 10 Ninox HR: Digitale Personalakte: https://forum.ninox.de/t/h7ykbgm/10-ninox-hr-digitale-personalakte
- 10.01 Aufbau: https://forum.ninox.de/t/35ykbgg/10-01-digitale-personalakte-aufbau
- 10.02 Felder: https://forum.ninox.de/t/q6ykbgj/10-02-digitale-personalakte-felder
- 10.03 Ninox Nutzer zuordnen: https://forum.ninox.de/t/m1ykbgr/10-03-ninox-nutzer-zuordnen
- 10.04 Neue Personalakte erstellen: https://forum.ninox.de/t/x2ykbg2/10-04-neue-personalakte-erstellen
- 10.05 Stammdaten ändern: https://forum.ninox.de/t/35ykbgw/10-05-digitale-personalakte-stammdaten-andern
- 10.05.01 Arbeitszeitmodell zuweisen: https://forum.ninox.de/t/q6ykbgn/10-05-01-arbeitszeitmodell-zuweisen
- 10.05.01.01 Standard-Arbeitszeitmodell: https://forum.ninox.de/t/83yksms/10-05-01-01-standard-arbeitszeitmodell
- 10.05.02 Abwesenheitskontingente zuweisen: https://forum.ninox.de/t/h7ykbg7/10-05-02-abwesenheitskontingente-zuweisen
- 10.05.03 Negative Abwesenheitskontingente: https://forum.ninox.de/t/m1yksf4/10-05-03-negative-abwesenheitskontingente
- 10.05.04 Vergütung: https://forum.ninox.de/t/p8ykbgs/10-05-04-vergutung
- 10.05.04.01 Gehalt: https://forum.ninox.de/t/g9ykbg0/10-05-04-01-gehalt
- 10.05.04.02 Wiederkehrende Vergütungen: https://forum.ninox.de/t/x2ykbgc/10-05-04-02-wiederkehrende-vergutungen
- 10.05.04.03 Einmalige Vergütungen: https://forum.ninox.de/t/83ykbg4/10-05-04-03-einmalige-vergutungen
- 10.05.04.04 Gehaltstabelle: https://forum.ninox.de/t/60yksfd/10-05-04-04-gehaltstabelle
- 10.05.04.05 Vergütungsart hinzufügen: https://forum.ninox.de/t/q6ykbjr/10-05-04-05-vergutungsart-hinzufugen
- 10.05.05 Dokumente hochladen: https://forum.ninox.de/t/y4ykbg9/10-05-05-dokumente-hochladen
- 10.05.06 Nachträgliche Korrekturen in der Änderungshistorie: https://forum.ninox.de/t/83yka8d/10-05-06-nachtragliche-korrekturen-in-der-anderungshistorie-der-personalakte
- 10.06 Arbeitszeiten erfassen: https://forum.ninox.de/t/g9ykb1l/10-06-arbeitszeiten-erfassen
- 10.06.01 Zeiterfassung mit Widget: https://forum.ninox.de/t/q6ykslv/10-06-01-zeiterfassung-mit-widget

## Seite 4 (?pg=4)
- 10.06.02 Zeiterfassung über die Navigationsleiste: https://forum.ninox.de/t/p8yksfh/10-06-02-zeiterfassung-uber-die-navigationsleiste
- 10.06.03 Zeiterfassung über die Personalakte: https://forum.ninox.de/t/60yksf3/10-06-03-zeiterfassung-uber-die-personalakte
- 10.07 Überstundenkonto: https://forum.ninox.de/t/p8ykcwp/10-07-uberstundenkonto
- 10.07.01 Konto editieren: https://forum.ninox.de/t/g9ykcwg/10-07-01-uberstundenkonto-konto-editieren
- 10.07.02 Auszahlung (Platzhalter): https://forum.ninox.de/t/60ykcwj/10-07-02-uberstundenkonto-auszahlung
- 10.07.03 In Zeitausgleich konvertieren (Platzhalter): https://forum.ninox.de/t/m1ykcw5/10-07-03-uberstundenkonto-in-zeitausgleich-konvertieren
- 10.08 Abwesenheiten beantragen: https://forum.ninox.de/t/m1ykb1f/10-08-abwesenheiten-beantragen
- 10.09 Abwesenheitskonto (Platzhalter): https://forum.ninox.de/t/x2ykcwr/10-09-abwesenheitskonto
- 10.09.01 Manuelle Korrektur (Platzhalter): https://forum.ninox.de/t/83ykcw2/10-09-01-abwesenheitskonto-manuelle-korrektur
- 10.10 Dokumente aus der Personalakte herunterladen: https://forum.ninox.de/t/x2ykb1k/10-10-dokumente-aus-der-personalakte-herunterladen
- 11 Ninox HR: Kalender: https://forum.ninox.de/t/35ykbgv/11-ninox-hr-kalender
- 12 Zusätzliche Ninox HR Lizenzen zuweisen: https://forum.ninox.de/t/q6ykbjq/12-zusatzliche-ninox-hr-lizenzen-zuweisen
- 13 Vorbereitende Lohnbuchhaltung: https://forum.ninox.de/t/h7ykbjh/13-vorbereitende-lohnbuchhaltung
- 13.01 Personalstammdaten einrichten: https://forum.ninox.de/t/p8ykbjy/13-01-lohnbuchhaltung-personalstammdaten-einrichten
- 13.02 Zusätzliche Spalten im Bereich Gehalt: https://forum.ninox.de/t/g9ykbj3/13-02-zusatzliche-spalten-im-bereich-gehalt
- 13.03 Anteilige Gehaltsabrechnung: https://forum.ninox.de/t/60ykbjx/13-03-anteilige-gehaltsabrechnung
- 13.04 Personalstammdaten in der Lohnbuchhaltung einrichten: https://forum.ninox.de/t/35ykbjt/13-04-personalstammdaten-in-der-lohnbuchhaltung-einrichten
- 13.05 Vorbereitende Lohnabrechnung freigeben: https://forum.ninox.de/t/h7ykbjl/13-05-vorbereitende-lohnabrechnung-freigeben
- 13.06 Excel Vorschau aktivieren: https://forum.ninox.de/t/g9ykbjk/13-06-excel-vorschau-aktivieren
- 13.07 Export (z. B. DATEV, LODAS): https://forum.ninox.de/t/m1ykbjp/13-07-vorbereitende-lohnbuchhaltung-export
- 14 Berichte: https://forum.ninox.de/t/35ykbj5/14-berichte
- 15 Integrationen: https://forum.ninox.de/t/h7ykbj2/15-integrationen
- 15.01 DATEV eAU: https://forum.ninox.de/t/p8ykbjb/15-01-datev-eau
- 15.02 DATEV Lohnauswertungsdatenservice (Platzhalter): https://forum.ninox.de/t/g9ykbjd/15-02-datev-lohnauswertungsdatenservice
- 15.03 Integration: JOIN.COM: https://forum.ninox.de/t/x2ykbj7/15-03-integration-join-com

## Seite 5 (?pg=5)
- 16 Dokumenten-Cloud (Rolle hr-documents): https://forum.ninox.de/t/35ykbj0/16-dokumenten-cloud
- 16.01 Zugang für den Steuerberater: https://forum.ninox.de/t/p8ykbj4/16-01-zugang-fur-den-steuerberater
- 16.02 Ein Dokument hochladen (Platzhalter): https://forum.ninox.de/t/h7ykax9/16-02-ein-dokument-in-der-dokumenten-cloud-hochladen
- 17 Datensicherung: https://forum.ninox.de/t/p8ykbjf/17-datensicherung
- 18 FAQ: https://forum.ninox.de/t/x2ykb5h/18-faq
- 18.01 FAQ: Allgemein (Rollen hr-admin, hr-manager, hr-documents, hr-employee): https://forum.ninox.de/t/83ykb5y/18-01-faq-allgemein
- 18.02 FAQ: Anwesenheiten (Platzhalter): https://forum.ninox.de/t/q6ykb5x/18-02-faq-anwesenheiten
- 18.03 FAQ: Abwesenheiten (Platzhalter): https://forum.ninox.de/t/p8ykb56/18-03-faq-abwesenheiten
- 18.04 FAQ: Personalakte (Platzhalter): https://forum.ninox.de/t/m1ykb5z/18-04-faq-personalakte
- 18.05 FAQ: DATEV (Platzhalter): https://forum.ninox.de/t/83ykb5f/18-05-faq-datev
- 18.06 FAQ: JOIN: https://forum.ninox.de/t/y4ykb5k/18-06-faq-join
- 18.07 FAQ: Lohnabrechnung (Platzhalter): https://forum.ninox.de/t/h7ykb5p/18-07-faq-lohnabrechnung
- 18.08 Häufige Fehler: https://forum.ninox.de/t/83yk0wg/18-08-haufige-fehler
- 19 Profilbild hochladen: https://forum.ninox.de/t/y4ykb1n/19-profilbild-hochladen

Nur als Text in der Seitenleiste, ohne Link: Versionshinweise HR, Anleitung Onboarding, Versionshinweise Onboarding.
