---
name: feedback-eml-immer-korrekt
description: Zwingend: Der Outlook-Entwurf (.eml) von Archie muss immer korrekt sein, mit Text und beiden PDFs, automatisch geprüft
metadata:
  type: feedback
---

Norbert (04.11.2026): Die .eml bei Kuchlbauer stimmte nicht (Mailtext fehlte im Outlook-Fenster), Archie muss zwingend aufnehmen, dass die .eml immer korrekt ist.

**Why:** Der Entwurf geht direkt an Kunden; ein leeres Mailfenster ist peinlich und kostet Norbert Zeit. Ursache war ein reiner Nur-Text-Teil; Outlook zeigt den Text zuverlässig, wenn die Nachricht multipart/alternative (Nur-Text und HTML) enthält.

**How to apply:**
- Aufbau: multipart/mixed, darin multipart/alternative (Nur-Text und HTML) plus die beiden PDFs als Anhang. Nur Grußformel im Text, die Signatur ergänzt Outlook.
- Das Bau-Skript prüft jeden Entwurf mit CDO (Betreff, Text DE und EN, HTML, 2 Anhänge, keine Platzhalter/Personenbezug) und bricht bei Fehlern ab. Bei Änderungen am Aufbau zusätzlich in Outlook öffnen und Norbert prüfen lassen.
- Nie "fertig" ohne bestandene Entwurfsprüfung. Siehe [[project-kundenbericht-pdf]] und [[feedback_absolut-professionell]].