---
name: project_wissensstand
description: Wissensstand Architekturbericht Stand 28.10.2026 und offene Punkte
metadata:
  type: project
---

Der interne Architekturbericht (öffentliche Doku plus vier interne Confluence-Seiten, mit Vertrauensstufen) liegt als Seite in `02_Erstellte_Apps\06_ninox4_architektur\` und bleibt intern. Kundenberichte entstehen separat in `04_Mitarbeiter\archie_berichte\` und enthalten nur öffentliche Quellen (siehe [[project-kundenbericht-pdf]]).

Offen (Stand 28.10.2026): zentrale Architekturübersicht, Rate-Limits, Interna der Skript-Engine (do as server), Rollenmodell-Details, Stand der RFCs (Custom Apps V2, Sovereign Hosting).

Offen für die Kundenberichte (Stand 04.11.2026, Nachprüfung von Claudia): Hosting-Aussage zu Ninox 4 stammt nur aus einem Blog zum "neuen Ninox" (Vorbehalt nötig); Aussage zur Klartext-Passphrase in der Ninox-3-Konfiguration ist in der Quelle nicht bestätigt; Zertifizierungs- und Vertragsaussagen sollen Management und Legal einmal freigeben.
