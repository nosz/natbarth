---
name: feedback-dateinamen-schema
description: Zwingend: Archies Dateien heißen kunde_systemarchitektur-ninox4_sprache_datum.pdf, Kunde vorn, Datum hinten, überall bei Archie
metadata:
  type: feedback
---

Norbert (04.11.2026): "Die Dateinamen müssen überall bei Archie so aussehen: `kuchlbauer_systemarchitektur-ninox4_en_datum.pdf`. Ändere dies ab und merke es dir gut."

**Why:** Der Kunde soll im Dateinamen vorn stehen, das Datum hinten; die Dateien gehen als Anhang an Kunden. Das ersetzt das frühere Schema mit Zeitstempel vorn (Otto-Schema).

**How to apply:**
- PDF: `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf`, Outlook-Entwurf: `<kunde>_mailtext-ninox<N>_<JJJJ-MM-TT>.eml`, Web-Link: `<kunde>_mailtext-ninox<N>-outlook-web_<JJJJ-MM-TT>.url`. Alles klein, Kunde = Firmenkurzname (nie Personenname oder E-Mail).
- Neutrale Dokumente (ohne Kundenbezug, `-Neutral`): Ordner `berichte\neutral\ninox<N>\`, Dateinamen ohne Kundenvorsatz (`systemarchitektur-ninox4_de_2026-11-04.pdf`), kein Firmenname im Dokument (Norbert: "mach das neutral_ am Anfang weg").
- Gilt für jede Datei, jedes Skript, jeden Mailtext und jeden Anhangnamen bei Archie. Nur das Datum, keine Uhrzeit im Namen.
- Gleiches Datum, gleicher Kunde: das Bau-Skript verschiebt vorhandene Dateien nach `ersetzt\vor-lauf-<Uhrzeit>\`, nichts überschreiben oder löschen.
- Zusammen mit [[feedback_ergebnisse-nur-pdf-und-eml]] und [[project-kundenbericht-pdf]] anwenden.
