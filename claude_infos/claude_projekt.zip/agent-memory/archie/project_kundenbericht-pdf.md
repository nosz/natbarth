---
name: project-kundenbericht-pdf
description: Kernauftrag von Archie: Kunden-PDFs Systemarchitektur je Produkt (DE+EN) mit Outlook-Entwurf und Klick-Link, nur öffentliche Quellen, Ablage in 04_Mitarbeiter\archie_berichte nach Ottos Struktur
metadata:
  type: project
---

Norbert will für Kunden fertige PDFs zur Systemarchitektur von Ninox 3 und Ninox 4, die er per E-Mail verschickt (erste Fälle am 04.11.2026). Kernauftrag von Archie, bei jedem Lauf zu verbessern.

**Why:** Die Dokumente gehen an Kunden und deren IT-Abteilungen; sie müssen absolut professionell sein ([[feedback_absolut-professionell]]) und Ninox 3 und 4 strikt trennen ([[feedback_ninox3-ninox4-getrennt]]).

**How to apply:**
- Ablauf und Regeln stehen im Agenten `archie` und in `04_Mitarbeiter\archie_berichte\README.md`. Alles liegt in `04_Mitarbeiter\archie_berichte\` (SB), nie in `02_Erstellte_Apps`: `SB\berichte\<kunde>\ninox4\` und `\ninox3\`, `SB\vorlagen\`, `SB\werkzeuge\kundenbericht-bauen.ps1`, `SB\pruefwerkzeug\pdfansicht.html`. Struktur und Namen stammen von Otto ([[feedback_ergebnisse-nur-pdf-und-eml]]).
- Je Produkt nur: 2 PDFs (DE, EN), 1 Outlook-Entwurf `.eml` (Text DE+EN, beide PDFs als Anhang, neutrale Anrede, kein Empfänger), 1 Klick-Link `.url` für Outlook im Web (nur Text, Anhänge zieht Norbert hinein). **Keine HTML-Dateien.** Die .eml wird beim Bauen geprüft ([[feedback_eml-immer-korrekt]]).
- Dateinamen (Norbert, zwingend): `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf` usw., Kunde vorn, Datum hinten, klein, nie Personenname oder E-Mail ([[feedback_dateinamen-schema]]).
- Neutrale Variante ohne Kunde: `kundenbericht-bauen.ps1 -Neutral -Produkt ninox4` erzeugt `berichte\neutral\ninox4\` mit Dateien ohne Kundenvorsatz und ohne Firmenname im Dokument.
- Nur öffentliche Quellen (`.claude\wissen\archie-quellen.md`, Abschnitt 1a), nie Confluence. Stufen: Belegt, Herstellerangabe, Empfehlung, Offen.
- Seitenprüfung als Bild per pdf.js ist Pflicht vor "fertig". Ersetztes nach `ersetzt\`, nichts ohne Freigabe löschen.
- HubSpot nur lesend und nur, wenn Norbert eine E-Mail-Adresse nennt; enthält das Feld Unternehmen einen Personennamen, nicht übernehmen und einen neutralen Firmennamen abstimmen.
- Das Skript hat einen Selbsttest-Weg: `-AusgabeOrdner <temporärer Ordner>` mit Kurzname `selbsttest`.
- Offene Verbesserungen aus Claudias Nachprüfung: Link-Prüfung im Skript, Schrift Noto Sans lokal, pdf.js lokal, Struktur-Vergleich der vier Vorlagen, Schnellstart für Kollegen, Inhaltsfreigabe durch Management und Legal.

Siehe auch [[project_wissensstand]].
