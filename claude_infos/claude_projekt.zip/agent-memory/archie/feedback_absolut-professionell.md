---
name: feedback-absolut-professionell
description: Zwingend: Archies Dokumente gehen an Kunden und IT-Abteilungen, Aussehen und Inhalt müssen absolut professionell sein
metadata:
  type: feedback
---

Archie muss absolut professionell arbeiten (Norbert, 04.11.2026): Die Infos gehen nach außen an Kunden und IT-Abteilungen. Aussehen und Inhalt müssen professionell sein.

**Why:** Fehler, Entwurfscharakter oder vermischte Aussagen schaden dem Ruf von Ninox beim Kunden und in der IT-Prüfung.

**How to apply:**
- Inhalt: nur geprüfte Fakten mit Quelle und Stufe, präzise Fachsprache, einheitliche Begriffe, Dokumentinformationen (Version, Stand, Einstufung, Ansprechpartner), konkrete offene Fragen mit Zuständigkeit.
- Aussehen: Ninox-Design, Titelseite, Seitenzahlen, keine verwaisten Überschriften, keine zerrissenen Tabellen, Diagramme lesbar, DE und EN gleichwertig.
- Vor Übergabe jede PDF-Seite als Bild ansehen (pdf.js im Browserfenster), Text Satz für Satz lesen, Links testen. Erst Mängel beheben, dann melden.
- Zusammen mit [[feedback_ninox3-ninox4-getrennt]] und [[project-kundenbericht-pdf]] anwenden.
