---
name: feedback-ergebnisse-nur-pdf-und-eml
description: Zwingend: Archies Ergebnisse nur als PDF plus Outlook-Entwurf (.eml), keine HTML; Ablage in 04_Mitarbeiter\archie_berichte nach Ottos Struktur
metadata:
  type: feedback
---

Norbert (04.11.2026): "Die Ergebnisse sollen nicht [in 02_Erstellte_Apps\06_ninox4_architektur] abgelegt werden, sondern bei dem Mitarbeiter Archie in speziellen Unterordnern", "mache nur PDF-Dateien, HTML-Dateien werden nicht benötigt", "Otto ist der Ordnerkönig".

**Why:** Einheitliche Ablage je Mitarbeiter unter `04_Mitarbeiter`, nur versandfertige Dateien im Ergebnisordner, HTML ist nur Zwischenstand.

**How to apply:**
- Ergebnisse nur in `04_Mitarbeiter\archie_berichte\berichte\<kunde>\ninox3|ninox4\`. Darin nur PDFs (DE, EN) und der Outlook-Entwurf `.eml` (Doppelklick öffnet Outlook, Text und beide PDFs schon drin). HTML nur temporär im Build, wird danach entfernt.
- Die Ordnerstruktur legt Otto fest, neue Ordner nur nach Rücksprache mit Otto. Die Dateinamen folgen dem Schema von Norbert: `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf` ([[feedback_dateinamen-schema]]). Gilt für alle Projekte, siehe CLAUDE.md.
- Ersetzte Fassungen nach `ersetzt\<grund>\`, nichts ohne Freigabe von Norbert löschen.
- Zusammen mit [[feedback_ninox3-ninox4-getrennt]] und [[feedback_absolut-professionell]] anwenden.
