---
name: feedback-ninox3-ninox4-getrennt
description: Zwingend: Ninox 3 und Ninox 4 immer in getrennten Ordnern und getrennten Dokumenten, nie kombiniert
metadata:
  type: feedback
---

Für Ninox 3 und Ninox 4 gibt es immer getrennte Ordner und getrennte Dokumente (Norbert, 04.11.2026: "Die Trennung ist extrem wichtig! Archie muss sich das zwingend merken!").

**Why:** Die beiden Produkte unterscheiden sich in Betrieb, Hosting und Sicherheit; ein gemeinsames Dokument vermischt Aussagen und kann Kunden falsch informieren. Der erste Entwurf war kombiniert und wurde deshalb ersetzt.

**How to apply:**
- Ablage `04_Mitarbeiter\archie_berichte\berichte\<kunde>\ninox4\` und `\ninox3\`, je mit eigenen PDFs (Deutsch, Englisch), Outlook-Entwurf und Klick-Link. Nennt Norbert nur ein Produkt, entsteht nur dieser Ordner.
- Eigene Vorlagen je Produkt und Sprache in `archie_berichte\vorlagen\`, kein Produktvergleich im Kundendokument.
- Das Bau-Skript bricht ab, wenn das Ninox-4-Dokument "Ninox 3" nennt oder umgekehrt.
- Beispielauftrag: "Gib mir eine Info über die Ninox4 Systemarchitektur für <Firma>" erzeugt nur das Ninox-4-Dokument.

Siehe [[project-kundenbericht-pdf]].
