---
name: zentrale-todo-stufe2
description: Zentrale To-do-Liste 08_Todos ist die einzige Liste; Sarahs Übersicht, Favoriten-Erinnerungen und Suche sind Live-Ansichten (Stand 28.10.2026, Stufe 2)
metadata:
  type: project
---

Alle Aufgaben und Erinnerungen stehen nur in `08_Todos\todos.json` (Spiegel `todos.js`, Werkzeug `todos.ps1`). Die To-do-App (ab 1.11.0) verbindet den Ordner 08_Todos (showDirectoryPicker) und schreibt den Spiegel bei jeder Änderung selbst.

**Why:** Norbert wollte EINE zentrale Stelle für alle To-dos, keine zweite Liste (auch nicht bei Sarah).

**How to apply:**
- Sarahs Übersicht hat die feste Adresse `05_Sarah_Erinnerungen\sarah-uebersicht.html` (Live-Ansicht, Ausnahme von Ottos Timestamp-Regel); `erinnerungen.md` ist nur Archiv.
- Live-Ansichten (Sarah, Favoriten, Suche) lesen über `window.nxTodoListe()` aus `zaehler.js`; nie wieder statische Arrays oder Indexeinträge für Aufgaben pflegen.
- Tests: `nxTestSarah`, `nxTestFavoriten`, `nxTestOrdner` in `_standard\pruefung.js` (simulierter Verzeichnis-Handle; echter Dialog nicht testbar). Echte `todos.json` nie anfassen, Norbert ändert sie laufend.
- Mehrere Browser-Testläufe nie gleichzeitig (gemeinsamer Browserspeicher).
