---
name: feedback-pdf-und-tests
description: PDF-Bau, Acrobat-Sperre und Testablauf für Seiten und Flyer
metadata:
  type: feedback
---

- PDFs entstehen per Edge headless (erst Temp, dann Kopie); das frühere Skript `flyer-bauen.ps1` existiert nicht mehr. Flyer 1 Seite, Falzflyer 2 Seiten (A4 quer, doppelseitig, Wenden an der kurzen Kante).
- **Acrobat sperrt offene PDFs:** Dann meldet das Skript GESPERRT und die alte Datei bleibt. Norbert sah dadurch alte Fassungen. Nach jedem Bau Änderungszeit der Ziel-PDFs prüfen und **sofort** sagen, wenn etwas gesperrt ist; die Datei nicht stillschweigend liegen lassen. Nichts ohne Freigabe löschen (alte Dateien nur mit Ja).
- Tests: Sicherung außerhalb OneDrive, `pruefung.ps1` (0 Fehler), Seiten über `localhost:8100` (nie file://), Links 200, Deutsch und Englisch ohne Restwörter, kein seitliches Scrollen, jedes Flyer-Panel ohne Überlauf, Seitenzahl der PDFs, Konsole ohne Fehler. Nach jeder Änderung Versionsnummer erhöhen und README-Verlauf ergänzen. Suchindex neu erzeugen.
- Nicht prüfbar für mich: QR-Codes scannen, PDFs als Bild ansehen. Das ehrlich sagen.

**Why:** Norbert verlangt ehrliche Berichte mit Zahlen. **How to apply:** Jede Meldung "fertig" nennt, was geprüft wurde und was nicht.