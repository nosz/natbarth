---
name: reference-links-und-regeln-zugangsdaten
description: Wichtige Links und der Umgang mit Zugangsdaten und Endpunkt-Adressen
metadata:
  type: reference
---

- Wirtshaus: https://www.wirtshaus-zum-reiterhof.de/ (angezeigt als wirtshaus-zum-reiterhof.de).
- Anmeldeseite (geplant): https://norbert-szpak.de/anmeldung.html, noch nicht veröffentlicht.
- Datenschutz: https://ninox.com/de/rechtliche-hinweise/datenschutz
- Heilbronn als KI-Zentrum (Argument im Genehmigungstext): https://ip.ai/ , https://ki-campus.org/ueber-uns/hubs/hub-bw , https://schwarz-digits.de/
- Geschäftsführung genehmigt (Text: `03_texte`); versendet wird nichts ohne Norberts Ja.
- **Zugangsdaten/Endpunkte:** Eine Google-Apps-Script-Adresse (Anmeldungen in Google Sheet) wurde im Chat genannt und bewusst nicht eingebaut. Regel: als Geheimnis behandeln, aus Bitwarden erst beim Veröffentlichen in `ENDPOINT` eintragen, Platzhalter `<APPS_SCRIPT_URL>`, bei Weitergabe im Chat erneuern, Unterhaltung löschen, IT (it@ninox.com) informieren.