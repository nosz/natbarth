---
name: feedback-regeln-materialien
description: Alle Gestaltungs- und Inhaltsregeln, die Norbert für Seiten, Flyer und Falzflyer festgelegt hat
metadata:
  type: feedback
---

- **Anmeldung** so einfach wie möglich: nur Name und E-Mail-Adresse (plus Pflichthaken Einwilligung).
- **QR-Codes:** für die Anmeldung steht auf Flyern keine Web-Adresse, nur der QR-Code. Zusätzlich QR zum Wirtshaus. Webadressen in Texten ohne "www.". Englischer Flyer: Anmelde-QR mit `?lang=en`. QR lokal erzeugt (qrcode-generator), nie über Fremddienst.
- **Öffentlicher Kopf:** Landingpage und Anmeldung immer ohne "Nobbis Super-Firma", ohne interne Navigation, ohne To-do-Spiegel (`seite-standard.ps1 -Oeffentlich`), `<title>` ohne Firmennamen.
- **Veranstalter-Name** "Norbert Szpak" steht auf allen Materialien. In der Falzflyer-Karte "Dein Gastgeber" steht **nur der Name**, kein Zusatztext (mehrfach verlangt).
- **Kein "wir", "uns", "unser"** (auch nicht auf Englisch): neutral formulieren ("danach wird live gezeigt ..."). Vor dem Fertigmelden danach suchen.
- **Nutzen deutlich:** "Dein Vorteil" (KI-Agents beherrschen; mit Herz-Intelligenz auch in schwierigen Zeiten mit Freude und Spaß durch das Leben gehen). Beitrag deutlich sichtbar. Heilbronn ist KI-Zentrum (nur als Argument im Text an die Geschäftsführung, Links ip.ai, ki-campus.org Hub BW, schwarz-digits.de).
- **Rotes Herz** (#e11d48, Bootstrap Icon `heart-fill`) überall, aber **klein und dezent**: weißer Kreis 15 mm oben rechts auf Flyer und Falzflyer, kein großes Herz. Keine Emojis, nur Bootstrap Icons.
- **Seiten füllen:** Flyer-Spalten und Panels gefüllt (größere Schrift, Karten unten), kein großer leerer Raum; Überlauf prüfen.
- **Datenschutz:** Link zur Datenschutzerklärung von Ninox (https://ninox.com/de/rechtliche-hinweise/datenschutz) in der Fußzeile beider Seiten und auf der Anmeldeseite; Impressum-Platzhalter vom Management. Ob die Erklärung die Anmeldung (besonders Google Sheets) abdeckt, klärt die Geschäftsführung.
- **Dateinamen der PDFs:** `2026-11-27_ninox-live_<flyer-a4|falzflyer-3-spalten>_<de|en>.pdf` (Datum der Veranstaltung zuerst).
- **Ordner:** `01_webseite`, `02_druck`, `03_texte`, damit Norbert durchblickt.

**Why:** Norbert hat das im Lauf der ersten Veranstaltung am 2026-10-29 so verlangt, einiges mehrfach. **How to apply:** Bei jeder neuen Veranstaltung und jeder Änderung diese Liste vorher lesen und nachher prüfen.