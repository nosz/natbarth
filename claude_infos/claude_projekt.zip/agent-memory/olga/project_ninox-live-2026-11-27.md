---
name: project-ninox-live-2026-11-27
description: Erste Veranstaltung Ninox Live am 27.11.2026: Eckdaten, Programm, Dateien, offene Punkte
metadata:
  type: project
---

**Veranstaltung:** Ninox Live: Herz-Intelligenz trifft KI-Agents. Freitag 27.11.2026 (Black Friday), 20:00 bis 21:30 Uhr. Ort: Wirtshaus zum Reiterhof, Kelterweg 41, 74081 Heilbronn-Horkheim. Veranstalter: Norbert Szpak (allein). Beitrag: 10 EUR für die Raummiete (pro Person oder gesamt noch offen).

**Programm:** Teil 1, 20:00 bis 20:45: Herz-Intelligenz (Gesundheit, Beziehungen, Finanzen, Partner). Pause 20:45 bis 20:55 (abgeleitet). Teil 2, 20:55 bis 21:30: KI in der Praxis und was Herz-Intelligenz und KI verbindet; Live-Demo: Erstellung von KI-Agents, Anbindung an Ninox (KI-native Low-Code-Plattform).

**Dateien:** Der Projektordner `07_ninox_live_2026-11-27` (Webseite, Druckvorlagen, `flyer-bauen.ps1`, Texte) wurde von Norbert am 02.11.2026 bewusst gelöscht und existiert nicht mehr. Materialien müssten neu gebaut werden.

**Offen:** Empfänger der Anmeldungen (js\anmeldung.js `EMPFAENGER`/`ENDPOINT` leer), Datenschutz-Abdeckung und Impressum vom Management, QR-Codes mit dem Handy scannen, Genehmigung durch die Geschäftsführung, Veröffentlichung nur nach Ja von Norbert, alte `faltflyer_de.pdf` löschen (nur mit Freigabe).

**Why:** Norbert plant die Veranstaltung selbst und will Ninox vor Ort bekannter machen. **How to apply:** Neue Veranstaltungen nach demselben Aufbau; Vorlagen und Skripte wiederverwenden.