---
name: project_berichte
description: Ablage und Verlauf der Prüfberichte, umgesetzte Empfehlungen
metadata:
  type: project
---

Berichte: 04_Mitarbeiter\claudia_berichte\ (bisher 27.10., 29.10., 01.11., 04.11., 05.11.2026). Neuester: 2026-11-05_1000_pruefung-gesamt.md (Ottos Schema JJJJ-MM-TT_HHMM_name; claudia.md/README nennen noch Pruefung_<Datum>.md, Anpassung offen).

Am 01.11.2026 hat Norbert alle Empfehlungen freigegeben (settings.json, tools/disallowedTools, Widersprüche). Bis 05.11. umgesetzt: disallowedTools bei Olga/Leonardo/Nicoletta, Bootstrap lokal, Haupt-Memory Ninox Live korrigiert.

Offen am 05.11.: Apps-Script-Adresse in 09_Ablage\uebertragung\...\info-anmeldung.js Z. 6 klären (K1); settings.local.json verweist auf alten Ordner NOBBIS_SUPER_FIRMA (zwei Arbeitsordner, Memory getrennt); Otto ohne tools-Zeile; Hook für Schreibschutz Kundendateien.
