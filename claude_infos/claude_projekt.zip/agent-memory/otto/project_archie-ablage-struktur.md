---
name: archie-ablage-struktur
description: Ablageregel für Archies Ergebnisse (Kundenberichte Ninox 3/4) unter 04_Mitarbeiter\archie_berichte, Dateinamen-Ausnahme (Kunde vorn, Datum hinten), Prüfpunkte, Stand 2026-11-04
metadata:
  type: project
---

Archies Ergebnisse liegen in `04_Mitarbeiter\archie_berichte\` (nicht in `02_Erstellte_Apps\06_ninox4_architektur`).

**Struktur:** `berichte\<kunde>\ninox3\` und `\ninox4\` (strikt getrennt), je Produkt nur Versanddateien. `berichte\<kunde>\ersetzt\<grund>\` für Ersetztes (nie löschen; Archiv behält alte Namen, z. B. `ersetzt\alte-dateinamen\ninox4\`, `ersetzt\vor-lauf-<Uhrzeit>\`). Daneben `vorlagen\`, `werkzeuge\kundenbericht-bauen.ps1`, `pruefwerkzeug\pdfansicht.html`, `README.md`. Kundenordner ohne Datum, Firmen-Kurzname klein mit Bindestrichen. Nur PDF, .eml und .url in den Ergebnisordnern, keine HTML/md-Mailtexte.

**Dateinamen (Ausnahme vom Timestamp-Schema, Norbert 2026-11-04, steht in CLAUDE.md und otto.md, kein Befund):**
- `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf`
- `<kunde>_mailtext-ninox<N>_<JJJJ-MM-TT>.eml`
- `<kunde>_mailtext-ninox<N>-outlook-web_<JJJJ-MM-TT>.url`
- Beispiel: `kuchlbauer_systemarchitektur-ninox4_en_2026-11-04.pdf`. Kunde vorn, Datum hinten, keine Uhrzeit, kein Timestamp vorn.

**Neutrale Dokumente (ohne Kundenbezug, Norbert 2026-11-04, steht in CLAUDE.md und otto.md, kein Befund):** Ordner `berichte\neutral\ninox4\` (später auch `ninox3\`), Dateinamen ohne Kundenvorsatz: `systemarchitektur-ninox4_<de|en>_<JJJJ-MM-TT>.pdf`, `mailtext-ninox4_<JJJJ-MM-TT>.eml`, `mailtext-ninox4-outlook-web_<JJJJ-MM-TT>.url`. Ordner `neutral` ist erlaubt (wie ein Kundenordner behandeln, Trennung ninox3/ninox4 gilt); Namen ohne Kundenvorsatz nur dort, sonst Befund. Alte `neutral_`-Namen liegen unter `berichte\neutral\ersetzt\alte-dateinamen\ninox4\` (ersetzt, kein Befund).

**Why:** Norbert: Ergebnisse gehören zum Mitarbeiter Archie, Ninox 3 und 4 immer getrennt, Kundenname erkennbar, skalierbar; Namen kundenorientiert für den Versand.
**How to apply:** Prüfung (lesend): Trennung (kein `ninox4` im Namen unter `ninox3\` und umgekehrt), Namen nach dem neuen Schema, Vollständigkeit je Satz (2 PDF + .eml + .url), `@`/Personenname im Pfad, lose Dateien in `archie_berichte\` oder `berichte\`, leere Ordner. Alte Namen (`JJJJ-MM-TT_HHMM_...`) nur außerhalb von `ersetzt\` als Befund melden. Bei gleichem Datum verschiebt das Bau-Skript Vorhandenes nach `ersetzt\vor-lauf-<Uhrzeit>\`. DSGVO: Firmenname ja, nie Personennamen/E-Mail/Kundennummern; `.eml` enthalten PDF-Anhänge, nur intern ablegen. Das Quiz `Desktop\kuchlbauer-quiz` ist ein anderes Projekt und bleibt unberührt.
