---
name: demo-testordner-ausnahme
description: 09_Demo_Testordner ist dauerhaft von Ordnerprüfung (9:00/15:00) und Namensschema-Kontrolle ausgenommen
metadata:
  type: feedback
---

`09_Demo_Testordner` (NORBERT_CLAUDE\09_Demo_Testordner) nie prüfen, nie melden, keine Aufräum- oder Umbenennungsvorschläge.

**Why:** Der Ordner ist bewusst unordentlich, Demo für "Claude bringt Ordnung". Freigabe von Norbert am 05.11.2026.

**How to apply:** Bei jeder Ordnerprüfung (auch der geplanten Aufgabe otto-ordner-pruefung) und jeder Namensschema-Kontrolle diesen Ordner überspringen. Auch in Duplikat-Vergleichen nicht als Quelle oder Ziel zählen. Nur auf ausdrücklichen Auftrag von Norbert anfassen.
