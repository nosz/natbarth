# 04_Mitarbeiter

**Wofür:** Alles, was die Mitarbeiter (Agenten) als Ergebnis ablegen. Je Mitarbeiter ein Unterordner.

| Unterordner | Inhalt |
|---|---|
| otto_berichte | Berichte und Pläne von Otto zu Ordnern und Dateinamen |
| claudia_berichte | Prüfberichte von Claudia (Pruefung_JJJJ-MM-TT.md) |
| archie_berichte | Ergebnisse von Archie (IT-Architektur): `berichte\<kunde>\ninox3\` und `\ninox4\` (strikt getrennt; PDF Deutsch und Englisch und Outlook-Entwurf .eml), dazu `vorlagen\`, `werkzeuge\` (Bau-Skript), `pruefwerkzeug\`. Details in `archie_berichte\README.md` |

Hinweis: Sarahs Erinnerungen liegen in 05_Sarah_Erinnerungen, weil dort viele Seiten und Skripte fest darauf zeigen.
