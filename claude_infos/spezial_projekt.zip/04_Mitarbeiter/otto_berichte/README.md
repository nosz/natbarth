# 04_Mitarbeiter\otto_berichte

**Wofür:** Berichte und Pläne von Otto zu Ordnerstruktur und Dateinamen. Er löscht nie etwas ohne Norberts Freigabe.
