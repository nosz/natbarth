# Otto – Plan: übersichtliche Ordnerstruktur

Stand: 2026-11-04 04:10. Nur Planung und lesende Analyse. Nichts verschoben, umbenannt oder gelöscht. `02_Erstellte_Apps\kuchlbauer` unangetastet. `10_webseite` ist laut Norbert gelöscht und wird nicht mehr betrachtet.

## 1. Ist-Zustand

| Ordner | Zweck | Dateien / Ordner / MB | Auffälligkeiten |
|---|---|---|---|
| `.claude` | Agenten, Wissen, Agent-Memory, Server (`serve.ps1`, `launch.json`), Einstellungen | 37 / 14 / 0,1 | 6 leere Memory-Ordner (`arnold`, `garry`, `niko`, `otto`, `sarah`, `willi`); `niko` ist verwaist (Agent heißt `niklas`); `launch.json` ok (`firma` zeigt auf `.claude\serve.ps1`); `settings.local.json` enthält nur eine leere Allow-Liste |
| `00_Aktuell` | Ablage für lose Arbeitsstände (Prompts, Stellenbeschreibung, To-do-Import) | 5 / 0 | Gemischt, nichts davon steht in Skripten; 3 Dateien ohne Timestamp-Format |
| `01_Praesentationen` | Präsentationen (lokal, nicht veröffentlicht) | 1 / 0 | Dateiname ohne Timestamp-Format; Firmenname wirkt wie Platzhalter |
| `02_Erstellte_Apps` | Alle Apps, Standard-Werkzeuge (`_standard`), Kuchlbauer | 77 / 16 / 4,6 | Apps `01`–`06`, `_standard` (19 Dateien), `kuchlbauer` (39 Dateien, gesperrt); Nummern `07`–`10` fehlen seit 11-01 (bewusst entfernt?); `01_mitarbeiter_organigramm` enthält nur `README.md` (Organigramm liegt als `firma.htm` in der Wurzel) |
| `03_Tagesberichte` | Tagesberichte-Seite | 1 / 0 | Nur `tagesberichte.html` (fester Name) |
| `04_Otto_Berichte` | Berichte von Otto | 1 / 0 (jetzt 2 mit diesem Plan) | Fester Name `ordner-pruefung_aktuell.md` |
| `05_Sarah_Erinnerungen` | Sarahs Übersichtsseite, Erinnerungs-Archiv | 3 / 0 | `erinnerungen.md` ist nur noch Archiv (Liste liegt in `08_Todos`) |
| `05_Uebertragung` | Übergabepaket Veranstaltungsseite (GitHub-Update) | 10 / 2 / 0,6 | **Doppelte Nummer 05.** Laut Bericht überholt (Seiten der gelöschten `10_webseite` waren neuer) und jetzt ohne Gegenstück; Löschkandidat |
| `06_sicherungen` | Sicherungen vor Änderungen | 9 / 1 / 0,2 | Lose Dateien und ein Unterordner gemischt; `sicherung_begehungsbericht_…json` ohne App-Bezug, Inhalt nicht geprüft (eventuell Kundendaten, DSGVO) |
| `07_NINOX3_SKILL` | Arbeitskopie der Skills `ninox3` und `ninox3-zu-ninox4-migration` | 55 / 11 | Großbuchstaben im Ordnernamen (Regel: Kleinschreibung) |
| `08_Todos` | Zentrale To-do-Liste (`todos.json` einzige Wahrheit, Skript, Spiegel) | 4 / 1 | `sicherung\` leer, wird von `todos.ps1` genutzt (behalten) |
| `09_Tests` | Tests für Webseite (`seitentest.js`, Apps-Script) | 4 / 2 | Gehört zur gelöschten `10_webseite`; `test-bestaetigung.js` lädt Pfad `/10_webseite/apps-script/…` (läuft ins Leere); Sinn des Ordners klären |
| `Claudia_Berichte` | Claudias Prüfberichte | 5 / 0 | Keine Nummer; Dateinamen `Pruefung_JJJJ-MM-TT.md` (Großschreibung, Datum hinten) |
| `CLAUDE.md`, `firma.htm` | Regeln, Organigramm-Startseite | – | Müssen in der Wurzel bleiben (feste Namen) |

Leer: 7 Ordner (6 in `.claude\agent-memory`, `08_Todos\sicherung`). Duplikate und Testdateien: außer den bekannten Sicherungs-Duplikaten nichts Neues. Einzelheiten und Größen stehen in `ordner-pruefung_aktuell.md`.

## 2. Abhängigkeiten (was bricht beim Umbenennen oder Verschieben)

Gezählt: Textdateien im Arbeitsordner (ohne `kuchlbauer`, Berichte, Sicherungen, gebündeltes Bootstrap) plus Memory-Dateien; Treffer = Fundstellen des Ordnernamens. Die Zahlen sind Näherungen (Textsuche), keine Garantie auf Vollständigkeit; vor einem Umbau mache ich die Suche erneut.

| Ordner | Treffer / Dateien | Wo (wichtigste Stellen) | Bruchrisiko |
|---|---|---|---|
| `02_Erstellte_Apps` | ca. 292 / 27 (+ Agenten, Memory) | `firma.htm` (Navi, Suche, Texte), `seite-standard.ps1` (56 in `_standard`-Skripten), `pruefung.ps1` (Seitenliste, Ausschlüsse), `pruefung.js` (Seiten-URLs), `suchindex-erstellen.ps1`, `suche-global.js`, `STANDARD.md`, `TESTS.md`, `CLAUDE.md`, `.claude\settings.json` (**deny-Regel für `kuchlbauer`**), 6 Agenten (`nobbi`, `olga`, `otto`, `sarah`, `seb`, `willi`), 2 Skills außerhalb (`demo-app-bauen`, `trainer-app-bauen`), 5 Memory-Dateien, alle App-READMEs | sehr hoch; Kuchlbauer-Schutz (Prüfsummen, deny-Regel) hängt am Pfad |
| `03_Tagesberichte` | ca. 42 / 14 | `firma.htm`, alle Seiten-Navigation (jede Seite hat den Link über `seite-standard.ps1`), `pruefung.ps1/js`, `suchindex-erstellen.ps1` (liest die Seite), `STANDARD.md`, tägliche Tagesabschluss-Erzeugung (Memory `tagesabschluss-tschuess`) | hoch |
| `05_Sarah_Erinnerungen` | ca. 38 / 13 | `firma.htm`, `pruefung.js`/`.ps1`, `suchindex-erstellen.ps1`, `sarah.md`, `STANDARD.md`, `04_favoriten`, Nobbi-Memory | hoch |
| `08_Todos` | ca. 102 / 29 | **Jede Seite** bindet `08_Todos/todos.js` per Script-Tag ein (Spiegel); `zaehler.js`, `pruefung.ps1` (Dateiliste, `todos.ps1 -Pruefen`), `sarah.md`, **geplante Aufgabe `sarah-morgenuebersicht`** (Aufruf `.\08_Todos\todos.ps1`), alle App-READMEs und -Seiten | sehr hoch (Sarahs Aufgabe läuft werktags um 8:10 Uhr) |
| `04_Otto_Berichte` | 5 / 4 | `firma.htm` (Text), `otto.md`, `pruefung.ps1` (Ausschlussliste), `suchindex.js` | niedrig–mittel |
| `Claudia_Berichte` | 2 / 2 + Task | `claudia.md`, Claudia-Memory, **geplante Aufgabe `claudia-best-practice-pruefung`** (Schreibpfad und Dateiname im Prompt) | niedrig |
| `06_sicherungen` | 6 / 3 | `pruefung.ps1` (Alias-Prüfung und Ausschlussliste), `STANDARD.md`, `05_Sarah…\README.md` | niedrig |
| `07_NINOX3_SKILL` | 5 / 3 | `ben-und-uwe.md`, dessen Memory, `seb-quellen.md`, `pruefung.ps1` (Ausschluss) | niedrig |
| `09_Tests` | 2 / 1 | `seitentest.js` (intern), Memory `webseiten-breitenmatrix-testen` | niedrig |
| `00_Aktuell` | 2 / 2 | `pruefung.ps1` (Ausschluss), `08_Todos\README.md` (Beispiel), `…Agentic_System…txt` | niedrig |
| `01_Praesentationen` | 2 / 1 + 3 Memory | Memory `praesentationen-ordner`, `praesentationen-im-explorer-oeffnen`; `pruefung.ps1` prüft die Präsentation über die Sicherung | niedrig |
| `05_Uebertragung` | 0 funktional | nur Berichte | keine |

Weitere harte Stellen, die nicht am Ordnernamen hängen:
- `.claude\launch.json`: absoluter Pfad zum **Wurzelordner** `NOBBIS_SUPER_FIRMA` und zu `.claude\serve.ps1`. Bleibt unberührt, solange die Wurzel und `.claude` ihren Namen behalten.
- `pruefung.ps1` Zeile 108: prüft den festen Sicherungsordner `C:\Users\NorbertSzpak\NOBBIS_SICHERUNG_20261028` (veraltet, sollte auf den aktuellen Sicherungsordner zeigen). Zeile 91: Ausschlussliste nennt `08_herzintelligenz` (gibt es nicht mehr, kein Schaden).
- Relative Pfade (`../../08_Todos/todos.js`, `../../_standard/…`): jede Tiefenänderung eines Ordners (z. B. `03_Tagesberichte` nach `03_Berichte\tagesberichte`) bricht Links, Script-Tags und `Rel`-Berechnung in `seite-standard.ps1`.
- Service Worker und App-Versionen: `03_todo` hat `sw.js`; nach Pfadänderungen neue Versionsnummer in `index.html`, `sw.js`, README (Memory-Regel „Neue Version bei Änderung“).
- `suchindex.js` muss nach jeder Änderung neu erzeugt werden (`suchindex-erstellen.ps1`), sonst meldet `pruefung.ps1` einen Fehler.
- Geplante Aufgaben liegen außerhalb des Arbeitsordners (`C:\Users\NorbertSzpak\.claude\scheduled-tasks\…`): `sarah-morgenuebersicht` (`08_Todos`), `claudia-best-practice-pruefung` (`Claudia_Berichte`, Dateiname), `otto-ordner-pruefung` (nur Wurzelpfad). Änderungen dort brauchen Norberts Ja.
- Memory-Dateien (11 mit Ordnernamen) liegen unter `C:\Users\NorbertSzpak\.claude\projects\…\memory` und müssten mitgezogen werden.
- OneDrive: Umbenennungen synchronisieren als Löschen + Neuanlegen; Sicherung vorher außerhalb OneDrive.

## 3. Vorschlag

### Gemeinsame Regeln (beide Varianten)
- Jeder Top-Ordner bekommt eine kurze `README.md` „Wofür ist dieser Ordner“ (4–8 Zeilen: Zweck, wer schreibt hinein, feste Dateinamen und warum, was nicht hierher gehört). `README.md` ist Ausnahme vom Timestamp.
- Neue Dateien: `JJJJ-MM-TT_HHMM_beschreibender-name.endung`; Ordner ohne Timestamp, klein, Bindestrich, keine Umlaute.
- Feste Namen bleiben (Ausnahmeliste in `otto.md`): `index.html`, `README.md`, `sw.js`, `manifest.webmanifest`, `icons\`, `firma.htm`, `launch.json`, `tagesberichte.html`, `sarah-uebersicht.html`, `todos.json/js/ps1`, `erinnerungen.md`, `ordner-pruefung_aktuell.md`. Vorschlag: diese Liste in `otto.md` und `CLAUDE.md` um die fehlenden Namen ergänzen.
- Dateien in den Ordnern, die bisher nicht dem Muster folgen, nur mit deinem Ja umbenennen: `00_Aktuell\de_agents_prompt.txt`, `en_agents_prompt.txt`, `Agentic_System_Vorteile_und_Demo_Prompts_2026-10-27.txt`, `01_Praesentationen\Mustermann_GmbH_…html`, `Claudia_Berichte\Pruefung_*.md` (5), die zwei PDFs in `06_ninox4_architektur`.

### Variante A – nur sicher
Idee: Alle fest verdrahteten Ordner (`02_Erstellte_Apps`, `03_Tagesberichte`, `04_Otto_Berichte`, `05_Sarah_Erinnerungen`, `08_Todos`) behalten Namen und Platz.

| Schritt | Änderung | Betroffene Stellen |
|---|---|---|
| A1 | Doppelnummer: `05_Uebertragung` löschen (nach Ja, Paket überholt) oder, falls behalten, in `10_uebertragung` umbenennen | 0 funktional |
| A2 | `Claudia_Berichte` → `10_claudia_berichte` (Nummer, Kleinschreibung) | `claudia.md`, Claudia-Memory, geplante Aufgabe `claudia-best-practice-pruefung` (Pfad), Otto-Bericht |
| A3 | `README.md` in jedem Top-Ordner (13 Stück; bei `05_Sarah…` und `08_Todos` vorhanden, nur prüfen) | keine (neue Dateien) |
| A4 | Innen aufräumen: `00_Aktuell` in `agenten-prompts\`, `stellenbeschreibungen\`, `todo-import\` gliedern; `06_sicherungen` nach `JJJJ-MM-TT_anlass\` gliedern (Sicherung `begehungsbericht` separat melden, Inhalt prüfen lassen); `09_Tests` klären (Pfadfehler `/10_webseite/` oder Ordner löschen); `.claude\agent-memory\niko` löschen (nur nach Ja); `settings.local.json` und `launch.json` bereinigen | `pruefung.ps1` Ausschlussliste (`06_sicherungen`, `00_Aktuell` bleiben als Namen) |
| A5 | Dateinamen nach Muster (nur die oben genannten, jede mit Ja) | siehe 2.; Claudia-Dateiname im Task-Prompt |
| A6 | `pruefung.ps1` Zeile 108 auf aktuellen Sicherungsordner umstellen; Ausnahmeliste in `otto.md`/`CLAUDE.md` ergänzen | 2 Dateien |

Aufwand: ca. 1–2 Stunden. Risiko: niedrig (A2 ist die einzige Änderung mit externem Bezug, geplante Aufgabe). Tests: Sicherung außerhalb OneDrive vor dem Start; danach `pruefung.ps1` (0 Fehler) und Suchindex neu, dann `pruefung.js` über `http://localhost:8100` (nur nötig, wenn Seiten oder Skripte angefasst wurden, d. h. bei A6/A4-Skriptänderung; sonst genügt `pruefung.ps1` plus Kuchlbauer-Prüfsumme 0 Abweichungen).
Ergebnis: Doppelnummer weg, nichts ohne Nummer, jeder Ordner erklärt, innen sortiert. Grenze: Ordnernamen wie `05_Sarah_Erinnerungen`/`08_Todos` und die Lücke in der Nummerierung (06, 07, 09 stehen thematisch durcheinander) bleiben.

### Variante B – voller Umbau
Zielstruktur (thematisch gruppiert, lückenlos, keine Doppelnummer):

```
NOBBIS_SUPER_FIRMA\
  CLAUDE.md, firma.htm            (bleiben in der Wurzel)
  .claude\                        (bleibt)
  00_eingang\                     (war 00_Aktuell, gegliedert nach Thema)
  01_praesentationen\
  02_apps\                        (war 02_Erstellte_Apps)   <- siehe Warnung
      01_..06_..\, _standard\, kuchlbauer\
  03_berichte\
      tagesberichte\              (war 03_Tagesberichte)
      otto\                       (war 04_Otto_Berichte)
      claudia\                    (war Claudia_Berichte)
  04_todos\
      zentrale-liste\             (war 08_Todos)
      sarah\                      (war 05_Sarah_Erinnerungen)
  05_skills\                      (war 07_NINOX3_SKILL)
  06_tests\                       (war 09_Tests)
  07_sicherungen\                 (war 06_sicherungen)
```
`05_Uebertragung` entfällt (Löschen nach Ja).

Warnung zu `02_Erstellte_Apps` → `02_apps`: Kuchlbauer liegt darin. Das Umbenennen des Elternordners ändert Kuchlbauers Pfad (deny-Regel in `settings.json`, `kuchlbauer.sha256`, Prüfung in `pruefung.ps1`, drei Skill-/Regeltexte). Nach deiner Regel nur mit ausdrücklichem Ja für genau diese Änderung. Mein Rat: `02_Erstellte_Apps` auch in B behalten; der Name sagt bereits klar, was drin ist, und der Nutzen ist klein gegenüber ca. 290 Treffern.

Nötige Anpassungen in B (zusätzlich zu A): alle in Abschnitt 2 genannten Stellen, besonders
1. `seite-standard.ps1`: Navigationsziele und `Rel`-Berechnung (Tiefe), danach alle Seiten neu erzeugen (Tagesberichte, Sarah-Übersicht, Apps, `firma.htm`).
2. Script-Tag `08_Todos/todos.js` in jeder Seite (Pfad und Tiefe ändern), `zaehler.js`, `todos.ps1`-Aufrufe in `sarah.md`, Sarah-Task, README-Texte.
3. `pruefung.ps1` (Regex Zeile 12/13/50–57/91, Seitenliste), `pruefung.js` (SEITEN-URLs, Titeltabelle, Suchseiten, Formseiten), `suchindex-erstellen.ps1` (7 feste Pfade), `suche-global.js`, Index neu erzeugen.
4. `CLAUDE.md`, `STANDARD.md`, `TESTS.md`, 8 Agenten-Dateien, 3 geplante Aufgaben (Sarah, Claudia, Otto-Hinweise), 11 Memory-Dateien, 2 Skills außerhalb, `settings.json`.
5. Neue Versionsnummern der betroffenen Apps (`index.html`, `sw.js`, README), Service-Worker-Cache neu.
6. Memory- und Suchtext: Tagesabschluss („zeig Präsentationen“ etc.).

Aufwand: ca. 1 Arbeitstag mit Tests. Risiko: hoch (Sarahs Morgenübersicht läuft werktags 8:10 Uhr und liest `08_Todos\todos.ps1`; ein Pfadfehler fällt erst beim Lauf auf; Kuchlbauer; OneDrive-Sync). Tests: Sicherung außerhalb OneDrive vor dem Start; schrittweise (ein Ordner pro Runde, nach jeder Runde `pruefung.ps1` mit 0 Fehlern und `suchindex-erstellen.ps1`); am Ende vollständige Browserprüfung `pruefung.js` über `http://localhost:8100` (Deutsch und Englisch, alle Links 200, Konsole ohne Fehler); Testlauf `todos.ps1 -Aktion Liste` und der Sarah-Task manuell; Kuchlbauer: 39 Prüfsummen, 0 Abweichungen (bei Pfadwechsel des Elternordners nur mit Freigabe und angepasstem `kuchlbauer.sha256`-Pfad).
Empfohlen als Zwischenform: B light, nur Ordner mit niedrigem Risiko umbenennen (`00_Aktuell`, `06_sicherungen`, `07_NINOX3_SKILL`, `09_Tests`, `Claudia_Berichte`, `05_Uebertragung`) und die fünf fest verdrahteten Ordner lassen.

## 4. Empfehlung
Zuerst Variante A. Sie löst die Doppelnummer und die unnummerierten Berichte, liefert die READMEs und die innere Ordnung, und ändert nur eine geplante Aufgabe. Danach kann B light (nur niedrige Risiken) folgen. Voll-B nur, wenn der Gewinn die ca. 290 Pfadänderungen und das Risiko für Sarahs Morgenlauf rechtfertigt.

Offene Löschkandidaten (nur nach Ja, jeweils mit Pfad, Grund, Größe, Datum): `05_Uebertragung\github-update-info-veranstaltung-20261030\` (überholt, 0,6 MB, 2026-10-30), `.claude\agent-memory\niko\` (leer, 2026-10-26).
