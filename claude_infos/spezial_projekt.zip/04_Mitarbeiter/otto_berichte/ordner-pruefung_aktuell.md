﻿# Otto – Ordnerprüfung

Lauf: 2026-11-05 21:18 (geplanter Lauf, nur lesend; der 15:00-Lauf ist nach meinem Wissen nicht erfolgt, Vergleich daher mit dem Bericht von 09:27)

## Kurzfassung
- Geprüft: rekursiv, 275 Dateien in 100 Ordnern (vorher 241 / 95). `.git`/`node_modules` nicht vorhanden. `09_Demo_Testordner\` ist auf Anweisung von Norbert (05.11.2026) ausgenommen und nicht geprüft.
- **Weiter offen und wichtigster Punkt:** `09_Ablage\` ist seit 2026-11-05 05:21 leer. Verbleib der früheren Inhalte (`sicherungen\`, `tests\`, `uebertragung\`) ungeklärt; Root-`README.md` und `05_Sarah_Erinnerungen\README.md` verweisen weiter darauf.
- **Neu:** Projektordner `10_Ninox_Projekte\kindercoaching\` (Ninox-4-App per API). Namen nach Schema, Struktur klar. Hinweise: Ordner `uebergabe_it\` steht nicht in der README, `notizen\` ist leer, Timestamps der IT-Fehlerprotokolle liegen vor der echten Erstellungszeit, 22 Modul-Sicherungen in zwei Stunden (1,14 MB, wächst weiter).
- Leere Ordner: 11 (vorher 10; neu `kindercoaching\notizen\`, gewollt). `*.tmp`, `*.bak`, `*.old` und 0-Byte-Dateien: keine. Echte Hash-Duplikate außerhalb von `ersetzt\` und Demo-Material: keine.
- Löschkandidaten (nur nach Ja, unverändert): `.claude\hooks\`, `01_Praesentationen\.claude\` (leeres, falsch abgelegtes Memory), zwei leere `ersetzt\alte-dateinamen\ninox4\` bei Archie (Kuchlbauer, MKW).
- Nicht prüfbar: Dateiinhalte (geprüft wurden Hash, Name, Datum, Größe; bei `ninox.config.json` nur die Feldnamen: `apiBase`, `workspaceId`, `workspaceName`, `moduleName`, kein Key-Feld), Verbleib der Inhalte von `09_Ablage`, OneDrive-Papierkorb, alles außerhalb des Arbeitsordners.

## Änderungen seit dem letzten Bericht (2026-11-05 09:27)
- **Neu:** `10_Ninox_Projekte\` mit `README.md` (Struktur laut README von mir festgelegt, 11:24) und `kindercoaching\`: `ninox.config.json`, `sicherungen\` (22 JSON, 11:23–13:20), `uebergabe_it\` (5 Fehlerprotokolle DE+EN und 1 Begleittext, 12:35–13:25), `notizen\` (leer).
- **Neu:** `04_Mitarbeiter\claudia_berichte\Pruefung_2026-11-05_0930.md` (09:30). Damit 7 Dateien im alten Schema, jetzt sogar in zwei Varianten (`Pruefung_JJJJ-MM-TT.md` und `Pruefung_JJJJ-MM-TT_HHMM.md`).
- **Geändert:** `.claude\launch.json` (12:38), `.claude\settings.local.json` (12:40).
- **Neu in der Liste „über 30 Tage unverändert“:** 27 Dateien in `07_NINOX3_SKILL\ninox3-zu-ninox4-migration\` (Stand 2026-10-06, heute 30 Tage). Skill-Bestand, kein Befund.
- Unverändert offen: alle übrigen Befunde aus der Tabelle.

## Befunde
| Pfad | Befund | Grund | Größe | letzte Änderung | Empfehlung |
|---|---|---|---|---|---|
| `09_Ablage\` | **Leer, Inhalt verschwunden** | Bis 04.11. `sicherungen\`, `tests\`, `uebertragung\`. Root-`README.md` (Z. 22) und `05_Sarah_Erinnerungen\README.md` (Z. 52) verweisen weiter darauf; `pruefung.ps1` schließt den Ordner aus. | 0 | 2026-11-05 05:21 | Klären, ob gewollt und wo die Inhalte liegen. Ordner **nicht** löschen, bis geklärt. READMEs danach anpassen. |
| `10_Ninox_Projekte\kindercoaching\uebergabe_it\` | **Neu**, Struktur weicht von README ab | `10_Ninox_Projekte\README.md` nennt nur `ninox.config.json`, `sicherungen\`, `notizen\` | ca. 45 KB, 11 Dateien | 2026-11-05 13:25 | Behalten; README um `uebergabe_it\` (Fehlerprotokolle DE+EN, Begleittext an IT) ergänzen. |
| `10_Ninox_Projekte\kindercoaching\uebergabe_it\2026-11-05_1145_…`, `_1150_…`, `_1152_…`, `_1200_…` | **Neu**, Timestamp nicht real | Uhrzeit im Namen (11:45–12:00) liegt vor der echten Erstellung (12:35–13:25); vermutlich Zeitpunkt des Fehlers statt der Datei | ca. 34 KB, 9 Dateien | 2026-11-05 12:35–13:25 | Nur Hinweis. Wenn bewusst Fehlerzeitpunkt: so in README festhalten. |
| `10_Ninox_Projekte\kindercoaching\sicherungen\` | **Neu**, schnell wachsend | 22 vollständige Moduldefinitionen in rund zwei Stunden; keine Hash-Duplikate (auch `_1258_` und `_1259_…vor-optionsfarben` unterscheiden sich) | 1,14 MB | 2026-11-05 13:20 | Behalten, solange das Projekt läuft. Danach Aufbewahrungsregel festlegen (z. B. letzte 5 plus Meilensteine, Rest nach `ersetzt\`). |
| `10_Ninox_Projekte\kindercoaching\notizen\` | **Neu**, leerer Ordner | Laut README vorgesehen, noch ungenutzt | 0 | 2026-11-05 11:24 | Behalten. |
| `01_Praesentationen\.claude\agent-memory\otto\` | Leerer Ordner, falscher Ort | Agent-Memory gehört nach `.claude\agent-memory\` in der Wurzel | 0 | 2026-11-05 04:42 | `01_Praesentationen\.claude\` komplett löschen (nur nach Ja). |
| `.claude\hooks\` | Leerer Ordner | Kein Hook eingerichtet | 0 | 2026-11-04 05:44 | Löschen (nur nach Ja), falls kein Hook geplant ist (Claudia schlägt einen Schreibschutz-Hook vor). |
| `04_Mitarbeiter\archie_berichte\berichte\kuchlbauer\ersetzt\alte-dateinamen\ninox4\` | Leerer Ordner | Kette ohne Inhalt | 0 | 2026-11-04 06:19 | Löschen inkl. leerer Elternordner bis `ersetzt\` (nur nach Ja). |
| `04_Mitarbeiter\archie_berichte\berichte\mkw-steuerberatung\ersetzt\alte-dateinamen\ninox4\` | Leerer Ordner | wie oben | 0 | 2026-11-04 06:19 | Löschen inkl. leerer Elternordner bis `ersetzt\` (nur nach Ja). |
| `04_Mitarbeiter\archie_berichte\berichte\neutral\ersetzt\alte-dateinamen\ninox4\` (4 Dateien) | Archiv / Fast-Duplikat | `.url` hash-gleich mit `neutral\ninox4\mailtext-ninox4-outlook-web_2026-11-04.url` | ca. 1,4 MB | 2026-11-04 06:19 | Behalten (`ersetzt\` nie ohne Freigabe löschen). |
| `04_Mitarbeiter\claudia_berichte\Pruefung_*.md` (7 Dateien, davon 1 neu) | Uneinheitliche Namen, Regelkonflikt | Altes Schema `Pruefung_JJJJ-MM-TT.md`, neu auch `Pruefung_JJJJ-MM-TT_HHMM.md`; Claudias geplanter Auftrag und die README ihres Ordners geben es so vor. Manuelle Berichte heißen `JJJJ-MM-TT_HHMM_…` | 8–12 KB | 2026-10-27 bis 11-05 09:30 | Norbert entscheidet ein Schema; danach Claudias geplante Aufgabe und README anpassen, Altdateien umbenennen. |
| `claudia_berichte\2026-11-05_1000_…md`, `olga_berichte\…\2026-11-05_1200_…` | Timestamp nicht real | Uhrzeit im Namen liegt nach der tatsächlichen Erstellung (05:17 bzw. 08:27) | – | 2026-11-05 | Nur Hinweis: echte Uhrzeit verwenden. |
| `04_Mitarbeiter\archie_berichte\vorlagen\ersetzt-kombiniert\` | Ordnername weicht ab | Die Regel sieht `ersetzt\` vor | ca. 75 KB, 2 Dateien | 2026-11-04 05:05 | Umbenennung in `vorlagen\ersetzt\kombiniert\` vorschlagen. |
| `04_Mitarbeiter\archie_berichte\berichte\kuchlbauer\ninox3\` | Fehlt | README sieht `<kunde>\ninox3\` vor | – | – | Mit Archie klären, ob gewollt. |
| `01_Praesentationen\claude-code-vorteile\demo-materialien\01_aufraeumen\vorher\` | Hash-Duplikat und Kopie-Namen (absichtlich) | `todo neu.txt` = `Kopie von todo neu.txt`; `(1)`, `Kopie von`, `(alt)` sind Demo-Material | ca. 1,5 KB, 14 Dateien | 2026-11-05 04:38 | Kein Befund, behalten. |
| `01_Praesentationen\Mustermann_GmbH_Ninox_Praesentation_2026-10-27.html` | Namensformat weicht ab | Großschreibung, Datum hinten, kein `HHMM` | 4 KB | 2026-10-28 | Umbenennung vorschlagen. |
| `00_Aktuell\agenten-prompts\de_agents_prompt.txt`, `en_agents_prompt.txt`, `Agentic_System_Vorteile_…_2026-10-27.txt` | Ohne Timestamp / Format weicht ab | Kein Präfix `JJJJ-MM-TT_HHMM_` | 4,6–33,7 KB | 2026-11-04 10:07 | Umbenennung vorschlagen. |
| `02_Erstellte_Apps\06_ninox4_architektur\2026-10-28_ninox4-architektur_DE.pdf` / `_EN.pdf` | Namensformat weicht ab | Ohne Uhrzeit, Großbuchstaben | je ca. 0,58 MB | 2026-10-28 | Nur Hinweis. |
| `02_Erstellte_Apps\_standard\pruefung.ps1` (Z. 12) | Veralteter Verweis | Ausschlussliste nennt Ordner, die es nicht mehr gibt (`sauberer_neckar`, `09_visitenkarten`, `08_ki_training`, `08_herzintelligenz`) | 12 KB | 2026-11-05 08:36 | Nur Hinweis. Prüfen, ob `10_Ninox_Projekte` dort berücksichtigt werden soll (nicht geprüft). |
| `10_Ninox_Projekte\kindercoaching\ninox.config.json` | Ohne Timestamp | Fester Name, vom Skill `ninox4-api-builder` verwendet; enthält laut Feldnamen nur IDs | 145 B | 2026-11-05 11:24 | Kein Befund; als Ausnahme in `otto.md` aufnehmen. |
| `04_Mitarbeiter\olga_berichte\flyer\ninox4-schulung\quellen\assets\*.ttf` | Ohne Timestamp | Schriftdateien mit festen Namen, vom Bauskript verwendet | ca. 189 KB, 3 Dateien | 2026-11-05 08:24 | Kein Befund; als Ausnahme (`assets\`) in `otto.md` aufnehmen. |
| `02_Erstellte_Apps\_standard\*`, `03_Tagesberichte\tagesberichte.html`, `05_Sarah_Erinnerungen\*`, `08_Todos\todos.*`, `archie_berichte\vorlagen\*`, `werkzeuge\*`, `pruefwerkzeug\*`, `07_NINOX3_SKILL\*`, `.claude\agent-memory\*` | Ohne Timestamp | Feste Namen, die Skripte, Skills und Seiten verwenden | – | – | Nur Hinweis; als Ausnahme in `otto.md` aufnehmen. |
| `02_Erstellte_Apps\01_mitarbeiter_organigramm\` | Unklare Struktur | Nur `README.md`; das Organigramm liegt als `firma.htm` in der Wurzel | 6 KB | 2026-11-04 | Klären, ob so gewollt. |
| Wurzel: Nummer `06_` fehlt, `07_NINOX3_SKILL` in Großbuchstaben, `09_` doppelt vergeben (`09_Ablage`, `09_Demo_Testordner`) | Unklare Struktur | Lücke nach dem Umbau; Großbuchstaben und doppelte Nummer verstoßen gegen die Regel. `10_Ninox_Projekte` ist korrekt fortlaufend. | – | – | Nur Hinweis; bei Klärung von `09_Ablage` mit entscheiden. |
| Quiz-Projekt `kuchlbauer-quiz` | Verbleib unklar | Weder auf dem Desktop noch in `02_Erstellte_Apps` | – | – | Klären (außerhalb nicht geprüft). |
| `.claude\agent-memory\arnold`, `garry`, `sarah`, `willi` | Leere Ordner | Memory noch ungenutzt | 0 | 2026-10-27 bis 30 | Behalten. |
| `08_Todos\sicherung\` | Leerer Ordner | Ziel von `todos.ps1` | 0 | 2026-10-28 | Behalten. |

Nicht beanstandet: Archies Ninox-4-Sätze (Kuchlbauer, MKW, neutral) sind vollständig und nach Schema benannt. Die Präsentation `claude-code-vorteile` ist sauber strukturiert. Olgas Flyer-Ablage ist klar gegliedert. Die neuen Kindercoaching-Sicherungen und Fehlerprotokolle sind einheitlich nach `JJJJ-MM-TT_HHMM_…` benannt (Fehlerprotokolle DE und `_en` paarweise vollständig). Über 30 Tage unverändert sind nur Skill-Dateien in `07_NINOX3_SKILL\` (4 Swagger-Referenzen, 27 Dateien der Migration; behalten). Fehlalarme: `kopie-in-anderen-workspace.md` (Skill-Referenz) und `2026-11-05_0438_abbildung-alt-neu.csv` (Demo-Werkzeug).
