# 04_Mitarbeiter\claudia_berichte

**Wofür:** Prüfberichte von Claudia, ob mit Claude professionell gearbeitet wird.

Name: Pruefung_JJJJ-MM-TT.md. Die geplante Aufgabe claudia-best-practice-pruefung schreibt hier hinein.
