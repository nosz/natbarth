# Nachprüfung Seb, 04.11.2026 (Vergleich mit 2026-11-04_1200_pruefung-seb.md)

Nur lesend. Nichts an Seb-Dateien geändert, nichts gebaut, nichts gesendet, keine Zugangsdaten gelesen. Zeitstempel im Dateinamen nominal. Geprüft am Ist-Stand: seb.md, kundenbericht-bauen.ps1, Seb-Memory (7 Dateien), beide Kunden-READMEs, seb_berichte\README.md, mailtext-Vorlage Ninox 4, Struktur der .eml (Content-Type-Zeilen), Dateiliste seb_berichte, Suche nach alten Pfaden und Quiz-Verweisen. Neue Doku-Abrufe gab es in diesem Lauf nicht; die Quellen für Claude-Best-Practices stehen im ersten Bericht (code.claude.com sub-agents und best-practices, am 04.11.2026 abgerufen).

## Gesamturteil (Ampel gelb, leicht besser als rot-gelb)
Die .eml ist jetzt im Aufbau korrekt (mixed, alternative mit Text und HTML, zwei PDFs) und wird automatisch geprüft; das ist die größte echte Verbesserung. Die in meinem ersten Bericht kritisierten Widersprüche in seb.md, der veraltete Memory-Eintrag, die Skript-Themen für Kollegen und die Inhaltsbefunde sind unverändert offen. Neu und wichtig: Das Skript enthält zwei feste Personennamen im Prüfcode, die Entwurfsprüfung wird ohne CDO nur zur Warnung, und die Signaturannahme für Outlook ist ungeprüft.

## Prüfung der .eml-Logik
| Punkt | Ist-Stand | Bewertung |
|---|---|---|
| Aufbau | Alle drei vorhandenen Entwürfe (Struktur der Kuchlbauer-Ninox-3-Datei und früher der MKW-Datei gelesen) zeigen `multipart/mixed` > `multipart/alternative` (text/plain vor text/html) > zwei PDFs mit `Content-Disposition: attachment`. Reihenfolge ist richtig (HTML zuletzt = bevorzugt). | in Ordnung |
| Skript-Prüfung | CDO prüft Betreff (enthält "Ninox N" und Firma), Textlänge je mindestens 800 Zeichen, Textanker "anbei erhalten" und "please find attached", Anhangsnamen und -anzahl. Fehler führen per `throw` zum Abbruch. | gut, aber Lücken |
| Lücke 1 | Fängt CDO nicht (COMException), gibt das Skript nur "WARNUNG" aus und läuft weiter. seb.md sagt "bei jeder Abweichung bricht der Bau ab" und "nie fertig, wenn Entwurfsprüfung fehlt". Widerspruch. Ob CDO auf Norberts Rechner läuft, belegt nur der Lauf, den ich nicht sehe. | hoch, Skript auf Abbruch oder expliziten `-OhneCdo` umstellen |
| Lücke 2 | Prüft nicht, dass die Anhänge byte-gleich mit den PDFs sind (die READMEs behaupten das, das Skript prüft es nicht), nicht die Signaturzeilen und nicht, dass `To:` leer ist, wenn kein `-An` gesetzt wurde. | mittel |
| Lücke 3 | Personenbezug-Prüfung ist `Karner|Ashauer`: zwei feste Nachnamen (vermutlich Kundenkontakte) im Skript. Das ist selbst Personenbezug in einer Datei, deckt nur diese zwei Fälle ab und taugt für andere Kunden nicht. Nach Entfernen der Namen bleibt `<...>|{{` als Platzhalterprüfung. | hoch (DSGVO, Wartbarkeit) |
| Lücke 4 | Textanker sind fest im Skript. Ändert jemand den Mailtext, schlägt die Prüfung falsch an. | niedrig |
| Signaturannahme | "Outlook fügt die Signatur selbst an" ist eine Annahme. Bei geöffneten `.eml` mit `X-Unsent` ist nicht belegt, dass Outlook die Standardsignatur anhängt; ob es bei Norberts Kuchlbauer- und MKW-Entwurf geschah, weiß ich nicht. Ohne Signatur endet die Mail nach "Mit freundlichen Grüßen" ohne Namen. Auch die .url (Outlook im Web) ist ungeprüft. Die Entfernung per Regex gilt nur für exakt "Norbert Szpak" und "Ninox Software GmbH" (fester Name, siehe Nr. 14 im ersten Bericht). | hoch, Norbert fragen, ob Signatur erschien; sonst Name und Firma wieder in den Text |
| Outlook-Test | seb.md verlangt Öffnen in Outlook bei Aufbauänderung. Norbert hat laut Koordinator geöffnet; das Ergebnis (Text, Anhänge, Signatur) ist nirgends dokumentiert. Beide Kunden-READMEs sagen weiter "Das tatsächliche Öffnen in Outlook wurde nicht geprüft". | mittel, README aktualisieren |

## Übereinstimmung seb.md, Memory, Skript, README
| Thema | Befund |
|---|---|
| Ablage | Skript, seb_berichte\README.md, Memory (project_kundenbericht-pdf, feedback_ergebnisse…) und seb.md Punkt 5 stimmen überein (seb_berichte\berichte\<kunde>\ninox3\|ninox4\). Ausnahme: seb.md Z. 13, 29, 71 (siehe unten). |
| .url | Skript erzeugt sie, Norbert wünscht sie. seb.md (Punkt 4: "nur PDFs und .eml"), seb_berichte\README (Regeln und Tabelle), Memory und beide Kunden-READMEs erwähnen sie nicht. Regel und Ist-Stand weichen ab, die Regel muss angepasst werden ("PDFs, .eml und .url"). |
| Memory | `feedback_eml-immer-korrekt` und MEMORY.md-Eintrag sind neu und passen zu seb.md. `feedback_ninox3-ninox4-getrennt` enthält weiter den alten Pfad `kunden\<datum>_<kunde>\ninox4\` und "je mit eigenem HTML". `project_wissensstand` nennt weiter `02_Erstellte_Apps\06_ninox4_architektur`. |
| seb.md Punkt 6 | Verweist auf `pruefung.ps1` (Pflicht) und "Quell-Links 200"; das Skript prüft beides nicht und es betrifft Seiten in 02_Erstellte_Apps, nicht Kunden-PDFs. |
| seb.md Z. 67 | Formatfehler: die Regel "Berichte als Seiten immer mit seite-standard.ps1 … nach TESTS.md" und "Sprache: …" stehen in einer Zeile ("`TESTS.md`.- Sprache"). Zusätzlich steht die Seiten-Regel gegen "Ergebnisse nicht in 02_Erstellte_Apps". |
| Kunden-READMEs | Kuchlbauer-README Z. 33: "Der Ordner `02_Erstellte_Apps\kuchlbauer` (Kuchlbauer-Quiz) wurde nicht angefasst." Der Ordner existiert nicht mehr; Verwechslung Quiz und Kunde. Auch "Jede PDF hat 6 Seiten" ist Selbstaussage. |

## Alte Pfade und Verwechslungen
- `06_ninox4_architektur\kunden`, `_vorlage`, `_pruefung`, `kundenberichte`: In seb.md, Seb-Memory, Skript und seb_berichte-READMEs nicht gefunden. Der Suchtreffer für `_vorlage` und `_pruefung` (nur in Ottos Bericht, `seb_berichte\_pruefung\`, `_vorlage\`) betrifft leere Altordner; sie sind laut Ottos Bericht zum Löschen vorgeschlagen, ich habe nicht geprüft, ob sie noch existieren (Glob zeigt keine Dateien darin).
- Weiterhin vorhanden: `02_Erstellte_Apps\06_ninox4_architektur\personalisiert\...` in seb.md Z. 29 und `02_Erstellte_Apps\<projektname>` Z. 13 (siehe Tabelle).
- Quiz gegen Kunde: seb.md enthält weder "Quiz" noch "Kuchlbauer". Seb-Memory nennt nur den Kunden (korrekt). Einzige Seb-Verwechslung: Kuchlbauer-README Z. 33 (siehe oben). Außerhalb von Seb (nur gemeldet, nicht geprüft, nicht Teil deines Auftrags): `woerterbuch.json` (Zeilen 132, 303, 350) und `suchindex.js` enthalten noch "Quiz" und "Kuchlbauer"; `otto_berichte\ordner-pruefung_aktuell.md` und Ottos Plan nennen das Quiz; Ottos Memory `project_seb-ablage-struktur.md` ebenfalls.

## Statusvergleich zum ersten Bericht
| Nr. | Bereich | Status | Prio | Vorschlag |
|---|---|---|---|---|
| neu E1 | .eml: Aufbau mixed/alternative mit zwei PDFs | erledigt (Norbert-Foto-Fehler behoben) | – | – |
| neu E2 | CDO-Prüfung im Skript, Memory `feedback_eml-immer-korrekt`, seb.md Absatz | erledigt, mit Lücken | hoch | Lücke 1 (Abbruch statt Warnung), Lücke 2 (Byte-Vergleich), `To:` leer prüfen |
| neu E3 | Feste Nachnamen `Karner\|Ashauer` im Skript | neu, offen | hoch | Namen entfernen, generisch auf Platzhalter und `-An`/`-Anrede`-Werte prüfen; Skript auf Namensspuren durchsuchen |
| neu E4 | Signaturannahme ungeprüft | neu, offen | hoch | Norbert fragen; wenn keine Signatur erschien, Name und Firma zurück in den Text oder per Parameter |
| neu E5 | .url nun gewollt, Regeln nennen sie nicht | neu, offen | mittel | seb.md, README, Memory, Kunden-READMEs: .url dokumentieren; Hinweis, dass bei `-An` die Adresse in der URL steht |
| neu E6 | Kuchlbauer-README nennt Quiz-Ordner | neu, offen | mittel | Satz streichen; sonst Verwechslungsgefahr zwischen Kunde und gelöschtem Projekt |
| neu E7 | seb.md Z. 67 Formatfehler | neu, offen | niedrig | Zeile trennen |
| 1 | seb.md Schritte 2 bis 5, personalisiert-Pfad | offen | hoch | Streichen (Entscheidungsbaum) |
| 2 | seb.md Z. 13, 67, 71, Punkt 6 (02_Erstellte_Apps, seite-standard, pruefung.ps1) | offen | hoch | Fälle trennen, interner Bericht mit Otto klären |
| 3 | Namensregel (keine Namen im Dateinamen gegen Kundenordner) | offen | mittel | Regel präzisieren |
| 4 | Länge und Verständlichkeit | offen, verschärft (Punkt 7 jetzt mit weiterem Absatz) | hoch | Skill `/kundenbericht`, README als einzige Regelstelle |
| 5 | description | offen | mittel | neu fassen |
| 6 | Tools | offen | mittel | `tools`-Allowlist |
| 7 | Memory-Veraltung | teilweise: eml-Eintrag neu und gut; getrennt-Eintrag und wissensstand weiter alt | mittel | beide korrigieren, Kundennamen reduzieren |
| 8 | Zwei Vertrauensstufen-Skalen | offen | niedrig | Zuordnung |
| 9 | Otto-Einbindung | teilweise erledigt (CLAUDE.md "Otto legt jede Ablage fest", otto.md Abschnitt); seb.md hat weiter nur "neue Ordner nur nach Rücksprache", kein Prüfschritt nach dem Lauf; Ausnahme für Vorlagen und Skript ohne Timestamp fehlt (Ottos Plan, nicht umgesetzt) | mittel | Dauerfreigabe und Prüfschritt |
| 10 | Ersetztes/ältere Sätze | offen | mittel | Skript-Hinweis |
| 11 | Link-Prüfung und Abrufdatum | offen | hoch | Skript prüft Links |
| 12 | Noto Sans lokal | offen | hoch | @font-face mitliefern |
| 13 | Server-Zwang, Asset-Prüfung | offen | mittel | file:/// testen oder lokaler Listener |
| 14 | Ansprechpartner als Parameter | offen (jetzt zusätzlich Signaturregex mit Name) | hoch | Parameter |
| 15 | Fehlerbehandlung (Edge-Exitcode, `$tmp`, Seitenzahl nur Warnung) | offen | mittel | wie Bericht 1 |
| 16 | Trennprüfung (nur "Ninox 3/4") | offen | mittel | Regex, Mailtext, PDF-Text |
| 17 | .url ohne Doku | siehe E5 | mittel | – |
| 18 | PII in .eml/.url bei -An/-Anrede | offen | mittel | Warnung, lokal ablegen |
| 19 | Versionierung `1.0.0` | offen | mittel | Vorlagenversion und Zähler |
| 20 | PS 5.1, BOM | offen | niedrig | BOM, `#requires` |
| 21 | pdf.js per CDN | offen | mittel | lokal ablegen |
| 22 | Vorlagen-Sync | offen | hoch | gemeinsames CSS, Strukturprüfung |
| 23 | Weitergabe an Kollegen (README, Voraussetzungen, Selbsttest) | offen | hoch | Schnellstart-README |
| 24 | Ninox-4-Hosting-Vorbehalt | offen (Vorlagen unverändert) | hoch | Vorbehalt auf Karte und Diagramm |
| 25 | Ninox-3-Härtungsaussage | offen | hoch | Original prüfen oder streichen |
| 26 | "Abbildung 2" im Ninox-3-Dokument | offen | mittel | auf 1 ändern |
| 27 | Abschnitt 4 ohne Quellen | offen | mittel | Quellenspalte |
| 28 | Stimme und Management/Legal-Freigabe | offen | hoch | Freigabe einholen |
| 29 | Mail-Zusage, Einstufung | offen | mittel | Schalter oder streichen |
| 30, 31 | Beleg-Stichproben, Sprache | offen | niedrig bis mittel | wie Bericht 1 |
| 32 | HubSpot-Schritt | offen | mittel bis hoch | Firmenname als Parameter |
| – | Kuchlbauer-Quiz-Bereinigung in CLAUDE.md, Agenten, pruefung | erledigt für CLAUDE.md und .claude\agents (keine Treffer); Rest im Wörterbuch/Suchindex unklar | niedrig | selbst prüfen oder Norbert fragen |
| – | Ottos Plan (nachweise\, archiv\, pruefwerkzeug zusammenlegen) | nicht umgesetzt, wie angekündigt | – | – |

## Die fünf wichtigsten nächsten Schritte
1. seb.md bereinigen: alten Ablauf (Schritte 2 bis 5, personalisiert-Pfad, Z. 13, 67, 71) streichen, .url aufnehmen, Namensregel klären, Formatfehler Z. 67 beheben, Länge kürzen (Skill). Memory `feedback_ninox3…` und `project_wissensstand` angleichen.
2. Skript härten: Namen `Karner|Ashauer` entfernen, CDO-Fehlen als Fehler behandeln, Byte-Vergleich der Anhänge und leeres `To:` prüfen, Link-Prüfung, Ansprechpartner als Parameter, Noto Sans lokal.
3. Signatur klären: Norbert sagt, ob in Outlook (.eml und .url) die Signatur erschien; Ergebnis des Outlook-Tests in den Kunden-READMEs festhalten.
4. Vorlagen freigeben und korrigieren: Hosting-Vorbehalt Ninox 4, Härtungsaussage Ninox 3, Abbildung 1, Quellenspalte Abschnitt 4, Mail-Zusage; Management/Legal für Stimme und Compliance-Aussagen.
5. Kunden-READMEs bereinigen (Quiz-Satz, Outlook-Test, .url, Versionsangabe) und Schnellstart-README für Kollegen erstellen.

## Nicht geprüft
- Die PDFs, das tatsächliche Öffnen der .eml und .url in Outlook, das Verhalten von CDO auf Norbert-Rechner und ob die Prüfung beim letzten Lauf "OK" meldete.
- Skriptausführung (nicht gebaut), BOM und PowerShell 5.1.
- Byte-Gleichheit der Anhänge, Inhalt der base64-Mailtexte (nur Struktur gelesen).
- Ob die leeren Altordner (`_vorlage`, `_pruefung`) noch existieren (Glob liefert nur Dateien).
- Quiz-Reste in Wörterbuch, Suchindex, Ottos Dateien; HubSpot-Sperrliste und Sebs echte Werkzeugliste.
- Keine neuen Prüfungen der Ninox-Quellen (Inhaltsbefunde 24 bis 31 gelten unverändert aus dem ersten Bericht).

**Frage an dich:** Erschien die Outlook-Signatur in den geöffneten Entwürfen (.eml und Outlook-Web-Link), und soll ich die Korrekturen an seb.md, Seb-Memory, Kunden-READMEs und Skript jetzt vorbereiten, beginnend mit dem Namen im Skript und den Widersprüchen in seb.md?
