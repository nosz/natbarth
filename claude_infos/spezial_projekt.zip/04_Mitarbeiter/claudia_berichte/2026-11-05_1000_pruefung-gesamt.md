# Prüfbericht Claudia, 05.11.2026 ("claudia prüfe alles")

Nur lesend. Außer diesem Bericht und dem Memory-Eintrag wurde nichts geändert. Zeitstempel im Dateinamen nominal. Keine Zugangsdaten wiedergegeben.

## Kurzfassung
- Die Empfehlungen aus dem Bericht vom 04.11. sind umgesetzt: Olga, Leonardo, Nicoletta (inkl. Atlassian-Schreibwerkzeuge) haben `disallowedTools`; Bootstrap-JS kommt nicht mehr per CDN in `firma.htm` und `03_todo`; der Haupt-Memory-Eintrag zu Ninox Live nennt den Ordner als gelöscht; die Karner/Ashauer-Namen sind nicht mehr im Archie-Werkzeug zu finden (Suche ohne Treffer).
- Keine Klartext-Zugangsdaten gefunden. Eine Endpunkt-Adresse bleibt offen (siehe K1).
- Neu: Der Agent "Seb" heißt jetzt "Archie"; die Seb-Berichte vom 04.11. sind historisch.

## Befunde nach Schweregrad

| Nr. | Grad | Befund | Beleg | Vorschlag |
|---|---|---|---|---|
| K1 | kritisch (zu klären) | Google-Apps-Script-Adresse (Anmelde-Endpunkt) im Klartext in `09_Ablage\uebertragung\github-update-info-veranstaltung-20261030\js_img_css\info-anmeldung.js`, Zeile 6. Wert nicht wiedergegeben. Org-Vorgabe und Olgas Regel: im Code nur Platzhalter. Bei einer öffentlichen Anmeldeseite muss die Adresse im Browser stehen; ob das gewollt ist, ist nicht belegt. | Org-Vorgaben (Endpunkt-Adressen); Olga-Regel | Norbert klären: Ist die Adresse als öffentlich gedacht? Wenn nein: als kompromittiert behandeln, Script neu bereitstellen (neue URL), Meldung an it@ninox.com. Adresse in Bitwarden/Schlüsselbund, im Code `<APPS_SCRIPT_URL>`. Ablageordner `09_Ablage` ist in OneDrive synchronisiert. |
| W1 | wichtig | `permissions.deny` deckt nur `git push --force`/`-f` und `gh repo delete`. Die Kernregeln aus CLAUDE.md (nichts löschen ohne Freigabe, Schreibschutz Kundendateien, kein Senden) sind nur Text bzw. `ask` für `Remove-Item`/`rm`. | Best Practices: "If something has to happen every time, make it a hook, a deny rule, or a managed setting." | PreToolUse-Hook, der Löschen und Überschreiben unter `04_Mitarbeiter\archie_berichte\berichte\` blockiert. Ask-Regeln für `del`, `Move-Item` auf `ersetzt\`-fremde Ziele prüfen. |
| W2 | wichtig | `.claude\settings.local.json` enthält eine Allow-Regel mit Pfad `...\Desktop\NOBBIS_SUPER_FIRMA\...` (anderer Arbeitsordner als `NORBERT_CLAUDE`) und `Remove-Item`. Die Ask-Regel für `Remove-Item*` hat Vorrang. Die Regel greift nie; zudem verweist sie auf einen Pfad, der in diesem Ordner nicht existiert. | Permissions: "deny, then ask, then allow"; Best Practices (settings.local.json ist persönlich) | Regel entfernen. Klären, ob `NOBBIS_SUPER_FIRMA` und `NORBERT_CLAUDE` zwei parallele Arbeitsordner sind (Memory und Projektverlauf liegen unter dem alten Namen: doppelte Wahrheit). |
| W3 | wichtig | Zwei Haupt-Memory-Verzeichnisse: der Projektspeicher von `NOBBIS_SUPER_FIRMA` (u. a. mit `veranstaltung-ninox-live-...`) wird in `NORBERT_CLAUDE` nicht geladen. Der Ordnerwechsel kann Gelerntes unsichtbar machen. | Memory-Doku: Auto-Memory pro Repository | Entscheiden, welcher Ordner der Arbeitsordner ist; Memory bei Bedarf übernehmen. |
| W4 | wichtig | Archie-Regel (archie.md Z. 22) sagt: Skript prüft Anhänge byte-gleich, CDO, "bricht bei Fehlern ab". Der Seb-Bericht vom 04.11. fand: CDO-Ausfall führt nur zu einer Warnung. Ob das Skript inzwischen angepasst wurde, habe ich in diesem Lauf nicht neu geprüft. | Best Practices: Prüfung muss ausführbar sein | Skript gegen die Regel prüfen lassen; bei Abweichung Skript oder Text angleichen. |
| W5 | wichtig | Kundennamen stehen in Ordner- und Dateinamen (`kuchlbauer`, `mkw-steuerberatung`) in `04_Mitarbeiter\archie_berichte\berichte\`. archie.md erlaubt das ausdrücklich (Firmenkurzname). Org-Vorgabe: Kundennamen nur wenn für die interne Aufgabe nötig, nie in Artefakten für externe Weitergabe. | Org-Vorgaben (DSGVO) | Hinweis: PDFs/.eml gehen an Kunden; Dateinamen der Anhänge enthalten den Firmenkurznamen des Empfängers selbst, das ist vertretbar. Ordner nicht extern teilen (OneDrive-Freigaben prüfen). |
| H1 | Hinweis | Agenten-Beschreibungen beginnen mit Name und Persönlichkeit ("Archie der geniale…") statt mit Aufgabe und Auslöser. Archie, Olga, Nicoletta, Tom & Tina haben sehr lange Descriptions. | Subagents: description = "When Claude should delegate", "keep them short". Alle Descriptions zusammen sollen unter 15.000 Token bleiben. | Beschreibung auf Aufgabe + Auslöser kürzen; Persönlichkeit in den Prompt-Text. Gute Beispiele: Beni, Tom & Tina (Abgrenzung). |
| H2 | Hinweis | `memory: project` schaltet Read/Write/Edit zu, auch bei `tools` ohne Write (Arnold, Beni, Dora, Niklas, Claudia). Bei Arnold (Fitnesstrainer) und Claudia (Edit) ist das mehr Recht als beschrieben. | Subagents: "Read, Write, and Edit tools are automatically enabled" | Bewusst so lassen oder `disallowedTools: Edit, Write` für reine Auskunftsagenten; vorher testen (Doku nennt das nicht für diese Kombination). |
| H3 | Hinweis | Tools: Hans, Archie, Olga, Leonardo, Nicoletta sperren nur HubSpot-Schreibtools; sonstige MCP-Tools (z. B. Atlassian bei Archie) bleiben offen. Garry, Nobbi, Otto, Sarah, Willi, Dora(?) ohne `tools`-Zeile: Bash/PowerShell möglich. Otto soll laut CLAUDE.md "nur lesend und planend" sein, hat aber keine `tools`-Zeile (Frontmatter: nur name, description, memory). | Subagents (Least Privilege); CLAUDE.md Z. 15 | Otto: `tools: Read, Glob, Grep` (plus Memory-Schreiben via `memory`). Archie: Atlassian-Schreibwerkzeuge ebenfalls sperren. |
| H4 | Hinweis | CLAUDE.md ist 39 Zeilen (Ziel unter 200). Sechsmal "(zwingend)"/"Pflicht", dazu Prüfungs- und Teststeps, die nur Text sind. | Memory-Doku; Best Practices: "adding IMPORTANT probably won't fix it" | Lange Pflichtabläufe (Tests, Standardseite, Suchindex) als Skill oder `.claude/rules/` mit `paths:` auslagern; Betonung zurücknehmen. |
| H5 | Hinweis | Namensschema widerspricht sich: Ottos Regel `JJJJ-MM-TT_HHMM_name`, `claudia.md` und `claudia_berichte\README.md` sagen `Pruefung_<Datum>.md`; Archie hat bewusste Ausnahme. Alte Berichte nutzen das alte Schema. | CLAUDE.md Z. 13 | claudia.md und README auf Ottos Schema umstellen (nach Freigabe). |
| H6 | Hinweis | Memory-Pflege: Claudia-Memory nennt "Pruefung_<Datum>.md, bisher bis 01.11."; Seb-Berichte und Archie-Memory enthalten noch den Seb-Namen und alte Pfade (`06_ninox4_architektur\kunden`). | Memory-Doku: veraltete/widersprüchliche Anweisungen | `/doctor prompt-audit` laufen lassen (laut Doku ab Claude Code v2.1.283). |
| H7 | Hinweis | `04_Mitarbeiter\archie_berichte\pruefwerkzeug\pdfansicht.html` lädt PDF.js per cdnjs (Z. 16, 27); `07_NINOX3_SKILL\...\swagger\*.html` lädt von unpkg. Beides interne Werkzeuge, kein Kundenbezug. | Willis Regel "lokal, kein CDN"; DSGVO (IP-Übermittlung) | Lokal einbinden, sobald es relevant wird. |

## Mitarbeiter (Frontmatter aller 16 Dateien gelesen; Olga und Archie vollständig)

| Mitarbeiter | Status | Abweichung | Vorschlag |
|---|---|---|---|
| Archie | verbesserungswürdig | Lange Description; Atlassian offen; W4 | H1, H3, W4 |
| Arnold | in Ordnung | `memory` gibt Write/Edit (H2) | optional |
| Beni | in Ordnung | – | – |
| Claudia | in Ordnung | Namensschema `Pruefung_<Datum>` (H5) | angleichen |
| Dora | in Ordnung | – | – |
| Garry | in Ordnung | Force-Push/Löschen per Deny | – |
| Hans | in Ordnung | HubSpot-Schreibtools gesperrt | – |
| Leonardo | in Ordnung (neu) | `disallowedTools` gesetzt | optional `tools` Read/Glob/Grep/Web |
| Nicoletta | in Ordnung (neu) | HubSpot- und Atlassian-Schreiben gesperrt | Description kürzen |
| Niklas | in Ordnung | – | – |
| Nobbi | in Ordnung | Bootstrap lokal umgesetzt | – |
| Olga | in Ordnung (neu) | HubSpot-Schreibtools gesperrt; keine Verweise auf fehlende Dateien | – |
| Otto | verbesserungswürdig | Soll nur lesen/planen, hat keine `tools`-Zeile (H3) | `tools: Read, Glob, Grep` |
| Sarah | in Ordnung | – | – |
| Tom & Tina | in Ordnung | Lange Description | H1 |
| Willi | in Ordnung | Quelle der `10_webseite` nicht geprüft | – |

Der Ordner `10_webseite` existiert in diesem Arbeitsordner nicht mehr (Glob ohne Treffer in Wurzel-Liste). Adina, Ben & Uwe und Seb gibt es als Agenten-Dateien nicht mehr (Seb = Archie). Der Bericht vom 04.11. lief offenbar auf dem Ordner `NOBBIS_SUPER_FIRMA`; Abweichungen siehe W2, W3.

## Sicherheits-Mustersuche
- Muster: key, token, passw, secret, bearer, authorization, private key, sk-ant, ghp_, github_pat_, AKIA, JWT (`eyJ`), langer Wert nach `key=`/`token=`. Bereich: gesamter Arbeitsordner, Swagger-Dateien ausgeschlossen, Dateitypen md/json/ps1/js/py/env/txt/yml/htm/html.
- Ergebnis: keine echten Schlüssel. Treffer sind Platzhalter (`<API_KEY>`), Testwerte in `selftest.ps1` und ein Beispielwert in `07_NINOX3_SKILL\ninox3\evals\evals.json:11` (offensichtlich erfunden). Dokumentations-Treffer nur Wortvorkommen.
- Die HubSpot-Connector-ID (`8d49c437-…`) steht in `disallowedTools` von sechs Agenten. Das ist eine Connector-Kennung, kein Geheimnis. Hinweis: ändert sich die Kennung (neuer Connector), greift die Sperre stillschweigend nicht mehr ("unbekannte Felder werden ignoriert"); gilt für Tool-Namen ähnlich. Nach jeder Connector-Änderung die Sperre prüfen.
- Offen: K1 (Endpunkt-Adresse).

## Quellen (in diesem Lauf abgerufen)

| Thema | Link | Belegte Aussage |
|---|---|---|
| Subagents | https://code.claude.com/docs/en/sub-agents | description = "When Claude should delegate"; Descriptions "keep them short", Warnung ab 15.000 Token Gesamt; ohne `tools` werden alle geerbt; `disallowedTools` wird zuerst angewendet; `memory` aktiviert Read/Write/Edit; unbekannte Felder ignoriert ohne Fehlermeldung. (Seite bis Zeichen 100.000 von 116.722 gelesen.) |
| Best Practices | https://code.claude.com/docs/en/best-practices | "If something has to happen every time, make it a hook, a deny rule, or a managed setting."; IMPORTANT/Großschreibung bringt bei ignorierter Zeile "probably" nichts; `/doctor prompt-audit`; `.claude/rules/` mit `paths:`. |
| Memory | https://code.claude.com/docs/en/memory | Ziel unter 200 Zeilen je CLAUDE.md; bei widersprüchlichen Anweisungen "Claude may pick one arbitrarily"; CLAUDE.md ist Kontext, keine erzwungene Konfiguration; `/doctor prompt-audit` ab v2.1.283; MEMORY.md: erste 200 Zeilen oder 25 KB. |
| Permissions | nicht neu abgerufen; Aussage "ask vor allow" stammt aus dem Bericht vom 04.11. (Quelle dort); in diesem Lauf nicht erneut belegt | – |

Die Abrufe sind Zusammenfassungen eines Hilfsmodells. Die Zitate zu Best Practices und Memory stammen aus dem gespeicherten Seitentext.

## Nicht geprüft
Skills-Seite und Prompting-Leitfaden (nicht abgerufen). Skills unter `07_NINOX3_SKILL` nur per Mustersuche, nicht inhaltlich. Inhalt der Agenten-Prompts (außer Olga, Archie) nicht vollständig neu gelesen. `pruefung.ps1`, Browser-/Linktests, Suchindex-Aktualität, Versionsnummern nicht ausgeführt (Auftrag: nur lesen). Archie-Skript `kundenbericht-bauen.ps1` nicht neu gelesen. Memory-Dateien der anderen Agenten nicht geprüft. Dateizahlen: 16 Agenten-Dateien, 4 Wissensdateien, 2 Settings-Dateien, 8 Berichte, CLAUDE.md; Mustersuche über den gesamten Arbeitsordner (354 Rohtreffer in 79 Dateien, durchgesehen nach Echtheit). Inhalt von `.claude\launch.json` und `serve.ps1` nicht gelesen.

## Empfohlene nächste Schritte (nach Freigabe)
1. K1 klären (Apps-Script-Adresse).
2. `settings.local.json` bereinigen, Arbeitsordner klären (W2, W3).
3. Hook für Schreibschutz Kundendateien (W1).
4. Otto auf `tools: Read, Glob, Grep`; Archie Atlassian-Schreiben sperren (H3).
5. Descriptions kürzen, claudia.md-Namensschema anpassen (H1, H5).
