# Baut den Flyer (HTML -> PDF) mit Edge headless. Aufruf: powershell -File flyer-bauen.ps1
$q = $PSScriptRoot
$ziel = Split-Path $q -Parent
$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$html = Join-Path $q '2026-11-05_1200_flyer-ninox4-schulung_quelle.html'
$pdf  = Join-Path $ziel '2026-11-05_1200_flyer-ninox4-schulung_a5-hoch_de.pdf'
$url  = ([System.Uri]$html).AbsoluteUri
& $edge --headless --disable-gpu --no-pdf-header-footer --virtual-time-budget=5000 "--print-to-pdf=$pdf" $url
Start-Sleep -Seconds 4
Get-Item $pdf | Select-Object Name, Length, LastWriteTime
