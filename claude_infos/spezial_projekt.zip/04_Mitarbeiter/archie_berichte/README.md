# archie_berichte: So benutzt du Archie

Archie erstellt für Kunden eine **Systemarchitektur-Information zu Ninox 3 oder Ninox 4**: PDF in Deutsch und Englisch, ein fertiger Outlook-Entwurf und ein Klick-Link für Outlook im Web. Nur öffentliche Quellen. Struktur und Namen stammen von Otto (Ordnerkönig).

## Schnellstart in 5 Schritten
1. **Voraussetzungen:** Windows mit Microsoft Edge und Outlook (klassisch, für die `.eml`), PowerShell 5.1, ein lokaler Webserver auf dem Arbeitsordner (Port 8100, in dieser Umgebung `preview_start firma`). Selbsttest: `werkzeuge\kundenbericht-bauen.ps1 -Kurz selbsttest -Firma "Selbsttest GmbH" -AusgabeOrdner <temporärer Ordner>` muss ohne Fehler durchlaufen.
2. **Angaben sammeln:** Kurzname des Kunden (klein, Bindestriche, kein Personenname), Firmierung, Produkt (Ninox 4, Ninox 3 oder beide), Ansprechpartner (Standard Norbert Szpak, anpassbar mit `-Ansprechpartner`).
3. **Bauen (neutral, ohne Kunde):** `werkzeuge\kundenbericht-bauen.ps1 -Neutral -Produkt ninox4`, Ergebnis in `berichte\neutral\ninox4\`. **Bauen (mit Kunde):** Archie beauftragen ("Info über die Ninox 4 Systemarchitektur für <Firma>") oder selbst `werkzeuge\kundenbericht-bauen.ps1 -Kurz <kunde> -Firma "<Firmierung>" [-Produkt ninox4|ninox3]` aufrufen.
4. **Prüfen:** Meldungen des Skripts lesen (Trennung der Produkte, Entwurfsprüfung), jede PDF-Seite als Bild ansehen mit `pruefwerkzeug\pdfansicht.html?pdf=<Pfad ab Server-Wurzel>` .
5. **Versenden:** `.eml` in `berichte\<kunde>\ninox<N>\` doppelklicken, Empfänger und Anrede ergänzen, senden. Outlook fügt die eigene Signatur an. Im Web stattdessen die `-outlook-web.url` öffnen und die beiden PDFs hineinziehen (Links können keine Anhänge tragen).

## Wo liegt was
| Ordner | Inhalt |
|---|---|
| `berichte\<kunde>\ninox4\` | Kundenbericht nur zu Ninox 4: PDF Deutsch, PDF Englisch, Outlook-Entwurf `.eml`, Klick-Link `.url` |
| `berichte\<kunde>\ninox3\` | Kundenbericht nur zu Ninox 3, gleiche Dateitypen |
| `berichte\<kunde>\ersetzt\<grund>\` | Ersetzte Fassungen, nie löschen |
| `vorlagen\` | Vorlagen je Produkt und Sprache (HTML) und Mailvorlagen. Inhalte ändert man nur hier, nie in den PDFs |
| `werkzeuge\` | `kundenbericht-bauen.ps1` (baut PDFs, Entwurf und Link und prüft sie) |
| `pruefwerkzeug\` | `pdfansicht.html` (zeigt jede PDF-Seite als Bild, benötigt Internet für pdf.js) |

## Regeln
- **Ninox 3 und Ninox 4 immer getrennt**: eigener Ordner, eigenes Dokument, keine Querverweise, nie ein kombiniertes Dokument.
- **Nur Versanddateien** im Ergebnisordner (2 PDFs, `.eml`, `.url`), keine HTML-Dateien (HTML entsteht nur kurz beim Bauen).
- **Dateinamen** (Vorgabe von Norbert, gilt überall): `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf`, `<kunde>_mailtext-ninox<N>_<JJJJ-MM-TT>.eml` und `<kunde>_mailtext-ninox<N>-outlook-web_<JJJJ-MM-TT>.url`, Beispiel `kuchlbauer_systemarchitektur-ninox4_en_2026-11-04.pdf`. Kunde = Firmenkurzname, nie Personenname oder E-Mail in Namen oder Dateien. Gibt es für dasselbe Datum schon Dateien, verschiebt das Skript sie nach `berichte\<kunde>\ersetzt\vor-lauf-<Uhrzeit>\`. **Neutrale Dokumente** (ohne Kundenbezug, Aufruf mit `-Neutral`, Norbert 04.11.2026): Ordner `berichte\neutral\ninox<N>\` und Dateinamen ohne Kundenvorsatz, zum Beispiel `systemarchitektur-ninox4_de_2026-11-04.pdf`, `mailtext-ninox4_2026-11-04.eml`; im Dokument steht kein Firmenname, der Mailbetreff trägt keine Firma.
- Der Outlook-Entwurf ist leer beim Empfänger und neutral in der Anrede. Mit `-An` und `-Anrede` kommen Personendaten in die Datei: nur auf ausdrücklichen Wunsch, danach lokal halten.
- Ersetztes nach `ersetzt\`, nichts ohne Freigabe löschen, neue Ordner nur nach Rücksprache mit Otto.
- Inhalte vor dem ersten Versand an einen neuen Empfängerkreis von Management und Legal freigeben lassen (Aussagen zu Zertifizierung, Auftragsverarbeitung und Datenschutz sind Vertragsthemen).
- Archie versendet nie selbst.

## Bekannte Grenzen
- Hosting-Aussagen zu Ninox 4 stammen aus einer Herstellerangabe (Blog zum "neuen Ninox"); BSI C5, Datenstandort der Ninox-3-Public-Cloud, Auftragsverarbeitung und Wiederherstellungszeiten sind öffentlich nicht belegt und stehen als Fragen im Dokument.
- Das Skript braucht den lokalen Server, Edge und CDO (Windows); die Schrift Noto Sans muss installiert sein, sonst fällt das Layout auf Arial zurück.
