# Mailtext Ninox 3 (Deutsch und Englisch)

Anhänge: `{{PDF_DE}}` und `{{PDF_EN}}`.
Die Anrede steht mit Platzhalter hier; Namen von Kontaktpersonen stehen nur in der Mail, nie in Dateien. Vor dem Senden den Absatz mit der Zusage zur Klärung der offenen Fragen prüfen.

## Deutsch

**Betreff:** Systemarchitektur Ninox 3: Information für {{FIRMA}}

Guten Tag <Vorname Nachname>,

anbei erhalten Sie die Dokumentation zur Systemarchitektur von Ninox 3, auf Deutsch und auf Englisch (zwei PDF-Dateien).

Das Dokument beschreibt die Betriebsmodelle, den Aufbau und die Sicherheit. Grundlage sind die öffentliche Ninox-Dokumentation und öffentlich zugängliche Herstellerangaben. Jede Aussage ist mit Quelle und Vertrauensstufe gekennzeichnet, sodass erkennbar ist, was belegt ist und was nicht.

Einzelne Punkte, etwa der Datenstandort der Public Cloud, Nachweise zu Zertifizierungen und die Auftragsverarbeitung, sind öffentlich nicht dokumentiert. Sie sind in Abschnitt 5 als offene Fragen mit Zuständigkeit aufgeführt. Auf Wunsch kläre ich diese mit den zuständigen Kolleginnen und Kollegen bei Ninox.

Das Dokument ist eine technische Information und kein Vertragsbestandteil. Es ist vertraulich und ausschließlich für Sie bestimmt.

Mit freundlichen Grüßen

## English

**Subject:** System architecture of Ninox 3: information for {{FIRMA}}

Hello <First name Last name>,

please find attached the documentation of the system architecture of Ninox 3, in German and in English (two PDF files).

The document describes the operating models, structure and security. It is based on the public Ninox documentation and publicly available vendor statements. Every statement is marked with its source and confidence level, so it is clear what is documented and what is not.

Some points, such as the Public Cloud data location, evidence of certifications and the data processing agreement, are not publicly documented. They are listed in section 5 as open questions with the responsible contact. On request, I will clarify them with the responsible colleagues at Ninox.

The document is technical information and not part of any contract. It is confidential and intended for you only.

Kind regards
