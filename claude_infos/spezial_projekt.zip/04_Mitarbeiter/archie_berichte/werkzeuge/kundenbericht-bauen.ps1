﻿# Baut die Kundenberichte von Archie (Systemarchitektur) strikt getrennt je Produkt (Ninox 3 und Ninox 4), jeweils in Deutsch UND Englisch.
# Ergebnis je Produkt: 2 PDFs (DE, EN), 1 Outlook-Entwurf (.eml, Doppelklick öffnet Outlook mit fertigem Text und beiden PDFs als Anhang) und 1 Klick-Link für Outlook im Web (.url, nur Betreff und Text, ohne Anhänge).
# Es werden KEINE HTML-Dateien abgelegt (Anweisung von Norbert, 04.11.2026): HTML entsteht nur als temporäre Zwischendatei und wird nach dem Lauf entfernt.
# Es gibt nie ein kombiniertes Dokument.
# Aufruf:  .\kundenbericht-bauen.ps1 -Kurz kuchlbauer -Firma 'Brauerei zum Kuchlbauer GmbH & Co. KG'                  (beide Produkte, getrennte Ordner)
#          .\kundenbericht-bauen.ps1 -Kurz beispiel -Firma 'Beispiel GmbH' -Produkt ninox4                           (nur Ninox 4)
#          .\kundenbericht-bauen.ps1 -Neutral -Produkt ninox4                                                         (ohne Kundenbezug: Ordner berichte\neutral\, Dateinamen ohne Kundenvorsatz, kein Firmenname im Dokument)
#          Optional im Entwurf: -Anrede 'Guten Tag Vorname Nachname' -An 'adresse@firma.at' (nur auf ausdrücklichen Wunsch; Standard: neutrale Anrede, kein Empfänger, keine personenbezogenen Daten in Dateien)
#          Weitere Parameter: -Ansprechpartner 'Name, Firma' (Titelseite und Dokumentinformationen, Standard Norbert Szpak), -AusgabeOrdner <Pfad> (statt berichte\, zum Testen),
#          -Datum, -Version, -Port, -OutlookHost, -OhneEntwurfspruefung (nur wenn CDO fehlt; danach die .eml von Hand in Outlook prüfen)
# Voraussetzung: ein Server mit dem Arbeitsordner als Wurzel läuft (preview_start firma, Port 8100; -Port 8101 für firma-sitzung), damit Schrift und Icons wie im Standard laden.
# Ablage (Ottos Schema): 04_Mitarbeiter\archie_berichte\berichte\<kunde>\ninox4\ und \ninox3\ mit
#   <kunde>_systemarchitektur-ninox<N>_de_<JJJJ-MM-TT>.pdf / _en_<JJJJ-MM-TT>.pdf, <kunde>_mailtext-ninox<N>_<JJJJ-MM-TT>.eml und <kunde>_mailtext-ninox<N>-outlook-web_<JJJJ-MM-TT>.url (Schema von Norbert, 04.11.2026)
#   Das Datum kommt aus -Datum (Standard heute). Gibt es für dasselbe Datum schon Dateien, werden sie nach <kunde>\ersetzt\vor-lauf-<Uhrzeit>\ verschoben, nie überschrieben oder gelöscht.
# Vorlagen: ..\vorlagen\ninox<N>.vorlage.de.html / .en.html und mailtext.ninox<N>.vorlage.md (je Produkt eigene Inhalte, keine Querverweise)
param(
  [string]$Kurz = '',
  [string]$Firma = '',
  [switch]$Neutral,
  [ValidateSet('ninox3', 'ninox4')][string[]]$Produkt = @('ninox4', 'ninox3'),
  [string]$Version = '1.0.0',
  [datetime]$Datum = (Get-Date),
  [string]$Anrede = '',
  [string]$An = '',
  [int]$Port = 8100,
  [string]$OutlookHost = 'outlook.cloud.microsoft',
  [string]$Ansprechpartner = 'Norbert Szpak, Ninox Software GmbH',
  [string]$AusgabeOrdner = '',
  [switch]$OhneEntwurfspruefung
)
$ErrorActionPreference = 'Stop'
if ($Neutral) { if (-not $Kurz) { $Kurz = 'neutral' }; $Firma = '' } elseif (-not $Kurz -or -not $Firma) { throw 'Entweder -Kurz und -Firma angeben oder -Neutral (Dokument ohne Kundenbezug).' }
$archie = Split-Path $PSScriptRoot -Parent
$root = (Resolve-Path (Join-Path $archie '..\..')).Path
$tag = $Datum.ToString('yyyy-MM-dd')
$stamp = $tag
if ($Kurz -notmatch '^[a-z0-9-]+$') { throw 'Kurzname klein, nur Buchstaben a-z, Ziffern, Bindestrich (Ottos Namensregeln, keine Personennamen).' }
$basisOrdner = if ($AusgabeOrdner) { $AusgabeOrdner } else { Join-Path $archie 'berichte' }
$kundenOrdner = Join-Path $basisOrdner $Kurz
$utf8 = New-Object System.Text.UTF8Encoding($false)
$logo = [IO.File]::ReadAllText((Join-Path $root '02_Erstellte_Apps\_standard\logo.svg'), $utf8)
$edge = @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe', 'C:\Program Files\Microsoft\Edge\Application\msedge.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { throw 'Microsoft Edge nicht gefunden.' }
$enc = { param($t) [System.Net.WebUtility]::HtmlEncode($t) }
$sprachen = @(
  @{ Code = 'DE'; Klein = 'de'; Datum = $Datum.ToString('dd.MM.yyyy', [Globalization.CultureInfo]::GetCultureInfo('de-DE')) },
  @{ Code = 'EN'; Klein = 'en'; Datum = $Datum.ToString('d MMMM yyyy', [Globalization.CultureInfo]::GetCultureInfo('en-GB')) }
)
# temporärer Zwischenordner für HTML (im Serverbaum, damit Schrift und Icons laden); wird am Ende entfernt
$tmpHtml = Join-Path $PSScriptRoot '_temp'
New-Item -ItemType Directory -Force $tmpHtml | Out-Null

function B64([byte[]]$b) { $s = [Convert]::ToBase64String($b); ($s -split '(.{76})' | Where-Object { $_ }) -join "`r`n" }
function KopfZeile([string]$text) {
  # RFC 2047: Betreff in Stücken zu höchstens 15 Zeichen als encoded-words
  $teile = @(); for ($i = 0; $i -lt $text.Length; $i += 15) { $teile += $text.Substring($i, [Math]::Min(15, $text.Length - $i)) }
  ($teile | ForEach-Object { '=?UTF-8?B?' + [Convert]::ToBase64String($utf8.GetBytes($_)) + '?=' }) -join "`r`n "
}

$gesperrt = $false
try {
foreach ($prod in $Produkt) {
  $n = $prod.Substring(5)
  $andere = if ($n -eq '4') { 'Ninox 3' } else { 'Ninox 4' }
  $ordner = Join-Path $kundenOrdner $prod
  New-Item -ItemType Directory -Force $ordner | Out-Null
  # Gleiches Datum, gleicher Kunde: vorhandene Dateien nie überschreiben, sondern nach ersetzt\ verschieben
  $vorhanden = @(Get-ChildItem $ordner -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "*_$stamp.*" })
  if ($vorhanden.Count -gt 0) { $arch = Join-Path (Join-Path $kundenOrdner 'ersetzt') ('vor-lauf-{0}\{1}' -f (Get-Date).ToString('HHmmss'), $prod); New-Item -ItemType Directory -Force $arch | Out-Null; foreach ($alt in $vorhanden) { Move-Item -LiteralPath $alt.FullName -Destination $arch }; Write-Output ('HINWEIS: {0} vorhandene Dateien vom {1} nach ersetzt\ verschoben ({2})' -f $vorhanden.Count, $stamp, $arch) }
  $praefix = if ($Neutral) { '' } else { "${Kurz}_" }   # neutrale Dokumente tragen keinen Kundenvorsatz im Dateinamen
  $stamm = "{0}systemarchitektur-ninox{1}" -f $praefix, $n
  $seitenzahl = @{}
  $pdfs = @()
  foreach ($s in $sprachen) {
    $vorlage = [IO.File]::ReadAllText((Join-Path $archie ("vorlagen\{0}.vorlage.{1}.html" -f $prod, $s.Klein)), $utf8)
    $vorlage = $vorlage.Replace('../../../_standard/', '../../../../02_Erstellte_Apps/_standard/')
    if ($Neutral) {
      # Dokument ohne Kundenbezug: kein Firmenname auf Titelseite, in Dokumentinformationen, Überschrift, Fußzeile und Titel
      $np = if ($s.Klein -eq 'de') {
        @(@('<dt>Erstellt für</dt><dd>{{FIRMA}}</dd>', '<dt>Verwendung</dt><dd>Allgemeine Information, ohne Kundenbezug</dd>'), @('<td class="k">Empfänger</td><td>{{FIRMA}}</td>', '<td class="k">Empfänger</td><td>Allgemein, ohne Kundenbezug</td>'), @('Einordnung für {{FIRMA}}', 'Einordnung'), @(' · erstellt für {{FIRMA}}', ''), @(' – {{KURZ}}', ''), @(' · {{KURZ}}', ''))
      } else {
        @(@('<dt>Prepared for</dt><dd>{{FIRMA}}</dd>', '<dt>Use</dt><dd>General information, no customer reference</dd>'), @('<td class="k">Recipient</td><td>{{FIRMA}}</td>', '<td class="k">Recipient</td><td>General, no customer reference</td>'), @('Assessment for {{FIRMA}}', 'Assessment'), @(' · prepared for {{FIRMA}}', ''), @(' – {{KURZ}}', ''), @(' · {{KURZ}}', ''))
      }
      foreach ($p in $np) { if (-not $vorlage.Contains($p[0])) { throw "Neutral-Vorlage ($prod $($s.Code)): Textstelle fehlt: $($p[0])" }; $vorlage = $vorlage.Replace($p[0], $p[1]) }
    }
    $html = $vorlage.Replace('{{LOGO}}', $logo).Replace('{{FIRMA}}', (& $enc $Firma)).Replace('{{KURZ}}', (& $enc $Kurz)).Replace('{{VERSION}}', $Version).Replace('{{DATUM}}', $s.Datum).Replace('{{ABRUF}}', $s.Datum).Replace('{{ANSPRECHPARTNER}}', (& $enc $Ansprechpartner))
    if ($html -match '\{\{[A-Z]+\}\}') { throw "Unersetzter Platzhalter in $prod $($s.Code): $($Matches[0])" }
    $sichtbar = $html -replace '(?s)<style.*?</style>', '' -replace '(?s)<svg.*?</svg>', '' -replace '<[^>]+>', ' '
    $quer = ([regex]::Matches($sichtbar, [regex]::Escape($andere))).Count
    if ($quer -gt 0) { throw "Trennung verletzt: $quer Verweis(e) auf $andere in $prod $($s.Code)" }
    if ($s.Code -eq 'EN' -and [regex]::IsMatch($sichtbar, '[äöüÄÖÜß]')) { throw "Umlaut im englischen Dokument ($prod)" }
    $htmlDatei = Join-Path $tmpHtml ("{0}_{1}.html" -f $stamm, $s.Klein)
    [IO.File]::WriteAllText($htmlDatei, $html, $utf8)

    $rel = $htmlDatei.Substring($root.Length + 1).Replace('\', '/')
    $url = "http://localhost:$Port/$rel"
    try { $null = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10 } catch { throw "Server auf Port $Port nicht erreichbar oder Seite fehlt: $url (preview_start firma starten)" }
    $pdfName = "{0}_{1}_{2}.pdf" -f $stamm, $s.Klein, $stamp
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ("kundenbericht_{0}.pdf" -f [guid]::NewGuid().ToString('N'))
    $profil = Join-Path ([IO.Path]::GetTempPath()) ("edge_kb_{0}" -f [guid]::NewGuid().ToString('N'))
    # Edge schreibt Meldungen nach stderr; sie dürfen den Bau nicht abbrechen (auch nicht bei Aufruf mit 2>&1), Erfolg wird an der PDF gemessen
    $fruehere = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    & $edge --headless=new --disable-gpu --no-pdf-header-footer --user-data-dir="$profil" --virtual-time-budget=20000 --print-to-pdf="$tmp" $url 2>$null | Out-Null
    $edgeCode = $LASTEXITCODE; $ErrorActionPreference = $fruehere
    Start-Sleep -Seconds 2
    if ($edgeCode -ne 0) { Write-Output "WARNUNG: Edge meldete Rückgabecode $edgeCode (PDF wird trotzdem auf Größe geprüft)" }
    if (-not (Test-Path $tmp) -or (Get-Item $tmp).Length -lt 20000) { throw "PDF $prod $($s.Code) wurde nicht erzeugt." }
    $ziel = Join-Path $ordner $pdfName
    try { Copy-Item -LiteralPath $tmp -Destination $ziel -Force } catch { Write-Output "GESPERRT: $ziel ist geöffnet (z. B. in Acrobat). Alte Datei bleibt. Neue PDF liegt in $tmp"; $gesperrt = $true; continue }
    Remove-Item -LiteralPath $profil -Recurse -Force -ErrorAction SilentlyContinue
    $bytes = [IO.File]::ReadAllBytes($ziel)
    $seiten = ([regex]::Matches([Text.Encoding]::GetEncoding(28591).GetString($bytes), '/Type\s*/Page[^s]')).Count
    $seitenzahl[$s.Code] = $seiten
    $pdfs += $ziel
    Write-Output ("OK Ninox {0} {1}: {2} ({3} KB, {4} Seiten, Änderungszeit {5}, Verweise auf {6}: {7})" -f $n, $s.Code, $ziel, [math]::Round($bytes.Length / 1KB), $seiten, (Get-Item $ziel).LastWriteTime.ToString('HH:mm:ss'), $andere, $quer)
  }
  if ($seitenzahl.Count -eq 2 -and $seitenzahl['DE'] -ne $seitenzahl['EN']) { Write-Output "WARNUNG Ninox ${n}: Seitenzahl DE $($seitenzahl['DE']) ungleich EN $($seitenzahl['EN'])" }

  # Outlook-Entwurf (.eml mit X-Unsent: öffnet sich per Doppelklick als neue Nachricht, Text und beide PDFs sind schon drin)
  $mail = [IO.File]::ReadAllText((Join-Path $archie ("vorlagen\mailtext.{0}.vorlage.md" -f $prod)), $utf8)
  $mail = $mail.Replace('{{FIRMA}}', $Firma).Replace('{{PDF_DE}}', ("{0}_de_{1}.pdf" -f $stamm, $stamp)).Replace('{{PDF_EN}}', ("{0}_en_{1}.pdf" -f $stamm, $stamp))
  if ($mail -match '\{\{[A-Z_]+\}\}') { throw "Unersetzter Platzhalter im Mailtext $prod" }
  $abschnitt = { param($titel) $m = [regex]::Match($mail, '(?ms)^## ' + $titel + '\s*\r?\n(.*?)(?=^## |\z)'); if (-not $m.Success) { throw "Mailtext-Abschnitt $titel fehlt" }; $m.Groups[1].Value }
  $nurText = { param($sec) ([regex]::Replace($sec, '(?m)^\*\*(Betreff|Subject):\*\*.*\r?\n', '')).Trim() }
  $de = & $nurText (& $abschnitt 'Deutsch'); $en = & $nurText (& $abschnitt 'English')
  $de = $de -replace '(?m)^Guten Tag <[^>]+>,', $(if ($Anrede) { $Anrede + ',' } else { 'Guten Tag,' })
  $en = $en -replace '(?m)^Hello <[^>]+>,', $(if ($Anrede) { $Anrede + ',' } else { 'Hello,' })
  if ($de -match '<[^>]+>' -or $en -match '<[^>]+>') { throw 'Platzhalter in spitzen Klammern im Mailtext übrig.' }
  # Die Mailvorlagen enthalten keine Namenszeilen: Outlook fügt die Signatur des Absenders selbst an (am 04.11.2026 am Entwurf bestätigt), im Text bleibt nur die Grußformel.
  $absaetze = { param($t) (([regex]::Split($t.Trim(), '\r?\n\r?\n') | ForEach-Object { '<p style="margin:0 0 12px 0">' + (& $enc $_).Replace("`r", '').Replace("`n", '<br>') + '</p>' }) -join "`r`n") }
  $htmlText = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body style="font-family:Calibri,Arial,sans-serif;font-size:11pt">' + (& $absaetze $de) + '<hr style="margin:16px 0">' + (& $absaetze $en) + '</body></html>'
  $text = ($de + "`n`n------------------------------------------------------------`n`n" + $en) -replace "`r?`n", "`r`n"
  $betreff = "Systemarchitektur Ninox $n / System architecture of Ninox $n" + $(if ($Neutral) { '' } else { " – $Firma" })
  $grenze = '----=_Archie_' + [guid]::NewGuid().ToString('N')
  $eml = New-Object System.Text.StringBuilder
  [void]$eml.Append("X-Unsent: 1`r`n")
  if ($An) { [void]$eml.Append("To: $An`r`n") }
  [void]$eml.Append("Subject: " + (KopfZeile $betreff) + "`r`nMIME-Version: 1.0`r`nContent-Type: multipart/mixed; boundary=`"$grenze`"`r`n`r`n")
  # Text als multipart/alternative (Nur-Text und HTML), so baut Outlook selbst Nachrichten auf
  $grenze2 = '----=_Alt_' + [guid]::NewGuid().ToString('N')
  [void]$eml.Append("--$grenze`r`nContent-Type: multipart/alternative; boundary=`"$grenze2`"`r`n`r`n")
  [void]$eml.Append("--$grenze2`r`nContent-Type: text/plain; charset=utf-8`r`nContent-Transfer-Encoding: base64`r`n`r`n" + (B64 $utf8.GetBytes($text)) + "`r`n")
  [void]$eml.Append("--$grenze2`r`nContent-Type: text/html; charset=utf-8`r`nContent-Transfer-Encoding: base64`r`n`r`n" + (B64 $utf8.GetBytes($htmlText)) + "`r`n")
  [void]$eml.Append("--$grenze2--`r`n")
  foreach ($pdf in $pdfs) {
    $nm = Split-Path $pdf -Leaf
    [void]$eml.Append("--$grenze`r`nContent-Type: application/pdf; name=`"$nm`"`r`nContent-Transfer-Encoding: base64`r`nContent-Disposition: attachment; filename=`"$nm`"`r`n`r`n" + (B64 ([IO.File]::ReadAllBytes($pdf))) + "`r`n")
  }
  [void]$eml.Append("--$grenze--`r`n")
  $emlDatei = Join-Path $ordner ("{0}mailtext-ninox{1}_{2}.eml" -f $praefix, $n, $stamp)
  [IO.File]::WriteAllBytes($emlDatei, [Text.Encoding]::ASCII.GetBytes($eml.ToString()))
  # Pflichtprüfung des Entwurfs, Teil 1 ohne Fremdkomponente: Anhänge byte-gleich mit den PDFs (Base64 aus der .eml zurückgerechnet und per SHA256 verglichen).
  $roh = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($emlDatei))
  $teile = $roh -split ('--' + [regex]::Escape($grenze) + '(?:--)?\r\n')
  $sha = New-Object Security.Cryptography.SHA256Managed
  $verglichen = 0
  foreach ($teil in $teile) {
    if ($teil -match 'filename="([^"]+)"') {
      $fn = $Matches[1]
      $quelleDatei = $pdfs | Where-Object { (Split-Path $_ -Leaf) -eq $fn } | Select-Object -First 1
      if (-not $quelleDatei) { throw "Outlook-Entwurf fehlerhaft: Anhang $fn gehört zu keiner erzeugten PDF" }
      $base64Text = (($teil -split '\r\n\r\n', 2)[1]) -replace '\s', ''
      $dekodiert = [Convert]::FromBase64String($base64Text)
      if ([BitConverter]::ToString($sha.ComputeHash($dekodiert)) -ne [BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($quelleDatei)))) { throw "Outlook-Entwurf fehlerhaft: Anhang nicht byte-gleich mit der PDF: $fn" }
      $verglichen++
    }
  }
  if ($verglichen -ne $pdfs.Count) { throw "Outlook-Entwurf fehlerhaft: $verglichen Anhänge byte-gleich geprüft, erwartet $($pdfs.Count)" }
  Write-Output ("OK Ninox {0} Entwurfsprüfung (Byte-Vergleich): {1} Anhänge identisch mit den PDFs" -f $n, $verglichen)
  # Teil 2 mit einem unabhängigen Mailparser (CDO): Betreff, Text (Nur-Text und HTML), Empfänger, Platzhalter. Bei Abweichung bricht der Bau ab, die .eml muss immer korrekt sein.
  try {
    $stm = New-Object -ComObject ADODB.Stream; $stm.Type = 1; $stm.Open(); $stm.LoadFromFile($emlDatei)
    $cdo = New-Object -ComObject CDO.Message; $cdo.DataSource.OpenObject($stm, '_Stream')
    $anh = @($cdo.Attachments | ForEach-Object { $_.FileName })
    $fehler = @()
    if ($cdo.Subject -notmatch "Ninox $n" -or (-not $Neutral -and $cdo.Subject -notmatch [regex]::Escape($Firma))) { $fehler += "Betreff falsch: $($cdo.Subject)" }
    if ($cdo.TextBody.Length -lt 800) { $fehler += "Nur-Text-Teil zu kurz ($($cdo.TextBody.Length) Zeichen)" }
    if ($cdo.HTMLBody.Length -lt 800) { $fehler += "HTML-Teil zu kurz ($($cdo.HTMLBody.Length) Zeichen)" }
    if ($cdo.TextBody -notmatch 'please find attached' -or $cdo.TextBody -notmatch 'anbei erhalten') { $fehler += 'deutscher oder englischer Mailtext fehlt' }
    if ($cdo.TextBody -match '<[^>]+>|\{\{') { $fehler += 'Platzhalter im Text' }
    if (-not $An -and -not $Anrede) {
      if ($cdo.TextBody -match '[\w.+-]+@[\w-]+\.[\w.-]+') { $fehler += 'E-Mail-Adresse im Text, obwohl weder -An noch -Anrede gesetzt sind' }
      if ($cdo.To) { $fehler += 'Empfängerzeile nicht leer, obwohl -An fehlt' }
    }
    if ($An -and $cdo.To -notmatch [regex]::Escape($An)) { $fehler += 'Empfänger weicht von -An ab' }
    foreach ($pdf in $pdfs) { if ($anh -notcontains (Split-Path $pdf -Leaf)) { $fehler += "Anhang fehlt: $(Split-Path $pdf -Leaf)" } }
    if ($anh.Count -ne $pdfs.Count) { $fehler += "Anzahl Anhänge $($anh.Count) statt $($pdfs.Count)" }
    if ($fehler.Count -gt 0) { throw ('Outlook-Entwurf fehlerhaft: ' + ($fehler -join '; ')) }
    Write-Output ("OK Ninox {0} Entwurfsprüfung (CDO): Betreff, Text {1} Zeichen, HTML {2} Zeichen, {3} Anhänge" -f $n, $cdo.TextBody.Length, $cdo.HTMLBody.Length, $anh.Count)
  } catch [System.Runtime.InteropServices.COMException] {
    if ($OhneEntwurfspruefung) { Write-Output 'WARNUNG: CDO nicht verfügbar, Entwurf nur per Byte-Vergleich geprüft (-OhneEntwurfspruefung gesetzt). Entwurf in Outlook öffnen und Text und Anhänge von Hand prüfen.' }
    else { throw 'Entwurfsprüfung nicht möglich: CDO ist auf diesem Rechner nicht verfügbar. Mit -OhneEntwurfspruefung bewusst fortfahren und die .eml danach in Outlook von Hand prüfen.' }
  }
  Write-Output ("OK Ninox {0} Outlook-Entwurf: {1} ({2} KB, {3} Anhänge)" -f $n, $emlDatei, [math]::Round((Get-Item $emlDatei).Length / 1KB), $pdfs.Count)

  # Klick-Link für Outlook im Web (Internet-Verknüpfung): öffnet das Schreibfenster mit Betreff und Text. Anhänge gehen über Links technisch nicht, die PDFs zieht Norbert hinein.
  $linkText = ($de + "`n`n------------------------------------------------------------`n`n" + $en)
  $url = "https://$OutlookHost/mail/deeplink/compose?" + $(if ($An) { 'to=' + [Uri]::EscapeDataString($An) + '&' } else { '' }) + 'subject=' + [Uri]::EscapeDataString($betreff) + '&body=' + [Uri]::EscapeDataString($linkText)
  $linkDatei = Join-Path $ordner ("{0}mailtext-ninox{1}-outlook-web_{2}.url" -f $praefix, $n, $stamp)
  [IO.File]::WriteAllBytes($linkDatei, [Text.Encoding]::ASCII.GetBytes("[InternetShortcut]`r`nURL=$url`r`n"))
  Write-Output ("OK Ninox {0} Outlook-Web-Link: {1} (Adresse {2} Zeichen{3})" -f $n, $linkDatei, $url.Length, $(if ($url.Length -gt 4000) { ', ACHTUNG sehr lang, Outlook kürzt eventuell den Text' } else { '' }))
}
} finally {
  Remove-Item -LiteralPath $tmpHtml -Recurse -Force -ErrorAction SilentlyContinue
}
if ($gesperrt) { exit 2 }
