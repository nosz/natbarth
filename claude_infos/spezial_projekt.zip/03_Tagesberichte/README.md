# 03_Tagesberichte

**Wofür:** Zusammenfassung des Arbeitstags mit Suche, erzeugt beim Tagesabschluss (tschüss).
