# NOBBIS_SUPER_FIRMA - Ordnerübersicht

**Start:** firma.htm im Browser öffnen, über den Server http://localhost:8100/firma.htm.

## Täglich gebraucht

| Ordner | Wofür |
|---|---|
| 00_Aktuell | Eingang für aktuelles Arbeitsmaterial |
| 01_Praesentationen | Präsentationen |
| 02_Erstellte_Apps | Gebaute Apps und Seiten |
| 03_Tagesberichte | Tagesberichte |
| 04_Mitarbeiter | Ergebnisse der Mitarbeiter: otto_berichte, claudia_berichte |
| 05_Sarah_Erinnerungen | Sarahs Erinnerungen und Übersicht |
| 08_Todos | Zentrale To-do-Liste |

## Selten gebraucht

| Ordner | Wofür |
|---|---|
| 07_NINOX3_SKILL | Quelle der Ninox-3-Skills |
| 09_Ablage | sicherungen, tests, uebertragung |
| .claude | Einstellungen, Agenten, Gedächtnis (nicht von Hand ändern) |

Dateien: CLAUDE.md (Regeln für alle Agenten und Skills), firma.htm (Organigramm). Jeder Ordner hat eine README.md mit Zweck und Inhalt.
