﻿# 01_Praesentationen

**Wofür:** Alle Präsentationen als lokale HTML-Dateien. Sie werden nicht veröffentlicht.

Name: JJJJ-MM-TT_HHMM_thema.html, eine Datei je Präsentation.

Projektordner sind erlaubt, wenn eine Präsentation Demo-Material braucht, z. B. claude-code-vorteile\ (HTML-Folien DE/EN plus demo-materialien\).

