<#
  Aufraeum-Demo (Use Case 1)
  Kopiert die Dateien aus "vorher" nach "nachher" und benennt sie nach der Abbildung alt -> neu.
  - Es wird NICHTS geloescht oder verschoben. Das Original in "vorher" bleibt unveraendert.
  - Mit -Trocken wird nur angezeigt, was passieren wuerde.
  Aufruf: powershell -NoProfile -ExecutionPolicy Bypass -File <dieses Skript> [-Trocken]
#>
param(
  [string]$Quelle = (Join-Path $PSScriptRoot '..\vorher'),
  [string]$Ziel   = (Join-Path $PSScriptRoot '..\nachher'),
  [string]$Abbildung = (Join-Path $PSScriptRoot '2026-11-05_0438_abbildung-alt-neu.csv'),
  [switch]$Trocken
)
$ErrorActionPreference = 'Stop'
$Quelle = (Resolve-Path $Quelle).Path
$zeilen = Import-Csv -Path $Abbildung -Delimiter ';' -Encoding UTF8
$ok = 0; $fehlt = 0
foreach ($z in $zeilen) {
  $von = Join-Path $Quelle $z.vorher
  $nach = Join-Path $Ziel $z.nachher
  if (-not (Test-Path -LiteralPath $von)) { Write-Host ("FEHLT  " + $z.vorher) -ForegroundColor Yellow; $fehlt++; continue }
  Write-Host ("{0,-42} -> {1}" -f $z.vorher, $z.nachher)
  if (-not $Trocken) {
    $dir = Split-Path $nach -Parent
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    Copy-Item -LiteralPath $von -Destination $nach -Force
  }
  $ok++
}
$modus = if ($Trocken) { 'Trockenlauf' } else { 'kopiert' }
Write-Host ("`n{0} Dateien {1}, {2} fehlen. Nichts geloescht." -f $ok, $modus, $fehlt)
