# Prompt Use Case 1: Ordner aufräumen (Deutsch)

Der Ordner `vorher` ist ein Durcheinander. Bitte:

1. Lies jede Datei und erkenne, worum es geht und von welchem Datum sie ist.
2. Schlage eine Ordnerstruktur vor (angebote, rechnungen, meetings, notizen, berichte, ersetzt).
3. Benenne jede Datei nach dem Schema `JJJJ-MM-TT_beschreibung.endung` (klein, Bindestriche, keine Umlaute, keine Leerzeichen).
4. Erkenne Duplikate und alte Stände und lege sie in `ersetzt`.
5. Arbeite nur auf einer Kopie nach `nachher`. Lösche und verschiebe nichts im Original.
6. Zeige mir vorher die Abbildung alt → neu als Tabelle und warte auf mein Ja.

## Demo-Ablauf

1. Ordner `vorher` im Explorer zeigen.
2. Prompt in Claude Code einfügen. Claude zeigt die Tabelle.
3. Freigeben. Claude führt `werkzeuge\2026-11-05_0438_aufraeumen-demo.ps1` aus.
4. Ordner `nachher` im Explorer zeigen.
