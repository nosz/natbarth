# Prompt use case 1: Tidy up a folder (English)

The folder `vorher` is a mess. Please:

1. Read every file and work out what it is about and which date it belongs to.
2. Propose a folder structure (angebote, rechnungen, meetings, notizen, berichte, ersetzt).
3. Rename every file to the pattern `YYYY-MM-DD_description.ext` (lowercase, hyphens, no umlauts, no spaces).
4. Detect duplicates and outdated versions and move them to `ersetzt`.
5. Work only on a copy in `nachher`. Do not delete or move anything in the original.
6. Show me the old → new mapping as a table first and wait for my approval.

## Demo flow

1. Show the folder `vorher` in Explorer.
2. Paste the prompt into Claude Code. Claude shows the table.
3. Approve. Claude runs `werkzeuge\2026-11-05_0438_aufraeumen-demo.ps1`.
4. Show the folder `nachher` in Explorer.
