# Speaker notes: Claude Code at Ninox (English)

For slides version 1.1.2. One thought per slide. Keywords, not scripts.

## Before you start (checklist)
- Server `firma` is running, slides open, language English (key L switches).
- Folder `demo-materialien\01_aufraeumen\nachher` does not exist.
- Explorer with the folder `vorher` ready, Claude Code opened in the folder `01_aufraeumen`.
- Prompt from `prompt\2026-11-05_0438_prompt-aufraeumen_en.md` ready to paste.
- Show fake data only, no customer data.

## Slide 1: Title
- Key sentence: Claude Code is a tool for your daily work.
- No technical talk. Today is about something everyone knows.

## Slide 2: Sound familiar?
- Ask the room: "Who has a folder like this?" Ask for a show of hands.
- Optional: someone names the worst file name they know.
- Key sentence: open, read, rename, sort. File by file, by hand.

## Slide 3: Tell it what you need
- Wait until the text is typed. Only then speak.
- Key sentence: one request in plain sentences. No code, no jargon.
- Point to the reply: it shows the plan first and asks "Shall I go ahead?".
- Only explain the word "prompt" if someone asks.

## Slide 4: From chaos to order
- Press the button (or Enter). Then stay silent for 5 seconds.
- Afterwards: chaos on the left, clean names with dates on the right. Duplicates go to "ersetzt".
- Point to the numbers: 14 files, 6 folders, 0 deleted.
- **Now live:** show `vorher` in Explorer, paste the prompt, show the plan, approve, the script runs, open `nachher` in Explorer.
- Plan B: if the live demo hangs, the animation on the slide stays.

## Slide 5: You do the work, the tool supports you
- Three steps: describe, review the plan, get the result.
- Key sentence: the original stays untouched, nothing is deleted without approval.
- The most important slide for sceptics. Speak calmly.

## Slide 6: What you take away
- Four words: time, consistency, learning, traceable.
- One half-sentence per card, no more.
- Add your own example, e.g. how you tidied a folder yourself. Only tell what is true.

## Slide 7: Your toolbox grows
- Only announce, do not explain: understand Ninox Script, build small tools, texts and docs.
- Key sentence: this was only the basics, there are more uses for your day.
- Note: these examples are not prepared live yet.

## Slide 8: Working safely at Ninox
- Do not skip it, it removes the most common worry.
- Five rules: no passwords in the chat (Bitwarden or keychain), no customer data unless necessary, delete only after approval, check Ninox behaviour against docs.ninox.com, ISO 27001 and BSI C5 apply. Questions to IT (it@ninox.com).

## Slide 9: Try it today
- Three steps: pick an annoying task, describe it in one sentence, check the result and approve.
- Mini task: tidy up a folder, working on a copy.
- Closing question: "Who will try it this week?"

## Possible questions
- **Does Claude see my data?** It works in the folder you choose. No customer data unless necessary, rules on slide 8.
- **Can it delete something?** Not without your approval. In the example it works on a copy.
- **Do I need to code?** No, one sentence in plain language is enough.
- **Is the result always right?** No. That is why you check the plan and the result. For Ninox topics always check against docs.ninox.com.
- **How do I install it?** I have not verified this. Please clarify with IT beforehand and add the answer here.
