# Sprechernotizen: Claude Code bei Ninox (Deutsch)

Zu den Folien Version 1.1.2. Pro Folie ein Gedanke. Stichworte, keine Vorlesetexte.

## Vor dem Start (Checkliste)
- Server `firma` läuft, Folien offen, Sprache Deutsch (Taste L wechselt).
- Ordner `demo-materialien\01_aufraeumen\nachher` ist nicht vorhanden.
- Explorer mit Ordner `vorher` bereit, Claude Code im Ordner `01_aufraeumen` geöffnet.
- Prompt aus `prompt\2026-11-05_0438_prompt-aufraeumen_de.md` zum Einfügen bereit.
- Nur Fake-Daten zeigen, keine Kundendaten.

## Folie 1: Titel
- Kernsatz: Claude Code ist ein Werkzeug für deine tägliche Arbeit.
- Kein Technikvortrag. Heute geht es um eine Sache, die jeder kennt.

## Folie 2: Kennst du das?
- Frage ins Publikum: „Wer hat so einen Ordner?" Hände heben lassen.
- Optional: Jemand nennt den schlimmsten Dateinamen, den er kennt.
- Kernsatz: Öffnen, lesen, umbenennen, sortieren. Datei für Datei, von Hand.

## Folie 3: Sag ihm, was du brauchst
- Warten, bis der Text getippt ist. Dann erst sprechen.
- Kernsatz: Ein Auftrag in normalen Sätzen. Kein Code, keine Fachbegriffe.
- Auf die Antwort zeigen: Es zeigt erst den Plan und fragt „Soll ich loslegen?".
- Das Wort „Prompt" nur erklären, wenn jemand fragt.

## Folie 4: Von Chaos zu Ordnung
- Knopf drücken (oder Enter). Dann 5 Sekunden schweigen.
- Danach: Links Chaos, rechts saubere Namen mit Datum. Duplikate liegen in „ersetzt".
- Auf die Zahlen zeigen: 14 Dateien, 6 Ordner, 0 gelöscht.
- **Jetzt live:** Explorer mit `vorher` zeigen, Prompt einfügen, Plan zeigen, freigeben, Skript läuft, `nachher` im Explorer öffnen.
- Plan B: Hängt die Live-Demo, bleibt die Animation auf der Folie.

## Folie 5: Du arbeitest, das Werkzeug unterstützt
- Drei Schritte: beschreiben, Plan prüfen, Ergebnis bekommen.
- Kernsatz: Das Original bleibt unberührt, nichts wird ohne Freigabe gelöscht.
- Für Skeptiker die wichtigste Folie. Ruhig sprechen.

## Folie 6: Das nimmst du mit
- Vier Wörter: Zeit, Konsistenz, Lernen, Nachvollziehbar.
- Je Karte ein Halbsatz, nicht mehr.
- Eigenes Beispiel einbauen, z. B. wie du selbst einen Ordner aufgeräumt hast. Nur erzählen, was wirklich stimmt.

## Folie 7: Dein Werkzeugkasten wächst
- Nur ankündigen, nicht erklären: Ninox Script verstehen, kleine Tools bauen, Texte und Doku.
- Kernsatz: Das waren erst die Grundlagen, es gibt mehr Einsatzfälle für den Alltag.
- Hinweis: Diese Beispiele sind noch nicht live vorbereitet.

## Folie 8: Sicher arbeiten bei Ninox
- Nicht überspringen, sie nimmt die häufigste Sorge.
- Fünf Regeln: keine Passwörter im Chat (Bitwarden oder Keychain), keine Kundendaten ohne Not, Löschen nur nach Freigabe, Ninox-Verhalten gegen docs.ninox.com prüfen, ISO 27001 und BSI C5 gelten. Fragen an IT (it@ninox.com).

## Folie 9: Probier es heute aus
- Drei Schritte: lästige Aufgabe wählen, in einem Satz beschreiben, Ergebnis prüfen und freigeben.
- Mini-Aufgabe: Einen Ordner aufräumen, auf einer Kopie.
- Schlussfrage: „Wer probiert es diese Woche aus?"

## Mögliche Fragen
- **Sieht Claude meine Daten?** Es arbeitet in dem Ordner, den du auswählst. Keine Kundendaten ohne Not, Regeln auf Folie 8.
- **Kann es etwas löschen?** Nicht ohne deine Freigabe. Im Beispiel arbeitet es auf einer Kopie.
- **Muss ich programmieren können?** Nein, ein Satz in normaler Sprache genügt.
- **Ist das Ergebnis immer richtig?** Nein. Deshalb prüfst du den Plan und das Ergebnis. Bei Ninox-Themen immer gegen docs.ninox.com prüfen.
- **Wie installiere ich es?** Das habe ich nicht belegt. Bitte vorab bei IT klären und die Antwort hier ergänzen.
