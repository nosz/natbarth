# Claude Code Vorteile / Benefits (Version 1.0.0)

**Wofür:** Kurze Präsentation für Ninox-Kollegen mit einem Use Case und vorbereiteter Live-Demo. Deutsch und Englisch (Knopf oben rechts, Taste L). Lokal, nicht veröffentlichen.

## Öffnen
- Server `firma` starten, dann `http://localhost:8100/01_Praesentationen/claude-code-vorteile/2026-11-05_0438_claude-code-vorteile.html`
- Bedienung: Pfeiltasten oder Klick, L wechselt die Sprache.

## Use Case 1: Ordner aufräumen und Dateien sauber benennen
Material in `demo-materialien\01_aufraeumen\`: `vorher` (14 chaotische Fake-Dateien), `prompt\` (Deutsch und Englisch), `werkzeuge\` (Skript und Abbildung alt zu neu). Der Ordner `nachher` entsteht live.

## Zurückgestellt
Use Case 2 (Ninox Script) und Use Case 3 (Mini-App) liegen vorerst in `ersetzt\`, samt der Folien-Fassung mit allen drei Use Cases. Nichts wurde gelöscht.

## Vor der Demo
- Ordner `01_aufraeumen\nachher` muss leer bzw. nicht vorhanden sein. Das Skript kopiert, es löscht nichts. Zum Zurücksetzen den Ordner `nachher` nach Freigabe entfernen.
- Alle Daten sind erfunden. Keine Kundendaten, keine Zugangsdaten.

## Hinweis Otto-Prüfung
`01_aufraeumen\vorher` ist absichtlich chaotisch benannt und kein Befund.
