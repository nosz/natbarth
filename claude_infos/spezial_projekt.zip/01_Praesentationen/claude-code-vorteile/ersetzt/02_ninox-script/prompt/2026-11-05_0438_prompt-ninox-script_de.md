# Prompt Use Case 2: Ninox Script erklären und erweitern (Deutsch)

Lies `beispiele\2026-11-05_0438_ausgangsscript-offene-rechnungen.txt`. Bitte:

1. Erkläre das Script Zeile für Zeile in einfachem Deutsch.
2. Erweitere es so, dass nur überfällige Rechnungen (Fällig vor heute) gezählt werden und der Text lautet: "3 Rechnungen überfällig, Summe: 4200 EUR".
3. Gib das Ergebnis als Ninox Script aus, mit Link zur Dokumentation auf docs.ninox.com.
4. Sage klar, was du nicht sicher weißt, und erfinde keine Funktionen.

## Hinweise für die Demo

- Fake-Tabelle `Rechnung` mit Feldern `Status`, `Betrag`, `Faellig`. Keine echten Kundendaten verwenden.
- Erwartetes Ergebnis: `beispiele\2026-11-05_0438_ergebnisscript-ueberfaellige-rechnungen.txt`.
- Vor dem Einsatz in einer echten Datenbank testen. Ninox-Verhalten immer gegen docs.ninox.com prüfen.
