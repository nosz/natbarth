# Prompt use case 2: Explain and extend Ninox Script (English)

Read `beispiele\2026-11-05_0438_ausgangsscript-offene-rechnungen.txt`. Please:

1. Explain the script line by line in plain English.
2. Extend it so that only overdue invoices (due before today) are counted and the text reads: "3 invoices overdue, total: 4200 EUR".
3. Output the result as Ninox Script, with a link to the documentation on docs.ninox.com.
4. State clearly what you are unsure about and do not invent functions.

## Notes for the demo

- Fake table `Rechnung` with fields `Status`, `Betrag`, `Faellig`. Use no real customer data.
- Expected result: `beispiele\2026-11-05_0438_ergebnisscript-ueberfaellige-rechnungen.txt`.
- Test before using it in a real database. Always check Ninox behaviour against docs.ninox.com.
