# Prompt Use Case 3: Mini-App in Minuten (Deutsch)

Baue mir eine einzelne HTML-Datei `index.html`: ein Meeting-Kostenrechner.

- Eingaben: Teilnehmerzahl, durchschnittlicher Stundensatz in EUR, Dauer in Minuten.
- Ausgabe: Kosten des Meetings, live berechnet, groß angezeigt.
- Ninox-Design: Hintergrund #f7f6f3, Blau #4970ff, Schrift Noto Sans bzw. Arial, abgerundete Karten.
- Deutsch und Englisch mit Umschalter, keine externen Bibliotheken, keine Daten werden gespeichert.
- Starte den Server und zeige mir das Ergebnis im Browser.

Ergebnis: `ergebnis\index.html`.

## Demo-Ablauf (ca. 3 Minuten)

1. Prompt einfügen, Claude schreibt die Datei.
2. Seite im Browser öffnen, Werte ändern, Sprache umschalten.
3. Beispiel: 6 Personen, 60 EUR/h, 45 Minuten = 270 EUR.
