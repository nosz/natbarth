# Prompt use case 3: Mini app in minutes (English)

Build me a single HTML file `index.html`: a meeting cost calculator.

- Inputs: number of attendees, average hourly rate in EUR, duration in minutes.
- Output: cost of the meeting, calculated live and shown large.
- Ninox look: background #f7f6f3, blue #4970ff, font Noto Sans or Arial, rounded cards.
- German and English with a switch, no external libraries, no data is stored.
- Start the server and show me the result in the browser.

Result: `ergebnis\index.html`.

## Demo flow (about 3 minutes)

1. Paste the prompt, Claude writes the file.
2. Open the page in the browser, change the values, switch the language.
3. Example: 6 people, 60 EUR/h, 45 minutes = 270 EUR.
