# Favoriten

Lokale Linkseite im Ninox-Design (Version 1.7.0, 2026-10-28).

- Es gibt keine Notizen mehr, nur noch To-dos (To-do-App, `02_Erstellte_Apps\03_todo`). Notizen, die früher hier gespeichert waren, werden beim ersten Öffnen einmalig als Aufgaben in die To-do-App übernommen (nur wenn beide Seiten denselben Browser-Speicher teilen).
- Kopfbereich im neuen kompakten Stil.

- Im blauen Kopfbereich ganz oben: Button „Nobbis Super-Firma“ zu `firma.htm`.

- Bereich Erinnerungen (ganz oben): **Live-Ansicht der zentralen To-do-Liste** (`08_Todos`, Spiegel `todos.js` plus Browser-Cache der To-do-App, zusammengeführt je Aufgabe). Gezeigt werden offene Aufgaben, die überfällig sind oder in den nächsten 7 Tagen fällig sind (Fälligkeit nicht leer), nach Fälligkeit sortiert, als Karte mit Titel, Info (Überfällig/Heute/Morgen/Wochentag, Datum, Uhrzeit oder "ganztägig"), Icon passend zur Quelle (Slack-/Outlook-Link im Hinweis, Sarah, Import, sonst Aufgabe); ein Klick öffnet die To-do-App. Die letzte Karte "Sarahs Übersicht" ist fest (Live-Ansicht `05_Sarah_Erinnerungen\sarah-uebersicht.html`). Das frühere statische Array `ERINNERUNGEN` und das manuelle Nachziehen entfallen. Die Seite aktualisiert sich bei Sprachwechsel, bei Änderungen im Browser-Speicher (To-do-App in einem anderen Fenster) und beim Zurückkehren; nach einer Änderung per `todos.ps1` zeigt eine offene Seite sie nach Neuladen. Deutsch und Englisch (Heute/Today, Morgen/Tomorrow, Wochentage).

- Feste Favoriten: Organigramm (firma.htm, ganz oben), Zeiten buchen, Sales JF Meeting Notes, Slack-Unterhaltung, Ninox Dokumentation.
- Eigene Favoriten: über das Formular hinzufügen oder mit dem X entfernen. Sie werden im Browser (localStorage) gespeichert, also pro Browser getrennt.
- Öffnen: `index.html` im Browser.

## Änderungsverlauf

| Datum | Änderung |
|---|---|
| 2026-10-28 | **1.7.0**: Abschnitt Erinnerungen dynamisch aus der zentralen To-do-Liste (überfällig und nächste 7 Tage), statisches Array `ERINNERUNGEN` entfernt; feste Karte "Sarahs Übersicht" mit neuer Adresse `sarah-uebersicht.html`; Standard-Kopf neu gesetzt |
| 2026-10-28 | **1.6.1**: Standard-Kopf neu gesetzt: lädt den Spiegel der zentralen To-do-Liste (`08_Todos/todos.js`) für den Zähler im Knopf To-dos (Quelle `NX_TODOS`, Rückfall Browser-Speicher); sonst keine Änderung |
| 2026-10-28 | **1.6.0**: Bereich Notizen entfernt, es gibt nur noch To-dos; vorhandene Notizen werden einmalig als Aufgaben übernommen |
| 2026-10-28 | **1.5.4**: Feste Favoritenkarte GitHub-Trainer |
| 2026-10-28 | **1.5.3**: Links dürfen mit data-nx-keinlang ohne Sprachparameter bleiben (Standard) |
| 2026-10-28 | **1.5.2**: Erinnerung 'Leo Text Ninox4' (Mittwoch, 04.11.2026) in ERINNERUNGEN nachgezogen |
| 2026-10-28 | **1.5.1**: Erinnerung 'Outlook Abwesenheitseintrag entfernen' (Mittwoch, 04.11.2026) in ERINNERUNGEN nachgezogen, Englisch im Wörterbuch |
| 2026-10-28 | **1.5.0**: Zähler-Plakette (offene Aufgaben) im Navigationsknopf To-dos; Notiz mit Häkchen 'Auch als To-do' aktualisiert sie sofort |
| 2026-10-28 | **1.4.0**: Seitenname vereinheitlicht ('Favoriten', Untertitel 'Norberts wichtigste Links an einem Ort'); Notizfeld, Favoriten-Formular, Knöpfe, Überschriften und Karten als gemeinsame nx-Komponenten (Höhe 48 px, Beschriftung über dem Feld, Primär-/Sekundärknopf); Kopf mit festen Spalten |
