﻿# Erzeugt den statischen Suchindex fuer die globale Suche im Organigramm (firma.htm): 02_Erstellte_Apps\_standard\suchindex.js
# Aufruf ohne Parameter: Index neu erzeugen. Mit -Pruefen: nur vergleichen (schreibt nichts), Exit-Code 1 bei Abweichung, 2 bei Quellfehler.
# Liest nur (Seiten, Woerterbuch); To-dos und Erinnerungen stehen NICHT im Index, die Suche liest sie live aus der zentralen Liste (08_Todos). geschrieben wird ausschliesslich suchindex.js.
# Bei kaputter oder fehlender Quelle: Fehlermeldung und Abbruch, es wird nie ein halber Index geschrieben.
# Regeln und Ablauf: STANDARD.md, Abschnitt Suche.
param([switch]$Pruefen)
$ErrorActionPreference = "Stop"
$u8 = New-Object System.Text.UTF8Encoding($false)
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$ziel = Join-Path $PSScriptRoot "suchindex.js"
$inv = [Globalization.CultureInfo]::InvariantCulture

function Lies($rel) {
  $p = Join-Path $root $rel
  if (-not (Test-Path -LiteralPath $p)) { throw "Quelle fehlt: $rel" }
  $t = [IO.File]::ReadAllText($p, $u8)
  if ([string]::IsNullOrWhiteSpace($t)) { throw "Quelle ist leer: $rel" }
  return $t
}

# ---------- Mini-Parser fuer JavaScript-Datenliteralle (Strings, Zahlen, Listen, Objekte, Aufrufe, String-Verkettung) ----------
$script:JT = ""; $script:JP = 0; $script:JBuf = $null; $script:JKonst = @{}
$script:JRx = New-Object Text.RegularExpressions.Regex('\G(?:(?<ws>\s+|//[^\r\n]*|/\*.*?\*/)|(?<str>"(?:[^"\\\r\n]|\\.)*"|''(?:[^''\\\r\n]|\\.)*'')|(?<num>-?\d+(?:\.\d+)?)|(?<id>[A-Za-z_$][\w$]*)|(?<p>[\[\]{}(),:+;]))', [Text.RegularExpressions.RegexOptions]::Singleline)
function JsEntschluesseln([string]$s) {
  $q = $s.Substring(1, $s.Length - 2)
  return [regex]::Replace($q, '\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)', {
    param($m)
    $c = $m.Groups[1].Value
    if ($c.Length -gt 1) { return [string][char][Convert]::ToInt32($c.Substring(1), 16) }
    switch ($c) { 'n' { "`n" } 't' { "`t" } 'r' { "`r" } default { $c } }
  })
}
function JsSchau {
  if ($null -ne $script:JBuf) { return $script:JBuf }
  while ($true) {
    if ($script:JP -ge $script:JT.Length) { $script:JBuf = @('eof', ''); return $script:JBuf }
    $m = $script:JRx.Match($script:JT, $script:JP)
    if (-not $m.Success) { throw ("JavaScript-Literal nicht lesbar bei Zeichen {0}: '{1}'" -f $script:JP, $script:JT.Substring($script:JP, [Math]::Min(30, $script:JT.Length - $script:JP))) }
    $script:JP += $m.Length
    if ($m.Groups['ws'].Success) { continue }
    if ($m.Groups['str'].Success) { $script:JBuf = @('str', $m.Groups['str'].Value) }
    elseif ($m.Groups['num'].Success) { $script:JBuf = @('num', $m.Groups['num'].Value) }
    elseif ($m.Groups['id'].Success) { $script:JBuf = @('id', $m.Groups['id'].Value) }
    else { $script:JBuf = @('p', $m.Groups['p'].Value) }
    return $script:JBuf
  }
}
function JsNimm { $t = JsSchau; $script:JBuf = $null; return $t }
function JsErwarte([string]$p) { $t = JsNimm; if ($t[0] -ne 'p' -or $t[1] -ne $p) { throw "Erwartet '$p', gefunden '$($t[1])' (nahe Zeichen $($script:JP))" } }
function JsAtom {
  $t = JsNimm
  if ($t[0] -eq 'str') { return (JsEntschluesseln $t[1]) }
  if ($t[0] -eq 'num') { return [double]::Parse($t[1], $inv) }
  if ($t[0] -eq 'id') {
    if ($t[1] -eq 'true') { return $true }
    if ($t[1] -eq 'false') { return $false }
    if ($t[1] -eq 'null') { return $null }
    $n = JsSchau
    if ($n[0] -eq 'p' -and $n[1] -eq '(') {
      JsErwarte '('
      $args2 = New-Object Collections.ArrayList
      while ($true) {
        $x = JsSchau
        if ($x[0] -eq 'p' -and $x[1] -eq ')') { [void](JsNimm); break }
        [void]$args2.Add((JsWert))
        $x = JsSchau
        if ($x[0] -eq 'p' -and $x[1] -eq ',') { [void](JsNimm) }
      }
      return [pscustomobject]@{ Aufruf = $t[1]; Args = $args2.ToArray() }
    }
    if ($script:JKonst.ContainsKey($t[1])) { return $script:JKonst[$t[1]] }
    throw "Unbekannte Konstante '$($t[1])' im Datenliteral"
  }
  if ($t[0] -eq 'p' -and $t[1] -eq '[') {
    $l = New-Object Collections.ArrayList
    while ($true) {
      $x = JsSchau
      if ($x[0] -eq 'p' -and $x[1] -eq ']') { [void](JsNimm); break }
      [void]$l.Add((JsWert))
      $x = JsSchau
      if ($x[0] -eq 'p' -and $x[1] -eq ',') { [void](JsNimm) }
    }
    return , $l
  }
  if ($t[0] -eq 'p' -and $t[1] -eq '{') {
    $o = [ordered]@{}
    while ($true) {
      $x = JsSchau
      if ($x[0] -eq 'p' -and $x[1] -eq '}') { [void](JsNimm); break }
      $k = JsNimm
      if ($k[0] -eq 'str') { $key = JsEntschluesseln $k[1] } else { $key = $k[1] }
      JsErwarte ':'
      $o[$key] = JsWert
      $x = JsSchau
      if ($x[0] -eq 'p' -and $x[1] -eq ',') { [void](JsNimm) }
    }
    return $o
  }
  throw "Unerwartetes Zeichen '$($t[1])' im Datenliteral (nahe Zeichen $($script:JP))"
}
function JsWert {
  $v = JsAtom
  while ($true) {
    $x = JsSchau
    if ($x[0] -eq 'p' -and $x[1] -eq '+') { [void](JsNimm); $r = JsAtom; $v = "$v$r" } else { break }
  }
  return , $v
}
# Liest den Wert hinter "const|let|var NAME =" aus dem Text
function JsKonstante([string]$text, [string]$name) {
  $m = [regex]::Match($text, '\b(?:const|let|var)\s+' + [regex]::Escape($name) + '\s*=\s*')
  if (-not $m.Success) { throw "Datenstruktur '$name' nicht gefunden" }
  $script:JT = $text; $script:JP = $m.Index + $m.Length; $script:JBuf = $null
  return , (JsWert)
}

# ---------- Hilfen ----------
function Glatt([string]$s) { if ($null -eq $s) { return "" }; return (($s -replace '\s+', ' ').Trim()) }
$wb = $null
$script:WBAlle = New-Object Collections.Hashtable
$script:WBSek = @{}
$script:WBMuster = New-Object Collections.ArrayList
function WbLaden {
  $j = (Lies '02_Erstellte_Apps\_standard\woerterbuch.json') | ConvertFrom-Json
  foreach ($p in $j.woerter.PSObject.Properties) { $script:WBAlle[(Glatt $p.Name)] = [string]$p.Value }
  foreach ($s in $j.seiten.PSObject.Properties) {
    $h = New-Object Collections.Hashtable
    foreach ($p in $s.Value.woerter.PSObject.Properties) { $h[(Glatt $p.Name)] = [string]$p.Value }
    $script:WBSek[$s.Name] = $h
  }
  foreach ($m in $j.muster) { [void]$script:WBMuster.Add(@($m[0], $m[1])) }
}
$WD = @{ Montag = "Monday"; Dienstag = "Tuesday"; Mittwoch = "Wednesday"; Donnerstag = "Thursday"; Freitag = "Friday"; Samstag = "Saturday"; Sonntag = "Sunday" }
# Englisch zu einem deutschen Text: erst Abschnitt der Seite, dann allgemeine Woerter, dann alle anderen Abschnitte, dann Muster. Leer = keine Uebersetzung bekannt.
function En([string]$de, [string]$sek = "") {
  $k = Glatt $de
  if (-not $k) { return "" }
  if ($sek -and $script:WBSek.ContainsKey($sek) -and $script:WBSek[$sek].ContainsKey($k)) { return $script:WBSek[$sek][$k] }
  if ($script:WBAlle.ContainsKey($k)) { return $script:WBAlle[$k] }
  foreach ($n in $script:WBSek.Keys) { if ($script:WBSek[$n].ContainsKey($k)) { return $script:WBSek[$n][$k] } }
  foreach ($m in $script:WBMuster) {
    try {
      if ([regex]::IsMatch($k, $m[0])) {
        $r = [regex]::Replace($k, $m[0], $m[1])
        return [regex]::Replace($r, '\b(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag)\b', { param($x) $WD[$x.Value] })
      }
    } catch { }
  }
  return ""
}
function Paar([string]$de, [string]$en) { $d = Glatt $de; $e = Glatt $en; if ($e -eq $d) { $e = "" }; return , @($d, $e) }

$script:Eintraege = New-Object Collections.ArrayList
$script:Ids = New-Object Collections.Generic.HashSet[string]
function NeuEintrag([hashtable]$f) {
  $o = [ordered]@{}
  foreach ($k in 'a', 'i', 't', 'r', 'x', 'k', 'b', 'u', 'p', 'kl', 'ext', 's', 'd') {
    if ($f.ContainsKey($k)) {
      $v = $f[$k]
      if ($v -is [array]) { if (-not ($v[0] -or $v[1])) { continue } }
      elseif ($null -eq $v -or "$v" -eq "") { continue }
      $o[$k] = $v
    }
  }
  if (-not $o.Contains('a') -or -not $o.Contains('i') -or -not $o.Contains('t') -or -not $o['t'][0]) { throw "Eintrag ohne Pflichtfelder: $($f['i'])" }
  if (-not $script:Ids.Add([string]$o['i'])) { throw "Doppelte Eintrags-ID: $($o['i'])" }
  [void]$script:Eintraege.Add($o)
}
# Relativen Link (von einer Seite in $basis aus) in einen Pfad ab Hauptordner umrechnen
function PfadAb([string]$basis, [string]$rel) {
  if ($rel -match '^[a-z][a-z0-9+.-]*:') { return $rel }
  $teile = New-Object Collections.ArrayList
  foreach ($s in (($basis.TrimEnd('/') + '/' + $rel) -split '/')) { if ($s -eq '' -or $s -eq '.') { continue } elseif ($s -eq '..') { if ($teile.Count) { $teile.RemoveAt($teile.Count - 1) } } else { [void]$teile.Add($s) } }
  return ($teile -join '/')
}
function Ext([string]$url) { return ($url -match '^https?://') }

# ---------- JSON-Ausgabe (eigene, deterministische Ausgabe) ----------
function JsonText([string]$s) {
  $s = $s.Replace('\', '\\').Replace('"', '\"').Replace('</', '<\/')
  $s = [regex]::Replace($s, '[\x00-\x1f  ]', { param($m) switch ([int][char]$m.Value) { 10 { '\n' } 13 { '\r' } 9 { '\t' } default { '\u' + ([int][char]$m.Value).ToString('x4') } } })
  return '"' + $s + '"'
}
function Json($o) {
  if ($null -eq $o) { return 'null' }
  if ($o -is [string]) { return (JsonText $o) }
  if ($o -is [bool]) { if ($o) { return 'true' } else { return 'false' } }
  if ($o -is [int] -or $o -is [long]) { return $o.ToString($inv) }
  if ($o -is [double]) { return $o.ToString($inv) }
  if ($o -is [System.Collections.IDictionary]) { return '{' + ((@($o.Keys) | ForEach-Object { (JsonText ([string]$_)) + ':' + (Json $o[$_]) }) -join ',') + '}' }
  if ($o -is [System.Collections.IEnumerable]) { return '[' + ((@($o) | ForEach-Object { Json $_ }) -join ',') + ']' }
  return (JsonText ([string]$o))
}

# ---------- Quellen ----------
$zaehlung = [ordered]@{}
$fehlerListe = New-Object Collections.ArrayList
function Quelle([string]$name, [int]$minimum, [scriptblock]$arbeit) {
  $vorher = $script:Eintraege.Count
  try { & $arbeit } catch { [void]$fehlerListe.Add("Quelle '$name': $($_.Exception.Message)"); return }
  $n = $script:Eintraege.Count - $vorher
  $zaehlung[$name] = $n
  if ($n -lt $minimum) { [void]$fehlerListe.Add("Quelle '$name': nur $n Eintraege (erwartet mindestens $minimum), Quelle vermutlich veraendert") }
}

try { WbLaden } catch { Write-Error "Woerterbuch: $($_.Exception.Message)"; exit 2 }

# Sarahs Uebersicht: neueste Seite und englische Texte (data-en) fuer Erinnerungen
$sarahSeite = $null; $sarahEn = @{}
try {
  # Feste Adresse (Live-Ansicht der zentralen Liste); aus der Seite wird nur die Tabelle "Wiederkehrend" indexiert
  $sarahSeite = '05_Sarah_Erinnerungen/sarah-uebersicht.html'
  $sh = Lies '05_Sarah_Erinnerungen\sarah-uebersicht.html'
  $mi = $sh.IndexOf('<main'); $me = $sh.IndexOf('</main>')
  if ($mi -ge 0 -and $me -gt $mi) { $sh = $sh.Substring($mi, $me - $mi) }
  foreach ($m in [regex]::Matches($sh, 'data-en="([^"]*)"[^>]*>([^<]+)<')) { $sarahEn[(Glatt ([Net.WebUtility]::HtmlDecode($m.Groups[2].Value)))] = (Glatt ([Net.WebUtility]::HtmlDecode($m.Groups[1].Value))) }
} catch { [void]$fehlerListe.Add("Quelle 'sarah-seite': $($_.Exception.Message)") }
$firma = $null
try { $firma = Lies 'firma.htm' } catch { [void]$fehlerListe.Add("Quelle 'firma.htm': $($_.Exception.Message)") }

# 1. Organigramm: Mitarbeiter
Quelle 'org' 5 {
  $team = JsKonstante $firma 'TEAM'
  $en = JsKonstante $firma 'EN'
  $modell = JsKonstante $firma 'MODEL_SESSION'
  foreach ($p in $team) {
    $e = $en[$p['id']]
    $tasksDe = (@($p['tasks']) -join ' · ')
    $roleEn = ''; $xEn = ''
    if ($e) {
      $roleEn = [string]$e['role']
      $summEn = if ($e['summary']) { $e['summary'] } else { $p['summary'] }
      $tasksEn = if ($e['tasks']) { (@($e['tasks']) -join ' · ') } else { $tasksDe }
      $howEn = if ($e['how']) { $e['how'] } else { $p['how'] }
      $xEn = "$summEn $tasksEn $howEn"
    }
    $xDe = "$($p['summary']) $tasksDe $($p['how'])"
    $k = $p['id']
    if (-not $p['boss']) { $k += " Modell model $modell" }
    NeuEintrag @{ a = 'org'; i = "org:$($p['id'])"; t = (Paar $p['name'] $p['name']); r = (Paar $p['role'] $roleEn); x = (Paar $xDe $xEn); k = $k; b = (Paar 'Mitarbeiter' 'Team member'); u = "firma.htm#person=$($p['id'])"; p = $p['id'] }
  }
}

# 1b. Erstellte Apps (App-Liste von firma.htm)
Quelle 'apps' 5 {
  $apps = JsKonstante $firma 'APPS'
  foreach ($a in $apps) {
    $f = @{ a = 'apps'; i = "apps:$($a['href'])"; t = (Paar $a['de'][0] $a['en'][0]); x = (Paar $a['de'][1] $a['en'][1]); b = (Paar 'App' 'App'); u = $a['href'] }
    if ($a['keinlang']) { $f['kl'] = 1 }
    NeuEintrag $f
  }
}

# 2. Agenten & Skills
Quelle 'agenten' 20 {
  $ag = Lies '02_Erstellte_Apps\02_agenten_skills_uebersicht\index.html'
  $items = JsKonstante $ag 'ITEMS'
  $sitz = JsKonstante $ag 'SITZUNGSMODELL'
  $modelle = JsKonstante $ag 'MODELLE'
  $src = JsKonstante $ag 'SOURCES'
  foreach ($c in $items) {
    if ($c.Aufruf -eq 'A') { $typ = 'agent'; $name = $c.Args[0]; $role = $c.Args[1]; $desc = $c.Args[2]; $sq = $c.Args[3]; $tags = $c.Args[4] }
    elseif ($c.Aufruf -eq 'S') { $typ = 'skill'; $name = $c.Args[0]; $role = ''; $desc = $c.Args[1]; $sq = $c.Args[2]; $tags = $c.Args[3] }
    else { throw "Unbekannter Eintrag $($c.Aufruf)" }
    $label = $src[$sq]['label']
    $mod = ''
    if ($typ -eq 'agent') { if ($sq -eq 'team') { $mod = if ($modelle.Contains($name)) { $modelle[$name] } else { $sitz } } else { $mod = 'nicht geprüft' } }
    $labEn = En $label 'agenten'
    $k = "$tags $label $labEn $mod $typ"
    $b = if ($typ -eq 'agent') { Paar 'Agent' 'Agent' } else { Paar 'Skill' 'Skill' }
    NeuEintrag @{ a = 'agenten'; i = "agenten:$typ`:$name"; t = (Paar $name $name); r = (Paar $role (En $role 'agenten')); x = (Paar $desc (En $desc 'agenten')); k = $k; b = $b; u = ('02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html#q=' + [Uri]::EscapeDataString($name)) }
  }
}

# 4. Favoriten: feste Favoriten und Erinnerungen (eigene Favoriten liest die Suche live aus dem Browser-Speicher)
Quelle 'favoriten' 4 {
  $fv = Lies '02_Erstellte_Apps\04_favoriten\index.html'
  $basis = '02_Erstellte_Apps/04_favoriten'
  $n = 0
  foreach ($grp in @(@('FEST', 'Fester Favorit', 'Fixed favorite'), @('ERINNERUNGEN_FEST', 'Erinnerung', 'Reminder'))) {
    $liste = JsKonstante $fv $grp[0]
    foreach ($f in $liste) {
      $n++
      $url = PfadAb $basis $f['url']
      $fl = @{ a = 'favoriten'; i = "favoriten:$n"; t = (Paar $f['name'] (En $f['name'] 'favoriten')); x = (Paar $f['info'] (En $f['info'] 'favoriten')); b = (Paar $grp[1] $grp[2]); u = $url }
      if (Ext $url) { $fl['ext'] = 1 }
      NeuEintrag $fl
    }
  }
}

# 5. Tagesberichte
Quelle 'tagesberichte' 1 {
  $tb = Lies '03_Tagesberichte\tagesberichte.html'
  $days = JsKonstante $tb 'DAYS'
  $n = 0
  foreach ($d in $days) {
    foreach ($it in $d['items']) {
      $n++
      NeuEintrag @{ a = 'tagesberichte'; i = "tagesberichte:$n"; t = (Paar $it (En $it 'tagesberichte')); r = (Paar $d['date'] $d['date']); b = (Paar 'Tagesbericht' 'Daily report'); u = '03_Tagesberichte/tagesberichte.html' }
    }
  }
}

# 6. Sarahs Uebersicht: nur die wiederkehrenden Aufgaben (Tabelle). Erinnerungen/Aufgaben kommen live aus der zentralen Liste, nicht aus dem Index.
Quelle 'sarah' 1 {
  if (-not $sarahSeite) { throw "keine Uebersichtsseite" }
  $n = 0
  # Wiederkehrende Aufgaben aus der Tabelle "Wiederkehrend"
  $sh2 = Lies ($sarahSeite.Replace('/', '\'))
  $tm = [regex]::Match($sh2, '(?s)<table>(.*?)</table>')
  if ($tm.Success) {
    foreach ($row in [regex]::Matches($tm.Groups[1].Value, '(?s)<tr>(.*?)</tr>')) {
      $td = @([regex]::Matches($row.Groups[1].Value, '(?s)<td[^>]*>(.*?)</td>') | ForEach-Object { Glatt ([Net.WebUtility]::HtmlDecode(($_.Groups[1].Value -replace '<[^>]+>', ''))) })
      if ($td.Count -lt 3) { continue }
      $n++
      NeuEintrag @{ a = 'sarah'; i = "sarah:$n"; t = (Paar $td[1] (En $td[1] 'sarah')); r = (Paar "$($td[0]) · $($td[2])" "$($td[0]) · $(En $td[2] 'sarah')"); k = 'wiederkehrend recurring'; b = (Paar 'Wiederkehrend' 'Recurring'); u = $sarahSeite }
    }
  }
}

# 7. GitHub-Trainer: Kapitel, Befehle, Fragen
Quelle 'github' 20 {
  $gt = Lies '02_Erstellte_Apps\05_github_trainer\index.html'
  $script:JKonst['DOC'] = (JsKonstante $gt 'DOC')
  $ch = JsKonstante $gt 'CH'
  $u = '02_Erstellte_Apps/05_github_trainer/index.html'
  $ci = 0
  foreach ($c in $ch) {
    $ci++
    $tDe = $c['t'][0]; $tEn = $c['t'][1]
    NeuEintrag @{ a = 'github'; i = "github:k$ci"; t = (Paar $tDe $tEn); r = (Paar $c['sub'][0] $c['sub'][1]); x = (Paar $c['intro'][0] $c['intro'][1]); b = (Paar "Kapitel $ci" "Chapter $ci"); u = $u }
    $ki = 0
    foreach ($k in $c['keys']) {
      $ki++
      NeuEintrag @{ a = 'github'; i = "github:k$ci`:b$ki"; t = (Paar $k[0] $k[0]); r = (Paar $tDe $tEn); x = (Paar $k[1][0] $k[1][1]); b = (Paar 'Befehl' 'Command'); u = $u }
    }
    $qi = 0
    foreach ($q in $c['q']) {
      $qi++
      NeuEintrag @{ a = 'github'; i = "github:k$ci`:q$qi"; t = (Paar $q['q'][0] $q['q'][1]); r = (Paar $tDe $tEn); x = (Paar $q['e'][0] $q['e'][1]); k = [string]$q['cmd']; b = (Paar 'Frage' 'Question'); u = $u }
    }
  }
}

# 8. Ninox-4-Architektur (Bericht von Archie): nur index.html, Abschnitte mit Ueberschrift und Text; optional (fehlt die Seite, gibt es keine Eintraege). Der Ordner "personalisiert" wird nie gelesen.
Quelle 'ninox4' 0 {
  $rel = '02_Erstellte_Apps\06_ninox4_architektur\index.html'
  if (-not (Test-Path -LiteralPath (Join-Path $root $rel))) { return }
  $h = Lies $rel
  $mi = $h.IndexOf('<main'); $me = $h.LastIndexOf('</main>')
  if ($mi -lt 0 -or $me -le $mi) { throw "kein main-Bereich" }
  $h = $h.Substring($mi, $me - $mi)
  $dec = { param($s) Glatt ([Net.WebUtility]::HtmlDecode(($s -replace '<[^>]+>', ' '))) }
  foreach ($s in [regex]::Matches($h, '(?s)<section[^>]*\sid="([^"]+)"[^>]*>(.*?)</section>')) {
    $id = $s.Groups[1].Value; $body = $s.Groups[2].Value
    $hm = [regex]::Match($body, '(?s)<h2[^>]*>(.*?)</h2>')
    if (-not $hm.Success) { continue }
    $tm = [regex]::Match($hm.Groups[1].Value, '(?s)<span[^>]*data-en="([^"]*)"[^>]*>([^<]*)</span>')
    if ($tm.Success) { $tDe = & $dec $tm.Groups[2].Value; $tEn = & $dec $tm.Groups[1].Value } else { $tDe = & $dec $hm.Groups[1].Value; $tEn = '' }
    $rest = $body.Replace($hm.Value, '')
    $de = New-Object Collections.ArrayList; $en = New-Object Collections.ArrayList
    foreach ($p in [regex]::Matches($rest, '(?s)<(li|p|td|th|dd|dt)\b([^>]*)>(.*?)</\1>')) {
      $d1 = & $dec $p.Groups[3].Value
      if (-not $d1) { continue }
      [void]$de.Add($d1)
      $em = [regex]::Match($p.Groups[2].Value, 'data-en="([^"]*)"')
      if ($em.Success) { [void]$en.Add((& $dec $em.Groups[1].Value)) } else { [void]$en.Add($d1) }
    }
    $xDe = ($de -join ' · '); $xEn = ($en -join ' · ')
    if ($xDe.Length -gt 2500) { $xDe = $xDe.Substring(0, 2500) }
    if ($xEn.Length -gt 2500) { $xEn = $xEn.Substring(0, 2500) }
    NeuEintrag @{ a = 'ninox4'; i = "ninox4:$id"; t = (Paar $tDe $tEn); x = (Paar $xDe $xEn); k = 'architektur architecture archie intern'; b = (Paar 'Bericht (intern)' 'Report (internal)'); u = "02_Erstellte_Apps/06_ninox4_architektur/index.html#$id" }
  }
}

if ($fehlerListe.Count -gt 0) {
  foreach ($f in $fehlerListe) { [Console]::Error.WriteLine("FEHLER: $f") }
  [Console]::Error.WriteLine("Suchindex NICHT geschrieben (Quellfehler).")
  exit 2
}

# ---------- Datenschutz-Pruefung: keine Zugangsdaten-Muster in den Texten ----------
$verdacht = New-Object Collections.ArrayList
foreach ($e in $script:Eintraege) {
  foreach ($k in 't', 'r', 'x', 'k') {
    if (-not $e.Contains($k)) { continue }
    $txt = (@($e[$k]) -join ' ')
    if ($txt -match '(?i)(password|passwort|kennwort|secret|bearer)\s*[:=]\s*\S+' -or $txt -match 'eyJ[A-Za-z0-9_-]{20,}' -or $txt -match '(?<![A-Za-z0-9])[A-Za-z0-9+/]{40,}(?![A-Za-z0-9])') { [void]$verdacht.Add("$($e['i']) ($k)") }
  }
}
if ($verdacht.Count -gt 0) { [Console]::Error.WriteLine("FEHLER: Verdacht auf Zugangsdaten im Index: " + ($verdacht -join ', ')); exit 2 }

# ---------- Index bauen ----------
$appsMeta = @(
  [ordered]@{ id = 'org'; n = (Paar 'Organigramm' 'Org chart'); ic = 'diagram-3'; u = 'firma.htm' },
  [ordered]@{ id = 'agenten'; n = (Paar 'Agenten & Skills' 'Agents & Skills'); ic = 'grid-3x3-gap'; u = '02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html' },
  [ordered]@{ id = 'todo'; n = (Paar 'To-dos' 'To-dos'); ic = 'check2-square'; u = '02_Erstellte_Apps/03_todo/index.html'; live = 1 },
  [ordered]@{ id = 'favoriten'; n = (Paar 'Favoriten' 'Favorites'); ic = 'star'; u = '02_Erstellte_Apps/04_favoriten/index.html' },
  [ordered]@{ id = 'tagesberichte'; n = (Paar 'Tagesberichte' 'Daily reports'); ic = 'journal-text'; u = '03_Tagesberichte/tagesberichte.html' },
  [ordered]@{ id = 'sarah'; n = (Paar 'Sarahs Übersicht' "Sarah's overview"); ic = 'bell-fill'; u = $sarahSeite },
  [ordered]@{ id = 'github'; n = (Paar 'GitHub-Trainer' 'GitHub trainer'); ic = 'github'; u = '02_Erstellte_Apps/05_github_trainer/index.html' },
  [ordered]@{ id = 'ninox4'; n = (Paar 'Ninox-4-Architektur' 'Ninox 4 architecture'); ic = 'diagram-2'; u = '02_Erstellte_Apps/06_ninox4_architektur/index.html' },
  [ordered]@{ id = 'apps'; n = (Paar 'Erstellte Apps' 'Created apps'); ic = 'grid'; u = 'firma.htm' }
)
$zeilen = @($script:Eintraege | ForEach-Object { Json $_ })
$kern = '"apps":' + (Json $appsMeta) + ',"eintraege":[' + "`n" + ($zeilen -join ",`n") + "`n]"
$sha = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($u8.GetBytes($kern))).Replace('-', '').ToLower()
function Baue([string]$stempel) {
  return "/* NX-SUCHINDEX: statischer Suchindex fuer die globale Suche (firma.htm). Erzeugt von suchindex-erstellen.ps1, NICHT von Hand aendern. */`n" +
    'window.NX_SUCHINDEX = {"version":1,"erzeugt":' + (JsonText $stempel) + ',"pruefsumme":"' + $sha + '","anzahl":' + $script:Eintraege.Count + ',' + $kern + "};`n"
}

if ($Pruefen) {
  if (-not (Test-Path -LiteralPath $ziel)) { Write-Output "Index fehlt: suchindex-erstellen.ps1 ausfuehren"; exit 1 }
  $alt = [IO.File]::ReadAllText($ziel, $u8)
  $st = [regex]::Match($alt, '"erzeugt":"([^"]*)"').Groups[1].Value
  if ($alt -eq (Baue $st)) { Write-Output "Suchindex aktuell ($($script:Eintraege.Count) Eintraege, Pruefsumme $($sha.Substring(0,12)))"; exit 0 }
  $altSha = [regex]::Match($alt, '"pruefsumme":"([0-9a-f]+)"').Groups[1].Value
  $altN = [regex]::Match($alt, '"anzahl":(\d+)').Groups[1].Value
  Write-Output "Index veraltet: suchindex-erstellen.ps1 ausfuehren (Datei: $altN Eintraege, Pruefsumme $($altSha.Substring(0,[Math]::Min(12,$altSha.Length))); Quellen: $($script:Eintraege.Count) Eintraege, Pruefsumme $($sha.Substring(0,12)))"
  exit 1
}

$stempel = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
[IO.File]::WriteAllText($ziel, (Baue $stempel), $u8)
Write-Output "Suchindex geschrieben: $ziel"
Write-Output "Eintraege gesamt: $($script:Eintraege.Count), Groesse: $([Math]::Round((Get-Item $ziel).Length / 1024)) KB, Pruefsumme $($sha.Substring(0,12))"
foreach ($k in $zaehlung.Keys) { Write-Output ("  {0,-14} {1}" -f $k, $zaehlung[$k]) }
exit 0
