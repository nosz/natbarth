/* Globale Suche (NX) fuer firma.htm: durchsucht den statischen Suchindex (suchindex.js, erzeugt von suchindex-erstellen.ps1) und liest To-dos und eigene Favoriten LIVE aus dem Browser-Speicher.
   Laeuft auch bei file:// (kein fetch). Merkt sich nichts Persoenliches (keine Suchhistorie); der Suchbegriff darf als #s=... in der Adresse stehen.
   Erwartet in der Seite: #sgQ (Eingabe .nx-search-input), #sgClear, #sgChips, #sgStatus, #sgResults. Verhalten des Feldes (Taste /, Esc, Loeschknopf) kommt von suche.js.
   Eigene Texte Deutsch/Englisch stehen in S unten (firma.htm uebersetzt nur Kopf und Fuss ueber den Standard-Uebersetzer). Sprache: window.nxLang(), Ereignis "nx-lang". */
(function () {
  "use strict";
  var TODO_KEY = "nobbis-todos-v1", FAV_KEY = "norbert-favoriten";
  var MIN = 2, WARTE = 120, LIMIT = 6, SNIPPET = 140;

  var S = {
    de: {
      label: "Alle Apps durchsuchen", ph: "Suchen: in allen Apps (z. B. Outlook, git commit, Willi)", clear: "Suche leeren", chipsAria: "Nach App filtern", all: "Alle",
      min: "Bitte mindestens 2 Zeichen eingeben.", none: "Keine Treffer", errBadge: "Suchindex nicht verfügbar",
      emptyTitle: "Keine Treffer für „{q}“", emptyHint: "Versuche einen anderen Begriff oder weniger Wörter.", sugg: "Vorschläge",
      errTitle: "Der Suchindex ist nicht verfügbar", errText: "Die Datei 02_Erstellte_Apps/_standard/suchindex.js fehlt oder ist leer. Bitte suchindex-erstellen.ps1 ausführen. To-dos und eigene Favoriten werden trotzdem durchsucht.",
      more: "Alle {n} anzeigen", less: "Weniger anzeigen", open: "offen", done: "erledigt", due: "fällig {d}", overdue: "überfällig", star: "Mit Stern", ext: "öffnet in neuem Tab",
      todo: "To-do", reminder: "Erinnerung", ownFav: "Eigener Favorit", foot: "Suchindex vom {d} · {n} Einträge. To-dos und Erinnerungen kommen live aus der zentralen Liste, eigene Favoriten aus diesem Browser.", footNoDate: "{n} Einträge. To-dos und Erinnerungen kommen live aus der zentralen Liste, eigene Favoriten aus diesem Browser."
    },
    en: {
      label: "Search all apps", ph: "Search: across all apps (e.g. Outlook, git commit, Willi)", clear: "Clear search", chipsAria: "Filter by app", all: "All",
      min: "Please enter at least 2 characters.", none: "No results", errBadge: "Search index not available",
      emptyTitle: "No results for “{q}”", emptyHint: "Try a different term or fewer words.", sugg: "Suggestions",
      errTitle: "The search index is not available", errText: "The file 02_Erstellte_Apps/_standard/suchindex.js is missing or empty. Please run suchindex-erstellen.ps1. To-dos and your own favorites are still searched.",
      more: "Show all {n}", less: "Show fewer", open: "open", done: "done", due: "due {d}", overdue: "overdue", star: "Starred", ext: "opens in a new tab",
      todo: "To-do", reminder: "Reminder", ownFav: "My favorite", foot: "Search index from {d} · {n} entries. To-dos and reminders come live from the central list, your own favorites from this browser.", footNoDate: "{n} entries. To-dos and reminders come live from the central list, your own favorites from this browser."
    }
  };
  var VORSCHLAEGE = { de: ["Outlook", "git commit", "Willi", "Tagesabschluss"], en: ["Outlook", "git commit", "Willi", "Reminder"] };
  var FALLBACK_APPS = [
    { id: "todo", n: ["To-dos", ""], ic: "check2-square", u: "02_Erstellte_Apps/03_todo/index.html" },
    { id: "favoriten", n: ["Favoriten", "Favorites"], ic: "star", u: "02_Erstellte_Apps/04_favoriten/index.html" }
  ];

  var q, clearBtn, chips, status, results, main, bar;
  var state = { q: "", app: "all", expanded: {}, active: -1, hits: [], timer: 0 };
  var prep = { src: undefined, list: [], apps: [], ok: false, erzeugt: "", n: 0 };

  function lang() { return (window.nxLang && window.nxLang() === "en") ? "en" : "de"; }
  function tx(key, v) { var s = (S[lang()] || S.de)[key] || S.de[key] || key; if (v) for (var k in v) s = s.split("{" + k + "}").join(v[k]); return s; }
  function pick(arr) { if (!arr) return ""; return (lang() === "en" && arr[1]) ? arr[1] : (arr[0] || ""); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  // Normalisierung: Gross/Klein egal, Akzente und Umlaute werden zum Grundbuchstaben (das u mit Umlautpunkten wird u), das scharfe S wird ss,
  // und die Umschreibungen ae, oe, ue werden zu a, o, u. So finden "uebersicht" und "Übersicht" (ue = ü) sowie "pruefung" und "Prüfung" dasselbe.
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\u00df/g, "ss").replace(/([aou])e/g, "$1"); }
  // Normalisierter Text mit Zuordnung jeder Position zurueck in den Originaltext (Anfang/Ende), fuer Markierung und Ausschnitt
  function nmap(s) {
    var raw = [], i, k, d, j, ms = [], me = [], n = "";
    for (i = 0; i < s.length; i++) {
      d = s.charAt(i).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\u00df/g, "ss");
      for (k = 0; k < d.length; k++) raw.push([d.charAt(k), i, i + 1]);
    }
    for (j = 0; j < raw.length; j++) {
      if (/[aou]/.test(raw[j][0]) && j + 1 < raw.length && raw[j + 1][0] === "e") { n += raw[j][0]; ms.push(raw[j][1]); me.push(raw[j + 1][2]); j++; }
      else { n += raw[j][0]; ms.push(raw[j][1]); me.push(raw[j][2]); }
    }
    return { n: n, ms: ms, me: me };
  }
  function ranges(text, tokens) {
    var m = nmap(text), hit = [], i, p, t;
    for (t = 0; t < tokens.length; t++) {
      if (!tokens[t]) continue;
      p = m.n.indexOf(tokens[t]);
      while (p !== -1) { hit.push([m.ms[p], m.me[p + tokens[t].length - 1]]); p = m.n.indexOf(tokens[t], p + 1); }
    }
    hit.sort(function (a, b) { return a[0] - b[0]; });
    var out = [];
    for (i = 0; i < hit.length; i++) { if (out.length && hit[i][0] <= out[out.length - 1][1]) out[out.length - 1][1] = Math.max(out[out.length - 1][1], hit[i][1]); else out.push(hit[i].slice()); }
    return out;
  }  function mark(text, tokens) {
    var r = ranges(text, tokens), out = "", pos = 0, i;
    for (i = 0; i < r.length; i++) { out += esc(text.slice(pos, r[i][0])) + "<mark>" + esc(text.slice(r[i][0], r[i][1])) + "</mark>"; pos = r[i][1]; }
    return out + esc(text.slice(pos));
  }
  function snippet(text, tokens) {
    text = String(text || "");
    if (!text) return "";
    var r = ranges(text, tokens);
    if (!r.length) return esc(text.length > SNIPPET ? text.slice(0, SNIPPET).replace(/\s+\S*$/, "") + " …" : text);
    var start = Math.max(0, r[0][0] - 50), end;
    if (start > 0) { var sp = text.indexOf(" ", start); if (sp !== -1 && sp < r[0][0]) start = sp + 1; }
    end = Math.min(text.length, start + SNIPPET);
    if (end < text.length) { var ep = text.lastIndexOf(" ", end); if (ep > r[0][1]) end = ep; }
    var part = text.slice(start, end);
    return (start > 0 ? "… " : "") + mark(part, tokens) + (end < text.length ? " …" : "");
  }

  // ---------- Index und Live-Quellen ----------
  function vorbereiten(e) {
    if (!e || !e.t || !e.a) return null;
    return { e: e, t0: norm(e.t[0]), t1: norm(e.t[1] || ""), nr: norm((e.r ? e.r[0] + " " + (e.r[1] || "") : "") + " " + (e.k || "")), nx: norm(e.x ? e.x[0] + " " + (e.x[1] || "") : "") };
  }
  function prepare() {
    var idx = window.NX_SUCHINDEX;
    if (prep.src === idx && idx !== undefined) return prep;
    prep = { src: idx, list: [], apps: [], ok: false, erzeugt: "", n: 0 };
    try {
      if (idx && Array.isArray(idx.eintraege) && idx.eintraege.length && Array.isArray(idx.apps)) {
        idx.eintraege.forEach(function (e) { var w = vorbereiten(e); if (w) prep.list.push(w); });
        prep.apps = idx.apps.slice();
        prep.ok = prep.list.length > 0;
        prep.erzeugt = idx.erzeugt || "";
        prep.n = prep.list.length;
      }
    } catch (x) { prep.ok = false; prep.list = []; }
    FALLBACK_APPS.forEach(function (f) { if (!prep.apps.some(function (a) { return a.id === f.id; })) prep.apps.push(f); });
    return prep;
  }
  // To-dos und Erinnerungen: LIVE aus der zentralen Liste (Spiegel window.NX_TODOS + Browser-Cache, zusammengefuehrt je id, ohne Geloeschte; siehe zaehler.js window.nxTodoListe).
  // Rueckfall ohne zaehler.js: nur der Browser-Cache der To-do-App.
  function todoQuelle() {
    var a = null;
    try { if (typeof window.nxTodoListe === "function") a = window.nxTodoListe(); } catch (x) { a = null; }
    if (a) return a;
    try { var raw = localStorage.getItem(TODO_KEY), c = raw ? JSON.parse(raw) : null; return Array.isArray(c) ? c : []; } catch (x) { return []; }
  }
  function liveTodos() {
    var out = [];
    try {
      todoQuelle().slice(0, 2000).forEach(function (t, i) {
        if (!t || t.geloescht || typeof t.text !== "string" || !t.text.trim()) return;
        var due = (typeof t.due === "string" && /^\d{4}-\d{2}-\d{2}$/.test(t.due)) ? t.due : "";
        var sarah = t.quelle === "sarah";
        var hint = String(t.hinweis || "").replace(/https?:\/\/\S+/g, "").replace(/\bLink:\s*/gi, "").replace(/\s+/g, " ").trim().slice(0, 300);
        var e = { a: "todo", i: "todo:" + (t.id || i), t: [t.text.trim().slice(0, 300), ""], b: sarah ? [S.de.reminder, S.en.reminder] : [S.de.todo, S.en.todo], u: "02_Erstellte_Apps/03_todo/index.html", s: t.done ? "done" : "open", d: due };
        if (hint) e.x = [hint, ""];
        if (sarah) e.k = "sarah erinnerung reminder";
        var w = vorbereiten(e);
        if (w) { w.e.star = t.star ? 1 : 0; out.push(w); }
      });
    } catch (x) { }
    return out;
  }  function liveFavoriten() {
    var out = [];
    try {
      var raw = localStorage.getItem(FAV_KEY);
      if (!raw) return out;
      var a = JSON.parse(raw);
      if (!Array.isArray(a)) return out;
      a.slice(0, 500).forEach(function (f, i) {
        if (!f || typeof f.name !== "string" || typeof f.url !== "string" || !/^https?:\/\//i.test(f.url.trim())) return;
        var host = ""; try { host = new URL(f.url.trim()).hostname; } catch (x) { return; }
        var w = vorbereiten({ a: "favoriten", i: "favoriten:eigen:" + i, t: [f.name.trim().slice(0, 200) || host, ""], x: [host, ""], b: [S.de.ownFav, S.en.ownFav], u: f.url.trim(), ext: 1 });
        if (w) out.push(w);
      });
    } catch (x) { }
    return out;
  }
  function safeUrl(u) { u = String(u || ""); return (/^[a-z][a-z0-9+.-]*:/i.test(u) && !/^https?:/i.test(u)) ? "#" : u; }

  // ---------- Suche ----------
  function score(w, tokens) {
    var total = 0, i, t, s;
    for (i = 0; i < tokens.length; i++) {
      t = tokens[i]; s = 0;
      if (w.t0 === t || w.t1 === t) s = 100;
      else if (w.t0.indexOf(t) === 0 || (w.t1 && w.t1.indexOf(t) === 0)) s = 60;
      else if ((" " + w.t0).indexOf(" " + t) !== -1 || (" " + w.t1).indexOf(" " + t) !== -1) s = 50;
      else if (w.t0.indexOf(t) !== -1 || w.t1.indexOf(t) !== -1) s = 40;
      else if (w.nr.indexOf(t) !== -1) s = 25;
      else if (w.nx.indexOf(t) !== -1) s = 10;
      if (!s) return 0;
      total += s;
    }
    return total;
  }
  function suchen(query) {
    var tokens = norm(query).split(/\s+/).filter(Boolean);
    var p = prepare();
    var all = p.list.concat(liveTodos(), liveFavoriten());
    var hits = [];
    all.forEach(function (w) { var s = score(w, tokens); if (s > 0) hits.push({ w: w, s: s }); });
    hits.sort(function (a, b) { return b.s - a.s || pick(a.w.e.t).localeCompare(pick(b.w.e.t), lang()); });
    return { tokens: tokens, hits: hits, p: p };
  }

  // ---------- Darstellung ----------
  function fmtDate(iso) { return iso ? iso.split("-").reverse().join(".") : ""; }
  function heute() { var d = new Date(); return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); }
  function appOf(p, id) { for (var i = 0; i < p.apps.length; i++) if (p.apps[i].id === id) return p.apps[i]; return { id: id, n: [id, ""], ic: "search", u: "" }; }

  function itemHtml(h, tokens, p, n) {
    var e = h.e || h.w.e, a = appOf(p, e.a), href = safeUrl(e.u), ext = !!e.ext, person = e.p;
    var attrs = ' id="sgI' + n + '" class="nx-card sg-item" href="' + esc(person ? "#person=" + person : href) + '"';
    if (person) attrs += ' data-p="' + esc(person) + '"';
    if (e.kl) attrs += " data-nx-keinlang";
    if (ext) attrs += ' target="_blank" rel="noopener noreferrer" title="' + esc(tx("ext")) + '"';
    var title = mark(pick(e.t), tokens), sub = e.r ? pick(e.r) : "", sn = e.x ? snippet(pick(e.x), tokens) : "";
    var b = '<span class="sg-badges">';
    if (e.b) b += '<span class="sg-badge">' + esc(pick(e.b)) + "</span>";
    b += '<span class="sg-badge sg-badge-app">' + esc(pick(a.n)) + "</span>";
    if (e.s === "open" || e.s === "done") b += '<span class="sg-badge sg-st-' + e.s + '">' + esc(tx(e.s)) + "</span>";
    if (e.a === "todo" && e.d) {
      var over = e.s === "open" && e.d < heute();
      b += '<span class="sg-badge' + (over ? " sg-st-over" : "") + '">' + esc(over ? tx("overdue") + " · " + fmtDate(e.d) : tx("due", { d: fmtDate(e.d) })) + "</span>";
    }
    if (e.star) b += '<span class="sg-badge sg-star" title="' + esc(tx("star")) + '"><i class="bi bi-star-fill" aria-hidden="true"></i><span class="nx-visually-hidden">' + esc(tx("star")) + "</span></span>";
    b += "</span>";
    return '<div role="listitem"><a' + attrs + '><span class="sg-ic"><i class="bi bi-' + esc(a.ic) + '" aria-hidden="true"></i></span><span class="sg-body"><span class="sg-title">' + title + "</span>" +
      (sub ? '<span class="sg-sub">' + mark(sub, tokens) + "</span>" : "") + (sn ? '<span class="sg-snip">' + sn + "</span>" : "") + b + '</span><i class="bi bi-' + (ext ? "box-arrow-up-right" : "arrow-right") + ' sg-go" aria-hidden="true"></i></a></div>';
  }
  function plural(n, one, many) { return n === 1 ? one : many; }
  function summe(n, m) {
    return lang() === "en" ? n + " " + plural(n, "result", "results") + " in " + m + " " + plural(m, "app", "apps") : n + " Treffer in " + m + " " + plural(m, "App", "Apps");
  }

  function render() {
    var query = state.q.trim(), aktiv = query.length >= MIN;
    main.classList.toggle("sg-aktiv", aktiv);
    results.hidden = !aktiv;
    chips.hidden = !aktiv;
    q.setAttribute("aria-expanded", aktiv ? "true" : "false");
    q.removeAttribute("aria-activedescendant");
    state.active = -1;
    clearBtn.hidden = !q.value;
    if (!aktiv) {
      results.innerHTML = ""; chips.innerHTML = "";
      status.textContent = query ? tx("min") : "";
      return;
    }
    var r = suchen(query), p = r.p, tokens = r.tokens;
    state.hits = r.hits;
    var counts = {}, order = [];
    p.apps.forEach(function (a) { counts[a.id] = 0; });
    r.hits.forEach(function (h) { counts[h.w.e.a] = (counts[h.w.e.a] || 0) + 1; });
    p.apps.forEach(function (a) { if (counts[a.id] > 0) order.push(a.id); });
    if (state.app !== "all" && order.indexOf(state.app) === -1) state.app = "all";
    // Filterchips
    var ch = '<button type="button" class="nx-chip" data-app="all" aria-pressed="' + (state.app === "all") + '">' + esc(tx("all")) + ' <span class="count">' + r.hits.length + "</span></button>";
    order.forEach(function (id) {
      var a = appOf(p, id);
      ch += '<button type="button" class="nx-chip" data-app="' + esc(id) + '" aria-pressed="' + (state.app === id) + '"><i class="bi bi-' + esc(a.ic) + '" aria-hidden="true"></i>' + esc(pick(a.n)) + ' <span class="count">' + counts[id] + "</span></button>";
    });
    chips.setAttribute("aria-label", tx("chipsAria"));
    var hadFocus = document.activeElement && document.activeElement.closest && document.activeElement.closest("#sgChips") ? document.activeElement.getAttribute("data-app") : null;
    chips.innerHTML = ch;
    if (hadFocus !== null) { var f = chips.querySelector('[data-app="' + hadFocus.replace(/"/g, "") + '"]'); if (f) f.focus(); }
    // Ergebnisse
    var html = "", n = 0, shown = 0, gruppen = 0;
    if (!p.ok) html += '<div class="nx-empty sg-error" role="alert"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i><p class="mb-1 fw-semibold">' + esc(tx("errTitle")) + '</p><p class="mb-0 small">' + esc(tx("errText")) + "</p></div>";
    order.forEach(function (id) {
      if (state.app !== "all" && state.app !== id) return;
      var a = appOf(p, id), list = r.hits.filter(function (h) { return h.w.e.a === id; });
      var cap = (state.app === id || state.expanded[id]) ? list.length : LIMIT;
      gruppen++;
      html += '<section class="sg-group" aria-labelledby="sgH-' + esc(id) + '"><h2 class="nx-h2" id="sgH-' + esc(id) + '"><i class="bi bi-' + esc(a.ic) + '" aria-hidden="true"></i><span>' + esc(pick(a.n)) + '</span><span class="sg-count">' + list.length + '</span></h2><div class="sg-list" role="list">';
      list.slice(0, cap).forEach(function (h) { html += itemHtml(h, tokens, p, n++); shown++; });
      html += "</div>";
      if (list.length > LIMIT && state.app !== id) html += '<button type="button" class="nx-btn-secondary nx-btn-sm sg-more" data-more="' + esc(id) + '" aria-expanded="' + (cap === list.length) + '">' + esc(cap === list.length ? tx("less") : tx("more", { n: list.length })) + "</button>";
      html += "</section>";
    });
    if (!r.hits.length) {
      html += '<div class="nx-empty"><i class="bi bi-search" aria-hidden="true"></i><p class="mb-1 fw-semibold">' + esc(tx("emptyTitle", { q: query })) + '</p><p class="mb-3 small">' + esc(tx("emptyHint")) + '</p><div class="sg-sugg"><span class="nx-chip-label">' + esc(tx("sugg")) + "</span>";
      VORSCHLAEGE[lang()].forEach(function (s) { html += '<button type="button" class="nx-chip" data-sugg="' + esc(s) + '">' + esc(s) + "</button>"; });
      html += "</div></div>";
    } else {
      var d = "";
      if (p.erzeugt) { try { d = new Date(p.erzeugt).toLocaleString(lang() === "en" ? "en-GB" : "de-DE", { dateStyle: "medium", timeStyle: "short" }); } catch (x) { d = p.erzeugt; } }
      if (p.ok) html += '<p class="nx-hint sg-foot">' + esc(d ? tx("foot", { d: d, n: p.n }) : tx("footNoDate", { n: p.n })) + "</p>";
    }
    results.innerHTML = html;
    // Status
    if (!r.hits.length) status.textContent = p.ok ? tx("none") : tx("errBadge") + " · " + tx("none");
    else if (state.app === "all") status.textContent = summe(r.hits.length, order.length) + (p.ok ? "" : " · " + tx("errBadge"));
    else status.textContent = (lang() === "en" ? counts[state.app] + " " + plural(counts[state.app], "result", "results") + " in " + pick(appOf(p, state.app).n) + " (" + r.hits.length + " in total)" : counts[state.app] + " " + plural(counts[state.app], "Treffer", "Treffer") + " in " + pick(appOf(p, state.app).n) + " (von " + r.hits.length + " insgesamt)");
  }
  function texte() {
    var l = document.querySelector('label[for="sgQ"]');
    if (l) l.textContent = tx("label");
    q.setAttribute("placeholder", tx("ph"));
    clearBtn.setAttribute("aria-label", tx("clear"));
    clearBtn.setAttribute("title", tx("clear"));
  }

  // ---------- Bedienung ----------
  function links() { return Array.prototype.slice.call(results.querySelectorAll("a.sg-item")); }
  function setActive(n) {
    var L = links(), i;
    for (i = 0; i < L.length; i++) L[i].classList.remove("is-active");
    state.active = n;
    if (n < 0 || !L[n]) { state.active = -1; q.removeAttribute("aria-activedescendant"); return; }
    L[n].classList.add("is-active");
    q.setAttribute("aria-activedescendant", L[n].id);
    if (L[n].scrollIntoView) L[n].scrollIntoView({ block: "nearest" });
  }
  function adresse() {
    try {
      var h = location.hash || "";
      if (state.q.trim().length >= MIN) history.replaceState(null, "", "#s=" + encodeURIComponent(state.q.trim()));
      else if (/^#s=/.test(h)) history.replaceState(null, "", location.pathname + location.search);
    } catch (e) { }
  }
  function lauf() { clearTimeout(state.timer); state.timer = 0; render(); adresse(); }
  function eingabe() {
    var neu = q.value;
    if (neu !== state.q) { state.q = neu; state.expanded = {}; state.app = "all"; }
    clearTimeout(state.timer);
    if (!neu.trim()) { lauf(); return; }
    state.timer = setTimeout(lauf, WARTE);
  }
  function ausAdresse() {
    var m = /^#s=(.*)$/.exec(location.hash || "");
    if (!m) return false;
    var v = ""; try { v = decodeURIComponent(m[1]); } catch (e) { return false; }
    if (v === state.q) return true;
    q.value = v; state.q = v; state.app = "all"; state.expanded = {};
    lauf();
    return true;
  }

  function init() {
    q = document.getElementById("sgQ"); results = document.getElementById("sgResults");
    if (!q || !results) return;
    clearBtn = document.getElementById("sgClear"); chips = document.getElementById("sgChips"); status = document.getElementById("sgStatus");
    main = q.closest("main") || document.body; bar = document.getElementById("sgBar");
    texte();
    q.addEventListener("input", eingabe);
    q.addEventListener("keydown", function (e) {
      var L;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        L = links(); if (!L.length) return;
        e.preventDefault();
        var n = state.active + (e.key === "ArrowDown" ? 1 : -1);
        setActive(Math.max(-1, Math.min(L.length - 1, n)));
      } else if (e.key === "Enter") {
        if (state.timer) lauf();
        L = links(); if (!L.length) return;
        e.preventDefault();
        L[state.active >= 0 ? state.active : 0].click();
      }
    });
    results.addEventListener("keydown", function (e) {
      var a = document.activeElement, L = links(), i = L.indexOf(a);
      if ((e.key === "ArrowDown" || e.key === "ArrowUp") && i !== -1) {
        e.preventDefault();
        if (e.key === "ArrowDown") { if (i < L.length - 1) L[i + 1].focus(); } else if (i > 0) L[i - 1].focus(); else q.focus();
      } else if (e.key === "Escape") { q.value = ""; eingabe(); q.focus(); }
    });
    results.addEventListener("click", function (e) {
      var t = e.target.closest("[data-more],[data-sugg],a[data-p]");
      if (!t) return;
      if (t.hasAttribute("data-more")) { var id = t.getAttribute("data-more"); state.expanded[id] = !state.expanded[id]; render(); var b = results.querySelector('[data-more="' + id + '"]'); if (b) b.focus(); }
      else if (t.hasAttribute("data-sugg")) { q.value = t.getAttribute("data-sugg"); state.q = q.value; state.app = "all"; state.expanded = {}; lauf(); q.focus(); }
      else if (t.hasAttribute("data-p") && typeof window.nxOeffnePerson === "function") { e.preventDefault(); window.nxOeffnePerson(t.getAttribute("data-p")); }
    });
    chips.addEventListener("click", function (e) {
      var t = e.target.closest("[data-app]");
      if (!t) return;
      var id = t.getAttribute("data-app");
      state.app = (state.app === id) ? "all" : id;
      render();
    });
    window.addEventListener("nx-lang", function () { texte(); render(); });
    window.addEventListener("hashchange", ausAdresse);
    // Esc ausserhalb des Feldes (z. B. Fokus auf einem Chip) leert ebenfalls
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape" || !state.q || document.activeElement === q) return;
      if (document.querySelector(".modal.show")) return;
      if (chips.contains(document.activeElement)) { q.value = ""; eingabe(); q.focus(); }
    });
    window.nxSuche = { lauf: lauf, suchen: suchen, state: state, render: render, setze: function (v) { q.value = v; q.dispatchEvent(new Event("input", { bubbles: true })); lauf(); } };
    if (!ausAdresse()) render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
