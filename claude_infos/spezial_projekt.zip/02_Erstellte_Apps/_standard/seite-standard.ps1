﻿# Setzt Kopfbereich, Fußzeile und Stil (Marker NX-KOPF / NX-FUSS / nx-stil) einheitlich in eine HTML-Seite ein.
# Läuft beliebig oft; ersetzt vorhandene Standard-Blöcke. Vorlage und Regeln: STANDARD.md in diesem Ordner.
#
# Beispiel:
#   .\seite-standard.ps1 -Seite ..\..\03_Tagesberichte\tagesberichte.html -Aktiv tagesberichte `
#       -Titel "Tagesberichte" -Icon journal-text -Untertitel "Was habe ich wann gemacht?" -Version 1.1.0
param(
  [Parameter(Mandatory)] [string]$Seite,
  [Parameter(Mandatory)] [string]$Titel,
  [Parameter(Mandatory)] [string]$Icon,            # Bootstrap-Icon ohne "bi-"
  [string]$Untertitel = "",
  [string]$Aktiv = "",                              # organigramm|agenten|todo|favoriten|tagesberichte (leer = keiner)
  [string]$Version = "",                            # leer = vorhandene meta app-version behalten
  [string]$Seitenkey = "",                          # Abschnitt in woerterbuch.json (firma|agenten|todo|favoriten|tagesberichte|sarah); leer = nur allgemeine Wörter
  [switch]$NurKopf,
  [switch]$Oeffentlich,                             # öffentliche Seite (z. B. Veranstaltung): Kopf nur mit Ninox-Logo, ohne Firmenname, ohne interne Navigation, ohne To-do-Spiegel                                 # Übersetzer wirkt nur auf Kopf/Fuß (Seite mit eigener Übersetzung, z. B. firma.htm)
  [string]$TitelZeile = "",                         # optional: komplette Titelzeile ersetzen (z. B. änderbarer Titel)
  [string]$NachTitel = "",                          # optional: HTML nach dem Untertitel (z. B. Formular)
  [string]$FussLinks = ""                           # optional: HTML links in der Fußzeile
)
$ErrorActionPreference = "Stop"
$utf8 = New-Object System.Text.UTF8Encoding($false)
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$pfad = (Resolve-Path $Seite).Path
$logo = [IO.File]::ReadAllText((Join-Path $PSScriptRoot "logo.svg"), $utf8)
$c = [IO.File]::ReadAllText($pfad, $utf8)
$S = [Text.RegularExpressions.RegexOptions]::Singleline

# Relativer Pfad von der Seite zum Hauptordner
$von = New-Object Uri(($pfad.Substring(0, $pfad.LastIndexOf('\') + 1)))
function Rel($ziel) { [Uri]::UnescapeDataString($von.MakeRelativeUri((New-Object Uri((Join-Path $root $ziel)))).ToString()) }

# Immer gleiche Reihenfolge der Knöpfe
$nav = @(
  @{ id = "organigramm";    ziel = "firma.htm";                                          icon = "diagram-3";       text = "Organigramm";    i18n = "navOrg" },
  @{ id = "agenten";        ziel = "02_Erstellte_Apps\02_agenten_skills_uebersicht\index.html"; icon = "grid-3x3-gap";    text = "Agenten &amp; Skills"; i18n = "navAgents" },
  @{ id = "todo";           ziel = "02_Erstellte_Apps\03_todo\index.html";                  icon = "check2-square";   text = "To-dos";         i18n = "navTodo" },
  @{ id = "favoriten";      ziel = "02_Erstellte_Apps\04_favoriten\index.html";             icon = "star";            text = "Favoriten";      i18n = "navFav" },
  @{ id = "tagesberichte";  ziel = "03_Tagesberichte\tagesberichte.html";                icon = "journal-text";    text = "Tagesberichte";  i18n = "navReports" }
)
$knoepfe = ($nav | ForEach-Object {
  $cur = if ($_.id -eq $Aktiv) { ' aria-current="page"' } else { '' }
  $badge = if ($_.id -eq 'todo') { '<span class="nx-badge" aria-hidden="true" translate="no" hidden></span>' } else { '' }
  $dn = if ($_.id -eq 'todo') { ' data-nav="todo"' } else { '' }
  '        <a class="nx-btn" href="{0}"{1}{4}><i class="bi bi-{2}" aria-hidden="true"></i><span>{3}</span>{5}</a>' -f (Rel $_.ziel), $cur, $_.icon, $_.text, $dn, $badge
}) -join "`r`n"

# Wörterbuch (allgemein + Seite) und Übersetzer
$wb = ([IO.File]::ReadAllText((Join-Path $PSScriptRoot "woerterbuch.json"), $utf8) | ConvertFrom-Json)
$dict = [ordered]@{}; $muster = New-Object System.Collections.ArrayList
foreach ($p in $wb.woerter.PSObject.Properties) { $dict[$p.Name] = $p.Value }
foreach ($m in $wb.muster) { [void]$muster.Add($m) }
if ($Seitenkey -and $wb.seiten.PSObject.Properties[$Seitenkey]) {
  $sec = $wb.seiten.$Seitenkey
  foreach ($p in $sec.woerter.PSObject.Properties) { $dict[$p.Name] = $p.Value }
  foreach ($m in $sec.muster) { [void]$muster.Add($m) }
}
$dictJson = $dict | ConvertTo-Json -Compress
if ($dict.Count -eq 0) { $dictJson = "{}" }
$musterJson = "[" + (($muster | ForEach-Object { "[" + ($_[0] | ConvertTo-Json -Compress) + "," + ($_[1] | ConvertTo-Json -Compress) + "]" }) -join ",") + "]"
$sprache = [IO.File]::ReadAllText((Join-Path $PSScriptRoot "sprache.js"), $utf8)
$suche = [IO.File]::ReadAllText((Join-Path $PSScriptRoot "suche.js"), $utf8) + "`n" + [IO.File]::ReadAllText((Join-Path $PSScriptRoot "zaehler.js"), $utf8)
$sprache = $sprache.Replace('/*NX-WOERTER*/{}', $dictJson).Replace('/*NX-MUSTER*/[]', $musterJson).Replace('/*NX-NURKOPF*/false', $(if ($NurKopf) { 'true' } else { 'false' }))

if (-not $Version) {
  $m = [regex]::Match($c, 'name="app-version"\s+content="([^"]+)"')
  $Version = if ($m.Success) { $m.Groups[1].Value } else { "1.0.0" }
}
$untertitelHtml = if ($Untertitel) { "      <p>$Untertitel</p>" } else { "" }
$titelZeileHtml = if ($TitelZeile) { $TitelZeile } else { "      <div class=`"nx-titlerow`"><i class=`"bi bi-$Icon nx-ico`" aria-hidden=`"true`"></i><h1>$Titel</h1></div>" }
$flaggeDe = '<svg viewBox="0 0 5 3" xmlns="http://www.w3.org/2000/svg"><rect width="5" height="3" fill="#FFCE00"/><rect width="5" height="2" fill="#DD0000"/><rect width="5" height="1" fill="#000"/></svg>'
$flaggeEn = '<svg viewBox="0 0 60 30" xmlns="http://www.w3.org/2000/svg"><clipPath id="nxukc"><path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/></clipPath><rect width="60" height="30" fill="#012169"/><path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" stroke-width="6"/><path d="M0,0 L60,30 M60,0 L0,30" clip-path="url(#nxukc)" stroke="#C8102E" stroke-width="4"/><path d="M30,0 v30 M0,15 h60" stroke="#fff" stroke-width="10"/><path d="M30,0 v30 M0,15 h60" stroke="#C8102E" stroke-width="6"/></svg>'
$rechts = '      <div class="nx-extra"><div class="nx-langswitch" role="group" aria-label="Sprache / Language" translate="no"><button type="button" class="nx-lang-opt" data-lang="de" aria-pressed="true" title="Deutsch"><span class="nx-flag" aria-hidden="true">' + $flaggeDe + '</span><span>DE</span></button><button type="button" class="nx-lang-opt" data-lang="en" aria-pressed="false" title="English"><span class="nx-flag" aria-hidden="true">' + $flaggeEn + '</span><span>EN</span></button></div></div>'

# Öffentliche Seiten: kein "Nobbis Super-Firma", keine interne Navigation, keine internen Daten (To-do-Spiegel), keine Suche/Zähler
if ($Oeffentlich) {
  $markeHtml = "<span class=`"nx-brand`" role=`"img`" aria-label=`"Ninox`">$logo</span>"
  $navHtml = ""
  $todosHtml = ""
  $sucheHtml = ""
} else {
  $markeHtml = "<a class=`"nx-brand`" href=`"$(Rel 'firma.htm')`" aria-label=`"Nobbis Super-Firma – Organigramm`">$logo<span>Nobbis Super-Firma</span></a>"
  $navHtml = "      <nav class=`"nx-nav`" aria-label=`"Hauptnavigation`">`n$knoepfe`n      </nav>"
  $todosHtml = "  <script src=`"$(Rel '08_Todos\todos.js')`"></script>"
  $sucheHtml = "  <script>`n$suche`n  </script>"
}
$kopf = @"
<!-- NX-KOPF-ANFANG (Standard-Kopfbereich, nicht von Hand ändern: seite-standard.ps1) -->
<header class="nx-header">
  <div class="nx-wrap">
    <div class="nx-bar">
      $markeHtml
$navHtml
$rechts
    </div>
    <div class="nx-title">
$titelZeileHtml
$untertitelHtml
$NachTitel
    </div>
  </div>
$todosHtml
  <script>(function(){var l=location.protocol==="file:"||location.hostname==="localhost"||location.hostname==="127.0.0.1";if(!l){var n=document.querySelector(".nx-nav");if(n)n.hidden=true;var b=document.querySelector(".nx-brand");if(b)b.removeAttribute("href");}})();</script>
  <script>
$sprache
  </script>
$sucheHtml
</header>
<!-- NX-KOPF-ENDE -->
"@

$fuss = @"
<!-- NX-FUSS-ANFANG (Standard-Fußzeile) -->
<footer class="nx-footer">
  <div class="nx-wrap">
    <span class="nx-foot-l">$FussLinks</span>
    <span class="nx-foot-r"><span>Version</span> <span data-app-version>$Version</span></span>
  </div>
</footer>
<!-- NX-FUSS-ENDE -->
"@

$stil = [IO.File]::ReadAllText((Join-Path $PSScriptRoot "stil.css"), $utf8)
$stilBlock = "<style id=`"nx-stil`">`r`n$stil`r`n</style>"

# Vorhandene Standard-Blöcke und alte Köpfe/Füße entfernen
$c = [regex]::Replace($c, '<!-- NX-KOPF-ANFANG.*?<!-- NX-KOPF-ENDE -->\r?\n?', '', $S)
$c = [regex]::Replace($c, '<!-- NX-FUSS-ANFANG.*?<!-- NX-FUSS-ENDE -->\r?\n?', '', $S)
$c = [regex]::Replace($c, '<style id="nx-stil">.*?</style>\r?\n?', '', $S)
$bodyIdx = $c.IndexOf('<body')
$vor = $c.Substring(0, $bodyIdx); $nach = $c.Substring($bodyIdx)
$nach = ([regex]::new('<header\b.*?</header>\s*', $S)).Replace($nach, '', 1)
$nach = ([regex]::new('<footer\b.*?</footer>\s*', $S)).Replace($nach, '', 1)
$c = $vor + $nach

# Pflicht-Einbindungen (Schrift, Icons, Version)
# Kein CDN, keine Google Fonts (DSGVO): alte externe Links entfernen, lokale Dateien aus _standard\vendor einbinden
$c = [regex]::Replace($c, '<link[^>]*(cdn\.jsdelivr\.net|fonts\.googleapis\.com|fonts\.gstatic\.com)[^>]*>\s*', '')
if ($c -notmatch '_standard/vendor/bootstrap-icons') { $c = $c.Replace('</head>', '<link href="' + (Rel '02_Erstellte_Apps\_standard\vendor\bootstrap-icons\bootstrap-icons.min.css') + '" rel="stylesheet">' + "`r`n</head>") }
if ((Test-Path (Join-Path $PSScriptRoot 'vendor\noto-sans\noto-sans.css')) -and $c -notmatch '_standard/vendor/noto-sans') { $c = $c.Replace('</head>', '<link href="' + (Rel '02_Erstellte_Apps\_standard\vendor\noto-sans\noto-sans.css') + '" rel="stylesheet">' + "`r`n</head>") }
if ($Oeffentlich -and $c -notmatch 'nx-oeffentlich') { $c = $c.Replace('<meta charset="utf-8">', '<meta charset="utf-8">' + "`r`n" + '<meta name="nx-oeffentlich" content="1">') }
if ($c -match 'name="app-version"') { $c = [regex]::Replace($c, '(name="app-version"\s+content=")[^"]+(")', "`${1}$Version`${2}") }
else { $c = $c.Replace('<meta charset="utf-8">', '<meta charset="utf-8">' + "`r`n" + "<meta name=`"app-version`" content=`"$Version`">") }

# Einsetzen: Stil vor </head>, Kopf nach <body>, Fuß nach </main>
$c = $c.Replace('</head>', "$stilBlock`r`n</head>")
$bm = [regex]::Match($c, '<body[^>]*>')
$c = $c.Substring(0, $bm.Index + $bm.Length) + "`r`n" + $kopf + $c.Substring($bm.Index + $bm.Length)
if ($c -notmatch '</main>') { throw "Kein </main> in $Seite" }
$idx = $c.LastIndexOf('</main>') + 7
$c = $c.Substring(0, $idx) + "`r`n" + $fuss + $c.Substring($idx)
# Standard-Seitenaufbau: Klassen nx-body (Schrift, Hintergrund) und nx-main (Breite 1140, Abstände)
function KlasseHinzu($html, $tag, $klasse) {
  if ($html -match "<$tag[^>]*$klasse") { return $html }
  [regex]::Replace($html, "<$tag(\s[^>]*?)?>", {
    param($m)
    $attr = $m.Groups[1].Value
    if ($attr -match 'class="([^"]*)"') { "<$tag" + ($attr -replace 'class="([^"]*)"', ('class="$1 ' + $klasse + '"')) + ">" }
    else { "<$tag class=`"$klasse`"$attr>" }
  }, 'None', [TimeSpan]::FromSeconds(5))
}
$c = KlasseHinzu $c 'body' 'nx-body'
$c = KlasseHinzu $c 'main' 'nx-main'
[IO.File]::WriteAllText($pfad, $c, $utf8)
"OK $Seite (Version $Version)"
