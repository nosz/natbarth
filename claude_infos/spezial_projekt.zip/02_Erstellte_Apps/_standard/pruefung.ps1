﻿# Datei-Prüfung für alle Standard-Seiten (nur lesend, ändert nichts). Aufruf: .\02_Erstellte_Apps\_standard\pruefung.ps1
# Prüft: Seiten vorhanden, Standard-Blöcke, Versionen, Wörterbuch, versehentliche NUL-Zeichen, Alias-Falle, Sicherung außerhalb OneDrive.
# Ergebnis: Tabelle; Exit-Code 1, wenn etwas fehlschlägt. Browser-Prüfung (Layout, Sprache, Links): pruefung.js, siehe TESTS.md.
$ErrorActionPreference = "Stop"
$u = New-Object System.Text.UTF8Encoding($false)
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location $root
$ergebnis = New-Object System.Collections.ArrayList
function Pruefe($name, $ok, $detail) { [void]$ergebnis.Add([pscustomobject]@{ Pruefung = $name; Ergebnis = $(if ($ok) { "OK" } else { "FEHLER" }); Detail = $detail }) }

# 1. Seiten: alle HTML-Seiten der Standard-Ordner (ohne Referenzen, Sicherungen, Präsentationen, eigenständige Demo-Projekte wie Herzintelligenz)
$seiten = @(Get-ChildItem -Recurse -File -Include *.htm, *.html | Where-Object { $_.FullName -match '\\(02_Erstellte_Apps|03_Tagesberichte|05_Sarah_Erinnerungen)\\|\\firma\.htm$' -and $_.FullName -notmatch 'sauberer_neckar|09_visitenkarten|08_ki_training|08_herzintelligenz|referenz|09_Ablage|_standard|\\(falt)?flyer(\.vorlage)?\.html$' })
$erwartet = 'firma.htm', '02_Erstellte_Apps\02_agenten_skills_uebersicht\index.html', '02_Erstellte_Apps\03_todo\index.html', '02_Erstellte_Apps\04_favoriten\index.html', '03_Tagesberichte\tagesberichte.html'
foreach ($e in $erwartet) { Pruefe "Seite vorhanden: $e" (Test-Path $e) "" }
foreach ($s in $seiten) {
  $rel = $s.FullName.Substring($root.Length + 1)
  $c = [IO.File]::ReadAllText($s.FullName, $u)
  $meta = [regex]::Match($c, 'name="app-version"\s+content="([^"]+)"').Groups[1].Value
  $fuss = [regex]::Match($c, '<span data-app-version>([^<]*)</span>').Groups[1].Value
  Pruefe "Standard-Blöcke: $rel" ($c.Contains('NX-KOPF-ANFANG') -and $c.Contains('NX-FUSS-ANFANG') -and $c.Contains('id="nx-stil"') -and $c.Contains('class="nx-langswitch"')) ""
  Pruefe "Genau ein <header>: $rel" (([regex]::Matches($c, '<header\b')).Count -eq 1) "gefunden: $(([regex]::Matches($c, '<header\b')).Count)"
  Pruefe "Version Meta = Fußzeile: $rel" ($meta -ne "" -and $meta -eq $fuss) "meta=$meta fuss=$fuss"
  Pruefe "Klassen nx-body/nx-main: $rel" (($c -match '<body[^>]*nx-body') -and ($c -match '<main[^>]*nx-main')) ""
  Pruefe "Kein NUL-Zeichen: $rel" (-not $c.Contains([string][char]0)) ""
  if ($c -match 'name="nx-oeffentlich"') {
    # Öffentliche Seite (Veranstaltung): kein Firmenname im Kopf, keine interne Navigation, keine internen Daten
    $kopfTeil = [regex]::Match($c, '(?s)<!-- NX-KOPF-ANFANG.*?<!-- NX-KOPF-ENDE -->').Value
    $okOeff = (-not $kopfTeil.Contains('<span>Nobbis Super-Firma</span>')) -and (-not $kopfTeil.Contains('class="nx-nav"')) -and (-not $c.Contains('08_Todos')) -and ($c -notmatch '<title>[^<]*Nobbis')
    Pruefe "Öffentliche Seite ohne Firmenname, Navigation und To-do-Spiegel: $rel" $okOeff ""
  } else {
  Pruefe "Spiegel todos.js eingebunden (zentrale To-do-Liste): $rel" ($c -match '<script src="[^"]*08_Todos/todos\.js"></script>') ""
  }
  Pruefe "Keine Zeichenkodierungs-Fehler (Mojibake): $rel" (-not [regex]::IsMatch($c, ([string][char]0x00C3 + '[\u0080-\u00BF]|' + [string][char]0x00E2 + [string][char]0x20AC))) ""
  # Linknamen: h1, <title> und aktiver Navigationsknopf tragen denselben kanonischen Namen (siehe STANDARD.md, Abschnitt Linknamen)
  $kanon = if ($rel -eq 'firma.htm') { 'Organigramm' } elseif ($rel -like '*agenten_skills_uebersicht*') { 'Agenten & Skills' } elseif ($rel -like '*\03_todo\*') { 'To-dos' } elseif ($rel -like '*\04_favoriten\*') { 'Favoriten' } elseif ($rel -like '*tagesberichte.html') { 'Tagesberichte' } elseif ($rel -like '*sarah-uebersicht.html') { 'Sarahs Übersicht' } else { '' }
  if ($kanon) {
    $h1 = ([regex]::Match($c, '<h1[^>]*>(.*?)</h1>').Groups[1].Value) -replace '&amp;', '&'
    $ti = ([regex]::Match($c, '<title>([^<]*)</title>').Groups[1].Value) -replace '&amp;', '&'
    $navAktiv = ([regex]::Match($c, '<a class="nx-btn"[^>]*aria-current="page"[^>]*>.*?<span>([^<]*)</span>', [Text.RegularExpressions.RegexOptions]::Singleline).Groups[1].Value) -replace '&amp;', '&'
    $okName = ($h1 -eq $kanon) -and ($ti -eq "$kanon – Nobbis Super-Firma") -and ((-not $navAktiv) -or $navAktiv -eq $kanon)
    Pruefe "Linkname einheitlich (h1/title/Navigation): $rel" $okName "soll=$kanon h1=$h1 title=$ti nav=$navAktiv"
  }}
# 2. To-do: Service-Worker-Version = Seitenversion
if ((Test-Path '02_Erstellte_Apps\03_todo\sw.js') -and (Test-Path '02_Erstellte_Apps\03_todo\index.html')) {
  $sw = [regex]::Match([IO.File]::ReadAllText((Resolve-Path '02_Erstellte_Apps\03_todo\sw.js').Path, $u), 'const VERSION = "([^"]+)"').Groups[1].Value
  $tv = [regex]::Match([IO.File]::ReadAllText((Resolve-Path '02_Erstellte_Apps\03_todo\index.html').Path, $u), 'name="app-version"\s+content="([^"]+)"').Groups[1].Value
  Pruefe "To-do sw.js VERSION = Seitenversion" ($sw -eq $tv) "sw=$sw seite=$tv"
}
# 2b. Zentrale To-do-Liste (08_Todos): Dateien vorhanden, todos.ps1 -Pruefen (json gültig, Spiegel = json)
foreach ($f in 'todos.json', 'todos.js', 'todos.ps1', 'README.md') { Pruefe "Zentrale To-do-Liste: 08_Todos\$f vorhanden" (Test-Path "08_Todos\$f") "" }
if (Test-Path '08_Todos\todos.ps1') {
  $global:LASTEXITCODE = 0
  $tOut = ((& (Resolve-Path '08_Todos\todos.ps1').Path -Aktion Pruefen) 2>&1 | Out-String).Trim()
  Pruefe "Zentrale To-do-Liste: todos.ps1 -Aktion Pruefen (JSON gültig, Spiegel = JSON)" ($LASTEXITCODE -eq 0) $tOut
}
# 3. Wörterbuch gültig, Standard-Dateien vorhanden
try { $wb = [IO.File]::ReadAllText((Resolve-Path '02_Erstellte_Apps\_standard\woerterbuch.json').Path, $u) | ConvertFrom-Json; Pruefe "Wörterbuch gültiges JSON" $true "$(@($wb.woerter.PSObject.Properties).Count) allgemeine Wörter" } catch { Pruefe "Wörterbuch gültiges JSON" $false $_.Exception.Message }
foreach ($f in 'stil.css', 'sprache.js', 'seite-standard.ps1', 'logo.svg', 'STANDARD.md') { Pruefe "Standard-Datei: $f" (Test-Path "02_Erstellte_Apps\_standard\$f") "" }
# 4. Versehentliche NUL-Zeichen in Regeldateien (Backtick-Falle in PowerShell-Strings)
$regel = @('CLAUDE.md') + @(Get-ChildItem '.claude\agents' -Filter *.md | ForEach-Object { $_.FullName }) + @(Get-ChildItem "$env:USERPROFILE\.claude\skills\trainer-app-bauen\SKILL.md", "$env:USERPROFILE\.claude\skills\demo-app-bauen\SKILL.md" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
$nulDateien = @($regel | Where-Object { [IO.File]::ReadAllText((Resolve-Path $_).Path, $u).Contains([string][char]0) })
Pruefe "Keine NUL-Zeichen in Regeldateien" ($nulDateien.Count -eq 0) ($nulDateien -join ", ")
# 5. Alias-Falle: keine eigenen Funktionen mit Namen von Löschbefehlen
$alias = '^\s*function\s+(rd|ri|rm|del|erase|rmdir|cd|sl|mv|move|mi|cp|copy|cpi|ls|dir|gci|cat|gc|sc|ac)\b'
$treffer = @(Get-ChildItem -Recurse -File -Include *.ps1 | Where-Object { $_.FullName -notmatch '09_Ablage|07_NINOX3|09_Demo_Testordner' } | Select-String -Pattern $alias -CaseSensitive:$false | ForEach-Object { "$($_.Path.Substring($root.Length + 1)):$($_.LineNumber)" })
Pruefe "Keine Funktionen mit Alias-Namen (rd, ri, rm, del ...)" ($treffer.Count -eq 0) ($treffer -join ", ")
# 6b. Modell der Mitarbeiter: Agentendateien ohne model: = Modell der Sitzung; Seiten müssen dasselbe zeigen
$ag = [IO.File]::ReadAllText((Resolve-Path '02_Erstellte_Apps\02_agenten_skills_uebersicht\index.html').Path, $u)
$fi = [IO.File]::ReadAllText((Resolve-Path 'firma.htm').Path, $u)
$sm = [regex]::Match($ag, 'const SITZUNGSMODELL = "([^"]+)"').Groups[1].Value
$fm = [regex]::Match($fi, 'const MODEL_SESSION = "([^"]+)"').Groups[1].Value
Pruefe "Modell der Sitzung: Agenten-Seite = Organigramm" ($sm -ne "" -and $sm -eq $fm) "agenten=$sm firma=$fm"
$mitModell = @(Get-ChildItem '.claude\agents' -Filter *.md | Where-Object { [IO.File]::ReadAllText($_.FullName, $u) -match '(?m)^model:\s*\S' } | ForEach-Object { $_.BaseName })
$ohneEintrag = @($mitModell | Where-Object { $ag -notmatch ('MODELLE\s*=\s*\{[^}]*\b' + [regex]::Escape($_) + '\b') })
Pruefe "Agentendateien mit model: stehen in MODELLE der Agenten-Seite" ($ohneEintrag.Count -eq 0) ("fehlt: " + ($ohneEintrag -join ", "))
# 6c. Suchindex aktuell (suchindex-erstellen.ps1 -Pruefen vergleicht die Quellen mit suchindex.js, schreibt nichts)
$siAus = ((& (Join-Path $PSScriptRoot 'suchindex-erstellen.ps1') -Pruefen) 2>&1 | Out-String).Trim()
Pruefe "Suchindex aktuell" ($LASTEXITCODE -eq 0) $(if ($LASTEXITCODE -eq 0) { $siAus } else { "Index veraltet: suchindex-erstellen.ps1 ausführen ($siAus)" })
foreach ($f in 'suchindex.js', 'suche-global.js', 'suche-global.css', 'suchindex-erstellen.ps1') { Pruefe "Such-Datei: $f" (Test-Path "02_Erstellte_Apps\_standard\$f") "" }
# 6d. Zentrale To-do-Liste Stufe 2: keine Reste der alten datierten Übersichtsdatei; erinnerungen.md ist Archiv; Live-Ansichten vorhanden
$altName = '\d{4}-\d{2}-\d{2}_\d{4}_sarah-uebersicht'
$ausschluss = '09_Demo_Testordner|09_Ablage|\\sicherung\\|\\sicherung_|04_Mitarbeiter|00_Aktuell|07_NINOX3|\\agent-memory\\|\.git\\'
$altTreffer = @(Get-ChildItem -Recurse -File -Include *.htm, *.html, *.ps1, *.js, *.json, *.md, *.webmanifest -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch $ausschluss } | Select-String -Pattern ('(?<!sicherungen[\\/])' + $altName) -ErrorAction SilentlyContinue | ForEach-Object { $_.Path.Substring($root.Length + 1) + ':' + $_.LineNumber } | Select-Object -Unique)
Pruefe "Keine Verweise auf die alte datierte Sarah-Übersicht (feste Adresse sarah-uebersicht.html)" ($altTreffer.Count -eq 0) ($altTreffer -join ", ")
Pruefe "Sarahs Übersicht: feste Adresse vorhanden, keine datierten Kopien im Ordner" ((Test-Path '05_Sarah_Erinnerungen\sarah-uebersicht.html') -and @(Get-ChildItem '05_Sarah_Erinnerungen' -Filter '*_sarah-uebersicht.html' -File).Count -eq 0) ""
$erin = [IO.File]::ReadAllText((Resolve-Path '05_Sarah_Erinnerungen\erinnerungen.md').Path, $u)
Pruefe "erinnerungen.md ist Archiv (Hinweis vorhanden)" ($erin -match 'ARCHIV' -and $erin -match 'KEINE eigene Liste') ""
$liest = @(Get-ChildItem -Recurse -File -Include *.htm, *.html, *.ps1, *.js -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch $ausschluss -and $_.Name -ne 'pruefung.ps1' } | Select-String -Pattern 'erinnerungen\.md' -ErrorAction SilentlyContinue | ForEach-Object { $_.Path.Substring($root.Length + 1) + ':' + $_.LineNumber } | Select-Object -Unique)
Pruefe "Kein Skript und keine Seite liest erinnerungen.md (nur Archiv)" ($liest.Count -eq 0) ($liest -join ", ")
$sa = [IO.File]::ReadAllText((Resolve-Path '.claude\agents\sarah.md').Path, $u)
Pruefe "Sarah arbeitet nur über todos.ps1 (keine zweite Liste)" ($sa -match 'todos\.ps1' -and $sa -notmatch 'Favoritenseite nachziehen' -and $sa -notmatch '\| Status \| Datum') ""
$sk = "$env:USERPROFILE\.claude\scheduled-tasks\sarah-morgenuebersicht\SKILL.md"
if (Test-Path $sk) { $skt = [IO.File]::ReadAllText($sk, $u); Pruefe "Geplante Aufgabe sarah-morgenuebersicht liest die zentrale Liste (kein NUL-Zeichen)" ($skt -match 'todos\.ps1 -Aktion Liste' -and $skt -notmatch 'erinnerungen\.md' -and -not $skt.Contains([string][char]0)) "" }
$sarahSeite = [IO.File]::ReadAllText((Resolve-Path '05_Sarah_Erinnerungen\sarah-uebersicht.html').Path, $u)
Pruefe "Sarahs Übersicht ist Live-Ansicht (nxTodoListe, nxSarahRender)" ($sarahSeite.Contains('nxTodoListe') -and $sarahSeite.Contains('nxSarahRender')) ""
$favSeite = [IO.File]::ReadAllText((Resolve-Path '02_Erstellte_Apps\04_favoriten\index.html').Path, $u)
Pruefe "Favoriten: Erinnerungen dynamisch (kein statisches Array ERINNERUNGEN)" ($favSeite.Contains('nxTodoListe') -and $favSeite -notmatch 'const ERINNERUNGEN\s*=') ""
# 7. Sicherung außerhalb von OneDrive
Pruefe "Sicherung außerhalb OneDrive vorhanden" (@(Get-ChildItem 'C:\Users\NorbertSzpak\NOBBIS_SICHERUNG_20261028' -Recurse -File -ErrorAction SilentlyContinue).Count -gt 0) "C:\Users\NorbertSzpak\NOBBIS_SICHERUNG_20261028"

$ergebnis | Format-Table -AutoSize -Wrap | Out-String -Width 220
$fehler = @($ergebnis | Where-Object { $_.Ergebnis -eq "FEHLER" })
"Summe: $($ergebnis.Count) Prüfungen, $($fehler.Count) Fehler"
if ($fehler.Count -gt 0) { exit 1 }
