/* Browser-Prüfung für alle Standard-Seiten. Läuft im Browserfenster auf http://localhost:8100 (Server "firma"), nie über file://.
   Aufruf (javascript_tool): Inhalt dieser Datei + await nxTest({ seiten: [...], breiten: [...], links: true, deutschRest: true })
   Jede Seite wird in einem unsichtbaren iframe der jeweiligen Breite geladen (Media-Queries reagieren auf die iframe-Breite).
   Geprüft je Seite und Breite: Umschalter und Kopf bleiben beim Sprachwechsel DE<->EN auf den Pixel gleich, gewählte Flagge ist hervorgehoben,
   kein seitliches Scrollen, Navigation mit Sprachparameter, Links (Status 200), Restdeutsch auf Englisch.
   Rückgabe: { ok, fehler: [...], zeilen: [...] }. ok=false, sobald ein Wert abweicht. */
async function nxTest(opt) {
  opt = opt || {};
  var ALLE = {
    firma: "firma.htm",
    agenten: "02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html",
    todo: "02_Erstellte_Apps/03_todo/index.html",
    favoriten: "02_Erstellte_Apps/04_favoriten/index.html",
    tagesberichte: "03_Tagesberichte/tagesberichte.html",
    sarah: "05_Sarah_Erinnerungen/sarah-uebersicht.html"
  };
  var seiten = opt.seiten || Object.keys(ALLE);
  var breiten = opt.breiten || [390, 760, 1040, 1300];
  var fehler = [], zeilen = [];
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var rect = function (el) { var r = el.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(","); };
  var de = /[äöüÄÖÜß]|\b(und|der|die|das|ein|eine|nicht|noch|keine|alle|mit|für|wird|zum|zur|von|bei|auf|ist|Neue|Aufgabe|Notiz)\b/;

  for (var s = 0; s < seiten.length; s++) {
    var key = seiten[s], pfad = ALLE[key] || key;
    for (var b = 0; b < breiten.length; b++) {
      var w = breiten[b];
      var f = document.createElement("iframe");
      f.style.cssText = "width:" + w + "px;height:900px;position:fixed;left:0;top:0;visibility:hidden;border:0";
      f.src = "/" + pfad + "?lang=de&x=" + Date.now();
      document.body.appendChild(f);
      await new Promise(function (r) { f.onload = r; setTimeout(r, 6000); });
      await wait(900);
      var d = f.contentDocument, win = f.contentWindow;
      var label = key + " @" + w;
      try {
        var gemessen = {};
        for (var l = 0; l < 2; l++) {
          var sprache = l === 0 ? "de" : "en";
          win.nxSetLang(sprache);
          await wait(450);
          gemessen[sprache] = {
            schalter: rect(d.querySelector(".nx-langswitch")),
            optDe: rect(d.querySelector('.nx-lang-opt[data-lang="de"]')),
            optEn: rect(d.querySelector('.nx-lang-opt[data-lang="en"]')),
            leiste: rect(d.querySelector(".nx-bar")),
            kopfH: Math.round(d.querySelector(".nx-header").getBoundingClientRect().height),
            logo: rect(d.querySelector(".nx-brand")),
            gedrueckt: Array.prototype.filter.call(d.querySelectorAll(".nx-lang-opt"), function (x) { return x.getAttribute("aria-pressed") === "true"; }).map(function (x) { return x.dataset.lang; }).join(","),
            ueberlauf: d.documentElement.scrollWidth > d.documentElement.clientWidth,
            navLinks: Array.prototype.map.call(d.querySelectorAll(".nx-nav a"), function (a) { return a.getAttribute("href"); }),
            sprachwert: win.nxLang()
          };
        }
        var g = gemessen;
        var diff = [];
        if (g.de.schalter !== g.en.schalter) diff.push("Umschalter " + g.de.schalter + " -> " + g.en.schalter);
        if (g.de.optDe !== g.en.optDe || g.de.optEn !== g.en.optEn) diff.push("Flaggen-Knöpfe verschoben");
        if (g.de.kopfH !== g.en.kopfH) diff.push("Kopfhöhe " + g.de.kopfH + " -> " + g.en.kopfH);
        if (g.de.leiste !== g.en.leiste) diff.push("Leiste " + g.de.leiste + " -> " + g.en.leiste);
        if (g.de.logo !== g.en.logo) diff.push("Logo verschoben");
        if (g.de.gedrueckt !== "de") diff.push("DE nicht hervorgehoben (" + g.de.gedrueckt + ")");
        if (g.en.gedrueckt !== "en") diff.push("EN nicht hervorgehoben (" + g.en.gedrueckt + ")");
        if (g.de.sprachwert !== "de" || g.en.sprachwert !== "en") diff.push("nxLang() falsch");
        if (g.de.ueberlauf || g.en.ueberlauf) diff.push("seitliches Scrollen");
        if (!g.en.navLinks.every(function (h) { return /lang=en/.test(h); })) diff.push("Navigation ohne lang=en");
        if (!g.de.navLinks.every(function (h) { return /lang=de/.test(h); })) diff.push("Navigation ohne lang=de");
        if (diff.length) { diff.forEach(function (x) { fehler.push(label + ": " + x); }); }
        zeilen.push(label + " | Umschalter " + g.de.schalter + " | Kopf " + g.de.kopfH + " | " + (diff.length ? "FEHLER" : "OK"));

        // einmal pro Seite (größte Breite): Links und Restdeutsch auf Englisch
        if (b === breiten.length - 1) {
          win.nxSetLang("en"); await wait(500);
          if (opt.links !== false) {
            var hrefs = Array.from(new Set(Array.prototype.map.call(d.querySelectorAll("a[href]"), function (a) { return a.href; }).filter(function (h) { return h.indexOf(location.origin) === 0; })));
            var kaputt = [];
            for (var i = 0; i < hrefs.length; i++) { try { var r = await fetch(hrefs[i]); if (!r.ok) kaputt.push(r.status + " " + hrefs[i]); } catch (e) { kaputt.push("ERR " + hrefs[i]); } }
            kaputt.forEach(function (k) { fehler.push(key + ": Link kaputt " + k); });
            var ohneLang = Array.prototype.filter.call(d.querySelectorAll("a[href]"), function (a) { var h = a.getAttribute("href"); return !a.hasAttribute("data-nx-keinlang") && /\.html?(\?|#|$)/.test(h) && !/^https?:/.test(h) && !/lang=en/.test(h); }).length;
            if (ohneLang) fehler.push(key + ": " + ohneLang + " Link(s) ohne lang=en");
            zeilen.push(key + " | Links " + hrefs.length + " geprüft, kaputt " + kaputt.length);
          }
          if (opt.deutschRest !== false) {
            var rest = new Set(), tw = d.createTreeWalker(d.body, NodeFilter.SHOW_TEXT), n;
            while ((n = tw.nextNode())) {
              var pe = n.parentElement; if (!pe || /SCRIPT|STYLE|TEXTAREA/.test(pe.tagName) || pe.closest(".nx-langswitch")) continue;
              var t = n.nodeValue.replace(/\s+/g, " ").trim(); if (t && de.test(t)) rest.add(t.slice(0, 70));
            }
            d.querySelectorAll("[placeholder],[title],[aria-label]").forEach(function (e) {
              ["placeholder", "title", "aria-label"].forEach(function (a) { var v = e.getAttribute(a); if (v && de.test(v) && !/^(Sprache \/ Language|Deutsch)$/.test(v)) rest.add("@" + a + ": " + v.slice(0, 60)); });
            });
            zeilen.push(key + " | Restdeutsch auf EN: " + (rest.size ? JSON.stringify(Array.from(rest)) : "keins") + " (Namen/eigene Eingaben prüfen)");
            if (opt.restdeutschFehler) Array.from(rest).forEach(function (x) { fehler.push(key + ": Restdeutsch " + x); });
          }
        }
      } catch (e) { fehler.push(label + ": Ausnahme " + e.message); }
      f.remove();
    }
  }
  try { localStorage.setItem("nobbis-super-firma-sprache-v1", "de"); } catch (e) {}
  return { ok: fehler.length === 0, fehler: fehler, zeilen: zeilen };
}

/* Komponenten-Prüfung (Linknamen, Suchfeld, Eingabefelder). Aufruf: await nxTestKomponenten({ breiten: [390, 760, 1300] })
   Linknamen: h1, <title> und Navigationsknopf tragen auf jeder Seite denselben Namen (Deutsch und Englisch).
   Suchfeld: agenten und tagesberichte haben dasselbe Feld (Höhe 48, gleiche Breite/Position, gleicher Platzhalter-Beginn); Tippen, Löschknopf, Esc und "/" funktionieren.
   Eingabefelder: alle .nx-input mindestens 44 px hoch, Knöpfe .nx-btn-primary/.nx-btn-secondary mindestens 44 px, ohne Bootstrap-Formularklassen. */
async function nxTestKomponenten(opt) {
  opt = opt || {};
  var breiten = opt.breiten || [390, 760, 1300];
  var NAMEN = {
    "firma.htm": ["Organigramm", "Org chart", "organigramm"],
    "02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html": ["Agenten & Skills", "Agents & Skills", "agenten"],
    "02_Erstellte_Apps/03_todo/index.html": ["To-dos", "To-dos", "todo"],
    "02_Erstellte_Apps/04_favoriten/index.html": ["Favoriten", "Favorites", "favoriten"],
    "03_Tagesberichte/tagesberichte.html": ["Tagesberichte", "Daily reports", "tagesberichte"],
    "05_Sarah_Erinnerungen/sarah-uebersicht.html": ["Sarahs Übersicht", "Sarah's overview", ""]
  };
  var fehler = [], zeilen = [];
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var R = function (el) { var r = el.getBoundingClientRect(); return { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }; };
  var laden = async function (pfad, w) {
    var f = document.createElement("iframe");
    f.style.cssText = "width:" + w + "px;height:900px;position:fixed;left:0;top:0;opacity:0;pointer-events:none;border:0;z-index:-1";
    f.src = "/" + pfad + "?lang=de&x=" + Date.now(); document.body.appendChild(f);
    await new Promise(function (r) { f.onload = r; setTimeout(r, 6000); }); await wait(700); return f;
  };
  // 1. Linknamen
  for (var pfad in NAMEN) {
    var f = await laden(pfad, 1300), d = f.contentDocument, win = f.contentWindow;
    for (var l = 0; l < 2; l++) {
      var sp = l === 0 ? "de" : "en"; win.nxSetLang(sp); await wait(400);
      var soll = NAMEN[pfad][l], h1 = d.querySelector(".nx-title h1").textContent.trim().replace(/\s+/g, " ");
      var titel = d.title, nav = d.querySelector('.nx-nav a[aria-current="page"] span');
      if (h1 !== soll) fehler.push(pfad + " [" + sp + "] h1 '" + h1 + "' != '" + soll + "'");
      if (titel !== soll + " – Nobbis Super-Firma") fehler.push(pfad + " [" + sp + "] title '" + titel + "' != '" + soll + " – Nobbis Super-Firma'");
      if (NAMEN[pfad][2]) { if (!nav || nav.textContent.trim() !== soll) fehler.push(pfad + " [" + sp + "] Nav-Knopf '" + (nav && nav.textContent.trim()) + "' != '" + soll + "'"); }
    }
    zeilen.push("Name " + NAMEN[pfad][0] + " / " + NAMEN[pfad][1] + ": geprüft (h1, title" + (NAMEN[pfad][2] ? ", Navigation" : "") + ")");
    f.remove();
  }
  // 2. Suchfeld auf beiden Suchseiten
  var suchseiten = ["02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html", "03_Tagesberichte/tagesberichte.html"];
  for (var b = 0; b < breiten.length; b++) {
    var w = breiten[b], m = [];
    for (var s = 0; s < suchseiten.length; s++) {
      var fr = await laden(suchseiten[s], w), dd = fr.contentDocument, ww = fr.contentWindow;
      var q = dd.querySelector(".nx-search-input"), bar = dd.querySelector(".nx-searchbar"), hdr = dd.querySelector(".nx-header");
      if (!q) { fehler.push(suchseiten[s] + " @" + w + ": kein .nx-search-input"); fr.remove(); continue; }
      var rq = R(q), rb = R(bar), hb = hdr.getBoundingClientRect().bottom;
      m.push({ seite: suchseiten[s], x: rq.x, w: rq.w, h: rq.h, abstandKopf: Math.round(rb.y - hb), ph: q.placeholder.slice(0, 7), icon: !!dd.querySelector(".nx-search-icon.bi-search"), hint: !!dd.querySelector(".nx-search-hint"), label: (dd.querySelector('label[for="' + q.id + '"]') || {}).textContent });
      if (rq.h !== 48) fehler.push(suchseiten[s] + " @" + w + ": Suchfeldhöhe " + rq.h + " statt 48");
      if (q.placeholder.indexOf("Suchen:") !== 0) fehler.push(suchseiten[s] + ": Platzhalter beginnt nicht mit 'Suchen:'");
      if (dd.querySelector(".form-control,.input-group,.search-box")) fehler.push(suchseiten[s] + ": altes Bootstrap-/Seiten-Suchfeld noch vorhanden");
      if (w === breiten[breiten.length - 1]) {
        var clear = dd.querySelector(".nx-search-clear");
        if (!clear.hidden) fehler.push(suchseiten[s] + ": Löschknopf sichtbar ohne Text");
        q.focus(); q.value = "a"; q.dispatchEvent(new Event("input", { bubbles: true })); await wait(150);
        var sichtbar = !clear.hidden;
        clear.click(); await wait(150);
        var leer = q.value === "" && clear.hidden && dd.activeElement === q;
        q.value = "ab"; q.dispatchEvent(new Event("input", { bubbles: true })); await wait(100);
        q.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); await wait(150);
        var esc = q.value === "" && clear.hidden;
        q.blur(); dd.body.focus();
        dd.dispatchEvent(new KeyboardEvent("keydown", { key: "/", bubbles: true })); await wait(100);
        var slash = dd.activeElement === q;
        if (!sichtbar) fehler.push(suchseiten[s] + ": Löschknopf erscheint nicht bei Text");
        if (!leer) fehler.push(suchseiten[s] + ": Löschknopf leert nicht / Fokus fehlt");
        if (!esc) fehler.push(suchseiten[s] + ": Esc leert nicht");
        if (!slash) fehler.push(suchseiten[s] + ": Taste / fokussiert nicht");
        zeilen.push(suchseiten[s].split("/").slice(-2, -1)[0] + ": Tippen/Löschknopf/Esc/'/' " + (sichtbar && leer && esc && slash ? "OK" : "FEHLER"));
      }
      fr.remove();
    }
    if (m.length === 2) {
      ["x", "w", "h", "abstandKopf", "icon", "hint", "label"].forEach(function (k) { if (m[0][k] !== m[1][k]) fehler.push("Suchfeld @" + w + ": " + k + " verschieden (" + m[0][k] + " / " + m[1][k] + ")"); });
      zeilen.push("Suchfeld @" + w + ": x=" + m[0].x + " Breite=" + m[0].w + " Höhe=" + m[0].h + " Abstand zum Kopf=" + m[0].abstandKopf + " (beide Seiten gleich: " + (m[0].x === m[1].x && m[0].w === m[1].w && m[0].abstandKopf === m[1].abstandKopf) + ")");
    }
  }
  // 3. Eingabefelder und Knöpfe
  var formseiten = ["02_Erstellte_Apps/03_todo/index.html", "02_Erstellte_Apps/04_favoriten/index.html", "02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html", "03_Tagesberichte/tagesberichte.html", "05_Sarah_Erinnerungen/sarah-uebersicht.html"];
  for (var i = 0; i < formseiten.length; i++) {
    var fx = await laden(formseiten[i], 390), dx = fx.contentDocument, anz = 0, klein = [];
    dx.querySelectorAll(".nx-input,.nx-search-input,.nx-btn-primary,.nx-btn-secondary,.nx-icon-btn,.nx-chip").forEach(function (e) {
      var r = e.getBoundingClientRect(); if (r.width === 0 && r.height === 0) return; anz++;
      var min = /nx-input-sm|nx-btn-sm|nx-icon-btn|nx-chip/.test(e.className) ? 44 : 48;
      if (Math.round(r.height) < min) klein.push((e.id || e.className) + " " + Math.round(r.height) + "px");
    });
    var alt = dx.querySelectorAll("main .form-control,main .btn-ninox,main .input-group,main button.add,main a.btn:not(.nx-btn-primary)");
    zeilen.push(formseiten[i].split("/").slice(-2, -1)[0] + ": " + anz + " Bedienelemente @390, zu klein: " + klein.length + ", alte Stile: " + alt.length);
    klein.forEach(function (k) { fehler.push(formseiten[i] + ": Touch-Ziel zu klein " + k); });
    if (alt.length) fehler.push(formseiten[i] + ": " + alt.length + " Element(e) mit alten Stilen");
    fx.remove();
  }
  try { localStorage.setItem("nobbis-super-firma-sprache-v1", "de"); } catch (e) {}
  return { ok: fehler.length === 0, fehler: fehler, zeilen: zeilen };
}

/* Zähler-Prüfung (Plakette "offene Aufgaben" im Knopf To-dos). Aufruf: await nxTestZaehler({ breiten: [390, 760, 1300] })
   Legt vorübergehend einen zweiten Eintrag in "nobbis-todos-v1" an (Zahl muss n -> n+1 -> n laufen) und stellt den Originalwert danach wieder her.
   Geprüft je Seite/Breite: Zahl in der Plakette, aria-label (DE/EN), Position von Umschalter, To-do-Knopf und Plakette in DE = EN, Live-Update über "storage",
   Ohne Speicher: zeigt die Plakette die Zahl des Spiegels NX_TODOS (zentrale Liste), ohne Spiegel ausgeblendet (kein Fehler). */
async function nxTestZaehler(opt) {
  opt = opt || {};
  var breiten = opt.breiten || [390, 760, 1300];
  var SEITEN = opt.seiten || ["firma.htm", "02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html", "02_Erstellte_Apps/03_todo/index.html", "02_Erstellte_Apps/04_favoriten/index.html", "03_Tagesberichte/tagesberichte.html", "05_Sarah_Erinnerungen/sarah-uebersicht.html"];
  var KEY = "nobbis-todos-v1", fehler = [], zeilen = [];
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var rect = function (el) { var r = el.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(","); };
  var original = localStorage.getItem(KEY);
  var offen = function () { try { return JSON.parse(localStorage.getItem(KEY)).filter(function (t) { return !t.done; }).length; } catch (e) { return null; } };
  var basis = offen();
  if (basis === null) { return { ok: false, fehler: ["kein Speicher 'nobbis-todos-v1' im Browser"], zeilen: [] }; }
  try {
    for (var s = 0; s < SEITEN.length; s++) {
      for (var b = 0; b < breiten.length; b++) {
        var w = breiten[b], label = SEITEN[s].split("/").slice(-2).join("/") + " @" + w;
        var f = document.createElement("iframe");
        f.style.cssText = "width:" + w + "px;height:900px;position:fixed;left:0;top:0;opacity:0;pointer-events:none;border:0;z-index:-1";
        f.src = "/" + SEITEN[s] + "?lang=de&x=" + Date.now(); document.body.appendChild(f);
        await new Promise(function (r) { f.onload = r; setTimeout(r, 6000); }); await wait(700);
        var d = f.contentDocument, win = f.contentWindow;
        var knopf = function () { return d.querySelector('.nx-nav a[data-nav="todo"]'); };
        var badge = function () { return knopf().querySelector(".nx-badge"); };
        var messe = function (sp) {
          win.nxSetLang(sp);
          return wait(450).then(function () {
            return { text: badge().textContent, sichtbar: getComputedStyle(badge()).visibility, aria: knopf().getAttribute("aria-label"), ariaHidden: badge().getAttribute("aria-hidden"),
              schalter: rect(d.querySelector(".nx-langswitch")), knopf: rect(knopf()), plakette: rect(badge()), nav: rect(d.querySelector(".nx-nav")), kopf: Math.round(d.querySelector(".nx-header").getBoundingClientRect().height) };
          });
        };
        for (var stufe = 0; stufe < 3; stufe++) {
          var soll = stufe === 1 ? basis + 1 : basis;
          if (stufe === 1) { var arr = JSON.parse(original); arr.push({ id: 999000000001, created: 999000000001, text: "TEST-TEMP", done: false, star: 0, due: "" }); localStorage.setItem(KEY, JSON.stringify(arr)); }
          if (stufe === 2) localStorage.setItem(KEY, original);
          await wait(300); // storage-Ereignis in den Frames
          var de = await messe("de"), en = await messe("en");
          var exp = String(soll > 99 ? "99+" : soll);
          if (de.text !== exp || en.text !== exp) fehler.push(label + " Stufe" + stufe + ": Zahl " + de.text + "/" + en.text + " statt " + exp);
          if (de.sichtbar !== "visible") fehler.push(label + ": Plakette nicht sichtbar");
          if (de.aria !== "To-dos, " + exp + " offen") fehler.push(label + ": aria-label DE '" + de.aria + "'");
          if (en.aria !== "To-dos, " + exp + " open") fehler.push(label + ": aria-label EN '" + en.aria + "'");
          if (de.ariaHidden !== "true") fehler.push(label + ": Zahl nicht aria-hidden");
          ["schalter", "knopf", "plakette", "nav", "kopf"].forEach(function (k) { if (de[k] !== en[k]) fehler.push(label + " Stufe" + stufe + ": " + k + " DE " + de[k] + " -> EN " + en[k]); });
          if (stufe === 0) zeilen.push(label + ": Zahl " + de.text + ", Umschalter " + de.schalter + ", Knopf " + de.knopf + ", Plakette " + de.plakette + ", aria '" + de.aria + "' / '" + en.aria + "'");
        }
        // ohne Speicher: Plakette ausgeblendet, keine Ausnahme
        var fe = null;
        try { Object.defineProperty(win, "localStorage", { configurable: true, get: function () { throw new Error("gesperrt"); } }); win.nxTodoZaehler(); } catch (e) { fe = e.message; }
        if (fe) fehler.push(label + ": Ausnahme ohne Speicher: " + fe);
        // Mit Spiegel (NX_TODOS, zentrale Liste) zeigt die Plakette auch ohne Browser-Speicher die Zahl des Spiegels; ohne Spiegel bleibt sie ausgeblendet
        var sp = win.NX_TODOS && Array.isArray(win.NX_TODOS.aufgaben) ? win.NX_TODOS.aufgaben.filter(function (t) { return !t.done && !t.geloescht; }).length : null;
        if (sp === null) {
          if (getComputedStyle(badge()).visibility !== "hidden") fehler.push(label + ": Plakette ohne Speicher und Spiegel nicht ausgeblendet");
          if (knopf().hasAttribute("aria-label")) fehler.push(label + ": aria-label ohne Speicher und Spiegel noch gesetzt");
        } else {
          if (getComputedStyle(badge()).visibility !== "visible" || badge().textContent !== String(sp > 99 ? "99+" : sp)) fehler.push(label + ": ohne Speicher soll die Plakette die Spiegelzahl " + sp + " zeigen, zeigt '" + badge().textContent + "'");
          if (knopf().getAttribute("aria-label") !== "To-dos, " + sp + " offen") fehler.push(label + ": aria-label ohne Speicher (Spiegel) falsch: " + knopf().getAttribute("aria-label"));
        }
        f.remove();
      }
    }
  } finally { localStorage.setItem(KEY, original); try { localStorage.setItem("nobbis-super-firma-sprache-v1", "de"); } catch (e) {} }
  return { ok: fehler.length === 0 && localStorage.getItem(KEY) === original, fehler: fehler, zeilen: zeilen, wiederhergestellt: localStorage.getItem(KEY) === original, offenBasis: basis };
}
/* ---------- Test der globalen Suche (firma.htm) ----------
   Aufruf: Inhalt dieser Funktion + await nxTestSuche({ teil: "funktion" | "layout", breiten: [390, 760, 1040, 1300, 1440] })
   Funktion: bedient die Suche mit echten Ereignissen (input/keydown/click) in einem unsichtbaren iframe (1300 px), prueft Treffer je App, Umlaute, Mehrwortsuche, Englisch,
   Filterchips, Tastatur, Leerzustand, fehlenden Index (window.NX_SUCHINDEX wird im Test geloescht und neu gerechnet), To-do- und Favoriten-Live-Treffer (Speicher wird exakt wiederhergestellt),
   Personen-Detailfenster, Wiederherstellung des Organigramms, Adresse (#s=), Sprachkette der Treffer-Links und Status 200 aller Index-Links.
   Layout: Suchfeld, Kopf und Ergebnisbereich je Breite in Deutsch und Englisch pixelgleich, kein seitliches Scrollen, Touch-Ziele >= 44 px. Rueckgabe: { ok, fehler, zeilen }. */
async function nxTestSuche(opt) {
  opt = opt || {};
  var teil = opt.teil || "funktion";
  var fehler = [], zeilen = [];
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var ok = function (name, cond, detail) { zeilen.push((cond ? "OK " : "FEHLER ") + name + (detail ? " - " + detail : "")); if (!cond) fehler.push(name + (detail ? " - " + detail : "")); };
  var TODO = "nobbis-todos-v1", TOMB = "nobbis-todos-tomb-v1", FAV = "norbert-favoriten", SPR = "nobbis-super-firma-sprache-v1";
  // Feste Testdaten fuer die zentrale Liste (Spiegel window.NX_TODOS wird im Test-iframe ersetzt, der echte Stand bleibt unberuehrt)
  var FIX = { version: 1, geaendert: "2026-10-28T12:00:00+01:00", aufgaben: [
    { id: 900001, text: "Bei der Person in der Slack-Unterhaltung melden (TEST)", done: false, star: 0, due: "2026-10-28", zeit: "", quelle: "sarah", hinweis: "Link: https://ninoxteam.slack.com/archives/TEST", created: 900001, geaendert: 900001, erledigtAm: 0, geloescht: false },
    { id: 900002, text: "Outlook Abwesenheitseintrag entfernen (TEST)", done: false, star: 0, due: "2026-11-04", zeit: "", quelle: "sarah", hinweis: "Gehoert zum To-do", created: 900002, geaendert: 900002, erledigtAm: 0, geloescht: false },
    { id: 900003, text: "Leo Text Ninox4 (TEST)", done: false, star: 0, due: "2026-11-04", zeit: "", quelle: "sarah", hinweis: "", created: 900003, geaendert: 900003, erledigtAm: 0, geloescht: false },
    { id: 900004, text: "Outlook Abwesenheitsnotiz eintragen (TEST)", done: false, star: 0, due: "", zeit: "", quelle: "manuell", hinweis: "", created: 900004, geaendert: 900004, erledigtAm: 0, geloescht: false }
  ] };
  var rect = function (el) { if (!el) return "fehlt"; var r = el.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(","); };

  async function laden(breite, lang) {
    var f = document.createElement("iframe");
    f.style.cssText = "width:" + breite + "px;height:900px;position:fixed;left:0;top:0;visibility:hidden;border:0";
    f.src = "/firma.htm?lang=" + (lang || "de") + "&x=" + Date.now();
    document.body.appendChild(f);
    await new Promise(function (r) { f.onload = r; setTimeout(r, 6000); });
    await wait(900);
    var w = f.contentWindow;
    w.__fehler = [];
    w.addEventListener("error", function (e) { w.__fehler.push(String(e.message)); });
    var ce = w.console.error; w.console.error = function () { w.__fehler.push(Array.prototype.join.call(arguments, " ")); ce.apply(w.console, arguments); };
    return { f: f, w: w, d: f.contentDocument };
  }
  async function tippe(P, q) {
    var i = P.d.getElementById("sgQ"); i.focus();
    i.value = ""; i.dispatchEvent(new P.w.Event("input", { bubbles: true }));
    var v = "";
    for (var k = 0; k < q.length; k++) { v += q.charAt(k); i.value = v; i.dispatchEvent(new P.w.InputEvent("input", { bubbles: true, data: q.charAt(k), inputType: "insertText" })); }
    await wait(380);
  }
  var taste = function (P, ziel, key, extra) { var e = new P.w.KeyboardEvent("keydown", Object.assign({ key: key, bubbles: true, cancelable: true }, extra || {})); ziel.dispatchEvent(e); return e; };
  function zaehler(P) {
    var o = {};
    [].forEach.call(P.d.querySelectorAll("#sgChips .nx-chip[data-app]"), function (c) { o[c.getAttribute("data-app")] = +c.querySelector(".count").textContent; });
    return o;
  }
  var titel = function (P) { return [].map.call(P.d.querySelectorAll(".sg-title"), function (t) { return t.textContent; }); };

  if (teil === "funktion") {
    var sichTodo = localStorage.getItem(TODO), sichTomb = localStorage.getItem(TOMB), sichFav = localStorage.getItem(FAV), sichSpr = localStorage.getItem(SPR);
    try { localStorage.removeItem(TODO); localStorage.removeItem(TOMB); } catch (e) { }
    var P = await laden(1300, "de");
    P.w.NX_TODOS = JSON.parse(JSON.stringify(FIX));
    try {
      var d = P.d, w = P.w;
      // 1. Ausgangszustand
      var main = d.querySelector("main");
      ok("Suchleiste ist erstes Element im main", main.firstElementChild && main.firstElementChild.id === "sgBar");
      ok("Index geladen", !!w.NX_SUCHINDEX && w.NX_SUCHINDEX.anzahl > 100, "Eintraege: " + (w.NX_SUCHINDEX && w.NX_SUCHINDEX.anzahl));
      ok("Ergebnisfeld anfangs verborgen, Organigramm sichtbar", d.getElementById("sgResults").hidden && getComputedStyle(d.querySelector(".tree")).display !== "none" && getComputedStyle(d.querySelector(".fx-apps")).display !== "none");
      var mcs = getComputedStyle(main); ok("Inhaltsbereich 1140 px, Suchleiste fuellt ihn (wie auf den anderen Seiten)", main.getBoundingClientRect().width === 1140 && d.getElementById("sgBar").getBoundingClientRect().width === 1140 - parseFloat(mcs.paddingLeft) - parseFloat(mcs.paddingRight), "main " + main.getBoundingClientRect().width + ", Leiste " + d.getElementById("sgBar").getBoundingClientRect().width);
      ok("Eingabefeld 48 px hoch, Schrift >= 16 px", d.getElementById("sgQ").getBoundingClientRect().height === 48 && parseFloat(getComputedStyle(d.getElementById("sgQ")).fontSize) >= 16);
      ok("Platzhalter beginnt mit Suchen:", /^Suchen:/.test(d.getElementById("sgQ").placeholder));
      var snapTeam = d.getElementById("team").innerHTML, snapApps = d.getElementById("apps").innerHTML, snapTree = d.querySelector(".tree").innerHTML, snapLegend = d.getElementById("legend").innerHTML;

      // 2. Begriffe je App
      var T = [
        ["outlook", { todo: 2 }], ["git commit", { github: 5 }], ["willi", { org: 1, agenten: 1 }], ["bootstrap", { org: 1, agenten: 1 }],
        ["sonnet", { agenten: 10, org: 5 }], ["tagesabschluss", { tagesberichte: 1 }], ["hubspot", { agenten: 1, org: 1 }], ["organigramm", { tagesberichte: 1, favoriten: 1 }],
        ["zeiten buchen", { favoriten: 1 }], ["slack", { favoriten: 1, todo: 1 }], ["morgenübersicht", { sarah: 1 }], ["pull request", { github: 1, agenten: 1 }],
        ["erinnerung", { todo: 3, agenten: 1 }], ["pwa", { org: 1, agenten: 1 }], ["leo", { todo: 1 }], ["hosting", { ninox4: 1 }]
      ];
      for (var t = 0; t < T.length; t++) {
        await tippe(P, T[t][0]);
        var z = zaehler(P), miss = [];
        Object.keys(T[t][1]).forEach(function (a) { if (!(z[a] >= T[t][1][a])) miss.push(a + ">=" + T[t][1][a] + " (ist " + (z[a] || 0) + ")"); });
        ok("Suche '" + T[t][0] + "'", miss.length === 0 && d.getElementById("sgResults").hidden === false, miss.length ? miss.join(", ") + " | " + JSON.stringify(z) : JSON.stringify(z) + " | " + d.getElementById("sgStatus").textContent);
      }

      // 3. Umlaute, Gross/Klein, Mehrwort
      var paare = [["uebersicht", "Übersicht"], ["pruefung", "Prüfung"], ["ÜBERSICHT", "übersicht"], ["strasse", "straße"]];
      for (var p = 0; p < paare.length; p++) {
        await tippe(P, paare[p][0]); var a1 = JSON.stringify(zaehler(P)) + titel(P).join("|");
        await tippe(P, paare[p][1]); var a2 = JSON.stringify(zaehler(P)) + titel(P).join("|");
        ok("Umlaut/Schreibweise gleich: " + paare[p][0] + " = " + paare[p][1], a1 === a2 && (p === 3 || a1.length > 20), a1.slice(0, 90));
      }
      await tippe(P, "willi"); var nW = +zaehler(P).org;
      await tippe(P, "willi bootstrap"); var nWB = zaehler(P);
      ok("Mehrwortsuche = UND (willi bootstrap)", nWB.org === 1 && !nWB.agenten || (nWB.org >= 1 && nWB.org <= nW), JSON.stringify(nWB));
      await tippe(P, "willi zzqxyv"); ok("Mehrwort UND ohne zweiten Treffer = leer", d.querySelectorAll(".sg-item").length === 0 && !!d.querySelector(".nx-empty"));
      await tippe(P, "a"); ok("1 Zeichen: Hinweis, Organigramm bleibt", /mindestens 2/.test(d.getElementById("sgStatus").textContent) && d.getElementById("sgResults").hidden && getComputedStyle(d.querySelector(".tree")).display !== "none", d.getElementById("sgStatus").textContent);
      // Markierung und Snippet
      await tippe(P, "commit"); var m1 = d.querySelectorAll(".sg-title mark").length, sn = d.querySelector(".sg-snip");
      ok("Fundstellen markiert (mark) und Textauszug", m1 > 0 && !!sn && sn.textContent.length <= 175, "marks " + m1 + ", snippet " + (sn && sn.textContent.length));
      await tippe(P, "uebersicht"); var mk = [].map.call(d.querySelectorAll("mark"), function (x) { return x.textContent; });
      ok("Markierung bei ue/ü deckt das ganze Wort-Zeichen ab", mk.some(function (x) { return /^(Ü|ü)bersicht$/.test(x); }), mk.slice(0, 4).join(","));

      // 4. Englisch
      w.nxSetLang("en"); await wait(400);
      await tippe(P, "reminder"); var ze = zaehler(P);
      ok("Englisch 'reminder' findet die Erinnerungen aus der zentralen Liste (Quelle sarah)", ze.todo >= 3, JSON.stringify(ze));
      ok("Treffer mit Quelle sarah tragen das Abzeichen Reminder", /Reminder/.test(d.getElementById("sgResults").textContent), d.getElementById("sgResults").textContent.slice(0, 80));
      ok("Statuszeile Englisch", /results? in \d+ apps?/.test(d.getElementById("sgStatus").textContent), d.getElementById("sgStatus").textContent);
      ok("Platzhalter und Beschriftung Englisch", /^Search:/.test(d.getElementById("sgQ").placeholder) && d.querySelector('label[for="sgQ"]').textContent === "Search all apps");
      await tippe(P, "outlook"); ze = zaehler(P);
      ok("Englisch: 'outlook' findet die Aufgaben der zentralen Liste", ze.todo >= 2, JSON.stringify(ze));
      ok("Anzeige in Englisch: Aufgabentext bleibt Eigeneingabe", titel(P).indexOf("Outlook Abwesenheitseintrag entfernen (TEST)") !== -1, titel(P).join("|"));
      await tippe(P, "software expert"); ok("Rolle in Englisch angezeigt", /Software Expert/.test(d.getElementById("sgResults").textContent));
      w.nxSetLang("de"); await wait(400);
      ok("Sprachwechsel rendert neu (Deutsch)", /^Suchen:/.test(d.getElementById("sgQ").placeholder) && /Treffer/.test(d.getElementById("sgStatus").textContent), d.getElementById("sgStatus").textContent);
      await tippe(P, "software experte"); ok("Deutsch findet Rolle auch in DE", /Software-Experte/.test(d.getElementById("sgResults").textContent));
      await tippe(P, "reminder"); ok("Englischer Begriff findet auch bei Deutsch-Anzeige", zaehler(P).todo >= 1, JSON.stringify(zaehler(P)));

      // 5. Filterchips und Gruppenzaehlung
      await tippe(P, "git");
      var ch = zaehler(P), sum = 0, alle = +d.querySelector('#sgChips [data-app="all"] .count').textContent;
      Object.keys(ch).forEach(function (k) { if (k !== "all") sum += ch[k]; });
      ok("Chip 'Alle' = Summe der App-Chips", alle === sum, alle + " vs " + sum);
      var gl = [].map.call(d.querySelectorAll(".sg-group"), function (g) { return +g.querySelector(".sg-count").textContent; }).reduce(function (a, b) { return a + b; }, 0);
      ok("Gruppenzaehler = Trefferzahl", gl === alle, gl + " vs " + alle);
      ok("Statuszeile nennt Trefferzahl", new RegExp("^" + alle + " Treffer in \\d+ Apps?").test(d.getElementById("sgStatus").textContent), d.getElementById("sgStatus").textContent);
      var chip = d.querySelector('#sgChips [data-app="github"]');
      if (chip) {
        chip.click(); await wait(150);
        ok("Chip filtert auf eine App (aria-pressed)", d.querySelectorAll(".sg-group").length === 1 && d.querySelector('#sgChips [data-app="github"]').getAttribute("aria-pressed") === "true" && d.querySelectorAll(".sg-item").length === ch.github, d.querySelectorAll(".sg-item").length + " von " + ch.github);
        ok("Statuszeile bei Filter", /Treffer in GitHub-Trainer \(von \d+ insgesamt\)/.test(d.getElementById("sgStatus").textContent), d.getElementById("sgStatus").textContent);
        d.querySelector('#sgChips [data-app="github"]').click(); await wait(150);
        ok("Chip erneut = alle Apps", d.querySelectorAll(".sg-group").length > 1 && d.querySelector('#sgChips [data-app="all"]').getAttribute("aria-pressed") === "true");
      } else ok("Chip github vorhanden", false);
      var mehr = d.querySelector("[data-more]");
      if (mehr) { var n0 = d.querySelectorAll(".sg-item").length; mehr.click(); await wait(100); ok("'Alle anzeigen' klappt Gruppe auf", d.querySelectorAll(".sg-item").length > n0 && d.querySelector("[data-more]").getAttribute("aria-expanded") === "true", n0 + " -> " + d.querySelectorAll(".sg-item").length); d.querySelector("[data-more]").click(); await wait(100); ok("'Weniger anzeigen' klappt zu", d.querySelectorAll(".sg-item").length === n0); }
      else ok("Mehr-Knopf bei langer Gruppe vorhanden", false);

      // 6. Tastatur
      d.getElementById("sgQ").blur(); d.body.focus();
      var ev = taste(P, d.body, "/");
      ok("Taste / fokussiert das Suchfeld", d.activeElement === d.getElementById("sgQ"), ev.defaultPrevented ? "" : "nicht abgefangen");
      await tippe(P, "willi");
      var klicks = []; d.addEventListener("click", function (e) { var a = e.target.closest && e.target.closest("a.sg-item"); if (a) { klicks.push(a.getAttribute("href")); e.preventDefault(); } }, true);
      var inp = d.getElementById("sgQ");
      taste(P, inp, "ArrowDown"); var a0 = inp.getAttribute("aria-activedescendant");
      ok("Pfeil ab markiert ersten Treffer (aria-activedescendant)", !!a0 && d.getElementById(a0) && d.getElementById(a0).classList.contains("is-active"), a0);
      taste(P, inp, "ArrowDown"); var a1b = inp.getAttribute("aria-activedescendant");
      ok("Pfeil ab bewegt weiter", a1b && a1b !== a0 && !d.getElementById(a0).classList.contains("is-active"), a0 + " -> " + a1b);
      taste(P, inp, "ArrowUp"); ok("Pfeil auf geht zurueck", inp.getAttribute("aria-activedescendant") === a0);
      taste(P, inp, "ArrowUp"); ok("Pfeil auf am Anfang hebt Markierung auf", !inp.hasAttribute("aria-activedescendant"));
      taste(P, inp, "ArrowDown"); taste(P, inp, "ArrowDown"); taste(P, inp, "Enter");
      ok("Enter oeffnet markierten Treffer", klicks.length === 1 && klicks[0] === d.getElementById(a1b).getAttribute("href"), klicks.join());
      taste(P, inp, "ArrowUp"); taste(P, inp, "ArrowUp"); taste(P, inp, "Enter");
      ok("Enter ohne Markierung oeffnet ersten Treffer", klicks.length === 2 && klicks[1] === d.querySelector("a.sg-item").getAttribute("href"), klicks.join());
      var l0 = d.querySelector("a.sg-item"); l0.focus(); var l1 = d.querySelectorAll("a.sg-item")[1];
      taste(P, l0, "ArrowDown"); ok("Pfeil ab im Ergebnis bewegt den Fokus", d.activeElement === l1);
      taste(P, d.activeElement, "ArrowUp"); taste(P, d.activeElement, "ArrowUp"); ok("Pfeil auf vom ersten Treffer zurueck ins Feld", d.activeElement === inp);
      inp.focus(); var esc = taste(P, inp, "Escape");
      ok("Esc leert, Ergebnisse weg, Organigramm zurueck", inp.value === "" && d.getElementById("sgResults").hidden && getComputedStyle(d.querySelector(".tree")).display !== "none" && getComputedStyle(d.querySelector(".fx-apps")).display !== "none" && d.getElementById("sgClear").hidden);
      await tippe(P, "willi"); var cl = d.getElementById("sgClear"); ok("Loeschknopf bei Text sichtbar", !cl.hidden);
      cl.click(); await wait(250);
      ok("Loeschknopf leert und stellt wieder her", inp.value === "" && d.getElementById("sgResults").hidden && getComputedStyle(d.querySelector(".tree")).display !== "none");
      ok("Organigramm und Erstellte Apps unveraendert", d.getElementById("team").innerHTML === snapTeam && d.getElementById("apps").innerHTML === snapApps && d.querySelector(".tree").innerHTML === snapTree && d.getElementById("legend").innerHTML === snapLegend);

      // 7. Leerzustand
      await tippe(P, "zzzqxvk");
      ok("Leerzustand mit Hinweis und Vorschlaegen", !!d.querySelector(".nx-empty") && d.querySelectorAll("[data-sugg]").length >= 3 && /Keine Treffer/.test(d.getElementById("sgStatus").textContent) && /anderen Begriff/.test(d.getElementById("sgResults").textContent));
      d.querySelector("[data-sugg]").click(); await wait(200);
      ok("Vorschlag startet Suche", d.querySelectorAll(".sg-item").length > 0 && inp.value.length > 0, inp.value);

      // 8. Adresse (#s=) und Debounce
      await tippe(P, "Prüfung 2");
      ok("Adresse traegt Suchbegriff (#s=)", w.location.hash === "#s=" + encodeURIComponent("Prüfung 2"), w.location.hash);
      inp.value = ""; inp.dispatchEvent(new w.Event("input", { bubbles: true })); await wait(100);
      ok("Adresse wird beim Leeren bereinigt", w.location.hash === "", w.location.hash);
      var vorher = d.getElementById("sgStatus").textContent;
      inp.value = "git"; inp.dispatchEvent(new w.Event("input", { bubbles: true })); await wait(40);
      var mitte = d.getElementById("sgStatus").textContent; await wait(300);
      ok("Verzoegerung ca. 120 ms (kein sofortiges Rendern, danach Ergebnis)", mitte === vorher && /Treffer/.test(d.getElementById("sgStatus").textContent), "nach 40ms: '" + mitte + "', danach: '" + d.getElementById("sgStatus").textContent + "'");

      // 9. To-do-Live
      var todos = [{ id: 910001, created: 910001, text: "Outlook Abwesenheitsnotiz eintragen (TESTKOPIE)", done: false, star: 1, due: "2026-10-01" }, { id: 910002, created: 910002, text: "Erledigt: outlook testen", done: true, star: 0, due: "" }];
      try { localStorage.setItem(TODO, JSON.stringify(todos)); } catch (e) { }
      await tippe(P, "outlook"); var zt = zaehler(P);
      ok("To-do-Live-Treffer (offen und erledigt, zusammen mit der zentralen Liste: 2 + 2)", zt.todo === 4 && /offen/.test(d.getElementById("sgResults").textContent) && /erledigt/.test(d.getElementById("sgResults").textContent), JSON.stringify(zt));
      ok("To-do: Faelligkeit, ueberfaellig und Stern", /überfällig · 01\.10\.2026/.test(d.getElementById("sgResults").textContent) && !!d.querySelector(".sg-star"));
      var tl = d.querySelector('#sgResults a[href*="03_todo/index.html"]'); ok("To-do-Treffer verlinkt die To-do-App", !!tl && /03_todo\/index\.html\?lang=de/.test(tl.getAttribute("href")), tl && tl.getAttribute("href"));
      try { localStorage.setItem(TODO, "kaputt{"); } catch (e) { }
      await tippe(P, "outlook"); ok("Kaputter To-do-Cache: nur die zentrale Liste (2 Treffer), kein Absturz", zaehler(P).todo === 2 && w.__fehler.length === 0, JSON.stringify(zaehler(P)));
      try { if (sichTodo === null) localStorage.removeItem(TODO); else localStorage.setItem(TODO, sichTodo); } catch (e) { }
      // 9b. Zentrale Liste: gleiche Zusammenfuehrung wie der Zaehler (je id nach geaendert), Geloeschte nie, nichts doppelt
      try { localStorage.setItem(TODO, JSON.stringify([{ id: 900004, text: "Outlook CACHE NEU", done: false, star: 0, due: "", zeit: "", quelle: "manuell", hinweis: "", created: 900004, geaendert: 999999, geloescht: false }])); } catch (e) { }
      await tippe(P, "outlook"); var z9 = zaehler(P);
      ok("Zentrale Liste + Cache: neuere Aenderung gewinnt, nichts doppelt", z9.todo === 2 && titel(P).indexOf("Outlook CACHE NEU") !== -1 && titel(P).indexOf("Outlook Abwesenheitsnotiz eintragen (TEST)") === -1, JSON.stringify(z9) + " " + titel(P).join("|"));
      try { localStorage.setItem(TODO, JSON.stringify([])); localStorage.setItem(TOMB, JSON.stringify([{ id: 900002, geaendert: 999999 }])); } catch (e) { }
      await tippe(P, "outlook"); z9 = zaehler(P);
      ok("Geloeschte Aufgabe (Grabstein) erscheint nicht mehr in der Suche", z9.todo === 1 && titel(P).indexOf("Outlook Abwesenheitseintrag entfernen (TEST)") === -1, JSON.stringify(z9) + " " + titel(P).join("|"));
      try { localStorage.setItem(TOMB, JSON.stringify([])); localStorage.setItem(TODO, JSON.stringify([{ id: 900002, text: "Outlook Abwesenheitseintrag entfernen (TEST)", geloescht: true, geaendert: 999999, created: 900002 }])); } catch (e) { }
      await tippe(P, "outlook"); z9 = zaehler(P);
      ok("Geloeschte Aufgabe im Cache (geloescht:true, neuer) erscheint nicht", z9.todo === 1, JSON.stringify(z9));
      try { localStorage.removeItem(TOMB); localStorage.removeItem(TODO); } catch (e) { }
      await tippe(P, "outlook"); ok("Ohne Cache zeigt die Suche die zentrale Liste unveraendert (2)", zaehler(P).todo === 2, JSON.stringify(zaehler(P)));
      await tippe(P, "slack"); var sl9 = d.querySelector('#sgResults a[href*="03_todo/index.html"]');
      ok("Aufgaben-Treffer oeffnet die To-do-App", !!sl9, sl9 && sl9.getAttribute("href"));
      try { if (sichTodo === null) localStorage.removeItem(TODO); else localStorage.setItem(TODO, sichTodo); } catch (e) { }
      ok("To-do-Speicher exakt wiederhergestellt", localStorage.getItem(TODO) === sichTodo);
      // Favoriten-Live
      try { localStorage.setItem(FAV, JSON.stringify([{ name: "Testfavorit Outlook", url: "https://example.org/pfad" }, { name: "Boese outlook", url: "javascript:alert(1)" }])); } catch (e) { }
      await tippe(P, "outlook"); var fl = d.querySelector('#sgResults a[href="https://example.org/pfad"]');
      ok("Eigener Favorit live gefunden, in neuem Tab mit rel=noopener", !!fl && fl.target === "_blank" && /noopener/.test(fl.rel), fl && fl.outerHTML.slice(0, 120));
      ok("Unsichere Favoriten-Adresse (javascript:) wird ignoriert", !d.querySelector('#sgResults a[href^="javascript"]') && !/Boese/.test(d.getElementById("sgResults").textContent));
      try { if (sichFav === null) localStorage.removeItem(FAV); else localStorage.setItem(FAV, sichFav); } catch (e) { }
      ok("Favoriten-Speicher exakt wiederhergestellt", localStorage.getItem(FAV) === sichFav);
      var ext = d.querySelector('#sgResults a[target="_blank"]'); await tippe(P, "slack"); ext = d.querySelector('#sgResults a[target="_blank"]');
      ok("Feste Favoriten extern: neuer Tab, rel=noopener", !!ext && /noopener/.test(ext.rel), ext && ext.getAttribute("href"));

      // 10. Personen-Detailfenster
      await tippe(P, "claudia"); var pl = d.querySelector("a[data-p='claudia']");
      ok("Mitarbeiter-Treffer vorhanden", !!pl);
      if (pl) { pl.click(); await wait(800);
        ok("Treffer oeffnet Detailfenster, Seite bleibt", d.getElementById("detail").classList.contains("show") && /Claudia/.test(d.getElementById("detailTitle").textContent) && w.location.pathname === "/firma.htm", w.location.pathname);
        w.bootstrap.Modal.getInstance(d.getElementById("detail")).hide(); await wait(600);
        ok("Fenster schliesst, Suche bleibt", !d.getElementById("detail").classList.contains("show") && d.getElementById("sgResults").hidden === false);
      }
      // 11. Sprachkette der Treffer-Links
      await tippe(P, "git"); var lk = [].map.call(d.querySelectorAll("a.sg-item:not([target])"), function (a) { return a.getAttribute("href"); }).filter(function (h) { return !/^#/.test(h); });
      ok("Treffer-Links tragen ?lang=de", lk.length > 0 && lk.every(function (h) { return /[?&]lang=de/.test(h); }), lk.slice(0, 2).join(" "));
      w.nxSetLang("en"); await wait(400);
      lk = [].map.call(d.querySelectorAll("a.sg-item:not([target])"), function (a) { return a.getAttribute("href"); }).filter(function (h) { return !/^#/.test(h); });
      ok("Nach Sprachwechsel tragen Links ?lang=en", lk.length > 0 && lk.every(function (h) { return /[?&]lang=en/.test(h); }), lk.slice(0, 2).join(" "));
      await tippe(P, "agenten"); var ag = d.querySelector('a.sg-item[href*="agenten_skills_uebersicht"]');
      ok("Agenten-Link mit #q= und Sprache", !!ag && /\?lang=en#q=/.test(ag.getAttribute("href")), ag && ag.getAttribute("href"));
      w.nxSetLang("de"); await wait(300);

      // 12. Index fehlt (Fehlerpfad)
      var idx = w.NX_SUCHINDEX; delete w.NX_SUCHINDEX; w.NX_SUCHINDEX = undefined;
      try { localStorage.setItem(TODO, JSON.stringify(todos)); } catch (e) { }
      await tippe(P, "outlook");
      ok("Index fehlt: klare Fehlermeldung (role=alert), kein Absturz", !!d.querySelector('.sg-error[role="alert"]') && /nicht verfügbar/.test(d.getElementById("sgResults").textContent) && /nicht verfügbar/.test(d.getElementById("sgStatus").textContent) && w.__fehler.length === 0, d.getElementById("sgStatus").textContent);
      ok("Index fehlt: To-do-Live-Treffer trotzdem (zentrale Liste 2 + Cache 2)", zaehler(P).todo === 4, JSON.stringify(zaehler(P)));
      w.NX_SUCHINDEX = { eintraege: [] }; w.nxSuche.lauf(); await wait(100);
      ok("Leerer Index wird wie fehlender behandelt", !!d.querySelector(".sg-error"));
      w.NX_SUCHINDEX = idx; try { if (sichTodo === null) localStorage.removeItem(TODO); else localStorage.setItem(TODO, sichTodo); } catch (e) { }
      await tippe(P, "outlook"); ok("Index wieder da: Fehlermeldung weg, Treffer da", !d.querySelector(".sg-error") && zaehler(P).todo >= 1);
      ok("To-do-Speicher nach Fehlerpfad wiederhergestellt", localStorage.getItem(TODO) === sichTodo);

      // 13. Konsole
      ok("Keine Konsolenfehler/Skriptfehler im Seitenfenster", w.__fehler.length === 0, w.__fehler.join(" | "));
      ok("Version 1.9.0 in Meta und Fusszeile", d.querySelector('meta[name="app-version"]').content === d.querySelector("[data-app-version]").textContent);
      // 14. Links: alle URLs des Index laden (Status 200)
      var urls = {}; w.NX_SUCHINDEX.eintraege.forEach(function (e) { if (!/^https?:/.test(e.u)) urls[e.u.split("#")[0]] = 1; });
      w.NX_SUCHINDEX.apps.forEach(function (a) { if (a.u) urls[a.u.split("#")[0]] = 1; });
      var ul = Object.keys(urls), bad = [];
      for (var u = 0; u < ul.length; u++) { try { var rr = await fetch("/" + ul[u], { cache: "no-store" }); if (rr.status !== 200) bad.push(ul[u] + " " + rr.status); } catch (e) { bad.push(ul[u] + " Fehler"); } }
      ok("Alle internen Index-Links liefern 200 (" + ul.length + " Seiten)", bad.length === 0, bad.join(", "));
      var ex = w.NX_SUCHINDEX.eintraege.filter(function (e) { return /^https?:/.test(e.u); }).length;
      zeilen.push("INFO externe Index-Links nicht abgerufen: " + ex);
    } finally {
      try { if (sichTodo === null) localStorage.removeItem(TODO); else localStorage.setItem(TODO, sichTodo); if (sichFav === null) localStorage.removeItem(FAV); else localStorage.setItem(FAV, sichFav); localStorage.setItem(SPR, "de"); if (sichTomb === null) localStorage.removeItem(TOMB); else localStorage.setItem(TOMB, sichTomb); } catch (e) { }
      P.f.remove();
    }
  } else {
    // Layout: je Breite Deutsch und Englisch vergleichen
    var breiten = opt.breiten || [390, 760, 1040, 1300, 1440];
    for (var b = 0; b < breiten.length; b++) {
      var W = breiten[b], M = {};
      var Q = await laden(W, "de");
      try {
        for (var l = 0; l < 2; l++) {
          var sp = l === 0 ? "de" : "en"; Q.w.nxSetLang(sp); await wait(350);
          var dd = Q.d, m = {}; var qi = dd.getElementById("sgQ"); qi.value = ""; qi.dispatchEvent(new Q.w.Event("input", { bubbles: true })); await wait(250);
          m.idle = [rect(dd.querySelector(".nx-header")), rect(dd.querySelector(".nx-langswitch")), rect(dd.getElementById("sgBar")), rect(dd.getElementById("sgQ")), rect(dd.querySelector(".nx-searchbar .nx-search"))].join(" | ");
          await tippe(Q, "git"); await wait(100);
          m.suche = [rect(dd.querySelector(".nx-header")), rect(dd.getElementById("sgQ")), rect(dd.getElementById("sgBar")), rect(dd.getElementById("sgResults")).split(",").slice(0, 3).join(",")].join(" | ");
          m.chipsH = rect(dd.getElementById("sgChips")).split(",")[3];
          m.ueber = Math.max(0, Q.d.documentElement.scrollWidth - Q.d.documentElement.clientWidth);
          var ziele = [].slice.call(dd.querySelectorAll("#sgChips .nx-chip, .sg-item, .sg-more, #sgClear")).map(function (e) { var r = e.getBoundingClientRect(); return Math.min(r.width, 9999) < 44 || r.height < 44 ? e.className + " " + Math.round(r.width) + "x" + Math.round(r.height) : ""; }).filter(Boolean);
          m.klein = ziele; m.eingabeFont = parseFloat(getComputedStyle(dd.getElementById("sgQ")).fontSize);
          m.items = dd.querySelectorAll(".sg-item").length;
          // Textabschneiden: Elemente, die seitlich aus ihrer Karte ragen
          m.raus = [].slice.call(dd.querySelectorAll(".sg-item")).filter(function (a) { var r = a.getBoundingClientRect(); return [].some.call(a.querySelectorAll(".sg-title,.sg-sub,.sg-snip,.sg-badges"), function (c) { var q = c.getBoundingClientRect(); return q.right > r.right + 1 || q.left < r.left - 1; }); }).length;
          m.fehler = Q.w.__fehler.length;
          M[sp] = m;
        }
        ok("Breite " + W + ": Kopf, Suchfeld, Leiste in DE = EN pixelgleich (Ruhe)", M.de.idle === M.en.idle, M.de.idle + "  <>  " + M.en.idle);
        ok("Breite " + W + ": Suchzustand Kopf/Suchfeld/Leiste/Ergebnisbereich DE = EN", M.de.suche === M.en.suche, M.de.suche + "  <>  " + M.en.suche);
        ok("Breite " + W + ": Chipzeilen-Hoehe DE = EN (kein Sprung)", M.de.chipsH === M.en.chipsH, M.de.chipsH + " / " + M.en.chipsH);
        ok("Breite " + W + ": kein seitliches Scrollen (DE und EN)", M.de.ueber === 0 && M.en.ueber === 0, M.de.ueber + "/" + M.en.ueber);
        ok("Breite " + W + ": Touch-Ziele >= 44 px", M.de.klein.length === 0 && M.en.klein.length === 0, M.de.klein.concat(M.en.klein).slice(0, 3).join("; "));
        ok("Breite " + W + ": Eingabeschrift >= 16 px", M.de.eingabeFont >= 16);
        ok("Breite " + W + ": Texte ragen nicht aus Karten", M.de.raus === 0 && M.en.raus === 0, M.de.raus + "/" + M.en.raus + " bei " + M.de.items + " Treffern");
        ok("Breite " + W + ": keine Konsolenfehler", M.de.fehler === 0 && M.en.fehler === 0);
      } finally { try { localStorage.setItem(SPR, "de"); } catch (e) { } Q.f.remove(); }
    }
  }
  return { ok: fehler.length === 0, fehler: fehler, anzahl: zeilen.filter(function (z) { return /^OK/.test(z); }).length + " OK, " + fehler.length + " Fehler", zeilen: zeilen };
}

/* ===== Tests Stufe 2: Live-Ansichten der zentralen Liste und Ordnerverbindung =====
   nxTestSarah()     Sarahs Uebersicht: Wochenlogik gegen die To-do-App (alle Tage, Jahreswechsel), Abschnitte/Zahlen mit Testaufgaben, DE/EN, Loeschen, Links, ohne Spiegel, Layout
   nxTestFavoriten() Favoriten: Abschnitt Erinnerungen aus der zentralen Liste (ueberfaellig + naechste 7 Tage), DE/EN, Live-Aktualisierung
   nxTestOrdner()    To-do-App: Ordnerverbindung mit SIMULIERTEM Verzeichnis-Handle (der echte Dialog ist nicht testbar), Spiegel todos.js, Rueckfall Datei, Fehlerfaelle
   Der echte Stand (Spiegel, Browser-Speicher, Sprache) wird gesichert und exakt wiederhergestellt. */
async function nxTestStufe2Hilfe() {
  var H = {};
  H.wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  H.KEYS = function () { var k = []; for (var i = 0; i < localStorage.length; i++) { var n = localStorage.key(i); if (/^nobbis-todos|^norbert-favoriten$|^nobbis-super-firma-sprache-v1$/.test(n)) k.push(n); } return k; };
  H.sichern = function () { var o = {}; H.KEYS().forEach(function (k) { o[k] = localStorage.getItem(k); }); return o; };
  H.leeren = function () { H.KEYS().forEach(function (k) { if (k !== "nobbis-super-firma-sprache-v1") localStorage.removeItem(k); }); };
  H.zurueck = function (o) { H.KEYS().forEach(function (k) { if (!(k in o)) localStorage.removeItem(k); }); Object.keys(o).forEach(function (k) { localStorage.setItem(k, o[k]); }); };
  H.lade = async function (url, breite) {
    var f = document.createElement("iframe");
    f.style.cssText = "width:" + (breite || 1300) + "px;height:900px;position:fixed;left:0;top:0;visibility:hidden;border:0";
    f.src = url + (url.indexOf("?") < 0 ? "?" : "&") + "x=" + Date.now();
    document.body.appendChild(f);
    await new Promise(function (r) { f.onload = r; setTimeout(r, 6000); });
    await H.wait(900);
    var w = f.contentWindow; w.__fehler = [];
    w.addEventListener("error", function (e) { w.__fehler.push(String(e.message)); });
    var ce = w.console.error; w.console.error = function () { w.__fehler.push(Array.prototype.join.call(arguments, " ")); ce.apply(w.console, arguments); };
    return { f: f, w: w, d: f.contentDocument };
  };
  H.pad = function (n) { return (n < 10 ? "0" : "") + n; };
  H.iso = function (d) { return d.getFullYear() + "-" + H.pad(d.getMonth() + 1) + "-" + H.pad(d.getDate()); };
  H.plus = function (iso, n) { var p = iso.split("-").map(Number), d = new Date(p[0], p[1] - 1, p[2]); d.setDate(d.getDate() + n); return H.iso(d); };
  H.dn = function (iso) { var p = iso.split("-").map(Number); return Math.floor(Date.UTC(p[0], p[1] - 1, p[2]) / 86400000); };
  H.wochen = function (iso) { return Math.floor((H.dn(iso) + 3) / 7); };   // 1970-01-01 war ein Donnerstag: Wochenindex Montag bis Sonntag, unabhaengig von der App berechnet
  H.soll = function (due, heute) {
    if (!due) return "nodate"; if (due < heute) return "overdue"; if (due === heute) return "today";
    var d = H.wochen(due) - H.wochen(heute); return d === 0 ? "week" : d === 1 ? "next" : "later";
  };
  H.aufg = function (id, text, due, o) {
    o = o || {};
    return { id: id, text: text, done: !!o.done, star: o.star ? 1 : 0, due: due || "", zeit: o.zeit || "", quelle: o.quelle || "manuell", hinweis: o.hinweis || "", created: id, geaendert: o.geaendert || id, erledigtAm: o.done ? id : 0, geloescht: !!o.geloescht };
  };
  return H;
}

async function nxTestSarah(opt) {
  opt = opt || {};
  var H = await nxTestStufe2Hilfe(), fehler = [], zeilen = [];
  var ok = function (n, c, d) { zeilen.push((c ? "OK " : "FEHLER ") + n + (d ? " - " + d : "")); if (!c) fehler.push(n + (d ? " - " + d : "")); };
  var SEITE = "/05_Sarah_Erinnerungen/sarah-uebersicht.html", sich = H.sichern(), S, A;
  H.leeren();
  try {
    S = await H.lade(SEITE + "?lang=de"); A = await H.lade("/02_Erstellte_Apps/03_todo/index.html?lang=de");
    H.leeren();   // die To-do-App schreibt beim Laden ihren Cache: fuer den Test wieder leeren
    var w = S.w, d = S.d, heute = H.iso(new Date());
    ok("Seite laedt, Live-Container vorhanden", !!d.getElementById("live") && typeof w.nxSarahGruppe === "function" && typeof A.w.groupOf === "function");
    // 1. Wochenlogik: Sarah = unabhaengige Berechnung; To-do-App = Sarah (ausser "Morgen" ist in der App eine eigene Gruppe)
    var tage = [], start = ["2026-10-19", "2026-12-21"], diffS = 0, diffA = 0, n = 0, bsp = "";
    start.forEach(function (s0) { for (var i = 0; i < 35; i++) tage.push(H.plus(s0, i)); });
    tage.push("2027-01-01", "2027-01-03", "2027-01-04", "2024-02-26", "2024-03-03", "2026-03-29", "2026-10-25", "2026-10-26");
    tage.forEach(function (T) {
      for (var o = -10; o <= 30; o++) {
        var due = H.plus(T, o), sg = w.nxSarahGruppe({ due: due }, T), ag = A.w.groupOf({ due: due, done: false }, T), is = H.soll(due, T); if (ag === "nextweek") ag = "next";
        n++;
        if (sg !== is) { diffS++; if (!bsp) bsp = "Sarah " + sg + " statt " + is + " (heute " + T + ", faellig " + due + ")"; }
        var erw = (due === H.plus(T, 1)) ? "tomorrow" : is;
        if (ag !== erw) { diffA++; if (!bsp) bsp = "App " + ag + " statt " + erw + " (heute " + T + ", faellig " + due + ")"; }
      }
      if (w.nxSarahGruppe({ due: "" }, T) !== "nodate" || A.w.groupOf({ due: "", done: false }, T) !== "nodate") diffS++;
    });
    ok("Wochenlogik: Sarah = unabhaengige Kalenderwochen-Berechnung (" + n + " Faelle, Wochen Mo-So, Jahreswechsel, Schaltjahr)", diffS === 0, bsp);
    ok("Wochenlogik identisch zur To-do-App (Gruppen, Morgen = eigene Gruppe der App) (" + n + " Faelle)", diffA === 0, bsp);
    // 2. Testaufgaben von gestern bis uebernaechster Woche (Kalenderwochengrenzen relativ zu heute)
    var mo = H.plus(heute, -((new Date().getDay() + 6) % 7)), soDiese = H.plus(mo, 6), moNaechste = H.plus(mo, 7), soNaechste = H.plus(mo, 13), moUeber = H.plus(mo, 14);
    var ids = 910000, fx = [];
    var T = function (text, due, o) { ids++; var a = H.aufg(ids, text, due, o); fx.push(a); return a; };
    T("T gestern", H.plus(heute, -1)); T("T heute ganztaegig", heute, { quelle: "sarah" }); T("T heute 09:30", heute, { zeit: "09:30", star: 1, hinweis: "Link: https://ninoxteam.slack.com/archives/TEST1" });
    T("T morgen", H.plus(heute, 1)); T("T sonntag diese Woche", soDiese); T("T montag naechste Woche", moNaechste, { hinweis: "http://unsicher.example/x" });
    T("T sonntag naechste Woche", soNaechste, { hinweis: "https://outlook.office.com/mail/ und mehr Text" }); T("T montag uebernaechste", moUeber); T("T ohne Datum", "");
    T("T erledigt heute", heute, { done: true }); T("T geloescht heute", heute, { geloescht: true }); T("T javascript", H.plus(heute, 40), { hinweis: "javascript:alert(1) https://example.org/ok" });
    w.NX_TODOS = { version: 1, geaendert: "x", aufgaben: fx.filter(function (t) { return !t.geloescht; }) };
    w.nxSarahRender();
    var gruppen = ["today", "overdue", "week", "next", "later", "nodate"], erw2 = {}, ist = {};
    gruppen.forEach(function (g) { erw2[g] = 0; });
    fx.forEach(function (t) { if (!t.done && !t.geloescht) erw2[H.soll(t.due, heute)]++; });
    var stats = function () { var o = {}; [].forEach.call(d.querySelectorAll("[data-stat]"), function (e) { o[e.getAttribute("data-stat")] = +e.querySelector(".n").textContent; }); return o; };
    var cards = function (g) { return [].map.call(d.querySelectorAll('[data-cards="' + g + '"] .card h3'), function (h) { return h.textContent; }); };
    ist = stats();
    ok("Zahlenkacheln stimmen (6 Kacheln)", JSON.stringify(ist) === JSON.stringify(erw2) && d.querySelectorAll("[data-stat]").length === 6, JSON.stringify(ist) + " erwartet " + JSON.stringify(erw2));
    gruppen.forEach(function (g) { var c = cards(g); ok("Abschnitt " + g + ": Kartenzahl = Kachel (" + erw2[g] + ")", c.length === erw2[g], c.join(" | ")); });
    ok("Erledigte und geloeschte Aufgaben erscheinen nicht", !/T erledigt|T geloescht/.test(d.getElementById("live").textContent));
    ok("Reihenfolge Heute: ganztaegig vor 09:30", cards("today").join("|") === "T heute ganztaegig|T heute 09:30" || cards("today").join("|").indexOf("T heute ganztaegig") < cards("today").join("|").indexOf("T heute 09:30"), cards("today").join("|"));
    var heuteTag = [].map.call(d.querySelectorAll('[data-cards="today"] .card'), function (c) { return c.querySelector(".tag").textContent; });
    ok("Uhrzeit bzw. ganztaegig als Abzeichen", heuteTag.join("|") === "ganztägig|09:30" || heuteTag.indexOf("09:30") >= 0 && heuteTag.indexOf("ganztägig") >= 0, heuteTag.join("|"));
    var btn = d.querySelectorAll("#live a.nx-btn-primary");
    var hrefs = [].map.call(btn, function (a) { return a.getAttribute("href"); });
    ok("Link-Knopf nur bei https-Link im Hinweis (slack, outlook, example.org; kein http, kein javascript)", hrefs.length === 3 && hrefs.every(function (h) { return /^https:\/\//.test(h); }) && !/javascript|unsicher/.test(hrefs.join()), hrefs.join(" "));
    ok("Link-Knoepfe: neuer Tab, noopener, ohne Sprachparameter", [].every.call(btn, function (a) { return a.target === "_blank" && /noopener/.test(a.rel) && !/lang=/.test(a.getAttribute("href")) && a.hasAttribute("data-nx-keinlang"); }));
    ok("Link-Knopf-Beschriftung (Slack/Outlook/Link) Deutsch", /Unterhaltung öffnen/.test(d.getElementById("live").textContent) && /Outlook öffnen/.test(d.getElementById("live").textContent) && /Link öffnen/.test(d.getElementById("live").textContent));
    ok("Hinweistext ohne rohe URL angezeigt", !/https?:\/\//.test([].map.call(d.querySelectorAll("#live .card p"), function (p) { return p.textContent; }).join(" ")));
    ok("Wochentag und Datum ausgeschrieben (Deutsch)", /(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag), \d\d\.\d\d\.\d{4}/.test(d.querySelector("#live .card p").textContent), d.querySelector("#live .card p").textContent);
    ok("Quelle-Abzeichen Sarah", !!d.querySelector('#live [data-quelle="sarah"]'));
    ok("Tabelle Wiederkehrend unveraendert (3 Zeilen)", d.querySelectorAll("table tr").length === 4 && /Claudia/.test(d.querySelector("table").textContent));
    // 3. Englisch
    w.nxSetLang("en"); await H.wait(500);
    var h2 = [].map.call(d.querySelectorAll("#live h2"), function (h) { return h.textContent.trim(); }).join("|");
    ok("Englisch: Abschnitte", h2 === "Today|Overdue|This week|Next week|Later|No date", h2);
    ok("Englisch: Kacheln", [].map.call(d.querySelectorAll("[data-stat] .l"), function (l) { return l.textContent; }).join("|") === "Due today|Overdue|This week|Next week|Later|No date");
    ok("Englisch: Wochentag, all day, Link-Knoepfe", /(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), \d\d\.\d\d\.\d{4}/.test(d.getElementById("live").textContent) && /all day/.test(d.getElementById("live").textContent) && /Open conversation/.test(d.getElementById("live").textContent) && /Open Outlook/.test(d.getElementById("live").textContent) && /Open link/.test(d.getElementById("live").textContent));
    ok("Englisch: Tabelle Wiederkehrend uebersetzt", /Morning overview/.test(d.querySelector("table").textContent) && /Who/.test(d.querySelector("table").textContent));
    ok("Englisch: Untertitel", /Tasks and reminders live from the central list/.test(d.querySelector(".nx-title p").textContent), d.querySelector(".nx-title p").textContent);
    w.nxSetLang("de"); await H.wait(400);
    ok("Zurueck auf Deutsch", /^Heute/.test(d.querySelector("#live h2").textContent.trim()) && /Aufgaben und Erinnerungen live/.test(d.querySelector(".nx-title p").textContent));
    // 4. Leerzustaende
    w.NX_TODOS = { version: 1, aufgaben: [] }; w.nxSarahRender();
    var leer = d.querySelectorAll("#live [data-empty]");
    ok("Leerzustaende: 6 Abschnitte mit Hinweis, alle Kacheln 0", leer.length === 6 && JSON.stringify(stats()) === JSON.stringify({ today: 0, overdue: 0, week: 0, next: 0, later: 0, nodate: 0 }) && /Heute ist nichts fällig\./.test(d.getElementById("live").textContent) && /Nichts überfällig\./.test(d.getElementById("live").textContent), leer.length + "");
    w.nxSetLang("en"); await H.wait(400);
    ok("Leerzustaende Englisch", /Nothing due today\./.test(d.getElementById("live").textContent) && /Nothing overdue\./.test(d.getElementById("live").textContent) && /No further entries\./.test(d.getElementById("live").textContent));
    w.nxSetLang("de"); await H.wait(300);
    // 5. Loeschen in der Liste -> weg nach Neuladen; Grabstein im Cache -> weg ohne Neuladen
    var nur = [H.aufg(920001, "Echt A", heute, { quelle: "sarah" }), H.aufg(920002, "Echt B", H.plus(heute, 1))];
    w.NX_TODOS = { version: 1, aufgaben: nur }; w.nxSarahRender();
    ok("Vorher: beide Aufgaben sichtbar", /Echt A/.test(d.getElementById("live").textContent) && /Echt B/.test(d.getElementById("live").textContent));
    localStorage.setItem("nobbis-todos-tomb-v1", JSON.stringify([{ id: 920001, geaendert: 920001 + 5 }])); await H.wait(400);
    ok("Grabstein im Browser-Speicher (storage-Ereignis): Aufgabe verschwindet ohne Neuladen", !/Echt A/.test(d.getElementById("live").textContent) && /Echt B/.test(d.getElementById("live").textContent), d.getElementById("live").textContent.slice(0, 60));
    localStorage.setItem("nobbis-todos-v1", JSON.stringify([Object.assign({}, nur[1], { text: "Echt B NEU", geaendert: 920002 + 9 })])); await H.wait(400);
    ok("Neuere Aenderung aus dem Cache gewinnt (Zusammenfuehrung je id), nichts doppelt", /Echt B NEU/.test(d.getElementById("live").textContent) && !/Echt B(?! NEU)/.test(d.getElementById("live").textContent) && d.querySelectorAll("#live .card").length === 1, d.querySelectorAll("#live .card").length + " Karten");
    localStorage.removeItem("nobbis-todos-tomb-v1"); localStorage.removeItem("nobbis-todos-v1");
    // 6. ohne Spiegel
    delete w.NX_TODOS; w.NX_TODOS = undefined; w.nxSarahRender();
    ok("Ohne todos.js und ohne Cache: klarer Hinweis, keine Karten", !!d.getElementById("noMirror") && /nicht verfügbar/.test(d.getElementById("noMirror").textContent) && d.querySelectorAll("#live .card.nx-card[data-id]").length === 0, d.getElementById("noMirror") && d.getElementById("noMirror").textContent);
    w.nxSetLang("en"); await H.wait(300); ok("Hinweis Englisch", /not available here/.test(d.getElementById("noMirror").textContent)); w.nxSetLang("de"); await H.wait(300);
    ok("Keine Konsolenfehler", w.__fehler.length === 0, w.__fehler.join(" | "));
    // 7. echter Stand (nur Bericht)
    var S2 = await H.lade(SEITE + "?lang=de"); var st2 = {}; [].forEach.call(S2.d.querySelectorAll("[data-stat]"), function (e) { st2[e.getAttribute("data-stat")] = +e.querySelector(".n").textContent; });
    zeilen.push("INFO echter Stand der zentralen Liste: " + JSON.stringify(st2) + "; Karten: " + [].map.call(S2.d.querySelectorAll("#live .card h3"), function (h) { return h.textContent; }).join(" | ") + "; Konsole: " + S2.w.__fehler.length + " Fehler");
    ok("Echter Stand: keine Konsolenfehler", S2.w.__fehler.length === 0, S2.w.__fehler.join(" | ")); S2.f.remove();
    // 8. Layout (Handy, Tablet, Desktop), DE und EN
    var breiten = opt.breiten || [360, 390, 768, 1300];
    for (var bi = 0; bi < breiten.length; bi++) {
      var L = await H.lade(SEITE + "?lang=de", breiten[bi]), lw = L.w, ld = L.d;
      lw.NX_TODOS = { version: 1, aufgaben: fx.filter(function (t) { return !t.geloescht; }).concat([H.aufg(930001, "Sehr langer Text ohne Leerzeichen " + "x".repeat(120), heute, { hinweis: "https://example.org/" + "a".repeat(100) })]) }; lw.nxSarahRender();
      var m = function () { var de = ld.documentElement; var raus = 0; [].forEach.call(ld.querySelectorAll("#live .card"), function (c) { [].forEach.call(c.querySelectorAll("h3,p,a"), function (e) { if (e.getBoundingClientRect().right > c.getBoundingClientRect().right + 1) raus++; }); });
        var klein = [].filter.call(ld.querySelectorAll("#live a"), function (a) { return a.getBoundingClientRect().height < 44; }).length;
        return { ueber: de.scrollWidth - de.clientWidth, raus: raus, klein: klein, kopf: Math.round(ld.querySelector(".nx-header").getBoundingClientRect().height), sw: Math.round(ld.querySelector(".nx-langswitch").getBoundingClientRect().left) }; };
      var md = m(); lw.nxSetLang("en"); await H.wait(500); var me = m();
      ok("Breite " + breiten[bi] + ": kein seitliches Scrollen, Texte ragen nicht aus Karten, Link-Knoepfe >= 44 px", md.ueber <= 0 && me.ueber <= 0 && md.raus === 0 && me.raus === 0 && md.klein === 0 && me.klein === 0, JSON.stringify(md) + " / " + JSON.stringify(me));
      ok("Breite " + breiten[bi] + ": Kopfhoehe und Umschalter DE = EN", md.kopf === me.kopf && md.sw === me.sw, md.kopf + "/" + me.kopf + " " + md.sw + "/" + me.sw);
      ok("Breite " + breiten[bi] + ": keine Konsolenfehler", lw.__fehler.length === 0, lw.__fehler.join("|"));
      lw.nxSetLang("de"); L.f.remove();
    }
  } finally { try { if (S) S.f.remove(); if (A) A.f.remove(); } catch (e) { } H.zurueck(sich); try { localStorage.setItem("nobbis-super-firma-sprache-v1", sich["nobbis-super-firma-sprache-v1"] || "de"); } catch (e) { } }
  return { ok: fehler.length === 0, fehler: fehler, anzahl: zeilen.filter(function (z) { return /^OK/.test(z); }).length + " OK, " + fehler.length + " Fehler", zeilen: zeilen };
}

async function nxTestFavoriten(opt) {
  opt = opt || {};
  var H = await nxTestStufe2Hilfe(), fehler = [], zeilen = [];
  var ok = function (n, c, d) { zeilen.push((c ? "OK " : "FEHLER ") + n + (d ? " - " + d : "")); if (!c) fehler.push(n + (d ? " - " + d : "")); };
  var sich = H.sichern(), F; H.leeren();
  try {
    F = await H.lade("/02_Erstellte_Apps/04_favoriten/index.html?lang=de"); var w = F.w, d = F.d, heute = H.iso(new Date());
    var karten = function () { return [].map.call(d.querySelectorAll("#erinnerungen .fav"), function (c) { return { n: c.querySelector("b").textContent, i: c.querySelector("span").textContent, h: c.querySelector("a").getAttribute("href"), ic: (c.querySelector(".ic i") || {}).className }; }); };
    var id = 940000, fx = [], T = function (text, due, o) { id++; var a = H.aufg(id, text, due, o); fx.push(a); return a; };
    var wdDe = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"], wdEn = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    var wd = function (iso) { var p = iso.split("-").map(Number); return (new Date(p[0], p[1] - 1, p[2]).getDay() + 6) % 7; };
    T("F spaeter 8 Tage", H.plus(heute, 8)); T("F in 7 Tagen", H.plus(heute, 7), { quelle: "sarah" }); T("F morgen", H.plus(heute, 1), { quelle: "import" }); T("F heute 09:30", heute, { zeit: "09:30", hinweis: "Link: https://ninoxteam.slack.com/archives/T" });
    T("F ueberfaellig", H.plus(heute, -3), { hinweis: "https://outlook.office.com/mail/" }); T("F ohne Datum", ""); T("F erledigt", heute, { done: true }); T("F geloescht", heute, { geloescht: true });
    w.NX_TODOS = { version: 1, aufgaben: fx.filter(function (t) { return !t.geloescht; }) }; w.dispatchEvent(new w.Event("pageshow"));
    var k = karten();
    ok("Erinnerungen: ueberfaellig + naechste 7 Tage (4 Aufgaben) + feste Karte Sarah", k.length === 5, k.map(function (c) { return c.n; }).join(" | "));
    ok("Sortiert nach Faelligkeit", k.slice(0, 4).map(function (c) { return c.n; }).join("|") === "F ueberfaellig|F heute 09:30|F morgen|F in 7 Tagen", k.map(function (c) { return c.n; }).join("|"));
    ok("Nicht gezeigt: spaeter, ohne Datum, erledigt, geloescht", !/F spaeter|F ohne|F erledigt|F geloescht/.test(d.getElementById("erinnerungen").textContent));
    var dd = function (iso) { return iso.split("-").reverse().slice(0, 2).join(".") + "."; };
    ok("Info Deutsch: Ueberfaellig / Heute+Uhrzeit / Morgen+ganztaegig / Wochentag", k[0].i === "Überfällig, " + wdDe[wd(H.plus(heute, -3))] + ", " + dd(H.plus(heute, -3)) + " (ganztägig)" && k[1].i === "Heute, " + dd(heute) + ", 09:30" && k[2].i === "Morgen, " + dd(H.plus(heute, 1)) + " (ganztägig)" && k[3].i === wdDe[wd(H.plus(heute, 7))] + ", " + dd(H.plus(heute, 7)) + " (ganztägig)", k.map(function (c) { return c.i; }).join(" | "));
    ok("Klick oeffnet die To-do-App (../03_todo/index.html)", k.slice(0, 4).every(function (c) { return /\/03_todo\/index\.html/.test(c.h) || /^\.\.\/03_todo\/index\.html/.test(c.h); }), k.map(function (c) { return c.h; }).join(" "));
    ok("Icon passend zur Quelle (slack, envelope, bell, import, Standard)", /bi-slack/.test(k[1].ic) && /bi-envelope/.test(k[0].ic) && /bi-bell-fill/.test(k[3].ic) && /bi-box-arrow-in-down/.test(k[2].ic), k.map(function (c) { return c.ic; }).join(" | "));
    ok("Feste Karte Sarahs Uebersicht mit neuer Adresse", k[4].n === "Sarahs Übersicht" && /05_Sarah_Erinnerungen\/sarah-uebersicht\.html/.test(k[4].h) && !/2026-10-28_0900/.test(d.documentElement.outerHTML), k[4].h);
    ok("Altes statisches Array ERINNERUNGEN ist weg", !/const ERINNERUNGEN\s*=/.test(d.documentElement.outerHTML));
    var hrefOk = true; for (var i = 0; i < k.length; i++) { var r = await fetch(new URL(k[i].h, d.baseURI).pathname.split("?")[0]); if (r.status !== 200) hrefOk = false; }
    ok("Links der Erinnerungskarten Status 200", hrefOk);
    w.nxSetLang("en"); await H.wait(500); var ke = karten();
    ok("Englisch: Today/Tomorrow/Overdue/Wochentage/all day, Sarah's overview", ke[0].i === "Overdue, " + wdEn[wd(H.plus(heute, -3))] + ", " + dd(H.plus(heute, -3)) + " (all day)" && ke[1].i === "Today, " + dd(heute) + ", 09:30" && ke[2].i === "Tomorrow, " + dd(H.plus(heute, 1)) + " (all day)" && ke[3].i === wdEn[wd(H.plus(heute, 7))] + ", " + dd(H.plus(heute, 7)) + " (all day)" && ke[4].n === "Sarah's overview" && ke[4].i === "All reminders live", ke.map(function (c) { return c.n + ": " + c.i; }).join(" | "));
    ok("Englisch: Ueberschrift Reminders, Aufgabentexte bleiben Eigeneingabe", /Reminders/.test(d.querySelector("h2").textContent) && ke[0].n === "F ueberfaellig");
    w.nxSetLang("de"); await H.wait(400);
    // Live: Aenderung im Browser-Speicher (To-do-App in anderem Fenster)
    localStorage.setItem("nobbis-todos-tomb-v1", JSON.stringify([{ id: 940004, geaendert: 940004 + 5 }])); await H.wait(400);
    ok("Geloeschte Aufgabe verschwindet live (storage-Ereignis)", karten().length === 4 && !/F heute 09:30/.test(d.getElementById("erinnerungen").textContent), karten().length + "");
    localStorage.removeItem("nobbis-todos-tomb-v1");
    w.NX_TODOS = { version: 1, aufgaben: [H.aufg(949001, "Nur spaeter", H.plus(heute, 30))] }; w.dispatchEvent(new w.Event("pageshow"));
    ok("Leerzustand: Hinweis + feste Karte", /Keine Erinnerungen in den nächsten 7 Tagen\./.test(d.getElementById("erinnerungen").textContent) && d.querySelectorAll("#erinnerungen .fav").length === 1);
    w.nxSetLang("en"); await H.wait(400); ok("Leerzustand Englisch", /No reminders in the next 7 days\./.test(d.getElementById("erinnerungen").textContent)); w.nxSetLang("de"); await H.wait(300);
    ok("Restliche Abschnitte unveraendert (6 feste Favoriten, Formular)", d.querySelectorAll("#fest .fav").length === 6 && !!d.getElementById("neu"));
    ok("Keine Konsolenfehler", w.__fehler.length === 0, w.__fehler.join(" | "));
    var breiten = opt.breiten || [360, 390, 768, 1300];
    for (var bi = 0; bi < breiten.length; bi++) {
      var L = await H.lade("/02_Erstellte_Apps/04_favoriten/index.html?lang=de", breiten[bi]); L.w.NX_TODOS = { version: 1, aufgaben: fx.filter(function (t) { return !t.geloescht; }) }; L.w.dispatchEvent(new L.w.Event("pageshow"));
      var ue = L.d.documentElement.scrollWidth - L.d.documentElement.clientWidth; var kl = [].filter.call(L.d.querySelectorAll("#erinnerungen .fav a"), function (a) { return a.getBoundingClientRect().height < 44; }).length;
      ok("Breite " + breiten[bi] + ": kein seitliches Scrollen, Karten >= 44 px", ue <= 0 && kl === 0, ue + " / " + kl); L.f.remove();
    }
  } finally { try { if (F) F.f.remove(); } catch (e) { } H.zurueck(sich); }
  return { ok: fehler.length === 0, fehler: fehler, anzahl: zeilen.filter(function (z) { return /^OK/.test(z); }).length + " OK, " + fehler.length + " Fehler", zeilen: zeilen };
}

async function nxTestOrdner(opt) {
  opt = opt || {};
  var H = await nxTestStufe2Hilfe(), fehler = [], zeilen = [];
  var ok = function (n, c, d) { zeilen.push((c ? "OK " : "FEHLER ") + n + (d ? " - " + d : "")); if (!c) fehler.push(n + (d ? " - " + d : "")); };
  var sich = H.sichern(), A, dump = {};
  // Simulierte Handles (der echte Verzeichnisdialog und die Berechtigungsabfrage sind nicht testbar)
  function mkFile(files, name, opt2) {
    return { kind: "file", name: name,
      getFile: async function () { return { text: async function () { return files[name]; } }; },
      createWritable: async function () { if (opt2 && opt2.schreibfehler) { var e = new Error("voll"); e.name = "QuotaExceededError"; throw e; } var buf = ""; return { write: async function (s) { buf += s; }, close: async function () { files[name] = buf; } }; },
      queryPermission: async function () { return "granted"; }, requestPermission: async function () { return "granted"; } };
  }
  function mkDir(files, opt2) {
    var o = { kind: "directory", name: "08_Todos", files: files, log: [],
      getFileHandle: async function (name, a) { o.log.push(name + (a && a.create ? "+" : "")); if (!(name in files)) { if (a && a.create) { if (opt2 && opt2.spiegelfehler && name === "todos.js") { var e1 = new Error("gesperrt"); e1.name = "NotAllowedError"; throw e1; } files[name] = ""; } else { var e = new Error("nf"); e.name = "NotFoundError"; throw e; } }
        if (opt2 && opt2.spiegelfehler && name === "todos.js") return mkFile(files, name, { schreibfehler: true });
        return mkFile(files, name); },
      queryPermission: async function () { return "granted"; }, requestPermission: async function () { return "granted"; } };
    return o;
  }
  var json = function (arr, stamp) { return '{\n  "version": 1,\n  "geaendert": "' + (stamp || "2026-10-28T10:00:00+01:00") + '",\n  "aufgaben": [\n' + arr.map(function (t) { return "    " + JSON.stringify(t).replace(/^\{/, "{ ").replace(/\}$/, " }").replace(/"(\w+)":/g, '"$1": ').replace(/,"/g, ', "'); }).join(",\n") + "\n  ]\n}"; };
  var spiegel = function (files) { var m = /window\.NX_TODOS\s*=\s*(\{[\s\S]*\})\s*;\s*$/.exec(files["todos.js"] || ""); return m ? JSON.parse(m[1]) : null; };
  var ids = [950001, 950002, 950003];
  var basis = [H.aufg(950001, "Ordner Aufgabe Eins", "2026-11-02", { quelle: "sarah" }), H.aufg(950002, "Ordner Aufgabe Zwei", ""), H.aufg(950003, "Ordner geloescht alt", "", { geloescht: true, geaendert: Date.now() - 86400000 })];
  try {
    H.leeren();
    A = await H.lade("/02_Erstellte_Apps/03_todo/index.html?lang=de"); var w = A.w, d = A.d, N = w.nxTodos;
    ok("Test-Schnittstelle vorhanden, Buttons Ordner/Datei vorhanden", !!N && !!d.getElementById("zlConnect") && !!d.getElementById("zlFile") && /Ordner 08_Todos verbinden/.test(d.getElementById("zlConnect").textContent));
    // 1. Ordner ohne todos.json: Fehlermeldung, nichts angelegt
    var leerDir = mkDir({}); await N.verbinde(leerDir); await H.wait(100);
    ok("Falscher Ordner (keine todos.json): nicht verbunden, klare Meldung, nichts angelegt", !N.state().connected && /keine todos\.json/.test(d.getElementById("zlMsg").textContent) && Object.keys(leerDir.files).length === 0, d.getElementById("zlMsg").textContent + " " + JSON.stringify(Object.keys(leerDir.files)));
    // 2. Verbinden: todos.json vorhanden, todos.js fehlt -> wird angelegt
    var files = { "todos.json": json(basis) }; var dir = mkDir(files);
    await N.verbinde(dir); await H.wait(200);
    var st = N.state();
    ok("Ordner verbunden (mode dir), Chip ok, Text 'Ordner verbunden, Spiegel aktuell'", st.connected && st.mode === "dir" && st.chip === "ok" && d.getElementById("zlChipText").textContent === "Ordner verbunden, Spiegel aktuell", JSON.stringify({ c: st.connected, m: st.mode, chip: st.chip, t: d.getElementById("zlChipText").textContent, msg: d.getElementById("zlMsg").textContent }));
    var sp = spiegel(files);
    ok("Spiegel todos.js beim Verbinden angelegt (ohne Grabstein, Zeitstempel = todos.json)", !!sp && sp.aufgaben.length === 2 && sp.geaendert === "2026-10-28T10:00:00+01:00" && files["todos.json"].indexOf(sp.geaendert) > 0, files["todos.js"] && files["todos.js"].slice(0, 160));
    ok("Ordner-Button nach Verbinden verborgen, Datei-Button verborgen", d.getElementById("zlConnect").hidden && d.getElementById("zlFile").hidden);
    // 3. Aenderung per echtem Klick: erledigen
    d.querySelector('[data-done="950001"]').click(); await H.wait(900);
    var j1 = JSON.parse(files["todos.json"]), t1 = j1.aufgaben.filter(function (t) { return t.id === 950001; })[0], s1 = spiegel(files);
    ok("Erledigen per Klick: todos.json UND todos.js geschrieben, gleicher Zeitstempel", t1.done === true && !!s1 && s1.aufgaben.filter(function (t) { return t.id === 950001; })[0].done === true && s1.geaendert === j1.geaendert && j1.geaendert !== "2026-10-28T10:00:00+01:00", j1.geaendert + " / " + (s1 && s1.geaendert));
    ok("Grabstein bleibt in todos.json, nicht im Spiegel", j1.aufgaben.some(function (t) { return t.id === 950003 && t.geloescht; }) && !s1.aufgaben.some(function (t) { return t.id === 950003; }));
    // 4. Neue Aufgabe per Eingabe + Absenden
    var inp = d.getElementById("newTodo"); inp.value = "Neu aus der App mit Umlaut \u00e4\u00f6\u00fc"; d.getElementById("addForm").requestSubmit(); await H.wait(900);
    var j2 = JSON.parse(files["todos.json"]), s2 = spiegel(files);
    ok("Neue Aufgabe: in todos.json und im Spiegel (Umlaute heil)", j2.aufgaben.some(function (t) { return t.text === "Neu aus der App mit Umlaut \u00e4\u00f6\u00fc"; }) && s2.aufgaben.some(function (t) { return t.text === "Neu aus der App mit Umlaut \u00e4\u00f6\u00fc"; }) && s2.aufgaben.length === 3, JSON.stringify(s2.aufgaben.map(function (t) { return t.id; })));
    // 5. Loeschen per Klick (Grabstein), Stern
    d.querySelector('[data-del="950002"]').click(); await H.wait(900);
    var j3 = JSON.parse(files["todos.json"]), s3 = spiegel(files);
    ok("Loeschen: Grabstein in todos.json, Aufgabe nicht im Spiegel", j3.aufgaben.some(function (t) { return t.id === 950002 && t.geloescht; }) && !s3.aufgaben.some(function (t) { return t.id === 950002; }));
    // 6. Format wie todos.ps1 (Kopfzeile, Struktur, Zeilenende, kein Newline am Ende von todos.json)
    var ft = files["todos.js"], fj = files["todos.json"];
    ok("Spiegel-Format wie todos.ps1 (Kopfzeile, window.NX_TODOS = {, Ende '};' + Zeilenumbruch)", ft.indexOf("// Spiegel von todos.json (ohne Grabsteine). Nicht von Hand aendern: wird von todos.ps1 erzeugt.\nwindow.NX_TODOS = {\n  \"version\": 1,\n  \"geaendert\": \"") === 0 && /\n  \]\n\};\n$/.test(ft) && ft.indexOf("\r") < 0, JSON.stringify(ft.slice(0, 140)) + " ... " + JSON.stringify(ft.slice(-12)));
    ok("todos.json-Format wie todos.ps1 (eine Aufgabe je Zeile, kein Zeilenumbruch am Ende, Zeitstempel mit Zeitzone)", /^\{\n  "version": 1,\n  "geaendert": "\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d[+-]\d\d:\d\d",\n  "aufgaben": \[\n    \{ "id": /.test(fj) && /\n  \]\n\}$/.test(fj) && fj.indexOf("\r") < 0);
    dump.json = fj; dump.js = ft;
    // 7. Externe Aenderung (anderer Schreiber, z. B. todos.ps1) wird uebernommen, eigene Aenderungen bleiben, Spiegel zieht nach
    var jx = JSON.parse(files["todos.json"]); jx.aufgaben.push(H.aufg(950010, "Extern hinzugefuegt (todos.ps1)", "2026-11-03", { quelle: "sarah" })); jx.geaendert = "2026-10-28T11:11:11+01:00";
    files["todos.json"] = json(jx.aufgaben, jx.geaendert); await N.sync(); await H.wait(300);
    var s4 = spiegel(files);
    ok("Externe Aenderung uebernommen (App zeigt sie) und Spiegel nachgezogen", N.state().alle.some(function (t) { return t.id === 950010; }) && !!s4 && s4.aufgaben.some(function (t) { return t.id === 950010; }) && s4.geaendert === "2026-10-28T11:11:11+01:00", JSON.stringify(s4 && s4.aufgaben.map(function (t) { return t.id; })));
    ok("Eigene Aenderungen gingen nicht verloren (erledigt + neue Aufgabe)", N.state().alle.some(function (t) { return t.id === 950001 && t.done; }) && N.state().alle.some(function (t) { return /Neu aus der App/.test(t.text); }));
    // 8. veralteter Spiegel wird geheilt
    files["todos.js"] = "window.NX_TODOS = {\"version\":1,\"geaendert\":\"alt\",\"aufgaben\":[]};\n"; await N.sync(); await H.wait(300);
    var s5 = spiegel(files); ok("Veralteter/abweichender Spiegel wird beim Lesen geheilt", !!s5 && s5.aufgaben.length === N.state().alle.filter(function (t) { return !t.geloescht; }).length && s5.geaendert !== "alt");
    // 9. Zusammenfuehren je id: gleiche Aufgabe, neuere gewinnt
    var jy = JSON.parse(files["todos.json"]); jy.aufgaben = jy.aufgaben.map(function (t) { return t.id === 950010 ? Object.assign({}, t, { text: "Extern NEUER Text", geaendert: Date.now() + 5000 }) : t; }); files["todos.json"] = json(jy.aufgaben, "2026-10-28T12:00:00+01:00"); await N.sync(); await H.wait(300);
    ok("Gleiche Aufgabe: neuere Aenderung der Datei gewinnt, Spiegel folgt", N.state().alle.filter(function (t) { return t.id === 950010; })[0].text === "Extern NEUER Text" && spiegel(files).aufgaben.some(function (t) { return t.text === "Extern NEUER Text"; }));
    // 10. Ungueltige Datei wird nicht ueberschrieben
    var vorher = files["todos.json"]; files["todos.json"] = "kaputt{ nicht json"; await N.sync(); await H.wait(200);
    ok("Ungueltige todos.json wird nicht ueberschrieben, Meldung", files["todos.json"] === "kaputt{ nicht json" && /kein gültiges Format/.test(d.getElementById("zlMsg").textContent), d.getElementById("zlMsg").textContent);
    files["todos.json"] = vorher; await N.sync(); await H.wait(200);
    // 11. Schreibfehler am Spiegel: json ok, Chip warnt, Aenderung nicht verloren
    var files2 = { "todos.json": json(basis.slice(0, 2)) }, dir2 = mkDir(files2, { spiegelfehler: true });
    await N.verbinde(dir2); await H.wait(200);
    ok("Spiegel nicht schreibbar: Chip warnt (Text), Verbindung bleibt", N.state().connected && N.state().mirrorOk === false && d.getElementById("zlChipText").textContent === "Spiegel todos.js nicht aktualisiert" && d.getElementById("zlChip").dataset.state === "wait", d.getElementById("zlChipText").textContent);
    d.querySelector('[data-star="950001"]').click(); await H.wait(900);
    ok("Spiegel-Fehler: todos.json wird trotzdem geschrieben", JSON.parse(files2["todos.json"]).aufgaben.filter(function (t) { return t.id === 950001; })[0].star === 1);
    // 12. Rueckfall: nur Datei verbinden -> Hinweis, kein Spiegel
    var files3 = { "todos.json": json(basis.slice(0, 2)) }; var fh = mkFile(files3, "todos.json");
    await N.verbinde(fh); await H.wait(200); var st3 = N.state();
    ok("Einzeldatei: mode file, Chip-Text 'Nur Datei verbunden (kein Spiegel)'", st3.connected && st3.mode === "file" && d.getElementById("zlChipText").textContent === "Nur Datei verbunden (kein Spiegel)", d.getElementById("zlChipText").textContent);
    ok("Einzeldatei: Hinweis, dass der Spiegel nur ueber todos.ps1 oder die Ordnerverbindung aktualisiert wird", /todos\.ps1 oder die Ordnerverbindung/.test(d.getElementById("zlMsg").textContent) && !d.getElementById("zlConnect").hidden, d.getElementById("zlMsg").textContent);
    d.querySelector('[data-star="950001"]').click(); await H.wait(900);
    ok("Einzeldatei: todos.json geschrieben, todos.js NICHT angelegt", JSON.parse(files3["todos.json"]).aufgaben.filter(function (t) { return t.id === 950001; })[0].star === 1 && !("todos.js" in files3));
    // 13. Englisch
    w.nxSetLang("en"); await H.wait(500);
    ok("Englisch: Chip, Hinweis, Knoepfe", d.getElementById("zlChipText").textContent === "File only connected (no mirror)" && /only updated by todos\.ps1 or the folder connection/.test(d.getElementById("zlMsg").textContent) && /Connect folder 08_Todos/.test(d.getElementById("zlConnect").textContent) && /Connect file only/.test(d.getElementById("zlFile").textContent), d.getElementById("zlChipText").textContent + " | " + d.getElementById("zlMsg").textContent);
    await N.verbinde(mkDir({}, {})); await H.wait(300);
    ok("Englisch: Meldung falscher Ordner", /does not contain todos\.json/.test(d.getElementById("zlMsg").textContent), d.getElementById("zlMsg").textContent);
    await N.verbinde(mkDir({ "todos.json": json(basis.slice(0, 2)) })); await H.wait(300); w.nxSetLang("en"); await H.wait(300);
    ok("Englisch: Chip Ordner", d.getElementById("zlChipText").textContent === "Folder connected, mirror up to date", d.getElementById("zlChipText").textContent);
    w.nxSetLang("de"); await H.wait(300);
    ok("Keine Konsolenfehler in der App", w.__fehler.length === 0, w.__fehler.join(" | "));
  } finally { try { if (A) A.f.remove(); } catch (e) { } H.zurueck(sich); }
  return { ok: fehler.length === 0, fehler: fehler, anzahl: zeilen.filter(function (z) { return /^OK/.test(z); }).length + " OK, " + fehler.length + " Fehler", zeilen: zeilen, dump: dump };
}


/* Darstellungsprüfung (generisch, ohne seitenspezifisches Wissen). Findet Fehler, die man nur sieht: Aufzählungspunkte in Knopf-/Chip-Leisten,
   Chips/Knöpfe, die ohne Grund untereinander stehen, fehlendes Bootstrap-CSS trotz Bootstrap-Klassen, Elemente rechts außerhalb des Fensters,
   kaputte Bilder, zu kleine Touch-Ziele, abgeschnittene Texte, leere sichtbare Hauptbereiche.
   Aufruf: await nxTestDarstellung({ seiten: ["todo"], breiten: [360,390,760,1040,1300], selbsttest: false })
   selbsttest: true injiziert absichtlich den alten Fehler (Liste mit Punkten, untereinander) in die To-do-Seite und erwartet, dass der Test ihn meldet.
   Rückgabe: { ok, fehler: [...], warnungen: [...], zeilen: [...] }. Fehler = ok=false. Warnungen sind Hinweise (zählen nicht). */
async function nxTestDarstellung(opt) {
  opt = opt || {};
  var ALLE = {
    firma: "firma.htm",
    agenten: "02_Erstellte_Apps/02_agenten_skills_uebersicht/index.html",
    todo: "02_Erstellte_Apps/03_todo/index.html",
    favoriten: "02_Erstellte_Apps/04_favoriten/index.html",
    github: "02_Erstellte_Apps/05_github_trainer/index.html",
    architektur: "02_Erstellte_Apps/06_ninox4_architektur/index.html",
    tagesberichte: "03_Tagesberichte/tagesberichte.html",
    sarah: "05_Sarah_Erinnerungen/sarah-uebersicht.html"
  };
  var seiten = opt.seiten || Object.keys(ALLE);
  var breiten = opt.breiten || [360, 390, 760, 1040, 1300];
  var fehler = [], warnungen = [], zeilen = [];
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  function pruefeSeite(win, d, label, w, sichtbarMin) {
    var f = [], wa = [];
    var sichtbar = function (el) { var r = el.getBoundingClientRect(), cs = win.getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== "hidden" && cs.display !== "none"; };
    var name = function (el) { return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (el.className && typeof el.className === "string" ? "." + el.className.trim().split(/\s+/).slice(0, 2).join(".") : ""); };

    // 1. Aufzählungspunkte in Listen, die nur aus Knöpfen/Links bestehen (Leisten, Chips, Navigation)
    d.querySelectorAll("ul,ol").forEach(function (ul) {
      if (!sichtbar(ul)) return;
      var lis = Array.prototype.filter.call(ul.children, function (c) { return c.tagName === "LI"; });
      if (lis.length < 2) return;
      var nurBedienung = lis.every(function (li) { return li.querySelector("button,a,[role=tab],[role=button]") && li.textContent.trim().length < 60; });
      if (!nurBedienung) return;
      var punkt = lis.some(function (li) { var cs = win.getComputedStyle(li); return cs.display === "list-item" && cs.listStyleType !== "none" && cs.listStyleType !== ""; });
      if (punkt) f.push(label + ": Aufzählungspunkte in Knopfleiste " + name(ul) + " (list-style none und display fehlen)");
    });

    // 2. Knopf-/Chip-Gruppen: 3 oder mehr gleichartige Geschwister, alle exakt untereinander, obwohl Platz für mehrere nebeneinander wäre
    var geprueft = new Set();
    d.querySelectorAll("button,a,[role=tab]").forEach(function (b) {
      var gruppe = b.closest("li") ? b.closest("li").parentElement : b.parentElement;
      if (!gruppe || geprueft.has(gruppe) || !sichtbar(gruppe)) return;
      geprueft.add(gruppe);
      var kinder = Array.prototype.filter.call(gruppe.children, function (c) { return sichtbar(c) && c.querySelector("button,a,[role=tab]") || (sichtbar(c) && /^(BUTTON|A)$/.test(c.tagName)); });
      if (kinder.length < 3) return;
      var r = kinder.map(function (c) { return c.getBoundingClientRect(); });
      var links = r[0].left, alleLinksGleich = r.every(function (x) { return Math.abs(x.left - links) < 2; });
      var maxBreite = Math.max.apply(null, r.map(function (x) { return x.width; }));
      var platz = gruppe.getBoundingClientRect().width;
      var kurz = r.every(function (x) { return x.height <= 64; });
      if (alleLinksGleich && kurz && platz >= maxBreite * 2 + 16 && !/^(NAV)$/.test(gruppe.tagName) && !gruppe.closest("[class*=menu],[class*=dropdown],[role=menu],[role=listbox]")) {
        wa.push(label + ": " + kinder.length + " Knöpfe stehen untereinander in " + name(gruppe) + " (Platz für mehrere nebeneinander)");
      }
    });

    // 3. Bootstrap-Klassen benutzt, aber Bootstrap-CSS fehlt
    var bsCss = Array.prototype.some.call(d.styleSheets, function (s) { return /bootstrap(\.min)?\.css/i.test(s.href || ""); });
    var probe = d.createElement("div"); probe.className = "d-none"; d.body.appendChild(probe);
    var bsWirkt = win.getComputedStyle(probe).display === "none"; probe.remove();
    if (!bsWirkt) {
      var benutzt = d.querySelectorAll('[class*="nav-pills"],[class*="nav-item"],[class*="d-flex"],[class*="gap-"],[class*="text-bg-"],[class*="btn-"],[class~="badge"],[class~="row"],[class*="col-"]');
      var eigene = 0;
      benutzt.forEach(function (el) { if (win.getComputedStyle(el).listStyleType !== "none" && el.tagName === "LI") eigene++; });
      if (benutzt.length) wa.push(label + ": " + benutzt.length + " Elemente mit Bootstrap-Klassen, aber Bootstrap-CSS wirkt nicht (Klassen haben keine Wirkung; eigenes CSS prüfen)" + (eigene ? ", " + eigene + " Listeneinträge mit Punkten" : ""));
    }

    // 4. Elemente ragen rechts aus dem Fenster (ohne bewusst scrollende Bereiche)
    var raus = [];
    d.querySelectorAll("body *").forEach(function (el) {
      if (!sichtbar(el)) return;
      var r = el.getBoundingClientRect();
      if (r.right > w + 2 && r.left < w) {
        var p = el, scroller = false;
        while (p && p !== d.body) { var cs = win.getComputedStyle(p); if (/(auto|scroll|hidden)/.test(cs.overflowX) && p !== el) { scroller = true; break; } p = p.parentElement; }
        if (!scroller && !win.getComputedStyle(el).position.match(/fixed/)) raus.push(name(el) + " (" + Math.round(r.right) + "px)");
      }
    });
    if (raus.length) f.push(label + ": ragt rechts aus dem Fenster: " + raus.slice(0, 4).join(", "));
    if (d.documentElement.scrollWidth > w + 1) f.push(label + ": seitliches Scrollen (scrollWidth " + d.documentElement.scrollWidth + " > " + w + ")");

    // 5. Kaputte Bilder
    var kaputt = Array.prototype.filter.call(d.images, function (i) { return sichtbar(i) && i.complete && i.naturalWidth === 0; });
    if (kaputt.length) f.push(label + ": " + kaputt.length + " kaputte Bilder: " + kaputt.slice(0, 3).map(function (i) { return i.getAttribute("src"); }).join(", "));

    // 6. Touch-Ziele (nur bis 768 px): Knöpfe und Links mindestens 44 x 44, außer Fließtext-Links
    if (w <= 768) {
      var klein = [];
      d.querySelectorAll("button,[role=button],[role=tab],input:not([type=hidden]),select,a.nx-btn-primary,a.nx-btn-secondary,a[class*=btn]").forEach(function (el) {
        if (!sichtbar(el)) return;
        var r = el.getBoundingClientRect();
        if (/^(checkbox|radio)$/.test(el.type) && el.closest("label")) { var lr = el.closest("label").getBoundingClientRect(); if (lr.width >= 43.5 && lr.height >= 43.5) return; }
        if (r.height < 43.5 || (el.tagName !== "INPUT" && el.tagName !== "SELECT" && r.width < 43.5)) klein.push(name(el) + " " + Math.round(r.width) + "x" + Math.round(r.height));
      });
      if (klein.length) wa.push(label + ": " + klein.length + " Touch-Ziele unter 44 px: " + klein.slice(0, 4).join(", "));
      // Eingabefelder mindestens 16 px, sonst zoomt iOS
      var winzig = Array.prototype.filter.call(d.querySelectorAll("input:not([type=hidden]):not([type=checkbox]):not([type=radio]),textarea,select"), function (el) { return sichtbar(el) && parseFloat(win.getComputedStyle(el).fontSize) < 16; });
      if (winzig.length) wa.push(label + ": " + winzig.length + " Eingabefelder unter 16 px Schrift (iOS-Zoom)");
    }

    // 7. Abgeschnittene Texte (Text läuft aus dem Kasten und wird versteckt, ohne Auslassungspunkte)
    var abg = [];
    d.querySelectorAll("button,a,h1,h2,h3,p,span,label,li").forEach(function (el) {
      if (!sichtbar(el) || el.children.length > 3) return;
      var cs = win.getComputedStyle(el);
      if (/(hidden|clip)/.test(cs.overflowX) && cs.textOverflow !== "ellipsis" && el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 4 && !/visually-hidden|sr-only/.test(el.className)) abg.push(name(el) + " (" + (el.textContent || "").trim().slice(0, 24) + ")");
    });
    if (abg.length) f.push(label + ": Text abgeschnitten ohne Auslassungspunkte: " + abg.slice(0, 3).join(", "));

    // 8. Hauptbereich nicht leer
    var main = d.querySelector("main") || d.querySelector(".nx-main");
    if (main && main.getBoundingClientRect().height < sichtbarMin) f.push(label + ": Hauptbereich fast leer (" + Math.round(main.getBoundingClientRect().height) + " px)");

    return { fehler: f, warnungen: wa };
  }

  for (var s = 0; s < seiten.length; s++) {
    var key = seiten[s], pfad = ALLE[key] || key;
    for (var b = 0; b < breiten.length; b++) {
      var w = breiten[b];
      var fr = document.createElement("iframe");
      fr.style.cssText = "width:" + w + "px;height:900px;position:fixed;left:0;top:0;visibility:hidden;border:0";
      fr.src = "/" + pfad + "?lang=de&x=" + Date.now();
      document.body.appendChild(fr);
      await new Promise(function (r) { fr.onload = r; setTimeout(r, 6000); });
      await wait(900);
      var d = fr.contentDocument, win = fr.contentWindow, label = key + " @" + w;
      try {
        if (opt.selbsttest) {
          var st = d.createElement("style");
          st.textContent = "#filters{display:block !important;list-style:disc !important;padding-left:24px !important} #filters>li{display:list-item !important;list-style:disc !important}";
          d.head.appendChild(st);
          await wait(100);
        }
        var res = pruefeSeite(win, d, label, w, 120);
        res.fehler.forEach(function (x) { fehler.push(x); });
        res.warnungen.forEach(function (x) { warnungen.push(x); });
        zeilen.push(label + ": " + res.fehler.length + " Fehler, " + res.warnungen.length + " Warnungen");
      } catch (e) { fehler.push(label + ": Test abgestürzt: " + e.message); }
      fr.remove();
    }
  }
  var out = { ok: fehler.length === 0, fehler: fehler, warnungen: warnungen, zeilen: zeilen };
  if (opt.selbsttest) out.selbsttestBestanden = fehler.some(function (x) { return /Aufzählungspunkte/.test(x); }) || warnungen.some(function (x) { return /untereinander/.test(x); });
  return out;
}