/* Standard-Zaehler (NX): Plakette mit der Anzahl OFFENER Aufgaben im Navigationsknopf "To-dos" (alle Seiten).
   Quellen (zusammengefuehrt je id, die neuere Aenderung "geaendert" gewinnt, nichts doppelt gezaehlt):
   1. Spiegel der zentralen Liste: window.NX_TODOS (Datei 08_Todos/todos.js, wird im Kopf per Script-Tag mit src geladen; ohne Grabsteine)
   2. Rueckfall/Cache: localStorage "nobbis-todos-v1" (JSON-Array, die To-do-App haelt dort ihren letzten Stand)
   3. Grabsteine der App: localStorage "nobbis-todos-tomb-v1" (geloeschte Aufgaben, damit ein veralteter Spiegel sie nicht wieder zaehlt)
   Offen = nicht erledigt und nicht geloescht. Ueberfaellig (Warnpunkt) = offen mit Faelligkeit vor heute.
   Fehlen Spiegel und Speicher: Plakette bleibt ausgeblendet.
   window.nxTodoListe() liefert dieselbe zusammengefuehrte Liste (offen und erledigt, ohne Geloeschte) fuer Live-Ansichten (Sarahs Uebersicht, Favoriten, Suche).
   Aktualisiert beim Laden, bei "storage" (andere Fenster) und per window.nxTodoZaehler() (die To-do-Seite und Favoriten rufen sie nach Aenderungen auf). */
(function () {
  var KEY = "nobbis-todos-v1", TOMB = "nobbis-todos-tomb-v1";
  function heute() { var d = new Date(), m = d.getMonth() + 1, t = d.getDate(); return d.getFullYear() + "-" + (m < 10 ? "0" : "") + m + "-" + (t < 10 ? "0" : "") + t; }
  function lies(key) {
    try { var raw = localStorage.getItem(key); if (raw === null) return null; var a = JSON.parse(raw); return Array.isArray(a) ? a : null; } catch (e) { return null; }
  }
  function stand(t) { return +t.geaendert || +t.created || +t.id || 0; }
  // Zusammengefuehrte Liste (ohne Geloeschte) als Array; null, wenn weder Spiegel noch Speicher vorhanden sind. Auch fuer Sarahs Uebersicht, Favoriten und die Suche (window.nxTodoListe).
  function liste() {
    var m = {}, da = false, sp = window.NX_TODOS;
    if (sp && Array.isArray(sp.aufgaben)) {
      da = true;
      sp.aufgaben.forEach(function (t) { if (t && t.id != null && !t.geloescht) m[t.id] = t; });
    }
    var c = lies(KEY);
    if (c) {
      da = true;
      c.forEach(function (t) {
        if (!t || t.id == null) return;
        var o = m[t.id];
        if (t.geloescht) { if (o && stand(t) >= stand(o)) delete m[t.id]; return; }
        if (!o || stand(t) >= stand(o)) m[t.id] = t;
      });
    }
    var g = lies(TOMB);
    if (g) g.forEach(function (x) { if (!x || x.id == null) return; var o = m[x.id]; if (o && (+x.geaendert || 0) >= stand(o)) delete m[x.id]; });
    if (!da) return null;
    return Object.keys(m).map(function (k) { return m[k]; });
  }
  function zaehle() {
    var l = liste();
    if (!l) return null;
    var h = heute(), o2 = 0, u = 0;
    l.forEach(function (t) { if (!t.done) { o2++; if (t.due && String(t.due) < h) u++; } });
    return { offen: o2, ueberfaellig: u };
  }
  function aktualisiere() {
    var link = document.querySelector('.nx-nav a[data-nav="todo"]');
    if (!link) return;
    var b = link.querySelector(".nx-badge");
    if (!b) return;
    var z = zaehle();
    if (!z) { b.hidden = true; b.classList.remove("nx-badge-warn", "nx-badge-null"); link.__nxA = undefined; link.removeAttribute("aria-label"); return; }
    b.hidden = false;
    b.textContent = z.offen > 99 ? "99+" : String(z.offen);
    b.classList.toggle("nx-badge-null", z.offen === 0);
    b.classList.toggle("nx-badge-warn", z.ueberfaellig > 0);
    // Der deutsche Text wird vom Standard-Uebersetzer (Woerterbuch, Muster) in Englisch umgesetzt; alten Merker verwerfen, damit die Zahl aktuell bleibt
    link.__nxA = undefined;
    link.setAttribute("aria-label", "To-dos, " + b.textContent + " offen");
  }
  window.nxTodoZaehler = aktualisiere;
  window.nxTodoListe = liste;
  window.addEventListener("storage", function (e) { if (!e.key || e.key === KEY || e.key === TOMB) aktualisiere(); });
  window.addEventListener("pageshow", aktualisiere);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", aktualisiere); else aktualisiere();
})();
