/* Standard-Suchfeld (NX): gemeinsames Verhalten fuer .nx-search-input. Taste / fokussiert, Esc leert, Loeschknopf (.nx-search-clear) nur bei Text.
   Seiten-eigener Code hoert wie bisher auf das "input"-Ereignis des Feldes (Loeschen und Esc loesen es aus). */
(function () {
  function init() {
    var q = document.querySelector(".nx-search-input");
    if (!q) return;
    var clear = document.querySelector(".nx-search-clear");
    function sync() { if (clear) clear.hidden = !q.value; }
    function leeren() { q.value = ""; q.dispatchEvent(new Event("input", { bubbles: true })); sync(); }
    q.addEventListener("input", sync);
    if (clear) clear.addEventListener("click", function () { leeren(); q.focus(); });
    q.addEventListener("keydown", function (e) { if (e.key === "Escape" && q.value) { e.preventDefault(); leeren(); } });
    document.addEventListener("keydown", function (e) {
      var a = document.activeElement;
      if (e.key !== "/" || e.ctrlKey || e.metaKey || e.altKey) return;
      if (a && (/^(input|textarea|select)$/i.test(a.tagName) || a.isContentEditable)) return;
      e.preventDefault(); q.focus(); q.select();
    });
    sync();
    setTimeout(sync, 0);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();