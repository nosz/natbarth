/* Standard-Sprachumschalter DE/EN (NX). Eine Sprache für alle Seiten.
   Quelle der Sprache (in dieser Reihenfolge): ?lang=de|en in der Adresse, gespeicherte Wahl (localStorage), window.name, sonst Deutsch.
   Jeder Link auf eine andere Seite des Systems trägt ?lang=... mit; so kommt die Sprache auch dort an, wo der Browser nichts speichert (file://, Vorschaufenster).
   Übersetzt Text, Platzhalter, Titel und Beschriftungen anhand eines Wörterbuchs (exakter deutscher Text -> Englisch).
   Dynamisch erzeugte Inhalte werden per MutationObserver mit übersetzt. Einzelne Elemente können mit data-en="..." selbst Englisch mitbringen. */
(function () {
  var KEY = "nobbis-super-firma-sprache-v1";
  var D = /*NX-WOERTER*/{};
  var P = /*NX-MUSTER*/[];
  var NUR_KOPF = /*NX-NURKOPF*/false;
  var WD = { Montag: "Monday", Dienstag: "Tuesday", Mittwoch: "Wednesday", Donnerstag: "Thursday", Freitag: "Friday", Samstag: "Saturday", Sonntag: "Sunday" };
  var ATTRS = ["placeholder", "title", "aria-label", "alt"];
  var lang = "de", busy = false, titleDe = null;
  var has = Object.prototype.hasOwnProperty;
  var rx = P.map(function (p) { return [new RegExp(p[0]), p[1]]; });

  function gueltig(l) { return l === "en" || l === "de" ? l : ""; }
  function ausAdresse() { var m = /[?&]lang=(de|en)\b/.exec(location.search); return m ? m[1] : ""; }
  function ausSpeicher() { try { return gueltig(localStorage.getItem(KEY)); } catch (e) { return ""; } }
  function ausName() { var m = /^nx-lang=(de|en)$/.exec(window.name || ""); return m ? m[1] : ""; }
  function merken() {
    try { localStorage.setItem(KEY, lang); } catch (e) {}
    try { if (!window.name || /^nx-lang=/.test(window.name)) window.name = "nx-lang=" + lang; } catch (e) {}
  }
  lang = ausAdresse() || ausSpeicher() || ausName() || "de";

  function norm(s) { return s.replace(/\s+/g, " ").trim(); }
  function tr(s) {
    var k = norm(s), i, r;
    if (!k) return null;
    if (has.call(D, k)) return D[k];
    for (i = 0; i < rx.length; i++) {
      if (rx[i][0].test(k)) { r = k.replace(rx[i][0], rx[i][1]); return r.replace(/\b(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag)\b/g, function (w) { return WD[w]; }); }
    }
    return null;
  }
  function skip(el, nurAttr) {
    return !el || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(el.tagName) || (!nurAttr && el.tagName === "TEXTAREA") || (el.closest && el.closest('[translate="no"],.nx-langswitch'));
  }
  function inScope(el) { return !NUR_KOPF || (el.closest && el.closest(".nx-header,.nx-footer")); }

  function textNode(n) {
    var el = n.parentElement;
    if (skip(el) || !inScope(el)) return;
    if (lang === "de") { if (n.__nxDe !== undefined) { n.nodeValue = n.__nxDe; n.__nxDe = undefined; } return; }
    if (n.__nxDe !== undefined && n.nodeValue !== n.__nxEn) n.__nxDe = undefined;
    var t = tr(n.nodeValue);
    if (t === null) return;
    var v = n.nodeValue, lead = v.match(/^\s*/)[0], trail = v.match(/\s*$/)[0], nv = lead + t + trail;
    if (nv === v) return; // gleicher Wortlaut: nichts setzen (sonst Endlosschleife über den Observer)
    if (n.__nxDe === undefined) n.__nxDe = v;
    n.__nxEn = nv;
    n.nodeValue = nv;
  }
  function attrs(el) {
    if (skip(el, true) || !inScope(el)) return;
    ATTRS.forEach(function (a) {
      if (!el.hasAttribute(a)) return;
      el.__nxA = el.__nxA || {};
      var cur = el.getAttribute(a);
      if (lang === "de") { if (el.__nxA[a] !== undefined) { el.setAttribute(a, el.__nxA[a]); el.__nxA[a] = undefined; } return; }
      var t = tr(cur);
      if (t === null || t === cur) return;
      if (el.__nxA[a] === undefined) el.__nxA[a] = cur;
      el.setAttribute(a, t);
    });
    var en = el.getAttribute("data-en");
    if (en !== null && el.children.length === 0) {
      if (lang === "en") { if (el.textContent === en) return; if (el.__nxHtml === undefined) el.__nxHtml = el.textContent; el.textContent = en; }
      else if (el.__nxHtml !== undefined) { el.textContent = el.__nxHtml; el.__nxHtml = undefined; }
    }
  }
  // Links auf andere Seiten des Systems tragen die Sprache mit
  function verlinken(a) {
    var h = a.getAttribute("href");
    if (!h || /^(#|mailto:|tel:|javascript:)/i.test(h) || a.hasAttribute("download") || a.hasAttribute("data-nx-keinlang")) return;
    var u;
    try { u = new URL(a.href); } catch (e) { return; }
    if (u.protocol !== location.protocol || u.host !== location.host) return;
    if (!/\.html?$/i.test(u.pathname) && !/\/$/.test(u.pathname)) return;
    var i = h.indexOf("#"), hash = i >= 0 ? h.slice(i) : "", base = i >= 0 ? h.slice(0, i) : h;
    var j = base.indexOf("?"), qs = j >= 0 ? base.slice(j + 1) : "", pfad = j >= 0 ? base.slice(0, j) : base;
    var teile = qs.split("&").filter(function (x) { return x && !/^lang=/.test(x); });
    teile.push("lang=" + lang);
    var neu = pfad + "?" + teile.join("&") + hash;
    if (neu !== h) a.setAttribute("href", neu);
  }
  function walk(root) {
    if (root.nodeType === 3) { textNode(root); return; }
    if (root.nodeType !== 1) return;
    attrs(root);
    if (root.tagName === "A") verlinken(root);
    var w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) textNode(n);
      else { attrs(n); if (n.tagName === "A") verlinken(n); }
    }
  }
  function schalter() {
    var opts = document.querySelectorAll(".nx-lang-opt");
    for (var i = 0; i < opts.length; i++) opts[i].setAttribute("aria-pressed", opts[i].getAttribute("data-lang") === lang ? "true" : "false");
  }
  function apply() {
    busy = true;
    try {
      document.documentElement.lang = lang;
      if (titleDe === null) titleDe = document.title;
      if (lang === "en") { var tt = tr(titleDe); if (tt !== null) document.title = tt; } else document.title = titleDe;
      walk(document.body);
      schalter();
    } finally { busy = false; }
  }
  function melden() { try { window.dispatchEvent(new CustomEvent("nx-lang", { detail: lang })); } catch (e) {} }
  function setLang(l, speichern) {
    l = gueltig(l) || "de";
    if (l === lang && speichern !== "neu") { if (speichern) merken(); return; }
    lang = l;
    if (speichern) merken();
    apply();
    melden();
  }
  function start() {
    var opts = document.querySelectorAll(".nx-lang-opt");
    for (var i = 0; i < opts.length; i++) opts[i].addEventListener("click", function () { setLang(this.getAttribute("data-lang"), true); });
    merken();
    apply();
    new MutationObserver(function (ms) {
      if (busy) return;
      busy = true;
      try {
        ms.forEach(function (m) {
          if (m.type === "childList") m.addedNodes.forEach(function (n) { if (lang === "en") walk(n); else if (n.nodeType === 1) { if (n.tagName === "A") verlinken(n); n.querySelectorAll("a[href]").forEach(verlinken); } });
          else if (lang === "en" && m.type === "characterData") textNode(m.target);
          else if (lang === "en" && m.type === "attributes") attrs(m.target);
        });
      } finally { busy = false; }
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    // Änderung in einem anderen Fenster oder Tab sofort übernehmen
    window.addEventListener("storage", function (e) { if (e.key === KEY) setLang(e.newValue, false); });
    // Zurück-Navigation (Seite kommt aus dem Zwischenspeicher): Sprache neu bestimmen
    window.addEventListener("pageshow", function (e) { if (e.persisted) setLang(ausAdresse() || ausSpeicher() || lang, false); });
  }
  window.nxLang = function () { return lang; };
  window.nxSetLang = function (l) { setLang(l, true); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
