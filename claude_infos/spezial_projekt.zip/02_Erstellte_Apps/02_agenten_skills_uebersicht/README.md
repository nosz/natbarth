# Agenten & Skills – Übersicht

Durchsuchbare Übersicht aller Agenten und Skills dieser Umgebung, mit Kurzbeschreibung zu jedem Eintrag.

| | |
|---|---|
| **Datei** | `index.html` |
| **Ersteller** | Nobbi |
| **Design** | Ninox Design System, Bootstrap 5.3.3, Bootstrap Icons 1.11.3 |
| **Aufruf** | Kachel „Agenten & Skills“ im Organigramm (`..\..\firma.htm`) |
| **Version** | 1.0.6 |

## Zweck

Auf einen Blick sehen, welche Agenten und Skills zur Verfügung stehen, was sie tun und wie man sie aufruft.

## Funktionen

| Funktion | Beschreibung |
|---|---|
| Suche | Sofort beim Tippen, über Name, Rolle, Beschreibung und Stichwörter; mehrere Wörter müssen alle passen; Umlaute und Groß-/Kleinschreibung egal; Treffer sortiert nach Relevanz, Fundstellen markiert |
| Filter | Nach Typ (Agenten, Skills) und Quelle (Team, eingebaut, Projekt, Anthropic, Claude Code); Zahlen an den Filtern zeigen die Treffer |
| Karten | Name, Rolle, Kurzbeschreibung, Typ, Quelle, Aufruf |
| Liegt in | Ablageort je Eintrag: Team-Agenten `.claude\agents\<name>.md` im Projekt, Projekt-Skills `~\.claude\skills\<name>\SKILL.md`, weitere Skills unter `~\.claude\skills\synced\…`, eingebaute ohne eigene Datei. Für Anthropic-Skills ohne gefundene Datei steht „Ablageort nicht geprüft“ |
| Aufruf kopieren | Knopf mit Zwischenablage-Symbol kopiert den Aufruf |
| Anweisungen öffnen | Bei Team-Agenten Link auf `.claude\agents\<name>.md` |
| Tastatur | `/` springt ins Suchfeld, `Esc` leert die Suche |
| Teilen | Suchbegriff steht in der Adresse (`#q=…`) |

## Datenspeicherung und Grenzen

- Die Liste ist im Code der Seite hinterlegt (Stand 2026-10-26). Neue oder geänderte Agenten und Skills müssen von Hand nachgetragen werden.
- Es wird nichts gespeichert. Keine Anmeldung, keine Zugangsdaten.
- Lokale Datei, keine PWA (nicht gehostet).
- Die Beschreibungen sind Kurzfassungen der jeweiligen Definitionen; maßgeblich bleibt die Originaldatei.

## Teststatus

Siehe Änderungsverlauf; Stand der Prüfung wird dort je Version festgehalten.

## Änderungsverlauf

| Datum | Änderung |
|---|---|
| 2026-10-29 | **1.11.0**: Neue Mitarbeiter Ben & Uwe (Die Problemlöser und Support-Götter, Agent `ben-und-uwe`) |
| 2026-10-29 | **1.10.0**: Neue Mitarbeiterin Olga (Seminar-Veranstalterin, Agent `olga`) |
| 2026-10-28 | **1.9.1**: Standard-Kopf neu gesetzt: lädt den Spiegel der zentralen To-do-Liste (`08_Todos/todos.js`) für den Zähler im Knopf To-dos (Quelle `NX_TODOS`, Rückfall Browser-Speicher); sonst keine Änderung |
| 2026-10-28 | **1.9.0**: Rolle von Seb: Der geniale IT-Architektur-Spezialist |
| 2026-10-28 | **1.8.0**: Neuer Mitarbeiter Seb (IT-Architektur-Experte, Agent `seb`) |
| 2026-10-28 | **1.7.0**: Anzeige des Modells je Agent (Stand: Claude Sonnet 5.5, von der Sitzung übernommen; Konstante SITZUNGSMODELL, Ausnahmen in MODELLE) |
| 2026-10-28 | **1.6.0**: Neuer Mitarbeiter Willi (Webdesigner, Agent `willi`) |
| 2026-10-28 | **1.5.1**: Links dürfen mit data-nx-keinlang ohne Sprachparameter bleiben (Standard) |
| 2026-10-28 | **1.5.0**: Zähler-Plakette im Navigationsknopf "To-dos" (Standard-Kopf) |
| 2026-10-28 | **1.4.0**: Suchfeld als gemeinsame nx-Komponente (48 px, Lupe, Löschknopf nur bei Text, Taste `/`, Esc leert, Platzhalter "Suchen: ...", direkt unter dem Kopf in 1140 px Breite), Filter-Chips im gleichen Stil, Karten und Leerzustand als nx-Komponenten; Kopf mit festen Spalten, Sprachumschalter springt nicht mehr |
| 2026-10-28 | **1.3.1**: Sprachumschalter auf schmalen Fenstern neben dem Logo |
| 2026-10-28 | **1.3.0**: Sprachumschalter mit beiden Flaggen (gewählte hervorgehoben); die Sprache wird zusätzlich in den Links mitgegeben und gilt so auf allen Seiten |
| 2026-10-28 | **1.2.1**: Kurzzeitig in Corinna Frechdachs umbenannt, auf Wunsch wieder Sarah (Agent `sarah`, Agentendatei `sarah.md`) |
| 2026-10-28 | **1.2.0**: Sprachknopf Deutsch/Englisch im Standard-Kopf; die Sprache gilt auf allen Seiten |
| 2026-10-28 | **1.1.1**: Einheitlicher Inhaltsbereich (Breite, Abstände, Schrift) wie auf allen Seiten |
| 2026-10-28 | **1.1.0**: Einheitlicher Standard-Kopf (Logo, feste Navigation, Titel) und Standard-Fußzeile mit Version |
| 2026-10-28 | **1.0.9**: Neuer Mitarbeiter Garry (GitHub-Experte, Agent `garry`) |
| 2026-10-28 | **1.0.8**: Kompakter Kopfbereich im neuen Stil (Verlauf, weiche Kreise, weniger Höhe) |
| 2026-10-28 | **1.0.7**: Neue Mitarbeiterin Sarah (Erinnerungskönigin, Agent `sarah`) |
| 2026-10-27 | **1.0.6**: Neuer Mitarbeiter Arnold (persönlicher Fitnesstrainer, Agent `arnold`) |
| 2026-10-27 | **1.0.5**: Martina umbenannt in „Adina die Git-Book Königin“ (Agent `adina`) |
| 2026-10-26 | **1.0.4**: Umbenennungen: Dora → Martina, Leo → Leonardo, Niko → Niklas, Nico → Nicoletta |
| 2026-10-26 | **1.0.3**: Obere Leiste weiß statt schwarz |
| 2026-10-26 | **1.0.2**: Obere Leiste mit großem Knopf „Zurück zum Organigramm“ bleibt beim Scrollen fixiert (zusammen mit Suche und Filtern); derselbe Knopf zusätzlich in der Fußzeile |
| 2026-10-26 | **1.0.1**: Hinweis „Liegt in“ auf jeder Karte (Ablageort der Datei bzw. „in Claude Code eingebaut“), auch durchsuchbar |
| 2026-10-26 | **1.0.0**: Erste Version mit Suche, Filtern, Kopierfunktion und Kurzbeschreibung zu jedem Eintrag |
| 2026-11-01 | **1.11.1**: Arnold mit model: haiku in MODELLE; Bootstrap Icons lokal statt CDN |
| 2026-11-04 | **1.11.3**: Umbenennung: Seb → Archie, Adina → Dora, Ben & Uwe → Tom & Tina (Karten, Agentendateien, Suchindex). Frühere Einträge nennen die damaligen Namen |
| 2026-11-04 | **1.11.2**: Englische Texte für Olga und Ben & Uwe wirksam (Seite mit aktuellem Wörterbuch neu gesetzt) |
