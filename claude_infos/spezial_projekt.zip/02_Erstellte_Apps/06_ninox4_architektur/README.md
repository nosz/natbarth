# Ninox-4-Architektur (Bericht von Archie)

Technische Architektur von Ninox 4 aus der öffentlichen Dokumentation, internen Confluence-Seiten und lokalen Notizen, mit Vertrauensstufe und Quelle zu jeder Aussage.

| | |
|---|---|
| **Dateien** | `index.html` (Bericht, Deutsch und Englisch per Sprachknopf), `2026-10-28_ninox4-architektur_DE.pdf`, `2026-10-28_ninox4-architektur_EN.pdf` |
| **Ersteller** | Archie (IT-Architektur-Experte, Agent `archie`) |
| **Einstufung** | Intern: enthält Confluence-Inhalte, nicht extern teilen |
| **Quellen** | `.claude\wissen\archie-quellen.md` |
| **Version** | 1.0.0 |

## Inhalt
Kurzfassung, Vertrauensstufen, Gesamtbild (Schichten), Struktur und API, Backend-Aufbau, Transaktionen und KI, Hosting, Sicherheit, geplante Änderungen (Entwürfe), Vergleich Ninox 3 und 4, lokale Beobachtungen, Lücken, Empfehlung, Quellen.

## Erzeugung des PDFs
Die PDFs entstehen aus `index.html` über den Server (`http://localhost:8100/...?lang=de` bzw. `?lang=en`) mit Microsoft Edge (`--headless=new --print-to-pdf --no-pdf-header-footer`). Druckstile (A4, ohne Navigation) stehen in der Seite. Nach jeder Änderung beide PDFs neu erzeugen.

## Personalisierte Berichte
Archie fragt vor jedem Auftrag: Ninox 3 oder Ninox 4, dann personalisiert Ja oder Nein. Bei Ja liest er nach Eingabe einer E-Mail-Adresse nur die nötigen Felder aus HubSpot (lesend) und legt den Bericht getrennt unter `personalisiert\<datum>_<nummer>\` ab. Diese Dateien enthalten personenbezogene Daten, kommen nicht in den Suchindex und werden nicht extern weitergegeben. Der Ordner `personalisiert` wird erst beim ersten personalisierten Bericht angelegt; ein solcher Bericht wurde noch nicht erstellt und der HubSpot-Ablauf ist noch nicht getestet.

## Grenzen
- Das PDF wurde als Datei erzeugt (8 Seiten je Sprache), die Seitenansicht konnte nicht visuell geprüft werden.
- Confluence-Links (Seiten-ID) brauchen Zugriff auf die Ninox-Confluence-Seite und wurden nicht einzeln abgerufen.
- Interne Entwürfe (RFCs) sind keine Ist-Beschreibung.

## Änderungsverlauf
| Datum | Änderung |
|---|---|
| 2026-11-04 | **1.0.2**: Ersteller umbenannt: Seb → Archie (Agent `archie`, Quellen `archie-quellen.md`); keine inhaltliche Änderung |
| 2026-10-28 | **1.0.1**: Standard-Kopf neu gesetzt: lädt den Spiegel der zentralen To-do-Liste (`08_Todos/todos.js`) für den Zähler im Knopf To-dos (Quelle `NX_TODOS`, Rückfall Browser-Speicher); sonst keine Änderung |
| 2026-10-28 | **1.0.0**: Erste Version, Deutsch und Englisch, HTML und PDF |
