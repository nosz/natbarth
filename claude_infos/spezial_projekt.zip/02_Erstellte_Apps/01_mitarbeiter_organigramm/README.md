# Nobbis Super-Firma – Organigramm

Übersicht über das Team von Nobbis Super-Firma mit Farben, Namen und Detailansicht pro Person.

| | |
|---|---|
| **Datei** | `..\..\firma.htm` (liegt ganz oben im Hauptordner `NOBBIS_SUPER_FIRMA`; hier liegt nur diese Beschreibung) |
| **Ersteller** | Nobbi |
| **Design** | Ninox Design System, Bootstrap 5.3.3, Ninox-Logo |

## Zweck

Das Team auf einen Blick sehen und per Klick nachlesen, was jede Person macht und wie.

## Aufbau

- **Norbert** (Inhaber & Chef) oben in der Mitte.
- **Claudia** als Stabsstelle rechts neben Norbert, mit gestrichelter Linie.
- Darunter: Nobbi, Dora die Git-Book Königin, Leonardo, Niklas, Beni, Nicoletta, Hans und Arnold.
- Jede Person hat eine eigene Farbe; die Legende steht oben.

## Funktionen

| Funktion | Beschreibung |
|---|---|
| Detailfenster | Klick auf eine Person zeigt Aufgaben und Arbeitsweise |
| Neu gelernt | Im Detailfenster neue Aufgaben eintragen und wieder entfernen |
| Ordner-Info | Fußzeile zeigt den Arbeitsordner |
| Responsive | Desktop 7 Spalten, schmaler 4, Handy 1 |

## Datenspeicherung und Grenzen

- „Neu gelernt" wird im `localStorage` des Browsers gespeichert, nicht auf anderen Geräten.
- Die Texte der Mitarbeiter sind im Code der Seite hinterlegt. Die Claude-Agenten (`.claude/agents`) sind davon getrennt und haben ihr eigenes Gedächtnis.

## Teststatus

- Getestet (Vorschau): Anordnung am Desktop, Klick und Detailfenster, Hinzufügen einer Aufgabe, Namenshinweise.
- Nicht getestet: dauerhaftes Speichern nach Neuladen, Handy-Ansicht der letzten Version.

## Änderungsverlauf

| Datum | Änderung |
|---|---|
| 2026-11-04 | **1.13.4**: Umbenennung: Seb → Archie, Adina → Dora, Ben & Uwe → Tom & Tina (Seite, Agentendateien, Suchindex; interne ids `archie`, `dora`, `tom-und-tina`). Frühere Einträge nennen die damaligen Namen |
| 2026-11-04 | **1.13.3**: Karte "Kuchlbauer-Quiz" entfernt: Das Quiz ist ein eigenständiges Projekt und liegt seit 04.11.2026 außerhalb von Nobbis Super-Firma (Desktop\kuchlbauer-quiz); der lokale Server liefert es nicht mehr aus |
| 2026-10-29 | **1.13.0**: Neue Mitarbeiter Ben & Uwe (Die Problemlöser und Support-Götter, Agent `ben-und-uwe`) |
| 2026-10-29 | **1.12.0**: Neue Mitarbeiterin Olga (Seminar-Veranstalterin, Agent `olga`) |
| 2026-10-28 | **1.11.2**: Link der App-Karte "Sarahs Übersicht" auf die feste Adresse `05_Sarah_Erinnerungen\sarah-uebersicht.html` (Live-Ansicht der zentralen To-do-Liste); Standard-Kopf neu gesetzt |
| 2026-10-28 | **1.11.1**: Standard-Kopf neu gesetzt: lädt den Spiegel der zentralen To-do-Liste (`08_Todos/todos.js`) für den Zähler im Knopf To-dos (Quelle `NX_TODOS`, Rückfall Browser-Speicher); sonst keine Änderung |
| 2026-10-28 | **1.11.0**: Rolle von Seb: Der geniale IT-Architektur-Spezialist |
| 2026-10-28 | **1.10.0**: Neuer Mitarbeiter Seb (IT-Architektur-Experte, Agent `seb`) im Organigramm |
| 2026-10-28 | **1.9.0**: Globale Suche über alle Apps oben im Organigramm (Suchindex `suchindex.js`, Logik `suche-global.js`, Gruppen je App, Filter, Tastatur, DE/EN); Details in `_standard\STANDARD.md`, Abschnitt Suche |
| 2026-10-28 | **1.8.1**: Willi baut jede Seite mit Bootstrap (lokal), Aufgabentext angepasst |
| 2026-10-28 | **1.8.0**: Modell des Mitarbeiters im Detailfenster (Konstante MODEL_SESSION) |
| 2026-10-28 | **1.7.0**: Neuer Mitarbeiter Willi (Webdesigner) im Organigramm |
| 2026-10-28 | **1.6.0**: Neuer Abschnitt Erstellte Apps mit Linkkarten zu allen Apps (To-dos, Favoriten, Agenten & Skills, Tagesberichte, Sarahs Übersicht, GitHub-Trainer, Kuchlbauer-Quiz) |
| 2026-10-28 | **1.5.0**: Seite heißt überall "Organigramm" (h1, Titel "Organigramm – Nobbis Super-Firma", Navigation); Zähler-Plakette im Knopf To-dos; Kopf mit festen Spalten, Sprachumschalter springt nicht mehr |
| 2026-10-26 | Erste Version, Beni, Nicoletta, Logo, Ordner-Info, Namenshinweise, Claudia neben Norbert |
| 2026-10-27 | **1.0.14**: Neuer Mitarbeiter Arnold (persönlicher Fitnesstrainer, Farbe Rot, Agentendatei `arnold.md`); Team-Reihe auf 9 Spalten, Umbruch auf 4 Spalten ab 1400 px |
| 2026-10-27 | **1.0.13**: Martina umbenannt in „Adina die Git-Book Königin“ (Seite, Agentendatei `adina.md`, Prompts); Einträge 1.0.9 bis 1.0.12 sind hier nicht dokumentiert |
| 2026-10-26 | **1.0.8**: Umbenennungen: Dora → Martina, Leo → Leonardo, Niko → Niklas, Nico → Nicoletta (Seite, Agentendateien, Prompts); Namenshinweise „mit k“ und „mit c“ entfernt |
| 2026-10-26 | **1.0.7**: Seite von `mitarbeiter_organigramm.htm` in `firma.htm` umbenannt, alle Verweise angepasst |
| 2026-10-26 | **1.0.6**: Kachel „Agenten & Skills“ im Kopfbereich (Link auf `02_Erstellte_Apps\02_agenten_skills_uebersicht`), Bootstrap Icons eingebunden |
| 2026-10-26 | **1.0.5**: Abgleich mit `.claude/agents`: Nicoletta (Confluence ES, Sales-Meeting-Link, Abstimmung mit Hans), Leonardo (Ninox Script, Doku-Links), Beni (DSGVO, Meldung an IT), Nobbi (Hosting-Abgleich, Fehlerprüfung), Otto (Berichtsformat), Hans (Freigabe, Ninox-Design) |
| 2026-10-26 | **1.0.4**: Martina und Beni nutzen gemeinsame Quellen (`.claude/wissen/ninox-quellen.md`), Einstiegslink docs.ninox.com/home/de |
| 2026-10-26 | **1.0.3**: Martinas Quellen (docs.ninox.com, Support Portal, Confluence, ninox.com/Status, Forum nur gekennzeichnet) ergänzt |
| 2026-10-26 | **1.0.2**: PWA- und Update-Regel in Nobbis Aufgabenliste ergänzt. Das Organigramm selbst ist keine PWA (lokale Datei, nicht gehostet) |
| 2026-10-26 | **1.0.1**: Nobbis Versionsregel in seiner Aufgabenliste ergänzt |
| 2026-10-26 | **1.0.0**: Versionsnummer eingeführt (Fußzeile und `meta app-version`); Stand aller bisherigen Änderungen gilt als 1.0.0 |
| 2026-10-26 | Prüfrhythmus von Otto (2× täglich) und Claudia (alle 2 Tage) in den Aufgaben ergänzt |
| 2026-10-26 | Otto (Ordnerkönig) ergänzt; Desktop-Raster auf 8 Spalten |
| 2026-10-26 | Norbert anklickbar mit Aufgabenliste; im Detailfenster Link zu den genauen Anweisungen (`.claude/agents/<name>.md`) |
| 2026-10-26 | Umbenannt in `firma.htm` und in den Hauptordner verschoben (Ausnahme von der Regel „eigener Ordner mit index.html") |
