# Nobbis To-dos

Eine schlanke To-do-App, um schnell zu notieren, was noch erledigt werden muss.

| | |
|---|---|
| **Datei** | `02_Erstellte_Apps\03_todo\index.html` |
| **Ersteller** | Nobbi |
| **Design** | Ninox Design System, Bootstrap 5.3.3 |

## Dashboard und Hosting

| | |
|---|---|
| **Auf dem Dashboard anzeigen** | Ja, als Kachel oben im Kopfbereich neben Firmenname und Beschreibung im Mitarbeiter-Organigramm (`firma.htm`); das Organigramm ist das Dashboard. Die Kachel öffnet die lokale Version (`02_Erstellte_Apps\03_todo\index.html`) im selben Tab; dort führt „Zurück zum Organigramm“ zurück zu `firma.htm`. Die gehostete Version ist weiterhin unter der Adresse unten erreichbar. |
| **Gehostet** | https://nosz.github.io/todoapp (GitHub Pages) |
| **Stand Veröffentlichung** | Noch nicht von Nobbi hochgeladen; Veröffentlichen nur nach Freigabe |

## Zweck

Die To-do-App ist die Oberfläche der **zentralen To-do-Liste** (`08_Todos\todos.json`, Beschreibung in `08_Todos\README.md`): alle Aufgaben und Erinnerungen an einer Stelle, auch für den nächsten Tag. Aufgaben in Sekunden erfassen: Seite öffnen, tippen, Enter. Das Eingabefeld ist beim Öffnen sofort aktiv. Agenten (z. B. Sarah) nutzen dieselbe Liste über `08_Todos\todos.ps1`.

## Funktionen

| Funktion | Beschreibung |
|---|---|
| Zentrale Liste (Ordnerverbindung) | Schaltfläche "Ordner 08_Todos verbinden" (`showDirectoryPicker`, Handle in IndexedDB): liest und schreibt `todos.json` **und** schreibt nach jeder Änderung den Spiegel `todos.js` im selben Ordner (Format wie `todos.ps1`, `todos.ps1 -Aktion Pruefen` meldet "Spiegel identisch"). Status-Chip im Kopfbereich: "Ordner verbunden, Spiegel aktuell", "Nur Datei verbunden (kein Spiegel)", "Spiegel todos.js nicht aktualisiert", "Nicht verbunden (nur lesend aus Spiegel)" oder "Änderungen warten auf Verbindung". Ein Ordner ohne `todos.json` wird abgelehnt (nichts wird angelegt) |
| Rückfall Einzeldatei | "Nur Datei verbinden" (nur `todos.json`, wie in Stufe 1) und "Neue zentrale Datei anlegen"; dann Hinweis, dass der Spiegel nur über `todos.ps1` oder die Ordnerverbindung aktualisiert wird |
| Zusammenführen | Vor jedem Schreiben frisch lesen und je Aufgabe nach `geaendert` zusammenführen (letzter Schreiber gewinnt je Aufgabe); Löschen = Grabstein; Neu-Lesen beim Fokus-Wechsel und alle 30 s |
| Ohne Verbindung | Anzeige aus dem Spiegel `08_Todos\todos.js` plus lokalem Cache; Änderungen warten in `localStorage` `nobbis-todos-pending-v1` und werden beim Verbinden einmalig übertragen. Der alte Schlüssel `nobbis-todos-v1` wird beim ersten Start einmalig übernommen und bleibt als Cache |
| Aufgabe hinzufügen | Text, Fälligkeit (Datum), Uhrzeit (optional), Schnellauswahl Heute / Morgen / Nächste Woche, Enter oder "Hinzufügen" |
| Ansichten nach Zeit | Chips mit Anzahl: Offen (Standard, alle offenen nach Gruppen mit Überschriften), Überfällig, Heute, Morgen, Diese Woche (bis Sonntag), Nächste Woche, Später, Ohne Datum, Erledigt, Alle (Kalenderwochen Montag bis Sonntag) |
| Anzeige | Fälligkeit mit Wochentag und Uhrzeit, Quelle als Abzeichen ("Sarah", "Import"), Hinweis (Links klickbar), Stern |
| Vorschläge | Beim Tippen die letzten 30 Einträge (ohne Doppelte); sie bleiben auch nach dem Löschen erhalten |
| Erledigen / Wichtig | Häkchen setzen; Stern ★ sortiert nach oben |
| Löschen | Papierkorb pro Aufgabe (auch für Erinnerungen von Sarah) und "Erledigte löschen", jeweils mit "Rückgängig" (6 s); technisch ein Grabstein, 30 Tage in der Datei aufgehoben |
| Zugangsdaten-Schutz | Texte, die nach Passwort, Token oder Schlüssel aussehen, werden nicht gespeichert |
| Sichern / Laden | Export schreibt das neue Schema (`version`, `aufgaben`); Import versteht altes (`todos`) und neues Format und führt je Aufgabe zusammen. Für Firefox/Safari ohne Dateiverbindung |

## Bedienung

1. `index.html` im Browser öffnen (am besten Chrome oder Edge).
2. Einmal "Ordner 08_Todos verbinden" klicken und den Ordner `08_Todos` auswählen; der Browser merkt sich den Ordner (nach einem Neustart fragt er die Berechtigung neu ab, dann wieder auf die Schaltfläche klicken). Bisher nur die Datei verbunden? Dann einmal den Ordner verbinden, damit auch der Spiegel aktuell bleibt.
3. Aufgabe tippen, optional Datum und Uhrzeit (oder Heute/Morgen/Nächste Woche), Enter drücken.
4. Mit dem Häkchen als erledigt markieren, mit dem Stern als wichtig, mit dem Papierkorb löschen (Rückgängig unten). Text, Datum und Uhrzeit lassen sich in der Zeile ändern.
5. Oben mit den Chips nach Zeit filtern.

## PWA und Updates

- Installierbar (Startbildschirm / „App installieren"), Vollbild ohne Browserleiste, App-Hülle offline verfügbar.
- Dateien: `manifest.webmanifest`, `sw.js`, `icons\` (192, 512, maskable 512, Apple-Touch-Icon).
- Wird eine neue Version hochgeladen, erscheint unten „Neue Version verfügbar" mit „Jetzt aktualisieren". Die Prüfung läuft beim Zurückkehren in die App und stündlich.
- Voraussetzung: https. Beim Öffnen der Datei vom Rechner läuft die App normal, aber ohne PWA-Funktionen.
- Beim Hochladen alle Dateien des Ordners mitnehmen, nicht nur `index.html`.
- Bei jeder Änderung die Version in `sw.js`, `index.html` (meta und sichtbar) und hier hochzählen.

## Datenspeicherung und Grenzen

- Die einzige Wahrheit ist `08_Todos\todos.json` (Schema und Regeln: `08_Todos\README.md`). Die App und `todos.ps1` ändern sie; nie von Hand bearbeiten.
- Der Spiegel `todos.js` wird bei verbundenem Ordner von der App nach jeder Änderung mitgeschrieben (und beim Neu-Lesen geheilt). Bei der Einzeldatei-Verbindung oder ohne Verbindung wird er nur von `todos.ps1` erneuert (`-Aktion Synchronisieren`). Die Plakette im Navigationsknopf nutzt Spiegel plus Browser-Cache (siehe `_standard\STANDARD.md`).
- Browser-Speicher: Cache `nobbis-todos-v1`, Grabsteine `nobbis-todos-tomb-v1`, wartende Änderungen `nobbis-todos-pending-v1`, Listenname und Vorschläge. Das Ordner- bzw. Datei-Handle liegt in IndexedDB.
- Firefox und Safari können keine Dateien verbinden (nur Spiegel plus Export/Import).
- Auf der gehosteten Seite (https) gibt es die Datei und den Spiegel nicht; dort läuft die App nur mit dem Browser-Cache.
- Erlaubt der Browser kein Speichern, zeigt die App einen Warnhinweis.

## Technik

- Eine einzelne HTML-Datei mit JavaScript, Ninox-Logo eingebettet; lädt den Spiegel `../../08_Todos/todos.js` per `<script src>`.
- Lädt Bootstrap und die Schrift Noto Sans über das Internet (CDN).

## Teststatus

Version 1.10.0 (28.10.2026), über den Server `http://localhost:8100`, im Testfenster per Skript gemessen (Fenster verdeckt):

- Getestet: Gruppen und Wochengrenzen (Testaufgaben gestern bis übernächste Woche), Anlegen mit Datum/Uhrzeit/Schnellauswahl, Erledigen/Wiederöffnen, Löschen mit Rückgängig (Grabstein), Stern, Bearbeiten, Zugangsdaten-Schutz, Quelle-Abzeichen, Plakette, Deutsch/Englisch, Layout bei 360, 390, 760, 1040 und 1300 px (Deutsch = Englisch pixelgleich, kein seitliches Scrollen, Touch-Ziele mindestens 44 px, Eingaben 16 px), Konsole ohne Skriptfehler.
- Dateiverbindung nur mit **simuliertem Datei-Handle** und ersetztem Auswahlfenster: Verbinden, Lesen, Schreiben, Zusammenführen (andere Aufgabe, gleiche Aufgabe, Löschung), ungültige Datei, Schreibfehler, wartende Änderungen, "Neue zentrale Datei anlegen", Abbruch, verweigerte Berechtigung; Zusammenspiel mit `todos.ps1`.
- **Nicht geprüft:** der echte Dateiauswahldialog und die echte Berechtigungsabfrage des Browsers, echtes `file://`, Handy-Gerät und Touch-Bedienung (nur Fenstergrößen), Service Worker und Update-Meldung (im Testfenster nicht möglich, erst online prüfbar), gehostete Version.

## Gemeldete Fehler

| Datum | Meldung | Ergebnis |
|---|---|---|
| 2026-10-26 | „Hinzufügen" schreibt auf nosz.github.io/todoapp nichts in die Liste | Lokal nicht nachstellbar: Klick und Enter funktionieren bei 375 px. Quelltext der gehosteten Version zeigt dieselbe Logik. Gehostete Seite konnte nicht im Browser geöffnet werden (gesperrt). Rückfragen an Norbert offen (Gerät, Browser, Konsolenmeldung). |

## Änderungsverlauf

| Datum | Änderung |
|---|---|
| 2026-11-05 | **1.12.1**: Bearbeiten bestehender Aufgaben im gleichen Stil: Text-Feld mit blauem Rahmen beim Ändern, Hover- und Fokus-Hervorhebung auf dem Aufgabentext, einheitliche Fokus-Rahmen und gedimmte Uhrzeit ohne Datum |
| 2026-11-05 | **1.12.0**: Formular „Neue Aufgabe“ überarbeitet: „Hinzufügen“ ist nur aktiv, wenn ein Text eingetragen ist (Leerzeichen zählen nicht); Schnellauswahl als Chips mit Symbol, gewählte Fälligkeit hervorgehoben, erneuter Klick löscht das Datum |
| 2026-11-04 | **1.11.4**: Bootstrap-JavaScript (5.3.8) jetzt lokal aus _standard\vendor\bootstrap statt von jsdelivr (Regel: kein CDN, Datenschutz) |
| 2026-10-28 | **1.10.0**: Zentrale To-do-Liste (`08_Todos\todos.json`): Verbindung per File System Access API, Zusammenführen je Aufgabe, Spiegel `todos.js` ohne Verbindung, Ansichten nach Zeit (Überfällig bis Ohne Datum), Uhrzeit, Schnellauswahl, Quelle-Abzeichen, Hinweis, Löschen als Grabstein auch für Erinnerungen, Export im neuen Schema, Zähler aus Spiegel und Cache |
| 2026-10-28 | **1.9.1**: Links dürfen mit data-nx-keinlang ohne Sprachparameter bleiben (Standard) |
| 2026-10-28 | **1.9.0**: Zähler-Plakette mit der Anzahl offener Aufgaben im Navigationsknopf "To-dos" (auf allen Seiten, aktualisiert sich sofort und über `storage`; ausgeblendet, wenn der Speicher nicht lesbar ist) |
| 2026-10-28 | **1.8.0**: Eingabe (Aufgabe, Fälligkeit), Titel-Dialog, Filter und Knöpfe auf die gemeinsamen nx-Komponenten umgestellt (gleiche Höhe 48 px, Radius, Fokusring, Primär-/Sekundärknopf, Icon-Knöpfe 44 px); Seitentitel "To-dos – Nobbis Super-Firma"; Kopf mit festen Spalten, Sprachumschalter springt nicht mehr (Position und Kopfhöhe in Deutsch und Englisch auf den Pixel gleich, gemessen 390 bis 1440 px) |
| 2026-10-26 | Erste Version |
| 2026-10-26 | In eigenen Ordner mit `index.html` verschoben |
| 2026-10-26 | (ohne App-Änderung) Lokaler Test mit Server `todo-lokal` (`.claude\launch.json`, Port 8099): Speichern nach Neuladen geprüft (Aufgabe, Fälligkeit und Name bleiben). Zusätzlich Claude-Mod `nobbis-todos` (`/todo`, eigene Liste als Pane, eigener Speicher, nicht synchron mit der Web-App). Der lokale Server liefert `sw.js` falsch aus, deshalb läuft dort der Service Worker nicht; das betrifft nur diesen Test |
| 2026-10-28 | **1.7.1**: Sprachumschalter auf schmalen Fenstern neben dem Logo |
| 2026-10-28 | **1.7.0**: Sprachumschalter mit beiden Flaggen (gewählte hervorgehoben); die Sprache wird zusätzlich in den Links mitgegeben und gilt so auf allen Seiten |
| 2026-10-28 | **1.6.1**: Wörterbuch angepasst (Name Sarah bleibt) |
| 2026-10-28 | **1.6.0**: Sprachknopf Deutsch/Englisch im Standard-Kopf; die Sprache gilt auf allen Seiten |
| 2026-10-28 | **1.5.1**: Einheitlicher Inhaltsbereich (Breite, Abstände, Schrift) wie auf allen Seiten |
| 2026-10-28 | **1.5.0**: Einheitlicher Standard-Kopf (Logo, feste Navigation, Titel) und Standard-Fußzeile mit Version |
| 2026-10-28 | **1.4.3**: Kopfbereich im neuen kompakten Stil (Verlauf, weiche Kreise, weniger Höhe) |
| 2026-10-26 | **1.4.2**: Knopf „Zurück zum Organigramm“ oben im Kopfbereich und unten vor der Versionsanzeige. Er erscheint nur lokal (Datei oder localhost), auf der gehosteten Seite ist er ausgeblendet, weil das Organigramm eine lokale Datei ist. Noch nicht hochgeladen |
| 2026-10-26 | **1.4.1**: Name im Manifest von „Nobbis To-dos“ auf „To-dos“ geändert (passt zum Seitentitel). Noch nicht hochgeladen |
| 2026-10-26 | **1.4.0**: Datum pro Aufgabe. „Erstellt“ setzt die App automatisch (nicht änderbar; alte Aufgaben nehmen das Datum aus ihrer ID). „Fällig bis“ ist optional, beim Anlegen und später änderbar; überfällige offene Aufgaben werden rot mit Warn-Icon markiert. Sortierung: Stern, dann früheste Fälligkeit (ohne Datum zuletzt), dann neueste. Export/Import enthalten beide Daten. Noch nicht hochgeladen |
| 2026-10-26 | **1.3.1**: Warnung „Speichern nicht möglich“ erscheint nur noch, wenn ein Test-Schreiben in den `localStorage` wirklich scheitert (vorher auch bei defekten Altdaten), mit genauerem Text und Hinweis auf Export. Die Warnung in der Vorschau kam, weil dort das Speichern gesperrt ist. Noch nicht hochgeladen |
| 2026-10-26 | **1.3.0**: Alle Symbole jetzt Bootstrap Icons (Pflicht, keine Emojis oder Textzeichen mehr). Aufgabentext per Antippen ändern (Enter oder Wegtippen speichert, Esc bricht ab). „Rückgängig“-Leiste 6 Sekunden nach Löschen einer Aufgabe oder der erledigten (ersetzt die Rückfrage). Sichern (Export) und Laden (Import) als JSON-Datei, Import ergänzt nur, was noch fehlt. „Erledigte löschen“ nur sichtbar, wenn es welche gibt. Name der Liste: Änderung erscheint beim Tippen sofort, Speichern-Button nur aktiv bei Änderung, ✕/Esc bricht ab. Lokal in der Vorschau geprüft: Bearbeiten, Esc, Löschen und Rückgängig, Erledigte löschen und Rückgängig, Icons sichtbar. Nicht geprüft: Export/Import mit echter Datei, Speichern nach Neuladen, Handy. Noch nicht hochgeladen |
| 2026-10-26 | **1.2.1**: Name der Liste oben änderbar (Stift-Button, Standard „To-dos“, im Browser gespeichert, auch als Seitentitel). Service Worker holt Seitenaufrufe jetzt zuerst aus dem Netz (alte Version bleibt nicht mehr im Cache hängen), offline weiter aus dem Cache. Lokal geprüft: Namen ändern in der Vorschau. Nicht geprüft: Speichern nach Neuladen, Service Worker online. Noch nicht hochgeladen |
| 2026-10-26 | **1.2.0**: PWA (Manifest, Service Worker, Icons, installierbar, offline) und Meldung „Neue Version verfügbar" mit „Jetzt aktualisieren" / „Später". Lokal geprüft: Manifest gültig, Icons vorhanden, Skript-Syntax, Banner-Optik. Erst online prüfbar: Installierbarkeit, Service-Worker-Registrierung, Update-Meldung, Offline. Noch nicht hochgeladen |
| 2026-10-26 | **1.1.0**: Automatische Vorschläge aus den letzten Einträgen und Versionsanzeige (lokal; noch nicht auf nosz.github.io hochgeladen). Die zuvor online liegende Version trägt keine Nummer und gilt als 1.0.0 |
