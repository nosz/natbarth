# 02_Erstellte_Apps

**Wofür:** Alle gebauten Apps und Seiten im Ninox-Design, je App ein Ordner mit Nummer.

| Ordner | Inhalt |
|---|---|
| 01_mitarbeiter_organigramm | Organigramm der Mitarbeiter |
| 02_agenten_skills_uebersicht | Übersicht der Agenten und Skills |
| 03_todo | To-do-App |
| 04_favoriten | Favoriten |
| 05_github_trainer | GitHub-Trainer |
| 06_ninox4_architektur | Ninox-4-Architektur |
| _standard | Gemeinsamer Standard: Kopf, Fußzeile, Sprache, Suche, Prüfskripte |

Regel: Jede Änderung bekommt eine neue Versionsnummer. Neue Seiten immer mit _standard\seite-standard.ps1 bauen.
