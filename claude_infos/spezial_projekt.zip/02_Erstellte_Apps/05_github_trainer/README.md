# GitHub-Trainer

Interaktiver Lern-Trainer für die wichtigsten Git- und GitHub-Befehle. Eine einzelne Datei (`index.html`), Deutsch und Englisch, im Ninox-Design von Nobbis Super-Firma.

**Version 1.0.0** · Stand 28.10.2026

## Zweck

Wer den Trainer durcharbeitet, kann die wichtigsten Befehle für die tägliche Arbeit mit Git und GitHub im Team einordnen und anwenden: Repository anlegen oder klonen, Änderungen speichern, mit GitHub abgleichen, Branches nutzen, Fehler rückgängig machen, über Pull Requests zusammenarbeiten und GitHub im Terminal mit `gh` bedienen.

## Funktionen

| Funktion | Beschreibung |
|---|---|
| 8 Kapitel | Je Kapitel eine kurze Lektion mit Befehlsliste, danach ein Quiz |
| 48 Aufgaben | 40 Quizfragen (5 je Kapitel) plus 8 Zuordnungsaufgaben (1 je Kapitel) |
| Aufgabentypen | Einzelauswahl, Mehrfachauswahl, Reihenfolge (mit Pfeilknöpfen) und Zuordnung (Auswahlfelder) |
| Erklärung und Praxisbeispiel | Nach jeder Antwort erscheinen eine Erklärung und der passende Befehl in einem Codeblock |
| Kopieren-Knopf | Jeder Befehl lässt sich mit einem Klick in die Zwischenablage kopieren |
| Fortschritt und Rang | Ab 75 % richtig gilt ein Kapitel als bestanden. Ränge: Entdecker (0), Anwender (ab 1), Praktiker (ab 3), Profi (ab 6), Meister (alle 8 Kapitel) |
| Zweisprachig | Der Sprachknopf im Kopf wirkt auf alles: Oberfläche, Fragen, Antworten, Erklärungen, Befehlsplatzhalter |
| Quellen | Jedes Kapitel verlinkt auf die offizielle Dokumentation |

## Kapitel

1. Grundlagen: Repository, Commit, Branch, Remote
2. Start: `git init`, `git clone`, `git status`
3. Änderungen speichern: `git add`, `git commit`, `git diff`, `git log`
4. Mit GitHub arbeiten: `git remote`, `git push`, `git pull`, `git fetch`
5. Branches: `git branch`, `git switch`, `git checkout`, `git merge`
6. Rückgängig machen und Aufräumen: `git restore`, `git reset`, `git revert`, `git stash`, `.gitignore`
7. Zusammenarbeit auf GitHub: Pull Request, Review, Issue, Fork
8. GitHub CLI: `gh auth login`, `gh repo clone`, `gh pr create`, `gh pr list`, `gh pr merge`, `gh issue create`

## Bedienung

1. Seite öffnen (`http://localhost:8100/02_Erstellte_Apps/05_github_trainer/index.html`).
2. Ein Kapitel wählen und die Lektion lesen. Befehle mit "Kopieren" übernehmen.
3. "Quiz starten" wählen und die Fragen beantworten. Einzelauswahl gilt sofort, Mehrfachauswahl, Reihenfolge und Zuordnung mit "Prüfen".
4. Nach jeder Antwort Erklärung und Praxisbeispiel lesen, dann "Weiter".
5. Im Ergebnis: Wiederholen, nächstes Kapitel, Lektion nochmals lesen oder zur Übersicht.
6. Auf der Übersicht lässt sich der Fortschritt mit "Fortschritt zurücksetzen" (mit Rückfrage) löschen.

Alles ist per Tastatur bedienbar. Platzhalter wie `<BENUTZER>`, `<REPO>` oder `<DATEI>` ersetzt du durch eigene Werte.

## Datenspeicherung und Grenzen

- Der Fortschritt liegt im `localStorage` des Browsers unter dem Schlüssel `github_trainer_prog_v1`. Er verlässt das Gerät nicht.
- Ist der Browser-Speicher gesperrt, funktioniert die App weiter, der Fortschritt gilt dann nur bis zum Schließen der Seite. Die Übersicht weist darauf hin.
- Die Sprache kommt vom Standard-Sprachknopf (`window.nxLang()`, Ereignis `nx-lang`).
- Die Befehle sind Lernbeispiele. Befehle mit Außenwirkung (`git push --force`, `gh pr merge`) nur nach Absprache im Team ausführen.
- Kein Dashboard-Eintrag, keine PWA, nicht gehostet (Stand 1.0.0). Hosting und Dashboard-Kachel sind nicht entschieden.
- Die Aufgaben sind eine Lernhilfe, keine Zertifizierung.

## Sicherheit

Es stehen keine echten Zugangsdaten in der App. Beispiele nutzen Platzhalter. Kapitel 4 und 8 weisen darauf hin: Tokens nie in Chats, Dateien oder Tickets speichern, sondern in Bitwarden oder im System-Schlüsselbund; für Anmeldungen nur IT-genehmigte Wege nutzen (`gh auth login --web`); ein offengelegtes Token sofort widerrufen und an it@ninox.com melden (ISO 27001, BSI C5).

## Technik

- Eine HTML-Datei mit eigenem CSS und JavaScript, keine eigenen Abhängigkeiten.
- Standard-Kopf, -Navigation, -Sprachknopf, -Fußzeile und -Stil von `02_Erstellte_Apps\_standard\seite-standard.ps1` (Seitenkey `github_trainer` in `woerterbuch.json`). Der Standard lädt Bootstrap Icons und Noto Sans von einem CDN. Ohne Netz erscheinen Icons und Schrift in Ersatzdarstellung, die App selbst läuft weiter.
- Ninox-Design: Blau `#4970ff`, Slate- und Sand-Töne, Radien 6/12/18/24 px, Bedienelemente `nx-btn-primary`, `nx-btn-secondary`, `nx-card`, `nx-input`, `nx-icon-btn`, `nx-grid`, `nx-h2`.
- Mobile-first: Touch-Ziele mindestens 44 px, Eingabefelder 16 px, kein seitliches Scrollen.
- Fragen und Antworten stehen mit Deutsch und Englisch in der Datenstruktur der App (`CH`). Nur der Seitentitel, der Untertitel und der Hinweis ohne JavaScript laufen über das Wörterbuch.
- Nicht barrierefrei geprüft mit Screenreader.

## Quellen (am 28.10.2026 abgerufen)

- Git: [git init](https://git-scm.com/docs/git-init), [git clone](https://git-scm.com/docs/git-clone), [git status](https://git-scm.com/docs/git-status), [git add](https://git-scm.com/docs/git-add), [git commit](https://git-scm.com/docs/git-commit), [git diff](https://git-scm.com/docs/git-diff), [git log](https://git-scm.com/docs/git-log), [git remote](https://git-scm.com/docs/git-remote), [git push](https://git-scm.com/docs/git-push), [git fetch](https://git-scm.com/docs/git-fetch), [git pull](https://git-scm.com/docs/git-pull), [git branch](https://git-scm.com/docs/git-branch), [git switch](https://git-scm.com/docs/git-switch), [git checkout](https://git-scm.com/docs/git-checkout), [git merge](https://git-scm.com/docs/git-merge), [git restore](https://git-scm.com/docs/git-restore), [git reset](https://git-scm.com/docs/git-reset), [git revert](https://git-scm.com/docs/git-revert), [git stash](https://git-scm.com/docs/git-stash), [gitignore](https://git-scm.com/docs/gitignore)
- GitHub Docs: [Über Git](https://docs.github.com/en/get-started/using-git/about-git), [Remote-Repositories](https://docs.github.com/en/get-started/git-basics/about-remote-repositories), [Pull Requests](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests), [Reviews](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/about-pull-request-reviews), [Issues](https://docs.github.com/en/issues/tracking-your-work-with-issues/learning-about-issues/about-issues), [Issue verknüpfen](https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/linking-a-pull-request-to-an-issue), [Forks](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/working-with-forks/about-forks), [Merge-Methoden](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/about-pull-request-merges), [Zugangsdaten zwischenspeichern](https://docs.github.com/en/get-started/git-basics/caching-your-github-credentials-in-git)
- GitHub CLI: [gh auth login](https://cli.github.com/manual/gh_auth_login), [gh repo clone](https://cli.github.com/manual/gh_repo_clone), [gh pr create](https://cli.github.com/manual/gh_pr_create), [gh pr list](https://cli.github.com/manual/gh_pr_list), [gh pr merge](https://cli.github.com/manual/gh_pr_merge), [gh pr review](https://cli.github.com/manual/gh_pr_review), [gh issue create](https://cli.github.com/manual/gh_issue_create)

Nicht belegt und deshalb bewusst weggelassen: das Standardverhalten von `git pull` ohne Konfiguration (die Doku-Seite war dazu widersprüchlich) und `git config user.name/user.email` (die Seite "Set up Git" nennt die Befehle nicht).

## Teststatus (Version 1.0.0)

| Prüfung | Ergebnis |
|---|---|
| `pruefung.ps1` vorher / nachher | vorher 58 Prüfungen, nachher 64 Prüfungen (inkl. dieser Seite), jeweils 0 Fehler |
| Seitenstandard (`pruefung.js`) bei 390, 760, 1300 px | bestanden: Umschalter DE/EN und Kopfhöhe pixelgleich, Links 200, kein Restdeutsch |
| Alle Kapitel durchgespielt (richtig, falsch, gemischt) in Deutsch und Englisch | bestanden (Ergebnis, Rang, Fortschritt) |
| Fortschritt nach Neuladen, Zurücksetzen mit Rückfrage | bestanden |
| Speicher gesperrt | bestanden (App läuft, Hinweis erscheint) |
| Touch-Ziele mindestens 44 px, kein seitliches Scrollen, 113 Ansichten | bestanden bei 360x740, 375x812, 390x844, 768x1024, 812x375 (Querformat) |
| Tastatur (Tab, Enter, Fokus sichtbar, Reihenfolge per Pfeilknopf) | bestanden |
| Kopieren-Knopf | Klick löst "Kopiert" aus; der Inhalt der Zwischenablage ließ sich im Testbrowser nicht auslesen |
| Befehle gegen offizielle Quellen | bestanden, siehe Quellen |
| Echtes Handy, Screenreader, `file://`-Direktstart | nicht geprüft |

## Änderungsverlauf

| Version | Datum | Änderung |
|---|---|---|
| 2026-10-28 | **1.0.2**: Standard-Kopf neu gesetzt: lädt den Spiegel der zentralen To-do-Liste (`08_Todos/todos.js`) für den Zähler im Knopf To-dos (Quelle `NX_TODOS`, Rückfall Browser-Speicher); sonst keine Änderung |
| 2026-10-28 | **1.0.1**: Links dürfen mit data-nx-keinlang ohne Sprachparameter bleiben (Standard) |
| 1.0.0 | 28.10.2026 | Erste Version: 8 Kapitel, 40 Quizfragen, 8 Zuordnungsaufgaben, Fortschritt, Ränge, Deutsch und Englisch |
