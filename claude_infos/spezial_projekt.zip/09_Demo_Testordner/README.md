﻿# Demo-Testordner

Dieser Ordner ist bewusst unordentlich. Er dient als Demo, wie Claude Ordnung in Ordner und Dateien bringt.
Alle Inhalte sind erfunden (keine Kunden-, Personen- oder Zugangsdaten).

Ausgangszustand: 20 Unterordner mit gemischten Dateien, Duplikaten und uneinheitlichen Namen.
