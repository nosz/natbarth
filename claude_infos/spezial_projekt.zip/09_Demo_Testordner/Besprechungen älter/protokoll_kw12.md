﻿# Protokoll KW12

- Punkt 1
- Punkt 2
