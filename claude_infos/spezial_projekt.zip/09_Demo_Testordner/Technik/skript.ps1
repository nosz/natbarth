﻿Write-Output 'Demo-Skript'
