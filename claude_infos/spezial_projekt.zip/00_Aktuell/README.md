# 00_Aktuell

**Wofür:** Eingang für Arbeitsmaterial, das gerade gebraucht wird und noch keinen festen Platz hat.

| Unterordner | Inhalt |
|---|---|
| agenten-prompts | Prompts und Demo-Texte für das Agentensystem (Deutsch und Englisch) |
| stellenbeschreibungen | Stellenbeschreibungen der Agenten |
| todo-import | Importdateien für die zentrale To-do-Liste |

Regel: Dateien mit Timestamp im Namen (JJJJ-MM-TT_HHMM_thema). Was fertig ist, wandert in den passenden Ordner.
