# Sarahs Übersicht

Live-Ansicht der zentralen To-do-Liste im Ninox-Design: alle offenen Aufgaben und Erinnerungen, nach Fälligkeit gegliedert. Sarah führt keine eigene Liste mehr.

| | |
|---|---|
| **Datei** | `05_Sarah_Erinnerungen\sarah-uebersicht.html` (feste Adresse, siehe unten) |
| **Version** | 2.0.0 (2026-10-28) |
| **Ersteller** | Nobbi (Seite), Sarah (Inhalte über `todos.ps1`) |
| **Dashboard** | Karte "Sarahs Übersicht" im Bereich Erstellte Apps von `firma.htm` und feste Karte in den Favoriten |
| **Gehostet** | Nein. Ohne `08_Todos\todos.js` (z. B. gehostet) zeigt die Seite einen klaren Hinweis statt Daten |

## Zweck

Seit 28.10.2026 steht jede Erinnerung als Aufgabe (`quelle sarah`) in `08_Todos\todos.json` (Beschreibung: `08_Todos\README.md`). Diese Seite zeigt die Liste live, statt als täglich neu erzeugte Momentaufnahme. Sarah (Agent und geplante Aufgabe `sarah-morgenuebersicht`) legt Erinnerungen nur mit `08_Todos\todos.ps1` an; die Seite muss nie nachgezogen werden.

## Funktionen

| Funktion | Beschreibung |
|---|---|
| Sechs Kacheln | Heute fällig, Überfällig, Diese Woche, Nächste Woche, Später, Ohne Datum (Anzahl offener Aufgaben je Abschnitt) |
| Abschnitte | Heute, Überfällig, Diese Woche (ab morgen bis Sonntag der laufenden Kalenderwoche), Nächste Woche (Montag bis Sonntag der Woche danach), Später, Ohne Datum; je Abschnitt ein Leerzustand |
| Karten | Titel, Uhrzeit oder "ganztägig", Abzeichen der Quelle (Sarah, Import), Stern, Wochentag und Datum, Hinweis; ein Knopf nur, wenn der Hinweis einen https-Link enthält (Slack: "Unterhaltung öffnen", Outlook: "Outlook öffnen", sonst "Link öffnen"; neuer Tab, ohne Sprachparameter) |
| Wochenlogik | Identisch zur To-do-App (Kalenderwochen Montag bis Sonntag), per Test gegen die App und eine unabhängige Berechnung geprüft |
| Live | Rendert beim Laden und bei Sprachwechsel, bei Änderungen im Browser-Speicher (`storage`) und beim Zurückkehren auf die Seite |
| Quelle der Daten | Spiegel `window.NX_TODOS` plus Browser-Cache der To-do-App, zusammengeführt je Aufgabe nach `geaendert` (`window.nxTodoListe()`, wie der Zähler); gelöschte und erledigte Aufgaben erscheinen nicht |
| Wiederkehrend | Statische Tabelle (Sarah Morgenübersicht, Otto, Claudia); Quelle für die wiederkehrenden Einträge der globalen Suche |
| Sprache | Deutsch und Englisch; Aufgabentexte sind Eigeneingaben und bleiben unübersetzt |

## Feste Adresse (Ausnahme von Ottos Timestamp-Regel)

Die Seite heißt `sarah-uebersicht.html` ohne Datum. Bisher entstand täglich eine neue Datei `<Datum>_0900_sarah-uebersicht.html` als Momentaufnahme, die hinter der Liste zurückbleiben konnte. Weil die Seite jetzt live ist, gibt es nur noch eine Datei mit fester Adresse; alle Verweise (Organigramm, Favoriten, Suchindex, Prüfskripte, Doku) zeigen auf sie. Die letzte datierte Fassung (1.5.5) liegt als Sicherung in `06_sicherungen\2026-10-28_0900_sarah-uebersicht.html`. `erinnerungen.md` ist ein Archiv.

## Bedienung

1. Seite über den Server `http://localhost:8100/05_Sarah_Erinnerungen/sarah-uebersicht.html` oder über die Karte im Organigramm öffnen.
2. Aufgaben ändern nur in der To-do-App oder mit `todos.ps1`; die Seite ist nur lesend. Nach einer Änderung in der To-do-App (anderes Fenster) aktualisiert sie sich selbst, nach `todos.ps1` ggf. nach Neuladen.

## Technik

Standard-Kopf und -Fußzeile über `_standard\seite-standard.ps1` (Seitenkey `sarah`), Bootstrap Icons, eine Datei mit JavaScript ohne eigene Datenhaltung. Eigene Texte stehen im Objekt `S` im Skript der Seite (Container mit `translate="no"`, rendert in `window.nxLang()`).

## Teststatus

Siehe Änderungsverlauf und `_standard\TESTS.md` (Abschnitt Stufe 2): `nxTestSarah` prüft Wochenlogik (alle Tage, Jahreswechsel, Schaltjahr), Abschnitte und Zahlen mit Testaufgaben, Deutsch/Englisch, Löschen, Links, Hinweis ohne Spiegel und Layout bei 360, 390, 768 und 1300 px (per Skript gemessen). Nicht geprüft: echtes `file://`, Handy-Gerät und Touch-Bedienung.

## Änderungsverlauf

| Datum | Änderung |
|---|---|
| 2026-10-28 | **2.0.0**: Umbau zur Live-Ansicht der zentralen To-do-Liste; feste Adresse `sarah-uebersicht.html`; sechs Kacheln und Abschnitt Ohne Datum; Deutsch/Englisch |
| 2026-10-28 | 1.5.5 und früher: täglich erzeugte Übersicht mit festem Stand (jetzt in `09_Ablage\sicherungen\`) |