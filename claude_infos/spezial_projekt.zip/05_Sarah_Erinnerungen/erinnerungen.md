# Erinnerungen von Norbert: ARCHIV

> **Seit 28.10.2026 führt Sarah KEINE eigene Liste mehr.** Alle Erinnerungen stehen als Aufgaben (`quelle sarah`) in der zentralen Liste `08_Todos\todos.json`. Anlegen, ändern, erledigen und löschen nur mit `08_Todos\todos.ps1` oder in der To-do-App. Diese Datei ist ein Archiv und wird nicht mehr gepflegt und von nichts mehr gelesen.

## Verlauf (Stand 28.10.2026, aus der Migration)

| Status | Datum | Uhrzeit | Was | Hinweis | Angelegt am |
|---|---|---|---|---|---|
| offen | 2026-10-28 | ganztägig | Bei der Person in der Slack-Unterhaltung melden (Update läuft) | Link: https://ninoxteam.slack.com/archives/D0B0F861NF3/p1793119707572859 | 2026-10-27 |
| offen | 2026-11-04 | ganztägig | Outlook Abwesenheitseintrag entfernen | Gehört zum To-do 'Outlook Abwesenheitsnotiz eintragen' | 2026-10-28 |
| offen | 2026-11-04 | ganztägig | Leo Text Ninox4 |  | 2026-10-28 |
