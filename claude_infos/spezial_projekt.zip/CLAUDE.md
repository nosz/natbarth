# Regeln für alle Agenten und Skills in diesem Ordner

## Fragen an Norbert immer mit Klick-Buttons

- Jede Frage oder Entscheidung, die Norbert beantworten muss, wird als **anklickbare Buttons** angeboten (Werkzeug `AskUserQuestion`; am Ende des Durchgangs bei `mcp__ccd_turn__wrap_up` als `actions`), sodass er nur klicken muss.
- Die empfohlene Antwort steht als erster Button mit "(Recommended)" bzw. "(Empfohlen)".
- Nicht nur "Schreib X oder Y" als Freitext anbieten. Freitext bleibt über "Other" möglich.
- Gilt für alle Agenten (Dora, Arnold, Beni, Claudia, Hans, Leonardo, Nicoletta, Niklas, Nobbi, Otto, Sarah, Garry, Willi, Archie, Olga, Tom & Tina) und alle Skills.
- Die Frage steht zusätzlich als eigener fetter Absatz am Ende ("Frage an dich:").

## Otto legt jede Ablage fest (zwingend, Anweisung von Norbert vom 04.11.2026)
Otto ist der Ordnerkönig und wird bei **jedem** neuen Projekt, jeder neuen App, jedem Bericht und jeder neuen Ablage eines Mitarbeiters (Agenten) eingebunden, bevor Ordner oder Dateien angelegt werden.
- Otto legt Ordnerstruktur und Dateinamen nach seinen Regeln (`.claude\agents\otto.md`) fest: Format `JJJJ-MM-TT_HHMM_beschreibender-name.endung`, klein, Bindestriche, keine Umlaute; Ordnernamen ohne Timestamp. Ausnahme auf Anweisung von Norbert (04.11.2026): Archies Kundendateien heißen `<kunde>_systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf` (Kunde vorn, Datum hinten); neutrale Dokumente ohne Kundenbezug heißen `systemarchitektur-ninox<N>_<de|en>_<JJJJ-MM-TT>.pdf` im Ordner `berichte\neutral\`. Kein Mitarbeiter legt eine eigene Struktur nach Gutdünken an.
- Ergebnisse der Mitarbeiter liegen in `04_Mitarbeiter\<name>_berichte\` in speziellen Unterordnern (bei Archie zum Beispiel `berichte\<kunde>\ninox3\` und `\ninox4\`, `vorlagen\`, `werkzeuge\`, `pruefwerkzeug\`). Apps und Seiten liegen in `02_Erstellte_Apps\<nn>_<name>\`.
- Vorgehen: Otto wird mit dem Auftrag beauftragt (Agent `otto`, nur lesend und planend), liefert Struktur, Namensschema und Abbildung alt zu neu, danach wird umgesetzt und Otto prüft das Ergebnis. Gilt für alle Agenten und Skills und für jedes künftige Projekt.
- Nichts wird ohne Freigabe von Norbert gelöscht; Ersetztes wandert in einen Unterordner `ersetzt\`. Leere Alt-Ordner meldet Otto mit Pfad, Grund, Größe und Datum.

## Pflicht-Prüfung: Alle Links und Seiten testen (zwingend)

Jede neue oder geänderte Seite, App, Präsentation oder jeder Bericht wird vor der Meldung "fertig" geprüft. Ohne bestandene Prüfung nie "fertig" melden.

1. Über den Server öffnen, nie über `file://`: `preview_start` mit Name `firma` (Port 8100), dann `http://localhost:8100/<Pfad>`. Das Browserfenster zeigt `file://`-Seiten nur als Schnappschuss (`data:`), darin funktionieren relative Links nicht.
2. Jeden Link der Seite per Abruf prüfen (Status 200, auch Links in Unterseiten). Fehlerhafte Links beheben, bevor Norbert die Seite sieht.
3. Die Unterseiten wirklich laden und prüfen, ob sie Inhalt zeigen, ohne Konsolenfehler.
4. Wurde etwas an einer Seite geändert, auch die Seiten prüfen, die darauf verlinken.
5. Im Ergebnis nennen, was geprüft wurde (Anzahl Links, alle 200) und was nicht prüfbar war. Nichts als geprüft ausgeben, was nicht geprüft wurde.
6. Wenn Norbert Seiten selbst öffnen soll, den Server-Link `http://localhost:8100/...` nennen oder die Seite im Browserfenster über den Server öffnen.

## Pflicht: Einheitlicher Kopf, Navigation und Fußzeile (zwingend)

Jede Seite, App, jeder Bericht und jede Übersicht im Ninox-Design bekommt immer denselben Kopfbereich (Logo, fünf feste Navigationsknöpfe oben im gleichen Bereich, Titel, Untertitel), denselben 1140-px-Inhaltsbereich und dieselbe Fußzeile mit Versionsnummer. Nie von Hand nachbauen: immer `02_Erstellte_Apps\_standard\seite-standard.ps1` verwenden. Aufbau, Parameter und Regeln stehen in `02_Erstellte_Apps\_standard\STANDARD.md` (vorher lesen). Ausgenommen sind Präsentationen und eigenständige Fan-/Demo-Projekte außerhalb des Ninox-Ökosystems. Öffentliche Veranstaltungsseiten (z. B. Ninox Live) nutzen `seite-standard.ps1 -Oeffentlich`: ohne Firmennamen "Nobbis Super-Firma", ohne interne Navigation und ohne To-do-Spiegel; Druck-Flyer tragen keinen Seitenkopf. Danach immer die Pflicht-Prüfung durchführen.

Zusätzlich zwingend: Jede Seite hat den Sprachknopf Deutsch/Englisch im Kopf, die Sprache gilt auf allen Seiten gemeinsam, und jeder Text hat sofort einen englischen Eintrag in `02_Erstellte_Apps\_standard\woerterbuch.json` (Details in STANDARD.md, Abschnitt Sprache). Täglich neu erzeugte Seiten (Sarah, Tagesberichte) bringen das Englisch per `data-en=`-Attribut mit.

## Pflicht: Professionelle Tests, immer (zwingend)
Jede Änderung wird nach `02_Erstellte_Apps\_standard\TESTS.md` getestet, bevor "fertig" gemeldet wird: Sicherung außerhalb OneDrive, Dateiprüfung `02_Erstellte_Apps\_standard\pruefung.ps1` (0 Fehler), Browserprüfung über den Server mit `pruefung.js` (Umschalter, Kopf und Leiste in Deutsch und Englisch pixelgleich, Links 200, kein Restdeutsch, ohne Speicher), danach Dateiprüfung erneut. Im Bericht stehen die Zahlen und was nicht prüfbar war. Nie "fertig" ohne bestandene Tests.

## Suchindex aktuell halten (zwingend)
Die App-übergreifende Suche im Organigramm (`firma.htm`) liest den Index `02_Erstellte_Apps\_standard\suchindex.js`. Nach jeder inhaltlichen Änderung an Apps, Favoriten, Tagesberichten, am GitHub-Trainer, an Mitarbeitern oder am Wörterbuch wird `02_Erstellte_Apps\_standard\suchindex-erstellen.ps1` ausgeführt. Sarahs Erinnerungen stehen seit 28.10.2026 nicht mehr im Index (die Suche liest die zentrale To-do-Liste live; `erinnerungen.md` ist nur Archiv). `pruefung.ps1` meldet einen veralteten Index als Fehler. Details in `STANDARD.md`, Abschnitt Suche.