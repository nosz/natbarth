# 10_Ninox_Projekte

Arbeitsordner für Ninox-4-Apps, die per API (Skill `ninox4-api-builder`) angepasst werden. Je App ein Unterordner mit `ninox.config.json` (nur IDs, keine Keys), `sicherungen\` (Moduldefinition vor jeder Änderung, `JJJJ-MM-TT_HHMM_moduldefinition-vor-<schritt>.json`) und `notizen\`. Struktur festgelegt von Otto am 2026-11-05.
