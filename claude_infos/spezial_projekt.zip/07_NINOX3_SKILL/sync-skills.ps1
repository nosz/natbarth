﻿# Abgleich der beiden Ninox-3-Skills: Quelle ist dieser Ordner (07_NINOX3_SKILL), Kopie liegt in ~\.claude\skills.
# Ohne Schalter: nur vergleichen (nichts wird geändert). Mit -Kopieren: Quelle -> Kopie übertragen.
# Es wird nie etwas in der Kopie gelöscht; nicht mehr vorhandene Dateien melden wir nur.
param([switch]$Kopieren)
$ErrorActionPreference = "Stop"
$quelle = $PSScriptRoot
$ziel = Join-Path $env:USERPROFILE ".claude\skills"
$skills = @("ninox3", "ninox3-zu-ninox4-migration")
$abweichungen = 0
foreach ($s in $skills) {
  $q = Join-Path $quelle $s
  $z = Join-Path $ziel $s
  if (-not (Test-Path $q)) { Write-Host "FEHLT in der Quelle: $s"; $abweichungen++; continue }
  $dateienQ = Get-ChildItem $q -Recurse -File
  foreach ($f in $dateienQ) {
    $rel = $f.FullName.Substring($q.Length + 1)
    $zf = Join-Path $z $rel
    $gleich = (Test-Path $zf) -and ((Get-FileHash $f.FullName).Hash -eq (Get-FileHash $zf).Hash)
    if (-not $gleich) {
      $abweichungen++
      if ($Kopieren) {
        New-Item -ItemType Directory -Force (Split-Path $zf) | Out-Null
        Copy-Item $f.FullName $zf -Force
        Write-Host "kopiert: $s\$rel"
      } else { Write-Host "abweichend oder neu: $s\$rel" }
    }
  }
  if (Test-Path $z) {
    foreach ($f in Get-ChildItem $z -Recurse -File) {
      $rel = $f.FullName.Substring($z.Length + 1)
      if (-not (Test-Path (Join-Path $q $rel))) { Write-Host "nur in der Kopie (nicht gelöscht): $s\$rel" }
    }
  }
}
if ($abweichungen -eq 0) { Write-Host "OK: beide Skills sind identisch ($($skills -join ', '))." }
elseif (-not $Kopieren) { Write-Host "$abweichungen Abweichung(en). Mit -Kopieren übertragen." }
else { Write-Host "$abweichungen Datei(en) übertragen." }