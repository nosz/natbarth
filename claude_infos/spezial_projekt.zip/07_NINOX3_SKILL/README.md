# 07_NINOX3_SKILL

**Wofür:** Quelle der beiden Ninox-3-Skills (ninox3, ninox3-zu-ninox4-migration).

Hinweis: Dieselben Skills liegen als Kopie in C:\Users\NorbertSzpak\.claude\skills. Stand 04.11.2026 sind beide Fassungen identisch. Änderungen immer hier machen und danach in die Kopie übernehmen.

**Abgleich:** sync-skills.ps1 vergleicht Quelle und Kopie (ohne Schalter nur Anzeige). Nach Änderungen an einem Skill .\07_NINOX3_SKILL\sync-skills.ps1 -Kopieren ausführen. Es wird nie etwas in der Kopie gelöscht.
