---
name: ninox3
description: Arbeitet ausschließlich mit Ninox 3 (api.ninox.com/v1 und Private Cloud / On-Premises, Workspaces heißen dort "Teams"). Liest Schema, Tabellen, Felder, Ansichten und Datensätze über die Ninox-3-REST-API, führt Ninox-Script-Abfragen (query/exec) aus, legt Datensätze und Dateien an, ändert oder löscht sie (nur mit Freigabe) und schreibt Ninox Script für Ninox 3 (Formeln, Trigger, http()). Immer nutzen bei "Ninox 3", "Ninox3", "api.ninox.com", "Ninox-3-API", "Team-ID / Datenbank-ID / Tabellen-ID", "Datensätze per API lesen/anlegen/ändern", "Ninox-3-Script", "Formel für Ninox 3", "Ninox 3 Schema auslesen", auch wenn das Wort API nicht fällt. Nicht für Ninox 4 (go.ninox.com, Module): dort nichts tun und auf die Ninox-4-Skills verweisen.
---

# Ninox 3 (Ninox Software GmbH)

Dieser Skill arbeitet **nur mit Ninox 3**. Ninox 4 ist nicht Teil davon, es wird weder angefasst noch als Vorlage oder Vergleich benutzt.

## Abgrenzung (zuerst prüfen)

| Merkmal | Ninox 3 (dieser Skill) | Nicht dieser Skill |
|---|---|---|
| API-Adresse | `https://api.ninox.com/v1` oder `https://{hostname}/v1` (Private Cloud / On-Premises) | `go.ninox.com` |
| Struktur | Team (Workspace), Datenbank, Tabelle (ID meist ein Buchstabe, z. B. `A`), Datensatz | Module |
| Anmeldung | Personal Access Token als `Authorization: Bearer ...` | |
| Sicherung | `.ninox`-Datei | |

Fragt jemand nach Ninox 4, Modulen oder `go.ninox.com`: nichts ausführen. In einem Satz sagen, dass dieser Skill nur Ninox 3 abdeckt, und auf `ninox-start` verweisen. Ist unklar, welche Version vorliegt, zuerst die Adresse der Instanz erfragen.

## Sicherheit (zwingend, ISO 27001 / BSI C5)

- **Kein Token im Chat.** Nie ein Token, einen Schlüssel oder ein Passwort verwenden, wiederholen oder speichern, das jemand im Chat, in Dateien oder Screenshots zeigt. Wird eines geteilt: sofort stoppen und sagen, dass es als kompromittiert gilt. Dann `references/sicherheit-und-freigaben.md`, Abschnitt "Token im Chat geteilt".
- **Ablage nur lokal verschlüsselt.** Das Token liegt im Windows-Benutzerprofil (DPAPI) oder in Bitwarden, über `scripts/ninox3-api.ps1` (`Set-Ninox3Key`, läuft im eigenen Terminal des Nutzers). Nie in Skripten, `.env`, Tickets oder Dokumenten. Im Output nur Platzhalter wie `<API_KEY>`.
- **Datenminimierung (DSGVO).** Nur die Tabellen und Felder lesen, die für die Aufgabe nötig sind. Keine Kundennamen, E-Mail-Adressen oder Lizenzschlüssel in Antworten oder Dateien, wenn nicht zwingend nötig. Bei größeren Datenmengen mit Personenbezug zuerst Anonymisierung vorschlagen.
- **Nur Testdatenbank für Änderungen**, bis der Nutzer ausdrücklich eine andere benennt.

## Rechte

| Aktion | Regel |
|---|---|
| Lesen (Teams, Datenbanken, Schema, Datensätze, Ansichten, Dateien, `query`) | frei, ohne Rückfrage |
| Schreiben (Datensatz anlegen/ändern/löschen, Datei hochladen/löschen, `exec`, Freigabelinks) | nur nach ausdrücklicher Freigabe **pro Schritt** |

Vor jedem Schreiben:
1. Vorhaben nennen: Datenbank, Tabelle, Anzahl Datensätze, Art der Änderung.
2. Bei Ändern/Löschen vorher die betroffenen Datensätze lesen und als Sicherung lokal ablegen.
3. Freigabe als Klick-Buttons erfragen (`AskUserQuestion`, Empfehlung zuerst). Erst danach `NINOX3_WRITE=1` setzen und ausführen.
4. Ergebnis lesen und bestätigen, dass genau das passiert ist.

Löschen von mehreren Datensätzen (`DELETE .../records`) und `exec` mit unbekanntem Skript immer erst als Probelauf beschreiben, nie als Erstes ausführen.

## Schlüssel-Ablage (beim ersten Einsatz immer abfragen)

Ist noch kein Schlüssel eingerichtet (`Test-Ninox3Key` meldet "Kein nutzbarer Schluessel"), fragt Claude **zuerst** per `AskUserQuestion`, wo der API-Key abgelegt werden soll. Nie nach dem Schlüssel selbst fragen.

| Antwort | Was passiert |
|---|---|
| **Terminal (Empfohlen)** | Der Nutzer führt im eigenen Terminal `Set-Ninox3Key` aus, Eingabe verdeckt, Ablage DPAPI-verschlüsselt im Windows-Profil. |
| **.env-Datei** | Claude führt `Set-Ninox3EnvFile` aus. Das legt nur eine Vorlage mit `NINOX3_API_KEY=<API_KEY>` im Benutzerprofil an (außerhalb von OneDrive und Git, nur für den Nutzer lesbar). Den Schlüssel trägt der Nutzer **selbst** im Editor ein. |

Danach `Test-Ninox3Key` ausführen. Das meldet nur, ob ein Schlüssel gesetzt ist und ob die API ihn akzeptiert, und zeigt ihn nie an.

Regeln:
- Claude schreibt nie einen echten Schlüssel in eine Datei und liest die `.env` nie. Auch nicht, wenn der Nutzer darum bittet.
- Die `.env` ist Klartext und weicht von der Vorgabe "Secrets nur in Bitwarden oder System-Keychain" ab. Darauf einmal hinweisen, Terminal empfehlen, bei Unsicherheit IT fragen (it@ninox.com). Wählt der Nutzer sie trotzdem, ist das seine Entscheidung.
- Wechsel der Ablage jederzeit mit `Set-Ninox3Key` (Terminal) oder `Set-Ninox3EnvFile` (.env).

## Führung des Nutzers (immer)

Wer den Skill nutzt, wird sicher, einfach und Schritt für Schritt geführt. Details und Empfehlungskatalog in `references/fuehrung.md`. Kurzfassung:

- **Claude führt, der Nutzer folgt (verbindlich, vom Auftraggeber verlangt).** Claude fragt **eins nach dem anderen**, was es braucht: pro Nachricht genau **eine** Frage oder **eine** Handlung des Nutzers, nie eine Liste mit mehreren Aufgaben. Der Nutzer muss nie überlegen, was als Nächstes kommt.
- Feste Reihenfolge, jeder Schritt erst nach Abschluss des vorigen: (1) Schlüssel-Ablage wählen, (2) Schlüssel setzen, (3) Schlüssel prüfen, (4) Adresse (Cloud oder eigene), (5) Team, (6) Datenbank, (7) Aufgabe. Schon erledigte Schritte überspringen.
- Nach jeder Handlung des Nutzers kurz bestätigen, was jetzt gilt, und **sofort den nächsten Schritt** nennen. Bleibt eine Antwort aus, die Frage ruhig und einfacher wiederholen, nicht weitere Fragen stapeln.

- **Ein Schritt, eine Frage**, als Klick-Buttons mit Empfehlung zuerst. Einfache Wörter, Fachbegriffe höchstens in Klammern.
- **Vorher sagen, was passiert**, ob es etwas verändert, und **nachher belegen**, was passiert ist.
- **Sicher als Standard:** Lesen vor Schreiben, Testdatenbank, ein Datensatz vor vielen, Sicherung vor Ändern. Claude hält das ein, der Nutzer muss es nicht kennen.
- **IDs nicht erfragen, sondern vorschlagen** (Teams und Datenbanken aus der Liste als Buttons).
- **Nach jedem Ergebnis eine Empfehlung** mit kurzer Begründung und den nächsten Schritt als Buttons. Nie mit "Sonst noch etwas?" enden.
- Ist das Ziel unklar, mit der Einstiegsfrage aus `references/fuehrung.md` beginnen ("Was möchtest du mit Ninox 3 tun?").

## Ablauf

0. **Schlüssel-Ablage** klären (siehe oben), falls noch nicht eingerichtet.
1. **Verbindung klären:** Public Cloud oder Private Cloud (Hostname)? Team-ID, Datenbank-ID. Fehlen sie, mit `Get-Ninox3Teams` und `Get-Ninox3Databases` auflisten, nicht raten.
2. **Struktur lesen:** `Get-Ninox3Schema` für Datenbank, `Get-Ninox3Table` für Feld-IDs. Filter und Schreibzugriffe brauchen die Feld-IDs (z. B. `L`), nicht die Namen.
3. **Aufgabe ausführen** nach `references/api-endpoints.md` (REST) oder `references/ninox-script.md` (Script).
4. **Ergebnis prüfen** und dem Nutzer belegen (Anzahl, Beispielwerte, ohne unnötige Personendaten).

## Was nicht geht (offen sagen, nichts erfinden)

**Schema ändern per API ist in der Ninox-3-REST-API nicht dokumentiert.** Die Endpunkte für Schema sind nur lesend (`GET`). Tabellen, Felder, Ansichten, Trigger und Formeln werden in Ninox 3 in der Oberfläche angelegt. Siehe `references/schema-aenderungen.md`. Ob es einen anderen Weg gibt, ist **nicht geprüft**; Nutzer an Ninox Support und die Doku verweisen, nichts ausprobieren.

Weitere Grenzen:
- Die API arbeitet mit Personal Access Token, der "Lese- und Schreibzugriff auf alle Datenbanken" gibt (laut Swagger-Datei). Deshalb die Freigaberegel oben.
- Alles, was nicht in `references/` oder der Ninox-3-Forum-Doku belegt ist, als ungeprüft kennzeichnen.

## Ninox Script (Pflicht für Beispiele)

Beispiele zu Ninox-Themen kommen **immer in Ninox Script** (API-Aufrufe über `http()`), nicht als curl oder PowerShell als Hauptlösung. Dazu immer Doku-Links. Das PowerShell-Skript in `scripts/` ist nur das Werkzeug, mit dem Claude selbst auf die API zugreift. Details in `references/ninox-script.md`.

## Quellen (nur diese, mit Art angeben)

- Ninox 3 Dokumentation (Forum, Bereich Documentation): https://forum.ninox.com/category/docs
- API (Forum, 8 Themen, Deutsch auch https://forum.ninox.de/category/api): https://forum.ninox.com/category/api
- Scripting (31 Themen): https://forum.ninox.com/category/scripting
- Funktionen (183 Themen): https://forum.ninox.com/category/functions
- API-Sandbox mit Swagger zum Üben (nur Testdaten): https://forum.ninox.com/t/g9yp9yp/api-sandbox-powered-by-swagger
- Produktverhalten im Zweifel: Ninox Support. Die Links `docs.ninox.com/en/api/...` (Swagger-Datei) liefern 404 und werden nicht weitergegeben; docs.ninox.com ist die Ninox-4-Dokumentation und keine Quelle für diesen Skill.
- Die Forum-Doku ist eine Community-Plattform und hat Fehler (siehe `references/api-forum-doku.md`, Abschnitt "Abweichungen"). Im Zweifel gilt die tatsächliche Antwort der Instanz.

## Dateien

| Datei | Inhalt |
|---|---|
| `references/fuehrung.md` | Nutzerführung, Einstiegsfrage, Empfehlungskatalog |
| `references/api-endpoints.md` | alle 31 Operationen, Parameter, Beispiele |
| `references/ninox-script.md` | Script-Beispiele für Ninox 3 mit `http()` |
| `references/api-forum-doku.md` | Token, Basis-Adressen, Änderungsabfragen, Parameter, Feldtypen, CORS, Doku-Fehler |
| `references/ninox-script/` | Scripting-Themen und Funktionsindex (183 Funktionen) aus der Forum-Doku |
| `references/api-sandbox.md` | Forum-Beitrag zur Swagger-Sandbox, verwandte Seiten, Regeln |
| `references/swagger/` | lokale Swagger-Dateien (HTML und YAML, Deutsch und Englisch) |
| `references/schema-aenderungen.md` | was für Schema dokumentiert ist und was nicht |
| `references/sicherheit-und-freigaben.md` | Token-Handling, Freigabe, Sicherung, Vorfall |
| `scripts/ninox3-api.ps1` | Werkzeug: Key-Ablage, Lesefunktionen, Schreibfunktionen mit Sperre |
| `evals/evals.json` | Testfälle für den Skill |

## Sprache und Stil

Antwort in der Sprache des Nutzers. Direkt und präzise, keine Floskeln. Fragen an Norbert als Klick-Buttons, dazu am Ende ein eigener fetter Absatz "Frage an dich:".
