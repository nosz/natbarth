# Ninox API-Sandbox (Swagger) im Forum

Quelle: https://forum.ninox.com/t/g9yp9yp/api-sandbox-powered-by-swagger (gelesen am 2026-10-27). Art: Forum-Beitrag, ob er zum offiziellen Doku-Bereich des Forums gehört, ist nicht bestätigt. Deshalb als **inoffiziell** behandeln, bis das geklärt ist. Der Beitrag nennt keinen Autor und kein festes Datum, nur "zuletzt vor etwa sieben Monaten aktualisiert".

## Was der Beitrag sagt

- Die Sandbox ist eine HTML-Anwendung, mit der man API-Aufrufe simulieren und die Syntax für die Integration üben kann.
- Laut Beitrag werden eingegebene Daten nicht bei Ninox gespeichert, weil alles im Browser abläuft.
- Eine Anleitung zu Anmeldung, Basis-Adresse, Team und Datenbank steht in dem Beitrag **nicht**. Einschränkungen nennt er ebenfalls nicht. Beides dort nicht raten.
- Einen direkten Link auf die Sandbox-Anwendung selbst lieferte der gelesene Text nicht. Der Nutzer öffnet sie über den Beitrag.

## Verwandte Forum-Seiten (Pfade aus der Navigation des Beitrags, Inhalt nicht gelesen)

Basis: https://forum.ninox.com

| Thema | Pfad |
|---|---|
| Introduction to Ninox API | `/t/83yzlg7/introduction-to-ninox-api` |
| API endpoints for Public Cloud | `/t/35yzp89/api-endpoints-for-public-cloud` |
| API endpoints for Private Cloud/On-Premises | `/t/x2yzfmf/api-endpoints-for-private-cloudon-premises` |
| Tables, fields, and records | `/t/x2yzljq/tables-fields-and-records` |

Die Basis-Domain ist aus dem Beitrag nicht erkennbar; die Pfade sind mit `forum.ninox.com` kombiniert und nicht einzeln aufgerufen.

## Lokale Variante

Die Swagger-Dateien im Projekt (`references/swagger/`, HTML und YAML) entsprechen dem Zweck einer Sandbox und laufen lokal. Sie sind die Grundlage für `api-endpoints.md`.

## Regeln für die Nutzung

- In einer Sandbox, auch wenn sie im Browser läuft, **kein echtes Token und keine Produktivdaten mit Personenbezug** eingeben. Nur ein Test-Token einer Testdatenbank.
- Claude gibt keine Tokens in Formularen oder Webseiten ein. Der Nutzer macht das selbst.
- Üben und Syntax prüfen ist der richtige Einsatz: Aufruf in der Sandbox bauen, dann als Ninox Script mit `http()` oder mit `scripts/ninox3-api.ps1` ausführen.
- Verbindliches Produktverhalten: Ninox Support. Die übrigen API-Seiten des Forums sind in `api-forum-doku.md` ausgewertet.
- Deutsche Fassung: https://forum.ninox.com/t/60yp9yg/api-testumgebung-ermoglicht-durch-swagger
