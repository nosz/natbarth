﻿Stand: 2026-10-27, gelesen aus dem Forum, nicht in Ninox getestet

Quelle: https://forum.ninox.com/category/functions (Seiten 1 bis 4 von 8, Ninox 3)

| Funktion | Kurzbeschreibung | Link |
|---|---|---|
| abs | Gibt den Betrag (positiven Wert) einer Zahl zurück. | https://forum.ninox.com/t/p8yzghq/abs |
| acos | Berechnet den Arkuskosinus einer Zahl. | https://forum.ninox.com/t/m1yzgh3/acos |
| age | Ermittelt die vollen Jahre zwischen heute und einem Datum. | https://forum.ninox.com/t/x2yzghx/age |
| alert | Öffnet ein Popup mit Hinweistext und OK-Schaltfläche. | https://forum.ninox.com/t/y4yzgh6/alert |
| appendTempFile | Hängt Inhalt an eine temporäre Datei auf dem Ninox-Server an. | https://forum.ninox.com/t/q6yzght/appendtempfile |
| appointment | Erzeugt aus zwei Zeitwerten einen Termin mit Beginn und Ende. | https://forum.ninox.com/t/m1yzj6j/appointment |
| array | Führt zwei Arrays gleichen Typs zu einem neuen Array zusammen. | https://forum.ninox.com/t/g9yz2xw/array |
| Array | Übersichtsseite zu den Array-Funktionen mit Verweisen auf die einzelnen Funktionen. | https://forum.ninox.com/t/p8yznq3/array |
| asin | Berechnet den Arkussinus einer Zahl. | https://forum.ninox.com/t/m1yz28c/asin |
| atan | Berechnet den Arkustangens einer Zahl. | https://forum.ninox.com/t/y4yz28v/atan |
| atan2 | Gibt den Arkustangens eines Quotienten aus zwei Werten zurück. | https://forum.ninox.com/t/q6yz26h/atan2 |
| avg | Berechnet den Mittelwert numerischer Werte aus Array oder Tabelle. | https://forum.ninox.com/t/35yzg6q/avg |
| barcodeScan | Öffnet den Barcodescanner und liefert den Wert als Text (nur mobile Geräte). | https://forum.ninox.com/t/35yzg6z/barcodescan |
| cached | Führt ein Skript einmal aus, speichert das Ergebnis und liefert es zurück. | https://forum.ninox.com/t/h7yzg6f/cached |
| capitalize | Schreibt den ersten Buchstaben jedes Wortes eines Textes groß. | https://forum.ninox.com/t/p8yzg6k/capitalize |
| ceil | Rundet eine Zahl auf die nächsthöhere ganze Zahl auf. | https://forum.ninox.com/t/60yzg6p/ceil |
| chosen | Liefert die gewählten Optionen eines Multiple-Choice-Feldes als Array. | https://forum.ninox.com/t/x2yz266/chosen |
| clientLang | Gibt die im Browser bzw. in der App eingestellte Sprache als Kürzel zurück. | https://forum.ninox.com/t/y4yz26t/clientlang |
| closeAllRecords | Schließt alle geöffneten Datensatzformulare. | https://forum.ninox.com/t/q6yz26l/closeallrecords |
| closeFullscreen | Schließt den Vollbildmodus der aktuellen Formularansicht. | https://forum.ninox.com/t/h7yz264/closefullscreen |
| closeRecord | Schließt das oberste Datensatzformular. | https://forum.ninox.com/t/83yz26s/closerecord |
| color | Liefert oder konvertiert Farbwerte, auch die Farbe einer Auswahloption. | https://forum.ninox.com/t/g9yz26v/color |
| concat | Verbindet Werte aus Arrays, Tabellen oder Multiple-Choice-Feldern zu einem Text mit Trennzeichen. | https://forum.ninox.com/t/35yz2m3/concat |
| contains | Prüft, ob ein Text oder Array einen exakten Treffer enthält. | https://forum.ninox.com/t/60yz2mt/contains |
| cos | Berechnet den Kosinus eines Winkels im Bogenmaß. | https://forum.ninox.com/t/q6yz2m1/cos |
| count (aka cnt) | Zählt nicht leere Einträge in Arrays oder Tabellen (ohne null und leere Strings). | https://forum.ninox.com/t/y4yz2f2/count-aka-cnt |
| createCalendarEvent | Legt einen Termin in Apple Kalender an (nur Mac, iPad, iPhone). | https://forum.ninox.com/t/y4yz2fc/createcalendarevent |
| createCalendarReminder | Legt eine Erinnerung in Apple Erinnerungen an (nur Mac, iPad, iPhone). | https://forum.ninox.com/t/x2yz2k3/createcalendarreminder |
| createTempFile | Erzeugt eine temporäre Datei auf dem Ninox-Server und liefert einen Link darauf. | https://forum.ninox.com/t/83yz2k1/createtempfile |
| createTextFile | Erstellt eine Textdatei (.txt) mit Name und Inhalt, standardmäßig am Datensatz angehängt. | https://forum.ninox.com/t/p8yz2kr/createtextfile |
| createXLSX | Erstellt formatierte Excel-Dateien mit mehreren Tabellenblättern aus Datenbankdaten. | https://forum.ninox.com/t/83yz2kw/createxlsx |
| createZipFile | Erstellt ein ZIP-Archiv aus einem Array von Dateien (laut Forum mit aktuellen Einschränkungen). | https://forum.ninox.com/t/83yz210/createzipfile |
| databaseId | Liefert die ID der aktuellen Datenbank als Text. | https://forum.ninox.com/t/m1yz2ph/databaseid |
| date | Extrahiert ein Datum aus einem Zeitstempel oder bildet es aus Jahr, Monat und Tag. | https://forum.ninox.com/t/60yzr13/date |
| datetime | Erzeugt einen lokalen Zeitstempel aus Datum und Uhrzeit oder aus Zahlenwerten. | https://forum.ninox.com/t/q6yzr1z/datetime |
| day | Gibt den Tag des Monats als Zahl aus Datum, Termin oder Zeitstempel zurück. | https://forum.ninox.com/t/p8yz28s/day |
| days | Berechnet die Tage zwischen zwei Datumswerten, alle Wochentage zählen. | https://forum.ninox.com/t/m1yzr2h/days |
| degrees | Rechnet einen Winkel von Bogenmaß in Grad um. | https://forum.ninox.com/t/83yzr23/degrees |
| dialog | Zeigt ein Popup mit Antwortoptionen, z. B. Ja oder Nein. | https://forum.ninox.com/t/h7yzr2m/dialog |
| duplicate | Erstellt eine exakte Kopie eines Datensatzes inklusive verknüpfter Untertabellendaten. | https://forum.ninox.com/t/35yzr2p/duplicate |
| duration | Berechnet die Dauer eines Termins zwischen Start und Ende in Stunden und Minuten. | https://forum.ninox.com/t/g9yzr2r/duration |
| email | Wandelt einen Wert in ein E-Mail-Feld mit mailto-Button um. | https://forum.ninox.com/t/h7yzr2s/email |
| endof | Gibt den Endzeitstempel eines Termins zurück. | https://forum.ninox.com/t/y4yzr2v/endof |
| even | Prüft, ob eine Zahl gerade ist (true/false). | https://forum.ninox.com/t/h7yzrby/even |
| exp | Berechnet die Exponentialfunktion zur Basis e. | https://forum.ninox.com/t/g9yzrbx/exp |
| extractx | Extrahiert den ersten Treffer eines regulären Ausdrucks aus einem Text. | https://forum.ninox.com/t/60yzrb8/extractx |
| fieldId | Gibt die interne ID eines Feldes zurück. | https://forum.ninox.com/t/83yl3kt/fieldid |
| file | Ruft einen bestimmten Dateianhang eines Datensatzes anhand des Dateinamens ab. | https://forum.ninox.com/t/q6yzrbz/file |
| fileMetadata | Liefert Metadaten einer Datei eines Datensatzes, z. B. Name, Größe, Änderungsdatum. | https://forum.ninox.com/t/p8yzrbf/filemetadata |
| files | Gibt alle Anhänge eines Datensatzes als Array zurück. | https://forum.ninox.com/t/y4yzrb5/files |
| fileUrl | Gibt die URL einer bestimmten Datei eines Datensatzes zurück. | https://forum.ninox.com/t/h7yfplz/fileurl |
| first | Gibt das erste Element eines Arrays zurück. | https://forum.ninox.com/t/60yzrbw/first |
| floor | Rundet eine Zahl auf die nächstniedrigere ganze Zahl ab. | https://forum.ninox.com/t/35yzrba/floor |
| format | Formatiert Zahlen, Datums- und Zeitwerte für Text- oder Formelfelder. | https://forum.ninox.com/t/p8yzv31/format |
| formatJSON | Wandelt ein JSON-Objekt in einen JSON-Text um. | https://forum.ninox.com/t/p8yzrb4/formatjson |
| formatXML | Wandelt Daten in XML-Text um. | https://forum.ninox.com/t/x2yzrdh/formatxml |
| get | Liefert den Wert eines Feldes per Name oder ID. | https://forum.ninox.com/t/60ylyvs/get |
| html | Stellt Werte mit HTML-Tags als Rich Text dar. | https://forum.ninox.com/t/60yzrdt/html |
| http | Sendet HTTP-Anfragen an REST-APIs (Zugriff auf andere Ninox-Datenbanken mit zusätzlichen Voraussetzungen). | https://forum.ninox.com/t/q6yzrdp/http |
| icon | Gibt einen Icon-Wert zurück, auch für eine gewählte Option eines Auswahlfelds. | https://forum.ninox.com/t/60yzrd5/icon |
| importFile | Importiert eine Datei von einer URL als Anhang oder in ein Bildfeld. | https://forum.ninox.com/t/q6yzbgc/importfile |
| index | Ermittelt die Startposition des ersten Treffers in Text oder Array. | https://forum.ninox.com/t/p8yzbg9/index |
| invalidate | Leert den Datenbank-Cache und die Werte aus cached(). | https://forum.ninox.com/t/60yzbgv/invalidate |
| isAdminMode | Prüft, ob der Bearbeitungsmodus aktiv ist. | https://forum.ninox.com/t/m1yzbjq/isadminmode |
| isDatabaseLocked | Prüft, ob die Datenbank gesperrt ist (Bearbeitungsmodus erfordert ein noch nicht eingegebenes Passwort). | https://forum.ninox.com/t/x2yzbjh/isdatabaselocked |
| isDatabaseProtected | Prüft, ob zum Aktivieren des Bearbeitungsmodus ein Passwort nötig ist. | https://forum.ninox.com/t/83yzbjy/isdatabaseprotected |
| item | Extrahiert einen Wert aus Array oder JSON-Objekt über Index oder Schlüssel. | https://forum.ninox.com/t/35yzbjx/item |
| join | Verbindet die Elemente eines Textarrays mit einem Trennzeichen zu einem Text. | https://forum.ninox.com/t/h7yzbj6/join |
| last | Gibt das letzte Element eines Arrays zurück. | https://forum.ninox.com/t/p8yzbjm/last |
| latitude | Liefert den Breitengrad eines Standortwerts. | https://forum.ninox.com/t/x2yzbjl/latitude |
| length | Zählt die Zeichen eines Textes oder die Elemente eines Arrays. | https://forum.ninox.com/t/83yzbjf/length |
| ln | Berechnet den natürlichen Logarithmus. | https://forum.ninox.com/t/y4yzbjk/ln |
| loadFileAsBase64 | Wandelt eine Datei in einen Base64-Text um. | https://forum.ninox.com/t/35yzbj1/loadfileasbase64 |
| loadFileAsBase64URL | Wandelt eine Datei in einen URL-tauglichen Base64-Text um. | https://forum.ninox.com/t/q6yzbjp/loadfileasbase64url |
| location | Erzeugt einen Standortwert aus Breitengrad, Längengrad und Titel. | https://forum.ninox.com/t/h7yzbjg/location |
| log | Berechnet den Logarithmus zu einer Basis (ohne Angabe 10). | https://forum.ninox.com/t/p8yzbjj/log |
| longitude | Gibt den Längengrad eines Standortfeldes als Dezimalzahl zurück. | https://forum.ninox.com/t/g9yzbj5/longitude |
| lower | Wandelt Großbuchstaben eines Textes in Kleinbuchstaben um. | https://forum.ninox.com/t/60yzbjr/lower |
| lpad | Füllt einen Text links mit Zeichen auf eine gewünschte Länge auf. | https://forum.ninox.com/t/x2yzbj2/lpad |
| max | Ermittelt den höchsten bzw. neuesten Wert eines Arrays (Zahlen oder Zeitwerte). | https://forum.ninox.com/t/y4yzbjd/max |
| min | Ermittelt den niedrigsten bzw. frühesten Wert eines Arrays (Zahlen oder Zeitwerte). | https://forum.ninox.com/t/83yzdkg/min |
| month | Gibt den Monat eines Datums als Zahl 1 bis 12 zurück. | https://forum.ninox.com/t/y4yzdkj/month |
| monthIndex | Wandelt einen Monatsnamen in die Monatsnummer um. | https://forum.ninox.com/t/35yzdk5/monthindex |
| monthName | Gibt den vollständigen Monatsnamen eines Datums zurück. | https://forum.ninox.com/t/q6yzdkr/monthname |
| ninoxApp | Ermittelt die Umgebung, in der Ninox gerade läuft. | https://forum.ninox.com/t/g9yzdkd/ninoxapp |
| now | Gibt den genauen Zeitstempel des Ausführungszeitpunkts zurück. | https://forum.ninox.com/t/x2yzdkn/now |
| number | Wandelt Werte verschiedener Datentypen in eine Zahl um. | https://forum.ninox.com/t/83yzdk7/number |
| numbers | Gibt die IDs der gewählten Optionen eines Multiple-Choice-Feldes zurück. | https://forum.ninox.com/t/q6yz3dl/numbers |
| odd | Prüft, ob eine Zahl ungerade ist (true/false). | https://forum.ninox.com/t/60yz3wt/odd |
| openFullscreen | Öffnet einen Datensatz im Vollbildmodus. | https://forum.ninox.com/t/x2yz3w2/openfullscreen |
| openPage | Schließt die aktuelle Seite und öffnet eine angegebene Seite, optional mit Tab. | https://forum.ninox.com/t/h7yzxtg/openpage |
| openPrintLayout | Öffnet einen Datensatz mit bestimmtem Layout im Druck-Layout-Editor. | https://forum.ninox.com/t/y4yzxtd/openprintlayout |
| openRecord | Wechselt zur zugehörigen Tabelle und öffnet einen bestimmten Datensatz. | https://forum.ninox.com/t/g9yzxt0/openrecord |
| openTable | Schließt die aktuelle Tabelle und öffnet eine angegebene Tabelle, optional mit View. | https://forum.ninox.com/t/35yzxw6/opentable |
| openURL | Öffnet einen Text als Link im Standardbrowser. | https://forum.ninox.com/t/h7yzd18/openurl |
| parseCSV | Wandelt CSV-Text in eine strukturierte Liste (Array) um. | https://forum.ninox.com/t/x2yl31c/parsecsv |
| parseJSON | Wandelt einen gültigen JSON-Text in ein JSON-Objekt um. | https://forum.ninox.com/t/p8yzd16/parsejson |
| parseXML | Wandelt einen XML-Text in ein JSON-Objekt um, z. B. für API-Verbindungen. | https://forum.ninox.com/t/g9yzd1m/parsexml |
| phone | Stellt einen Wert als Telefonfeld mit Anruf-Button dar. | https://forum.ninox.com/t/x2yzd1l/phone |
| popupRecord | Öffnet einen Datensatz als Popup-Formular, optional mit Tab. | https://forum.ninox.com/t/y4yzd1f/popuprecord |

Gesamtzahl erfasster Funktionen: 100
