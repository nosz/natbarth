Stand: 2026-10-27, gelesen aus dem Forum, nicht in Ninox getestet

Quelle: https://forum.ninox.com/category/functions (Ninox 3, Seiten 5 bis 8 von 8; Funktionen pow bis yearweek)

| Funktion | Kurzbeschreibung | Link |
|---|---|---|
| pow | Berechnet die Potenz einer Zahl; Exponent 0,5 ergibt die Wurzel. | https://forum.ninox.com/t/p8yzdph/pow |
| printAndSaveRecord | Erzeugt aus einem Datensatz oder einer Carbone-Vorlage ein PDF, speichert es im internen Dateisystem und liefert einen Download-Link. | https://forum.ninox.com/t/g9yzdpy/printandsaverecord |
| printRecord | Druckt einen Datensatz im gewählten Layout als PDF und öffnet es im Standardprogramm. | https://forum.ninox.com/t/x2yzdp8/printrecord |
| printTable | Druckt die sichtbaren Spalten einer Ansicht als PDF oder HTML. | https://forum.ninox.com/t/x2yzd5t/printtable |
| quarter | Forum-Vorschau fehlerhaft (zeigt den Text von pow); Beschreibung nicht verifiziert, Detailseite prüfen. | https://forum.ninox.com/t/y4yzd5l/quarter |
| queryConnection | Sendet einen SQL-Befehl an eine verbundene SQL-Datenbank und gibt Datensätze zurück. | https://forum.ninox.com/t/p8yzd51/queryconnection |
| radians | Rechnet Winkel von Grad in Radiant um. | https://forum.ninox.com/t/x2yzd55/radians |
| random | Gibt eine Zufallszahl von 0 (inklusive) bis 1 (exklusive) zurück. | https://forum.ninox.com/t/q6yzd5d/random |
| range | Erzeugt ein Array aufeinanderfolgender Zahlen über eine Von-bis-Angabe. | https://forum.ninox.com/t/g9yzd5n/range |
| raw | Gibt die interne Textdarstellung eines Werts zurück. | https://forum.ninox.com/t/m1yzd5s/raw |
| record | Ruft einen Datensatz anhand von Tabellenname und ID ab. | https://forum.ninox.com/t/y4yzd5c/record |
| removeFile | Entfernt eine Datei aus einem Feld oder Datensatz. | https://forum.ninox.com/t/m1yl3gz/removefile |
| removeItem | Entfernt ein Schlüssel-Wert-Paar aus einem JSON-Objekt. | https://forum.ninox.com/t/35yzd54/removeitem |
| renameFile | Benennt eine Datei in einem Feld oder Datensatz um. | https://forum.ninox.com/t/p8yl3py/renamefile |
| replace | Sucht Text und ersetzt ihn, wie in einer Textverarbeitung. | https://forum.ninox.com/t/q6yzd59/replace |
| replacex | Ersetzt Treffer eines regulären Ausdrucks; erweitert replace(). | https://forum.ninox.com/t/35yzw8a/replacex |
| round | Rundet eine Zahl kaufmännisch auf die gewünschte Nachkommastelle. | https://forum.ninox.com/t/p8yzw89/round |
| rpad | Füllt Text rechts mit Zeichen bis zu einer Ziellänge auf. | https://forum.ninox.com/t/60yzw6q/rpad |
| rsort | Sortiert Werte absteigend; alle Werte müssen denselben Datentyp haben. | https://forum.ninox.com/t/y4yzw63/rsort |
| sendCommand | Sendet einen SQL-Befehl über eine angegebene Verbindung an eine SQL-Datenbank. | https://forum.ninox.com/t/g9yzw6t/sendcommand |
| sendEmail | Versendet E-Mails direkt aus Ninox, mit Angaben direkt oder aus Feldern. | https://forum.ninox.com/t/y4yzw6k/sendemail |
| set | Aktualisiert den Wert eines Feldes, angegeben über Name oder ID. | https://forum.ninox.com/t/q6yly90/set |
| setItem | Aktualisiert oder ergänzt ein Schlüssel-Wert-Paar in einem JSON-Objekt. | https://forum.ninox.com/t/h7yzw6g/setitem |
| shareFile | Erzeugt einen Freigabelink für eine Datei (Gültigkeit eingeschränkt; Forum-Vorschau abgeschnitten). | https://forum.ninox.com/t/g9yzw65/sharefile |
| shareView | Erzeugt eine URL für eine Ansicht; ohne Angabe die Standardansicht. | https://forum.ninox.com/t/p8yzw6s/shareview |
| sign | Gibt das Vorzeichen einer Zahl zurück: 1 (positiv) oder -1 (negativ). | https://forum.ninox.com/t/x2yzw64/sign |
| sin | Berechnet den Sinus; Ergebnis liegt zwischen -1 und 1. | https://forum.ninox.com/t/35yzw6v/sin |
| sleep | Hält die Skriptausführung für eine Zeit in Millisekunden an. | https://forum.ninox.com/t/q6yzwmq/sleep |
| slice | Extrahiert einen Teilbereich aus Text oder Array über Start- und Endposition. | https://forum.ninox.com/t/p8yzwmy/slice |
| sort | Sortiert Werte aufsteigend; beliebig viele Parameter, gleicher Datentyp nötig. | https://forum.ninox.com/t/m1yzwm8/sort |
| split | Teilt einen Text an jedem Trennzeichen in ein Array. | https://forum.ninox.com/t/83yzwmm/split |
| splitx | Teilt einen Text anhand eines regulären Ausdrucks in ein Array. | https://forum.ninox.com/t/q6yzwmz/splitx |
| sqr | Quadriert eine Zahl; Ergebnis immer positiv. | https://forum.ninox.com/t/h7yzwml/sqr |
| sqrt | Berechnet die Quadratwurzel positiver Zahlen; bei negativen Werten abs() verwenden. | https://forum.ninox.com/t/g9yzwmk/sqrt |
| start | Gibt Startzeitpunkt (Datum und Uhrzeit) eines Termins zurück. | https://forum.ninox.com/t/g9yzwts/start |
| string | Wandelt einen Wert oder ein Array in Text um, ähnlich concat(). | https://forum.ninox.com/t/60yzwt0/string |
| styled | Wandelt Text in ein Styled-Objekt, z. B. für Farben und Icons in Formelfeldern. | https://forum.ninox.com/t/q6yznq2/styled |
| substr | Gibt einen Teiltext ab Startposition mit angegebener Länge zurück. | https://forum.ninox.com/t/p8yznqd/substr |
| substring | Gibt einen Teiltext zwischen Start- und Endposition zurück. | https://forum.ninox.com/t/60yznqn/substring |
| sum | Summiert die Zahlen eines Arrays oder einer Tabelle. | https://forum.ninox.com/t/m1yznq7/sum |
| tableId | Gibt die interne ID der aktuellen Tabelle zurück (beginnt mit A). | https://forum.ninox.com/t/83yznq0/tableid |
| tan | Berechnet den Tangens eines Winkels. | https://forum.ninox.com/t/y4yznqa/tan |
| teamId | Gibt die ID des aktuellen Workspaces zurück, z. B. für die REST-API. | https://forum.ninox.com/t/g9yznq9/teamid |
| testx | Prüft, ob ein Text einem regulären Ausdruck entspricht; Gegenstück zu contains(). | https://forum.ninox.com/t/60yznqv/testx |
| text | Wandelt nahezu jeden Datentyp in Text um, optional mit Formatoptionen. | https://forum.ninox.com/t/m1yznhq/text |
| Text | Übersichtsseite zu textbezogenen Funktionen (u. a. capitalize, chosen, concat). | https://forum.ninox.com/t/g9yznq1/text |
| time | Gibt die aktuelle Uhrzeit zurück oder setzt eine Uhrzeit. | https://forum.ninox.com/t/83yznhy/time |
| timeinterval | Wandelt einen zeitbezogenen Wert in ein Zeitintervall (Dauer) um. | https://forum.ninox.com/t/35yznhx/timeinterval |
| timestamp | Wandelt einen zeitbezogenen Wert in einen UTC-basierten Zeitstempel um. | https://forum.ninox.com/t/g9yznhm/timestamp |
| today | Gibt das aktuelle Datum ohne Uhrzeit zurück. | https://forum.ninox.com/t/m1yznhz/today |
| trim | Entfernt führende und nachgestellte Leerzeichen, z. B. nach Copy und Paste. | https://forum.ninox.com/t/y4yznhk/trim |
| unique | Liefert ein Array mit eindeutigen Werten; entfernt Duplikate aus einem oder mehreren Arrays. | https://forum.ninox.com/t/q6yznhp/unique |
| unshareAllViews | Beendet die Freigabe aller Ansichten einer Tabelle; nicht in Formelfeldern nutzbar. | https://forum.ninox.com/t/h7yznhg/unshareallviews |
| unshareFile | Beendet die Freigabe einer Datei. | https://forum.ninox.com/t/p8yz7xd/unsharefile |
| unshareView | Beendet die Freigabe einer bestimmten Ansicht; nicht in Formelfeldern nutzbar. | https://forum.ninox.com/t/g9yz7xw/unshareview |
| upper | Wandelt Kleinbuchstaben in Großbuchstaben um, andere Zeichen bleiben. | https://forum.ninox.com/t/60yz7xn/upper |
| url | Stellt ein Formelfeld als URL-Feld mit Schaltfläche dar, die den Link im Browser öffnet. | https://forum.ninox.com/t/m1yz7x7/url |
| urlDecode | Wandelt eine URL-kodierte Zeichenkette (ASCII) in Klartext zurück. | https://forum.ninox.com/t/83yz7x0/urldecode |
| urlEncode | Wandelt Text (ASCII) in eine URL-konforme Zeichenkette um. | https://forum.ninox.com/t/q6yz7xc/urlencode |
| urlOf | Liefert einen Link zu einem bestimmten Datensatz oder einer Ansicht. | https://forum.ninox.com/t/h7yz7x4/urlof |
| user | Gibt Name oder E-Mail des aktuellen oder eines bestimmten Benutzers zurück. | https://forum.ninox.com/t/p8yz7x9/user |
| userEmail | Gibt die E-Mail-Adresse eines Benutzers zurück (Adresse der Workspace-Einladung). | https://forum.ninox.com/t/60yz78q/useremail |
| userFirstName | Gibt den Vornamen aus dem Benutzerprofil zurück. | https://forum.ninox.com/t/m1yz78h/userfirstname |
| userFullName | Gibt den vollständigen Namen eines Benutzers zurück, standardmäßig des aktuellen. | https://forum.ninox.com/t/x2yz78b/userfullname |
| userHasRole | Prüft, ob der aktuelle oder ein bestimmter Benutzer eine Rolle hat (wahr/falsch). | https://forum.ninox.com/t/y4yzs6c/userhasrole |
| userId | Gibt die interne alphanumerische ID des aktuellen oder eines bestimmten Benutzers zurück. | https://forum.ninox.com/t/h7yzs69/userid |
| userIsAdmin | Prüft, ob der aktuelle Benutzer die Admin-Rolle hat. | https://forum.ninox.com/t/p8yzs6v/userisadmin |
| userLastName | Gibt den Nachnamen aus dem Benutzerprofil zurück. | https://forum.ninox.com/t/g9yzsmq/userlastname |
| userName | Gibt den im Profil hinterlegten Anzeigenamen zurück. | https://forum.ninox.com/t/60yzsmh/username |
| userRole | Gibt die Rolle des aktuellen oder eines bestimmten Benutzers zurück. | https://forum.ninox.com/t/x2yzsm3/userrole |
| userRoles | Gibt alle Rollen eines Benutzers im Workspace als Array zurück. | https://forum.ninox.com/t/35yzsm6/userroles |
| users | Gibt die IDs aller Mitarbeiter des Workspaces als Array zurück. | https://forum.ninox.com/t/y4yzsmp/users |
| validateXML | Prüft, ob ein XML-String den Regeln eines XSD-Schemas entspricht. | https://forum.ninox.com/t/35yl317/validatexml |
| waitForSync | Prüft, ob die Datenbank mit der Ninox Cloud synchronisiert ist, und versucht die Synchronisation. | https://forum.ninox.com/t/35yzsmg/waitforsync |
| week | Gibt die Kalenderwoche eines Datums als Zahl (1 bis 53) zurück. | https://forum.ninox.com/t/g9yzspb/week |
| weekday | Gibt den Wochentag eines Datums als Zahl zurück (Montag = 0). | https://forum.ninox.com/t/m1yzspw/weekday |
| weekdayIndex | Wandelt einen Wochentagsnamen in eine Zahl um (Montag = 0). | https://forum.ninox.com/t/g9yzsp4/weekdayindex |
| weekdayName | Gibt den vollen Wochentagsnamen zu einer Zahl zurück (0 = Montag bis 6 = Sonntag). | https://forum.ninox.com/t/m1yzspv/weekdayname |
| workdays | Zählt die Arbeitstage zwischen zwei Datumswerten, Start und Ende eingeschlossen. | https://forum.ninox.com/t/60yzsg6/workdays |
| year | Liefert das Jahr eines Datums als Zahl. | https://forum.ninox.com/t/x2yzsgt/year |
| yearmonth | Gibt Jahr und Monat eines Datums im Format JJJJ/MM aus. | https://forum.ninox.com/t/x2yzsg5/yearmonth |
| yearquarter | Gibt Jahr und Quartal eines Datums aus. | https://forum.ninox.com/t/35yzsgb/yearquarter |
| yearweek | Gibt Jahr und Kalenderwoche eines Datums im Format JJJJ WW aus. | https://forum.ninox.com/t/60yzsjh/yearweek |

Gesamtzahl erfasster Funktionen: 83 (Seiten 5 bis 8)
