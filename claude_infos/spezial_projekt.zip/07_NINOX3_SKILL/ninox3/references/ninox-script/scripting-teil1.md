Stand: 2026-10-27, gelesen aus dem Forum, nicht in Ninox getestet

# Ninox 3: Ninox Script, Teil 1 (Grundlagen)

Quelle aller Abschnitte: Ninox-3-Doku im Forum (https://forum.ninox.com), Community-Beiträge, keine offizielle Handbuchseite. Verbindliches Verhalten bestätigt der Ninox Support.

---

## 1. Introduction to Ninox script
Link: https://forum.ninox.com/t/y4yzzws/introduction-to-ninox-script (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Einführung. Ninox Script dient dazu, einfache, wiederkehrende Abläufe und komplexe Arbeitsabfolgen zu automatisieren. Der Text unterscheidet nicht zwischen Funktionen und Prozeduren. Funktion = liefert anhand von Parametern ein Ergebnis; Prozedur = führt mehrere Einzelaktionen nacheinander aus.

| Syntax | Beschreibung |
|---|---|
| (keine) | Seite enthält keine Syntax und keine Codebeispiele |

**Hinweise:** Seite verlinkt weitere Scripting-Artikel. Die einzige Antwort unter dem Beitrag ist Werbung ohne Bezug (nicht übernommen).

---

## 2. The formula editor
Link: https://forum.ninox.com/t/p8yzzw4/the-formula-editor (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Funktionen/Prozeduren werden im Formel-Editor eingegeben, erkennbar an der Kennzeichnung "fx". Einstiegspunkte laut Bildunterschriften: Tabelleneigenschaften, Formularfeld im Bearbeitungsmodus, Feldtyp Text (und andere Feldtypen) mit Optionen zum Einfügen von Skripten. Der Editor ist zunächst leer.

| Syntax | Beschreibung |
|---|---|
| (keine) | Seite besteht im Wesentlichen aus Screenshots; keine Codebeispiele lesbar |

**Hinweise:** Ein Nutzerkommentar (nicht offiziell) meldet die Meldung, die Formel könne Daten nicht ändern; Lösung steht nicht auf der Seite. (Erste Abrufversuche lieferten HTTP 503, zweiter Abruf erfolgreich.)

---

## 3. Formula editor features
Link: https://forum.ninox.com/t/p8yzzn6/formula-editor-features (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Editor-Funktionen laut Artikel (Bezug: Version 3.6.0, etwa zwei Jahre alt).

| Funktion | Beschreibung | Bedienung |
|---|---|---|
| Zeilennummern | links im Editor | immer sichtbar |
| Einrückung | Codeblöcke automatisch eingerückt | keine Angabe |
| Code-Formatierung | einheitlicher Stil, Umbrüche/Leerzeichen | Editor mit OK verlassen, beim nächsten Öffnen formatiert |
| Auto-Vervollständigung | Vorschläge beim Tippen | ENTER übernimmt ersten Vorschlag, Pfeiltasten wählen weitere |
| Syntax-Highlighting | Einfärbung beim Tippen | automatisch |
| Breadcrumbs | aktuelle Code-Position über dem Editor | automatisch |
| Fehler-/Warnmarkierung | Fehlerzeilen rot, Meldung beim Hovern über Zeilennummer | automatisch |
| Suchen/Ersetzen | Text, Variablen, Ausdrücke | Suchleiste oder STRG+F / CMD+F; Match Whole Word, Match Case, Use Regular Expression |
| Klammerzuordnung | zugehörige Klammern hervorgehoben, schließende wird ergänzt | Pfeiltasten |

**Hinweise:**
- Laut Artikel waren die neuen Funktionen nur in der Web-App (app.ninox.com) und der Mac-App verfügbar; aktueller Stand ungeprüft.
- Bei Syntaxfehlern wird nur der erste Fehler markiert (Folgecode nicht parsebar). Referenzfehler werden einzeln markiert, außer es liegt ein Syntaxfehler davor.
- Keine Codebeispiele (nur Bilder).

---

## 4. Arithmetic operators
Link: https://forum.ninox.com/t/60yzfsl/arithmetic-operators (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Grundrechenarten; verknüpfen zwei numerische Werte und liefern eine Zahl.

| Operator | Funktion | Beispiel |
|---|---|---|
| `+` | Addition (auch Text verbinden) | `1 + 2 = 3` |
| `-` | Subtraktion | `3 - 2 = 1` |
| `*` | Multiplikation | `2 * 3 = 6` |
| `/` | Division | `6 / 3 = 2` |
| `%` | Modulo | `13 % 5 = 3` |
| `()` | Klammern ändern Auswertungsreihenfolge | Beispiel auf der Seite unvollständig |

**Hinweise:**
- Ninox entfernt überflüssige Klammern (Vorrangregel) und Leerzeichen und fügt Leerzeichen zur Lesbarkeit ein (Verweis auf Artikel "Automatic adjustments").
- Nichts auf der Seite zu Division durch null, Datentypen, Rundung.

---

## 5. Comparison operators
Link: https://forum.ninox.com/t/83yzfs1/comparison-operators (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Vergleicht zwei Werte; Ergebnis true/false (im Feld als Yes/No). Form: `Wert1 Operator Wert2`.

| Operator | Bedeutung | Beispiel (true) | Beispiel (false) |
|---|---|---|---|
| `=` | gleich | `1 + 1 = 3 - 1` | `Apples = Pears` |
| `!=` | ungleich | `Apples != Pears` | `1 + 1 != 3 - 1` |
| `<` | kleiner | `4 * 2 < 10` | `10 < 4 * 2` |
| `<=` | kleiner/gleich | `5 * 2 <= 10` | `10 <= 4 * 2` |
| `>` | größer | `10 > 4 * 2` | `4 * 2 > 10` |
| `>=` | größer/gleich | `5 * 2 >= 10` | `4 * 2 >= 10` |
| `like` | enthält | `"Hello" like "el"` | `"el" like "Hello"` |

(Die Zuordnung true/false ist aus den Symbolen der Seite abgeleitet.)

**Hinweise:** `like`: Text links muss Text rechts enthalten. Seite spricht von numerischen Werten, Beispiele nutzen auch Text. Nichts zu Groß-/Kleinschreibung.

---

## 6. Ninox operators
Link: https://forum.ninox.com/t/q6yzfsj/ninox-operators (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Auswahl der wichtigsten Operatoren (keine vollständige Referenz).

| Operator | Bedeutung |
|---|---|
| `:=` | Zuweisung an Feld oder Variable |
| `;` | beendet eine Zeile; bei `let` setzt Ninox es automatisch nachträglich |
| `""` | Text |
| `''` | Tabellen-/Feldnamen mit Leerzeichen oder Sonderzeichen |
| `.` | Zugriff auf Felder von Datensätzen oder Werte von JSON-Objekten |
| `---` | Alternative zu `""`, macht dynamische Texte übersichtlicher |

```
Text := "Hello world!"
let x := 1000;
x := 2
```

```
"Hello" + " " + "world!"   => Hello world!
```

```
'Total net' + " " + "(VAT not included)"
=> 425,00 € (VAT not included)
```

```
(select Customers).CustomerIDs
```

```
---Hello world!---   => Hello world!
```

---

## 7. Writing dynamic texts
Link: https://forum.ninox.com/t/60yzfsr/writing-dynamic-texts (Art: Ninox-3-Doku im Forum)

**Zusammenfassung:** Texte per Script personalisieren (z. B. Serienbrief). Zwei Wege: Plus-Operator oder Template-Strings.

| Syntax | Beschreibung |
|---|---|
| `a + b` | verbindet beliebige Datentypen; mindestens ein Teil muss String sein, damit das Ergebnis ein String ist |
| `---Text { Ausdruck }---` | Template-String: beginnt/endet mit drei Minuszeichen, Werte in `{...}` |

```
"Hello " + 'First Name' + "!"
```
Ergebnis: `Hello Sam!` (Feld "First Name" = Sam), Eingabe in ein Formula-Feld.

```
---Hello { 'First Name' }!---
```
Ergebnis: `Hello Sam!`

---

## 8. Declare variable
Link: https://forum.ninox.com/t/x2yzfsb/declare-variable (Art: Ninox-3-Doku im Forum)

| Syntax | Beschreibung |
|---|---|
| `let <Name>` | Variable anlegen |
| `:=` | Wert zuweisen |

```
let myText := "Hello " + 'First Name' + "!";
myText
```
Ergebnis: Hello Sam!

**Hinweise:** Variablenname darf kein Schlüsselwort sein (z. B. `let let` nicht erlaubt). `var` geht ebenfalls, gilt laut Artikel als veraltet; `let` wird empfohlen.

---

## 9. Set conditional statement
Link: https://forum.ninox.com/t/35yzfsn/set-conditional-statement (Art: Ninox-3-Doku im Forum)

| Syntax | Beschreibung |
|---|---|
| `if ... then ... else ... end` | Bedingung prüfen; `then`-Teil bei true, sonst `else` |

**Regeln:** Bedingung muss true/yes oder false/no ergeben (Vergleichsoperatoren geeignet). `else` ist optional. `null` prüft, ob ein Feld leer ist (nicht gleich 0).

```
if Total >= 30 then "Card" else "Cash" end
```

```
let paymentMethod := "Cash";
if Total >= 30 then
paymentMethod := "Card"
end;
paymentMethod
```

```
if Total = null then
"Please enter an amount!"
end
```

**Hinweis:** Der Artikeltext nennt bei Beispiel 2 "greater than 30", der Code verwendet aber `>=`.

---

## 10. Set multiple conditional statements
Link: https://forum.ninox.com/t/60yzfsa/set-multiple-conditional-statements (Art: Ninox-3-Doku im Forum)

| Syntax | Beschreibung |
|---|---|
| `if ... then ... else if ... end` | Verkettung beliebig oft |
| `switch ... do case ...: ... default: ... end` | ersetzt verschachtelte Bedingungen; `default:` greift, wenn kein Fall zutrifft |

**Tipp laut Seite:** `switch ... case` funktioniert am besten bei Auswahlfeldern (Choice).

```
if Total = null then
"Please enter an amount!"
else if Total >= 30 then
"Card" else "Cash" end
end
```

```
switch 'Payment method' do
case 1:
"Payment method: " + text('Payment method') + "."
case 2:
"Payment method: " + text('Payment method') + ". Only from €30."
case 3:
"Payment method: " + text('Payment method') + ". Do not forget your signature."
default:
"Please select a payment method."
end
```
(Auswahlfeld: 1 Cash, 2 Bank transfer, 3 Direct debit.)

Videos laut Seite: https://youtu.be/0TBGUxTExRE?list=PL1zWamKK12TNeFAStQx1mgA5p9l58QKxn&t=4 (if), https://youtu.be/wndgXmJjUN4?list=PL1zWamKK12TNeFAStQx1mgA5p9l58QKxn&t=2 (switch)

---

## 11. Select and query specific records
Link: https://forum.ninox.com/t/h7yzf0y/select-and-query-specific-records (Art: Ninox-3-Doku im Forum)

| Syntax | Beschreibung |
|---|---|
| `select 'Tabelle';` | alle Datensätze der Tabelle |
| `select 'Tabelle' where Bedingung;` | nur Datensätze, die die Bedingung erfüllen |
| `let v := select 'Tabelle'; v[Bedingung]` | Auswahl in Variable, danach Filter mit eckigen Klammern |

**Regeln:** Namen mit Leerzeichen, Bindestrich, Unterstrich o. Ä. in einfache Anführungszeichen. `where` wählt nur passende Datensätze, `[...]` wählt erst alle und filtert danach; der Artikel empfiehlt `where` aus Performancegründen. `[...]` setzt ein bereits gewähltes Array vom Typ `[nid]` voraus.

```
select 'Customers (New)';
```
(Einsatz: Formula-Option einer eingebetteten Tabellenansicht.)

```
select 'Customers (new)' where 'Headquarter' = 1 or 'Headquarter' = 2 or 'Headquarter' = 3;
```
(Headquarter: 1 Germany, 2 Austria, 3 Switzerland, 4 France, 5 Spain, 6 Italy.)

```
let customers := select 'Customers (New)';
customers['Headquarter'=1]
```

**Hinweis:** Schreibweise des Tabellennamens im Artikel uneinheitlich (New/new); Relevanz der Groß-/Kleinschreibung nicht belegt. Video laut Seite: YouTube-Playlist PL1zWamKK12TNeFAStQx1mgA5p9l58QKxn, Zeitmarke 3:36.

---

## 12. Create and delete records
Link: https://forum.ninox.com/t/y4yz1m0/create-and-delete-records (Art: Ninox-3-Doku im Forum)

| Syntax | Beschreibung |
|---|---|
| `create <Tabelle>` | neuer leerer Datensatz (Einsatz in einer Schaltfläche) |
| `delete <Ausdruck>` | löscht Datensätze, kombiniert mit `this` oder `select` |

**Regeln:** Zum Befüllen den neuen Datensatz in einer Variablen speichern und per `.` auf Felder zugreifen. Die Kundennummer im Beispiel (Buchstabe + UNIX-Zeitstempel) gilt laut Artikel als eindeutig. `delete this` eignet sich, um vor dem Löschen eine Aktion auszulösen (z. B. E-Mail).

```
create Customers
```

```
let newCustomer := (create Customers);
newCustomer.('Customer number' := "C" + number(now()))
```

```
delete this
```

```
delete select Customers where Status = 4
```

**Hinweise:** Artikeltext sagt `create Customer`, Beispiel `create Customers`; Tabellenname muss zur eigenen Datenbank passen. Felder "Customer number" und "Status" werden vorausgesetzt. Keine Angaben zu Berechtigungen, Transaktionen oder Rückgängigmachen.
