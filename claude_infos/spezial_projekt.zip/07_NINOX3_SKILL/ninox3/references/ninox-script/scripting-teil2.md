Stand: 2026-10-27, gelesen aus dem Forum, nicht in Ninox getestet

# Ninox 3 Scripting, Teil 2 (Forum-Dokuseiten)

Art aller Quellen: Ninox-3-Doku im Forum (https://forum.ninox.com). Die Inhalte wurden über WebFetch zusammengefasst; was nicht auf den Seiten steht, wurde nicht ergänzt. Verbindliches Verhalten bestätigt der Ninox Support.

Zusatz zur Kategorie-Seite https://forum.ninox.com/category/scripting?pg=2: Dort stehen sechs Themen (Trigger in use, do as database ... end, Color picker, Icon picker, Date and time formats, Ninox languages). Fünf davon stehen schon in der Auftragsliste; neu dazugekommen ist nur "Trigger in use" (/t/m1yl457/trigger-in-use), siehe unten.

---

## Sort records
Link: https://forum.ninox.com/t/m1yz1th/sort-records (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Datensätze werden mit `order by` sortiert, reine Wertelisten mit `sort()`. Der Sortierwert kann auch ein berechneter Ausdruck sein.

| Syntax | Bedeutung |
|---|---|
| `(select Tabelle) order by Feld` | aufsteigend nach Feld sortieren |
| `(select Tabelle where ...) order by Ausdruck` | gefilterte Auswahl, Sortierung nach berechnetem Wert |
| `sort(Liste)` | Liste von Werten sortieren |

```
(select Invoices) order by Total
```
```
(select Invoices where Date = today()) order by number(substr('Invoice no.', 3))
```
```
concat(((select 'Example for order by') order by 'First name').'First name')
```
```
concat(((select 'Example for order by') order by upper('First name')).'First name')
```
```
concat(sort((select 'Example for order by').'First name'))
```

Hinweise:
- `order by` empfiehlt die Seite vor allem für Zahlen.
- Texte werden nach Zeichenindex sortiert: Großbuchstaben vor Kleinbuchstaben (laut Seite wird "ABcD" zu "ABDc"). Abhilfe: `upper()` oder `lower()` im Sortierwert.
- In View-Layout-Elementen wird zuerst nach der gewählten Spaltenüberschrift sortiert, danach nach dem `order by`-Wert.
- Nicht auf der Seite: absteigende Sortierung, Mehrfachsortierung, Umgang mit leeren Werten.

---

## Repeat conditional statements with loops
Link: https://forum.ninox.com/t/60yz1t5/repeat-conditional-statements-with-loops (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Drei Schleifenarten.

| Schleife | Einsatz | Besonderheit |
|---|---|---|
| `for x in Liste do ... end` | Listen/Datensätze (meist bevorzugt) | iteriert Elemente |
| `for i from a to b [step n] do ... end` | Zahlenfolgen | Start inklusiv, Ende exklusiv, Standardschritt 1 |
| `while Bedingung do ... end` | bedingungsbasiert | Endlosschleife möglich |

```
let customers := select 'Customers (new)' where Status = 2;
for customer in customers do
    customer.Status := 1;
end
```
```
let array := [10, 20, 30, 20, 10];
let result := 0;
for i from 0 to 3 do
result := result + item(array, i)
end;
result
```
Ergebnis laut Seite: 60.
```
let array := [10, 20, 30, 20, 10];
let result := 0;
for i from 0 to 5 step 2 do
result := result + item(array, i)
end;
result
```
Ergebnis laut Seite: 50.
```
let i := 0;
let result := "";
while i < 10 do
    result := result + " " + i;
    i := i + 1
end;
result
```
Ergebnis laut Seite: 0 1 2 3 4 5 6 7 8 9.

Hinweise:
- Laut Seite entspricht `for i in range(0, 10)` dem `for i from 0 to 10`.
- Eine `while`-Schleife ohne Abbruchbedingung kann Ninox zum Absturz bringen.
- Unklar: Beim `while`-Beispiel wäre durch `" " + i` ein führendes Leerzeichen zu erwarten; die Seite erwähnt es nicht. Im Editor prüfen.

---

## Create your own functions
Link: https://forum.ninox.com/t/x2yz1t2/create-your-own-functions (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Eigene Funktionen mit `function name(param : typ, ...) do ... end`. Die letzte Zeile ist der Rückgabewert. Ohne Parameter: leere Klammern.

```
function hello(name : text,age : number) do
"Hello " + name + ". You are " + age + " years old!"
end
```
Aufruf:
```
hello("Mom", 100)
```
Ergebnis: `Hello Mom. You are 100 years old!`

| Parametertyp | Bedeutung |
|---|---|
| `text` | Text (string) |
| `number` | Zahl |
| `boolean` | wahr/falsch |
| `date` | Datum |
| `time` | Uhrzeit |
| `datetime` | Zeitstempel (timestamp) |
| Tabellenname | ein Datensatz dieser Tabelle, z. B. `myRecord : 'Table 1'` |
| `text[]`, `TableName[]` | Arrays (laut Seite ab "3.17.X", so im Text angegeben) |

Hinweise:
- Globale Funktionen: im Bearbeitungsmodus unter Options, Global functions; in der ganzen Datenbank verfügbar.
- Eine Funktion direkt in einem Formelfeld gilt nur in diesem Feld.
- Nicht alle Datentypen werden unterstützt; welche fehlen, nennt die Seite nicht.

---

## Intro to "any" functions
Link: https://forum.ninox.com/t/q6yzz26/intro-to-any-functions (Art: Ninox-3-Doku im Forum)

Zusammenfassung: In der Funktionsdokumentation steht `any` als Platzhalter für beliebige Datentypen. Typisierte Funktionen wie `odd(number)` melden bei falschem Typ einen Fehler; `text(any)` akzeptiert alles und wandelt intern um. `[any]` bedeutet ein Array mit beliebigen Elementtypen (Beispiel der Seite: `count[any]`). Als Rückgabe bedeutet `any` meist: der übergebene Typ kommt zurück. Schlüssel-Wert-Paare in `{...}` (JSON) werden ebenfalls als `any` geführt, besonders relevant in der API.

```
sendEmail({
    from: "support@example.com",
    to: "customer123@example.com,
    subject: "Thank you for your email",
    text: "We received your request to get another copy of your invoice"
})
```
Hinweise:
- Im Original fehlt in der `to:`-Zeile das schließende Anführungszeichen (vermutlich Tippfehler der Seite). Nicht übernehmen, vor Einsatz gegen die Forum-Doku und in einer Testdatenbank prüfen.
- Verweis auf der Seite: sendEmail (/t/y4yzw6k/sendemail) und Introduction to Ninox API (/t/83yzlg7/introduction-to-ninox-api).
- Nicht auf der Seite: vollständige Liste der any-Funktionen, Konvertierungsregeln, Fehlerfälle.

---

## Automatic adjustments
Link: https://forum.ninox.com/t/m1yzz2h/automatic-adjustments (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ninox passt Skripte beim Speichern automatisch an. Keine eigene Syntax. (Beim ersten Abruf kam HTTP 503, der zweite Abruf lief.)

| Thema | Regel | Beispiel |
|---|---|---|
| Klammern | überflüssige Klammern werden entfernt | `1 + (2 * 3)` wird `1 + 2 * 3` |
| Leerzeichen | unnötige entfernt, hilfreiche ergänzt | `text (year (today () ) )` wird `text(year(today()))` |
| Feldnamen | jederzeit änderbar, Skript bleibt gültig (Verweis geht auf die Feld-ID) | keins |
| Semikolon | bei Variablendeklaration wird automatisch eins am Ende ergänzt | keins |
| Einrückung | wird beim Speichern übernommen | keins |

Hinweise: Die Feld-ID kann nicht geändert werden. Die Seite nennt keine Ausnahmen; Artikel laut Seite ca. 2 Jahre alt.

---

## Intro to transactions
Link: https://forum.ninox.com/t/p8yzzr9/intro-to-transactions (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Alle Aktionen in Ninox laufen als Transaktionen (Folge von Datenbankoperationen). Es gibt Read- und Write-Transaktionen, ausgeführt im Client oder auf dem Server. Client = Programm auf einem Endgerät, das mit einem Server kommuniziert.

Syntax/Codebeispiele: keine auf der Seite. Details stehen auf den Unterseiten.

---

## Read transactions
Link: https://forum.ninox.com/t/y4yzzp2/read-transactions (Art: Ninox-3-Doku im Forum)

Zusammenfassung:
- Beim Filtern/Suchen liest Ninox die Tabelle nur, um Treffer anzuzeigen.
- Es zählt der Datenstand zum Zeitpunkt der Abfrage; Änderungen von Kollegen während der Abfrage sind nicht enthalten.
- Mehrere Lesetransaktionen laufen parallel und blockieren sich nicht.

Syntax/Codebeispiele: keine auf der Seite.

---

## Write transactions
Link: https://forum.ninox.com/t/83yzzpr/write-transactions (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ändert eine Aktion Daten, ist es eine Write Transaction.

Beispiele laut Seite: Eingabe/Änderung von Daten; einzelne datenändernde Anweisungen eines Skripts (z. B. per Button); alle Anweisungen in einem `do as transaction`- oder `do as server`-Block, wenn mindestens eine Anweisung Daten ändern kann.

Regeln:
- Trigger "on create" und "after update" laufen innerhalb der Write Transaction, die sie ausgelöst hat.
- Es kann nur eine Write Transaction gleichzeitig laufen; andere warten.
- Sie dauern in der Regel nur Millisekunden.
- Verzögerungen entstehen z. B. durch externe Abfragen (`http()`) oder umfangreiche Auswertungen mit `select`.

Syntax/Codebeispiele: keine auf der Seite.

---

## Execution context
Link: https://forum.ninox.com/t/q6yzzp1/execution-context (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ninox führt Transaktionen im Client oder auf dem Server aus, abhängig von Typ und davon, ob Web-App oder native App. Die Spaltenzuordnung der Tabelle wurde aus flachem Seitentext abgeleitet, daher ohne Gewähr.

| Element | Typ | Web-App | Native App |
|---|---|---|---|
| Create / Change / Delete | Write | Server | Client |
| Load views | Read | Server | Client |
| Scripting allgemein ohne Datenänderung | Read | Client | Client |
| Scripting allgemein mit mind. einer Datenänderung | Write | Server | Client |
| `select` | Read | Server | Client |
| `do as transaction` | Read/Write | Server | Client |
| `do as server` | Read/Write | Server | Server |
| `do as deferred` | Read/Write | Server | Server |
| `do as database` | Read/Write | Client | Client |
| Trigger after open | Read/Write | Client | Client |
| Trigger on new record | Write | Server | Client |
| Trigger after update | Write | Server | Client |

Hinweise: Ein Forenbeitrag sagt, bei lokaler/iCloud-Speicherung der Mac-App gelte der Rechner als "Server" (Forenaussage, nicht offiziell). Codebeispiele: keine.

---

## Triggers
Link: https://forum.ninox.com/t/35yl452/triggers (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ein Trigger reagiert nach dem Prinzip "wenn das passiert, dann tu das". Einsatz: Werte ändern/ergänzen, Folgeaktionen, Tabellen/Datensätze öffnen oder schließen, Felder vorausfüllen. Die Seite endet mit einer Ankündigung zu "Trigger after modification", ohne Detailteil.

| Trigger | Fundort |
|---|---|
| Trigger on new record | Tabelleneinstellungen |
| Trigger after modification | Tabelleneinstellungen und Feldeinstellungen fast aller Felder |
| Trigger after opening | Datenbankoptionen |
| Trigger before display | Feldeinstellungen des Tab-Felds |
| Trigger after hiding | Feldeinstellungen des Tab-Felds |

Die ersten beiden gelten als die häufigsten. Syntax/Codebeispiele: keine (auch das erwähnte Beispiel Rechnungsnummer fehlt).

---

## Trigger at field level
Link: https://forum.ninox.com/t/q6yl45b/trigger-at-field-level (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Beispiel Rechnungspositionen: Der Einzelpreis soll bei der Rechnungsstellung als fester Zahlenwert gespeichert werden, nicht dynamisch aus der Tabelle "Food & Drinks" kommen. Dafür wird ein Trigger after modification (Ereignis Change) am Verknüpfungsfeld "Food & Drinks" der Subtabelle "Invoice Items" gesetzt.

```
Unit Price := 'Food & Drinks'.Unit Price
```

Vorgehen (Subtabelle): Zahlenfeld "Unit Price" anlegen, altes Formelfeld "Unit Price" löschen, Trigger in den More Options des Verknüpfungsfelds eintragen, Feld "Total Price" auf das neue Feld umstellen (konkrete Formel nennt die Seite nicht), speichern. In der Tabelle "Invoices": Bearbeitungsmodus, Spalte "Unit Price" über "Show Column" wieder einblenden, vor "Total Price" ziehen, speichern.

Hinweise:
- Bestehende Rechnungspositionen haben danach keine Berechnungsgrundlage mehr (keine Preise); die Lösung kommt in "Assign data via button".
- Der Trigger übernimmt den Preis nur beim Change des Verknüpfungsfelds (Ableitung aus dem Beschriebenen).

---

## Assign data via button
Link: https://forum.ninox.com/t/h7yl45d/assign-data-via-button (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ein temporärer Button befüllt die fehlenden Stückpreise in bestehenden Rechnungspositionen.

```
for i in select Invoice Items do
    i.UnitPrice := i.'Food & Drinks'.UnitPrice
end
```

Vorgehen: Tabelleneinstellungen von "Invoice Items", Layoutfeld Button hinzufügen, Skript unter "On Click" eintragen, Button klicken, Button optional wieder löschen, mit neuer Rechnung testen.

Hinweise: Das Skript setzt ein Feld "Food & Drinks" mit Unterfeld "UnitPrice" voraus (aus dem Code abgeleitet). Auf der Seite wird für `for ... in ... do ... end` und `select` auf die Einführung in Ninox Scripting verwiesen. Keine Angaben zu Fehlerfällen oder Berechtigungen.

---

## Create another invoice
Link: https://forum.ninox.com/t/p8yl45w/create-another-invoice (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Seite ist praktisch leer für Scripting. Es wird eine neue Rechnung mit viel Champagner zu aktuellen Preisen angelegt, danach der neue Preis eingetragen; der Text bricht ab. Keine Syntax, keine Codebeispiele (beim ersten Abruf HTTP 503, zweiter Abruf lief).

---

## Trigger in use (zusätzlich aus Kategorie-Seite 2)
Link: https://forum.ninox.com/t/m1yl457/trigger-in-use (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Szenario: Der Preis von Champagner wird in "Food & Drinks" auf 9 EUR geändert, danach wird eine weitere Rechnung erstellt. Laut Seite zeigen alle Rechnungen den zum Ausstellungszeitpunkt gültigen Einzelpreis; Preise früherer Rechnungen bleiben unverändert. Der Trigger-Code ist nur als Screenshot gezeigt und war nicht auslesbar. Ein Abschnitt "Roles and Permissions" wird nur angekündigt. Keine Syntax.

---

## do as database ... end
Link: https://forum.ninox.com/t/m1yz853/do-as-database-end (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Transaktion für den Zugriff auf eine andere Datenbank ohne API-Umweg (Seite nennt Version 3.10). Verfügbar laut Seite für Private Cloud und On-Premises; zur Public Cloud keine Aussage.

Regeln:
- Die Datenbanken müssen eine bestehende Beziehung haben.
- Datenbankname exakt angeben; bei Sonderzeichen in einfachen Anführungszeichen.
- Lesen und Schreiben sind clientseitig konsistent (Web und native Apps).
- Verwandt: `do as transaction`, `do as server`, `do as deferred`.

Beziehung einrichten (Beispiel der Seite, Datenbank "Offers and invoices", Tabelle "Invoices"): Bearbeitungsmodus (Schraubenschlüssel), Tabelleneinstellungen (Zahnrad, Edit fields), Option "All databases in current workspace" aktivieren, unter "Relationship fields" die Tabelle "Orders" der Datenbank "Procurement" nach "Fields" ziehen, Save.

Lesen (Formelfeld "Order date"):
```
do as database Procurement
    last ((select Orders).'Order date')
end
```
Schreiben (Button "New invoice", On click):
```
do as database Procurement
    let newInvoice := (create Orders);
    newInvoice.('Order date' := today());
    popupRecord(newInvoice)
end
```
Nicht auf der Seite: Fehlerverhalten, Berechtigungen, Performance.

---

## Color picker
Link: https://forum.ninox.com/t/60yzz2z/color-picker (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Beschreibt die neue Farbauswahl der Oberfläche in Version 3.12. Keine Script-Syntax, keine Codebeispiele.

- Farbvorgaben von 12 auf 30.
- Eingabe über HSL, HEX, CSS-Namen, Klartext; RGB bleibt.
- Integrierter Bildschirm-Farbwähler; Farben zur Palette hinzufügen ist für später angekündigt.
- Update 3.11 auf 3.12 ohne zusätzliche Schritte.
- Neuer Picker bei: Feldtypen Color, Choice, Multiple choice, Signature; Kanban-Ansicht; Pop-ups (Tab settings, Name/Rename database, Conditional formatting); Options-Tab Background settings (Workspace und Datenbank).
- Weiterhin alte Palette bei: Button, Free text, Heading, Style-Auswahl im Formelfeld.
- Nicht auf der Seite: Farbwerte in Formeln, Rückgabeformate.

---

## Icon picker
Link: https://forum.ninox.com/t/m1yzzwx/icon-picker (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Ab Version 3.12 neue Icon-Bibliothek und neuer Icon-Picker (von 254 auf über 3000 Icons), mit Suche; Farbe, Gewicht und Füllung einstellbar (die Seite nennt an einer Stelle auch Größe, ohne Erläuterung). Einsatzorte: Icon-, Auswahl-, Mehrfachauswahl-Feld, Kanban, Subtabellen-Ansicht, Tabelleneinstellungen, bedingte Formatierung, Funktionen `icon` und `styled`.

```
let myIcon := {
  filling: 1,
  weight: 500,
  icon: "mail",
  color: "#43d682"
};
icon(formatJSON(myIcon))
```

Hinweise:
- Alte Icon-Namen (3.11 und älter) werden automatisch auf die neue Version abgebildet; Standardwerte `FILL` 0, `wght` 400, `GRAD` 0, `opsz` 48. Eine Zuordnungs-PDF ist auf der Seite verlinkt.
- Downgrade auf 3.11: alte Icons kehren zurück, sofern in 3.12 keine neuen gewählt wurden; in 3.12 per Picker oder `icon`/`styled` gewählte Icons funktionieren in 3.11 nicht (leer oder fehlend).
- Zu `styled` steht nur ein Verweis, kein Beispiel. Screenshots waren nicht lesbar.

---

## Date and time formats
Link: https://forum.ninox.com/t/g9yzzwf/date-and-time-formats (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Liste der Format-Tokens. Die Seite zeigt keine Aufrufsyntax und keine Codebeispiele; ein Kommentar verweist auf `format()` als Einstieg (Aufrufform nicht belegt). Groß-/Kleinschreibung der Tokens ist relevant.

| Token | Bedeutung | Beispiel |
|---|---|---|
| YY / YYYY | Jahr 2-/4-stellig | 21 / 2021 |
| M / MM | Monat 1-2 / 2-stellig | 1..12 / 01..12 |
| Mo | Monat ordinal | 1st..12th |
| MMM / MMMM | Monat 3 Zeichen / ausgeschrieben | Feb / February |
| D / DD | Tag 1-2 / 2-stellig | 1..31 / 01..31 |
| Do | Tag ordinal | 1st..31st |
| d / do | Wochentag Zahl / ordinal | 0..6 / 0th..6th |
| dd / ddd / dddd | Wochentag 2 / 3 Zeichen / ausgeschrieben | Mo / Mon / Friday |
| w oder W | Kalenderwoche | 1..53 |
| Q | Quartal | 1..4 |
| l | Datum M/D/YYYY | 6/15/2021 |
| L | Datum MM/DD/YYYY | 06/15/2021 |
| h / hh | Stunde 12h, 1-2 / 2-stellig | 1..12 / 01..12 |
| H / HH | Stunde 24h, 1-2 / 2-stellig | 0..23 / 00..23 |
| a | am/pm | hh:mm a = 11:30 pm |
| m / mm | Minute | 0..59 / 00..59 |
| s / ss | Sekunde | 0..59 / 00..59 |
| x | Unix-Zeit in Millisekunden | 1617873118285 |
| X | Unix-Zeit in Sekunden | 1617873118 |
| Z | Zeitzonen-Offset zu UTC | -04:00:00 |

Hinweis: Seite laut Angabe ca. 2 Jahre alt; Vollständigkeit nicht prüfbar.

---

## Ninox languages
Link: https://forum.ninox.com/t/83yz1mj/ninox-languages (Art: Ninox-3-Doku im Forum)

Zusammenfassung: Liste der von Ninox unterstützten Sprachen mit Kürzeln, relevant z. B. für Datums- und Zeitformate. Keine Syntax, keine Codebeispiele.

| Kürzel | Sprache |
|---|---|
| de | Deutsch |
| en | Englisch |
| fr | Französisch |
| it | Italienisch |
| es | Spanisch |
| ca | Katalanisch |
| pl | Polnisch |
| ru | Russisch |
| cht | Chinesisch (traditionell) |
| chs | Chinesisch (vereinfacht) |
| zh-ch | Chinesisch (China) |
| zh-hk | Chinesisch (Hongkong) |
| zh-mo | Chinesisch (Macau) |
| zh-sg | Chinesisch (Singapur) |
| zh-tw | Chinesisch (Taiwan) |

---

## Themenliste Kategorie Scripting (Seite 2 und Navigation)
Die Seite pg=2 lieferte die Navigation mit 31 Scripting-Themen; die eigentliche Kategorie-Liste auf pg=2 zeigt Nr. 26 bis 31: Trigger in use (/t/m1yl457), do as database ... end (/t/m1yz853), Color picker (/t/60yzz2z), Icon picker (/t/m1yzzwx), Date and time formats (/t/g9yzzwf), Ninox languages (/t/83yz1mj). Weitere Navigationsthemen (nicht Teil dieses Auftrags, vermutlich in Teil 1): Introduction to Ninox script, The formula editor, Formula editor features, Arithmetic operators, Comparison operators, Ninox operators, Writing dynamic texts, Declare variable, Set conditional statement, Set multiple conditional statements, Select and query specific records, Create and delete records. Die Seite nennt außerdem "Next page"-Pagination, aber keine weiteren Themen über Nr. 31 hinaus.
