# Ninox Script (Ninox 3): Inhaltsverzeichnis

Stand: 2026-10-27. Alles gelesen aus der Ninox-3-Doku im Forum (https://forum.ninox.com/category/docs), zusammengefasst, **nicht in Ninox getestet**. Die Forum-Doku ist eine Community-Plattform und hat Fehler, die in den Dateien vermerkt sind.

| Datei | Inhalt | Umfang |
|---|---|---|
| `scripting-teil1.md` | Einführung, Formeleditor, Operatoren, Variablen (`let`), Bedingungen, `select`, Datensätze anlegen und löschen, dynamische Texte | 12 Themen |
| `scripting-teil2.md` | Sortieren, Schleifen, eigene Funktionen, "any"-Funktionen, Transaktionen, Ausführungskontext, Trigger, Button-Zuweisung, `do as database`, Farb- und Icon-Auswahl, Datums- und Zeitformate, Sprachen, Themenliste | 20 Themen |
| `funktionen-index-1.md` | Funktionen `abs` bis `popupRecord` mit Kurzbeschreibung und Link | 100 |
| `funktionen-index-2.md` | Funktionen `pow` bis `yearweek` mit Kurzbeschreibung und Link | 83 |

## So wird der Index benutzt

1. **Funktion suchen:** im Funktionsindex nach dem Namen suchen. Die Kurzbeschreibung stammt aus gekürzten Forum-Vorschauen und ist keine Syntaxangabe.
2. **Syntax verifizieren:** die Seite der Funktion (Link in der Tabelle) mit `WebFetch` lesen, bevor ein Script weitergegeben wird. Nie Parameter und Rückgabewerte aus dem Gedächtnis angeben.
3. **Nicht gefunden:** dann existiert die Funktion in der Ninox-3-Doku nicht oder liegt unter anderem Namen. Das offen sagen, nichts erfinden.
4. **Grundlagen:** für Syntax von `let`, `if`, `select`, `for`, `do as server` zuerst `scripting-teil1.md` und `scripting-teil2.md`.

## Bekannte Lücken

- Mehrere Seiten bestehen im Original nur aus Screenshots oder Konzepttext (Einführung, Formeleditor, Transaktionen, Trigger, "Trigger in use", "Create another invoice"). Dort gibt es hier keinen Code.
- Die Tabelle zum Ausführungskontext ist aus Fließtext abgeleitet, Spaltenzuordnung ohne Gewähr.
- `quarter` hat im Forum eine fehlerhafte Vorschau (zeigt den Text von `pow`), `shareFile` ist abgeschnitten. Detailseiten lesen.
- Die zwei Seiten "array"/"Array" und "text"/"Text" sind je eine Funktion und eine Übersichtsseite.

## Aktualisierung

Quelle ändert sich. Bei Zweifel an Aktualität die Forum-Seite erneut lesen und das Datum im Dateikopf anpassen.
