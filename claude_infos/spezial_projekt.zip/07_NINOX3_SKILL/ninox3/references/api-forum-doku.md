# Ninox-3-API: Inhalte der Forum-Dokumentation

Stand: 2026-10-27, gelesen aus dem Ninox-Forum (Bereich Documentation, API), **nicht gegen eine Instanz getestet**. Ergänzt `api-endpoints.md` (Swagger-Datei). Wo beide Quellen abweichen, steht es unten unter "Abweichungen". Das Forum nennt sich selbst Community; verbindliches Produktverhalten bestätigt der Ninox Support.

## Wichtig: tote Links

`https://docs.ninox.com/en/api/public-cloud-apis` und `https://docs.ninox.com/en/api/private-cloud-apis` (in der Swagger-Datei genannt) liefern am 2026-10-27 **404**. docs.ninox.com ist die Ninox-4-Dokumentation. Die Ninox-3-API-Doku liegt im Forum (Links unten). Die Anker-Links der Swagger-Datei nicht weitergeben.

## Quellen (Forum, Bereich Documentation, API)

Kategorie: https://forum.ninox.com/category/api (Deutsch auch https://forum.ninox.de/category/api). Acht Themen, jeweils Englisch und Deutsch:

| Thema | Englisch | Deutsch |
|---|---|---|
| Introduction to Ninox API | /t/83yzlg7/introduction-to-ninox-api | /t/m1ylnsq/einfuhrung-in-die-ninox-api |
| API endpoints for Public Cloud | /t/35yzp89/api-endpoints-for-public-cloud | /t/q6ylnsx/api-endpunkte-fur-public-cloud |
| API endpoints for Private Cloud/On-Premises | /t/x2yzfmf/api-endpoints-for-private-cloudon-premises | /t/35ylns3/api-endpunkte-fur-private-cloudon-premises |
| API calls in Ninox script | /t/x2yzljz/api-calls-in-ninox-script | /t/y4ylnsy/api-calls-im-ninox-skript |
| Tables, fields, and records | /t/x2yzljq/tables-fields-and-records | /t/83ylnsh/tabellen-felder-und-datensatze |
| Integrations | /t/y4yl4rw/integrations | /t/q6yxs6j/integrationen |
| API sandbox (Swagger) | /t/g9yp9yp/api-sandbox-powered-by-swagger | /t/60yp9yg/api-testumgebung-ermoglicht-durch-swagger |
| CORS and Allowed Origins | /t/p8ygwjc/cors-and-allowed-origins | /t/g9ygwj4/cors-und-zulassige-ursprunge |

Basis für alle Pfade: `https://forum.ninox.com`.

## Token erzeugen und Rechte

- Wer darf: Workspace-Inhaber (Public Cloud) bzw. Nutzer mit vollem Zugriff auf die Ninox-Einstellungen (Private Cloud).
- Weg: app.ninox.com, Zahnrad oben rechts, **Ninox Settings**, **Integrations**, **New API Key**, Schlüssel kopieren. Alternativ admin.ninox.com (Public Cloud) oder `[mydomain].ninoxdb.de/admin` (Private Cloud).
- Widerrufen: Papierkorb-Symbol neben dem Schlüssel. Schlüsselübersicht mit Erstelldatum und optionaler Beschreibung (ab Version 3.19.9).
- Public Cloud: Der Schlüssel gibt Lese- und Schreibzugriff auf alle Datenbanken des Inhabers.
- Private Cloud: Dem Schlüssel können Rollen zugewiesen werden. Die Rolle `admin` ist für alle API-Zugriffe nötig, außer für Lesen und Schreiben von Datensätzen.
- Schlüssel geheim halten, nicht in öffentliche Repositories oder Client-Code.

## Basis-Adressen und Anmeldung

| Umgebung | Adresse |
|---|---|
| Public Cloud (neu, empfohlen) | `https://api.ninox.com/v1` |
| Public Cloud (alt, funktioniert weiter) | `https://api.ninoxdb.de/v1` |
| Private Cloud | `https://{private-cloud}.ninoxdb.de/v1` (Text nennt auch `.ninoxdb.com`) |
| On-Premises | IP mit Port oder eigene Domain, `https://.../v1` |

- Header `Authorization: Bearer {accessToken}`, `Content-Type: application/json`.
- HTTPS ist Pflicht. HTTP wird in Public und Private Cloud umgeleitet, nicht gefolgte HTTP-Aufrufe scheitern.
- Ohne Anmeldung scheitern alle Aufrufe, auch wenn Benutzername und Passwort existieren.
- Empfohlene Clients laut Doku: Postman, cURL oder `http()` im Formeleditor.

## Statuscodes

Die Einführung nennt: 200, 201, 202, 204, 400, 401, 403, 404, 422, 500, 501, 502. Die Endpunkt-Seiten dokumentieren selbst nur 200, 202, 204 und 404. Das Fehlerformat bei 4xx/5xx ist nicht beschrieben. Grenzen (Rate Limit, Seitengröße, Dateigröße, Timeout) sind **nirgends dokumentiert**; als unbekannt behandeln.

## Zusätzlich zur Swagger-Datei dokumentiert

| Thema | Inhalt |
|---|---|
| Geschützte Datenbank | Optionaler Header `nx-password` am Schema-Endpunkt. Richtiges Passwort: Schema plus `hash`. Kein oder falsches Passwort: **trotzdem 200**, Antwort in geschützter Form (`version` "PROTECTED.1", gehashtes Schema, `hash`). Ein 200 heißt hier also nicht, dass das Schema lesbar ist. |
| Änderungen seit Sequenz | `GET .../databases/{dbid}/changes?sinceSq={n}` (Antwort: `config`, `nextRids`, `updates`, `removes`, `files`, `views`, `reports`, `seq`), `GET .../tables/{tid}/changes?sinceSq={n}` (`nextRid`, `updates`, `removes`, `files`, `views`, `reports`, `seq`), `GET .../records/{rid}/changes?sinceSq={n}` (`nextRid`, `updates`, `removes`, `files`, `seq`). `sinceSq` ist eine Ganzzahl. Lesend. |
| Sync-Empfehlung | Änderungen lesen (`changes`) und mit Upsert schreiben, um Tabellen abzugleichen und Datensatz-IDs zu erhalten. |
| Upsert-Antwort | Array mit `_id`, `_cu`, `_cd`, `_mu`, `_md` und Feldwerten, Schlüssel sind Feld-IDs (z. B. `"E"`). |
| Suche ohne Treffer | `POST .../record` liefert bei keinem Treffer ein **leeres Array**, nicht `null`. |
| Anlegen/Ändern (Nr. 15) | Mit `id` ändern, ohne `id` anlegen, Felder unter `fields` mit **Feldnamen**. Upsert dagegen mit `_upsert`, `_id` und **Feld-IDs**. |
| Lookup per GET | `filters` als JSON-Objekt im Query-String oder im Body, Schlüssel sind Feld-IDs. |
| Ausgabeformat | `style`, `choiceStyle` (`ids` oder `names`), nur bei POST-Suche zusätzlich `dateStyle`. |

## Parameter für Datensatzabfragen (Seite "Tables, fields, and records")

| Parameter | Typ | Standard | Bedeutung |
|---|---|---|---|
| `query` | string | | Ninox-Script, URL-kodiert |
| `filters` | string | | JSON-Kriterien als Text, z. B. `"A":"..."` |
| `page` | integer | 0 | Ergebnisseite |
| `perPage` | integer | 100 | Datensätze pro Seite |
| `order` | string | | Feldname zum Sortieren |
| `desc` | boolean | false | absteigend |
| `new` | boolean | false | neueste zuerst, nicht mit `order` kombinierbar |
| `updated` | boolean | false | zuletzt geändert zuerst, nicht mit `order` kombinierbar |
| `sinceId` | integer | | nur Datensätze mit höherer ID |
| `sinceSq` | integer | | nur Datensätze nach dieser Sequenz erstellt oder geändert |
| `ids` | boolean | | Schlüssel nach Feld-ID (true) oder Feldname (false) |
| `choiceStyle` | string | `ids` | Auswahlwerte als Options-ID oder Beschriftung |

`query` und `filters` mit `encodeURIComponent()` kodieren. Diese Parameter stammen von **einer** Forum-Seite und stehen nicht in der Swagger-Datei; vor produktiver Nutzung an einer Testdatenbank prüfen. Die Seite dokumentiert nur ein Filterbeispiel, Operatoren und verschachtelte Kriterien sind nicht beschrieben.

## IDs

- Tabellen-IDs: `A`, `B` ... `Z`, `AA`, `AB` ... Feld-IDs gleiches Muster. Sie ändern sich während der Lebensdauer der Datenbank nicht, das Format kann sich aber in künftigen Versionen ändern (Doku nennt sie "opaque handles").
- Datensatz-ID: Ganzzahl ab 1.

## Feldtypen und JSON-Werte

| Typ | JSON | Beispiel |
|---|---|---|
| text | string | `"Lisa"` |
| number | number | `13.42` |
| date | string | `"2021-01-23"` |
| datetime | string | `"2021-01-23T12:30:00"` |
| timeinterval | string | `"123:25:16.123"` |
| time | string | `"12:30:00"` |
| appointment | string | `"2021-01-23T12:30:00 - 2021-01-23T13:30:00"` |
| boolean | boolean | `true` |
| choice | string | `"blue"` |
| url | string | `"https://ninox.com"` |
| email | string | `"name@example.com"` |
| phone | string | `"+1 123456789"` |
| location | string | `"Straße 1, 10178 Berlin, Germany <52.53,13.39>"` |
| html | string | `"<h1>Hello</h1>"` |

**Nicht dokumentiert:** Mehrfachauswahl, Verweise (Referenzen) und Dateifelder. Dafür nichts raten, sondern an einem Test-Datensatz lesen und das Format ablesen.

Datensatz: `id`, `sequence`, `createdAt` und `modifiedAt` (UTC, `YYYY-MM-DDThh:mm:ss`), `createdBy`, `modifiedBy`, `fields` (Schlüssel standardmäßig Feldnamen).

## Private Cloud / On-Premises: zusätzlich

- Ansichten: `GET .../databases/{dbid}/views`, `GET .../tables/{tid}/views`.
- Geteilte Ansichten: `GET`/`POST`/`DELETE .../tables/{tid}/views/{viewid}/share` (Antwort `{url, options}`, URL-Muster `https://{private-cloud}.ninoxdb.de/share/<ID>`).
- Datei-Freigabelinks: `GET`/`POST`/`DELETE .../records/{rid}/files/{file}/share` (Antwort laut Forum eine URL als Text, laut Swagger ein Objekt `{url}`).
- Freigabelinks machen Inhalte öffentlich erreichbar: nur nach ausdrücklicher Bestätigung.

## CORS und Allowed Origins (Private Cloud ab 3.18.11)

- Seit 3.18.11 sind die CORS-Header strenger. Browser-Aufrufe (z. B. JavaScript auf einer externen Webseite) scheitern, wenn die Herkunft nicht freigegeben ist.
- Einstellung: Ninox Settings, Integrations, **Allowed Origins**. Mehrere Domains mit Komma trennen, jeweils mit Protokoll (`https://meine-domain.de`).
- Ein `http()`-Aufruf aus Ninox auf eine andere Private Cloud scheitert, solange die aufrufende Domain nicht freigegeben ist. Ausweg: `do as server ... end`, dann läuft der Aufruf vom Server.
- Nicht beschrieben: Wildcards, Subdomains, Fehlersuche, Verhalten bei Public Cloud und On-Premises.

## Integrationen

- Genannt: Make, Zapier, Syncspider, außerdem eigene direkte Integrationen (nicht beschrieben).
- Standard-Integration (Zapier): Workspace-Übersicht, Zahnrad, Integrations, Zap-Schaltfläche, Weiterleitung zu Zapier.
- Der API-Schlüssel wird oben im Integrations-Fenster "bei Bedarf" erzeugt und kann gelöscht werden. Rechte, Ablauf und Rotation sind nicht beschrieben.
- Vor Erstellen von Schlüsseln oder direkten Integrationen IT (it@ninox.com) einbeziehen.

## Abweichungen und Fehler in der Doku

| Stelle | Befund |
|---|---|
| `docs.ninox.com/en/api/...` | 404, Links der Swagger-Datei veraltet |
| Abfrage-Pfad | Forum-Überschrift `{query}` als Pfadteil, Beispiele nutzen `/query` (GET mit `?query=`, POST mit Body) |
| Beispiele mit curl | `-D` statt `-d`, Header-Syntax `-H "Authorization": ...` fehlerhaft, Zeilenfortsetzungen fehlen: Beispiele nicht kopieren |
| Pfade | `teams{teamid}` und `tables{tid}` ohne `/` an zwei Stellen der Private-Cloud-Seite |
| Datensatz-Antwort | Public-Cloud-Seite zeigt eine Liste bei Einzelabruf, Swagger ein Objekt; GET-Suche liefert Feld-IDs mit `_`-Metadaten, POST-Suche Feldnamen |
| Löschen | Swagger: Einzel-DELETE 200 mit `{}`; Forum Private Cloud: 204 |
| Datei-Freigabelink | Swagger Objekt `{url}`, Forum URL-Text |
| Upload-Antwort | Swagger 202 "File Uploaded Successfully", Forum Private Cloud ohne Antwort dokumentiert |
| Mehrdeutige Pfade | `GET .../records` für Liste und Suche, `POST .../records` für Anlegen/Ändern und Upsert, nur der Body unterscheidet |
| JSON-Beispiele | teils ungültig (fehlende Anführungszeichen, Kommas) |

Bei jeder Abweichung gilt die tatsächliche Antwort der Instanz. Erst an einem einzelnen Test-Datensatz prüfen.
