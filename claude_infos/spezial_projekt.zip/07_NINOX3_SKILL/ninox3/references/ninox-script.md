# Ninox Script für Ninox 3

Regel: Beispiele zu Ninox-Themen sind immer Ninox Script, nicht curl oder PowerShell. Dazu immer Doku-Links. Alles hier ist gegen die Dokumentation zu prüfen, bevor es in eine Produktivdatenbank kommt; ich kann Scripts in Ninox hier nicht ausführen und sage das bei jeder Lösung.

Doku (Ninox 3, Forum): https://forum.ninox.com/category/docs, Scripting: https://forum.ninox.com/category/scripting, Funktionen: https://forum.ninox.com/category/functions
API: https://forum.ninox.com/category/api, Seite "API calls in Ninox script": https://forum.ninox.com/t/x2yzljz/api-calls-in-ninox-script (Deutsch: https://forum.ninox.com/t/y4ylnsy/api-calls-im-ninox-skript)
Die Links `docs.ninox.com/en/api/...` aus der Swagger-Datei liefern 404 und werden nicht weitergegeben.

Ausführliche Script-Referenz aus der Forum-Doku: Ordner `ninox-script/` (Scripting-Themen und Funktionsindex). Für eine einzelne Funktion immer deren Seite lesen (Link im Funktionsindex), nicht aus dem Gedächtnis schreiben.

## API aus Ninox Script aufrufen: `http()`

Laut Forum-Doku (Seite "API calls in Ninox script", nicht in Ninox getestet):

| Form | Zweck |
|---|---|
| `http(method, url)` | ohne Body und Header |
| `http(method, url, body)` | mit Body |
| `http(method, url, headers, body)` | vollständig |

- `method`: GET, POST, PUT, DELETE. `url`: gültige HTTP/HTTPS-Adresse. `headers`: JSON-Objekt. `body`: Text oder JSON-Objekt.
- **Rückgabe:** ein JSON-Objekt mit `error` **oder** `result`. Üblich: zuerst `error` prüfen, dann `result` lesen.
- In **Triggern** geht `http()` mit POST, **nicht mit GET**.
- Aus einem **Button** läuft `http()` im Client (Browser/App). Für Serverkontext `do as server ... end` verwenden.
- Serverkontext ist für Nicht-SSL-Schnittstellen empfohlen, weil die nativen Apps (Mac, iPhone, iPad) unsichere Adressen nicht abfragen.
- Hilfsfunktionen: `urlEncode`, `urlDecode`, `url` (baut einen Query-String aus einem Objekt).
- JSON: Eigenschaftsnamen mit Leerzeichen, Sonderzeichen oder führender Zahl in einfache Anführungszeichen. Doppelte Anführungszeichen in Texten verdoppeln. Zugriff mit Punkt (`antwort.result.id`).
- Typumwandlung bei Bedarf: `text`, `number`, `date`, `datetime`, `time`, `appointment`, `url`, `phone`. Arrays: `first`, `last`, `item`, `for ... in`.
- Nicht beschrieben: Dateien, Fehlercodes, Timeouts.

Muster mit Fehlerprüfung:

```
let antwort := http("GET", "https://api.ninox.com/v1/teams",
  {Authorization: "Bearer <API_KEY>", "content-type": "application/json"}, {});
if antwort.error then
  alert(antwort.error)
else
  antwort.result
end
```

Beim Zugriff auf Ninox-Daten per `http()` muss immer ein Body übergeben werden, auch ohne Inhalt (`{}`) (belegt in Swagger-Datei und Forum).

```
http("GET", "https://api.ninox.com/v1/teams",
  {Authorization: "Bearer <API_KEY>", "content-type": "application/json"}, {})
```

- `<API_KEY>` ist ein Platzhalter. Das echte Token gehört nicht in ein Script, das gespeichert oder geteilt wird. Wo es in Ninox 3 sicher abgelegt werden kann, in der Doku prüfen, nicht raten.
- Private Cloud: statt `api.ninox.com` den eigenen Hostnamen verwenden (`https://{hostname}/v1`).
- Rückgabe und Fehlerbehandlung: siehe oben.

Datensätze einer Tabelle lesen (Nr. 10):

```
http("GET", "https://api.ninox.com/v1/teams/<TEAM_ID>/databases/<DB_ID>/tables/A/records",
  {Authorization: "Bearer <API_KEY>", "content-type": "application/json"}, {})
```

Datensatz ändern (Nr. 12, nur nach Freigabe):

```
http("PUT", "https://api.ninox.com/v1/teams/<TEAM_ID>/databases/<DB_ID>/tables/A/records/1",
  {Authorization: "Bearer <API_KEY>", "content-type": "application/json"},
  {fields: {"First name": "Jane"}})
```

## Abfragen für `query` und `exec`

Die Formel steht als Text im Body (`{"query": "..."}`). Beispiele aus der Swagger-Datei (belegt):

```
(select Contact).'First Name'
```
```
users()
```

`query` ist schreibgeschützt, `exec` darf Daten ändern. Eine Formel mit `create`, Zuweisung oder anderen Änderungen gehört nur in `exec`, und nur nach Freigabe.

## Script-Grundlagen

Die folgenden Muster gehören zur Ninox-Skriptsprache und sind in der Doku zu verifizieren, bevor sie weitergegeben werden. Welche Funktionen in welcher Ninox-3-Version verfügbar sind, entscheidet die Doku, nicht dieses Dokument.

```
let anzahl := cnt(select Contact);
let namen := (select Contact).'First Name';
if anzahl > 0 then
  "Kontakte: " + text(anzahl)
else
  "keine Kontakte"
end
```

Auf dem Server ausführen (für API-Aufrufe empfohlen, bei Bedarf):

```
do as server
  let antwort := http("GET", "https://api.ninox.com/v1/teams",
    {Authorization: "Bearer <API_KEY>", "content-type": "application/json"}, {});
  antwort
end
```

## Vorgehen bei Script-Aufgaben

1. Tabellen und Feldnamen aus dem Schema lesen (`GET .../tables/{tid}`), nicht aus dem Gedächtnis nehmen.
2. Script schreiben, mit Platzhaltern für Token und IDs.
3. Offen sagen, was nicht getestet werden konnte, und was der Nutzer in der Oberfläche prüfen soll.
4. Doku-Links zur Funktion mitgeben, nur geprüfte.
