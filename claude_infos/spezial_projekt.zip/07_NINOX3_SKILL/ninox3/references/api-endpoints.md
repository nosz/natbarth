# Ninox-3-REST-API: Endpunkte

Quelle: Swagger-Datei `references/swagger/ninox_api_swagger_en.yaml` (Stand 2026-03-06, OpenAPI 3.0.3, Version 1.0). Was dort nicht steht, ist hier nicht belegt und wird nicht geraten. Zusätzliche Angaben aus der Forum-Doku (Änderungsabfragen, `nx-password`, Abfrageparameter, Feldtypen, CORS) stehen in `api-forum-doku.md`. Die Links `docs.ninox.com/en/api/...` aus der Swagger-Datei liefern 404; die Ninox-3-API-Doku liegt im Forum: https://forum.ninox.com/category/api.

## Grundlagen

| Thema | Wert |
|---|---|
| Public Cloud | `https://api.ninox.com/v1` |
| Private Cloud / On-Premises | `https://{hostname}/v1` (z. B. Subdomain von `ninoxdb.de`, eigene Domain oder IP mit Port) |
| Anmeldung | Header `Authorization: Bearer <API_KEY>` (Personal Access Token) |
| Token erzeugen | Ninox-Web-App, Einstellungen, Integrationen, Generieren |
| Rechte des Tokens | laut Swagger: Lese- und Schreibzugriff auf alle Datenbanken |
| Platzhalter | `{teamid}`, `{dbid}`, `{tid}`, `{rid}` in geschweiften Klammern ersetzen (samt Klammern) |
| IDs | Team-ID z. B. `mnPLY6DMsvq9wz4id`, Datenbank-ID z. B. `gt5k36w957yt`, Tabellen-ID meist ein Buchstabe (`A`), Datensatz-ID eine Zahl |
| Fehler | 401 nicht angemeldet / Token ungültig, 404 nicht gefunden |

Query-Parameter für Ausgabeformat: `style` (`ids` oder `names`), `choiceStyle` (`ids` oder `names`), `dateStyle` (`ids` oder `names`, nur bei Nr. 14).

## Alle Operationen

Rechte-Spalte: **L** = Lesen (frei), **S** = Schreiben (Freigabe pro Schritt). "PC" = nur Private Cloud / On-Premises.

| Nr. | Methode und Pfad | Zweck | Recht |
|---|---|---|---|
| 01 | `GET /teams` | Teams (Workspaces) des Tokens | L |
| 02 | `GET /teams/{teamid}` | ein Team | L |
| 03 | `GET /teams/{teamid}/databases` | Datenbanken eines Teams | L |
| 04 | `GET /teams/{teamid}/databases/{dbid}` | Schema einer Datenbank inkl. Einstellungen | L |
| 05 | `GET .../databases/{dbid}/query?query=...` | schreibgeschützte Abfrage (Formel im Query-String) | L |
| 06 | `POST .../databases/{dbid}/query` | schreibgeschützte Abfrage, Body `{"query": "..."}` | L |
| 07 | `POST .../databases/{dbid}/exec` | **schreibfähige** Abfrage, Body `{"query": "..."}` | S |
| 08 | `GET .../databases/{dbid}/tables` | Schema aller Tabellen (ID, Name, Felder) | L |
| 09 | `GET .../tables/{tid}` | Schema einer Tabelle mit Feld-IDs und Typen | L |
| 10 | `GET .../tables/{tid}/records` | alle Datensätze einer Tabelle | L |
| 11 | `GET .../records/{rid}` | ein Datensatz | L |
| 12 | `PUT .../records/{rid}` | einen Datensatz ändern, Body `{"fields": {...}}` | S |
| 13 | `GET .../records?filters={...}` | Datensatz suchen (Filter als JSON im Query-String) | L |
| 14 | `POST .../tables/{tid}/record` | einen Datensatz suchen, Body `{"filters": {...}}`. Pfad ist `/record` ohne "s" | L |
| 15 | `POST .../tables/{tid}/records` | mehrere Datensätze anlegen/ändern/Upsert (Body ist ein Array) | S |
| 16 | `DELETE .../records/{rid}` | einen Datensatz löschen | S |
| 17 | `DELETE .../tables/{tid}/records` | mehrere löschen, Body `[23, 24]` (Alternative `?ids=23,24`, Body bevorzugt) | S |
| 18 | `GET .../records/{rid}/files/{file}` | Datei laden (binär) | L |
| 19 | `POST .../records/{rid}/files` | Datei hochladen (`multipart/form-data`, Feld `file`), Antwort 202 | S |
| 20 | `DELETE .../files/{file}` | Datei löschen | S |
| 21 | `GET .../records/{rid}/files` | Metadaten aller Dateien | L |
| 22 | `GET .../files/{file}/metadata` | Metadaten einer Datei | L |
| 23 | `GET .../files/{file}/thumb.jpg` | Vorschaubild | L |
| 24 | `GET .../databases/{dbid}/views` | Schema aller Ansichten (PC) | L |
| 25 | `GET .../tables/{tid}/views` | Schema der Ansichten einer Tabelle (PC) | L |
| 26 | `GET .../tables/{tid}/views/{viewid}/share` | URL einer geteilten Ansicht (PC) | L |
| 27 | `POST .../views/{viewid}/share` | geteilte Ansicht anlegen/ändern (PC) | S |
| 28 | `DELETE .../views/{viewid}/share` | Teilen einer Ansicht aufheben (PC) | S |
| 29 | `GET .../files/{file}/share` | Freigabelink einer Datei (PC) | L |
| 30 | `POST .../files/{file}/share` | Freigabelink anlegen/ändern (PC) | S |
| 31 | `DELETE .../files/{file}/share` | Freigabelink löschen (PC) | S |

`...` steht für `/teams/{teamid}/databases/{dbid}/tables/{tid}` bzw. den davor genannten Pfad.

Hinweis zu Nr. 17: OpenAPI rät von einem Body bei DELETE ab, die Ninox-API verlangt ihn aber technisch. Das Werkzeug sendet den Body.

Freigabelinks (27, 30) machen Inhalte öffentlich erreichbar. Vor dem Anlegen immer ausdrücklich bestätigen lassen, welche Daten dadurch sichtbar werden.

## Felder und Filter

- Schreiben und Filtern brauchen Feld-IDs (z. B. `L`), nicht die Namen. Feld-IDs liefert Nr. 09 (`Get-Ninox3Table`).
- Auswahlfelder (`choice`) haben `choices` mit `id` und `caption`. Mit `choiceStyle=names` kommen Klarnamen zurück.
- Datensatz-Antwort: `id`, `sequence`, `createdAt`, `createdBy`, `modifiedAt`, `modifiedBy`, `fields`.

## Anlegen, ändern, Upsert (Nr. 15)

Body ist ein Array:

| Fall | Element |
|---|---|
| Anlegen | `{"fields": {"First name": "Andrea"}}` (keine `id`) |
| Ändern | `{"id": 1, "fields": {"First name": "Tom"}}` |
| Upsert | `{"_upsert": true, "_id": 43, "E": "Alfred", "G": "Becker"}` |

Das Beispiel für Upsert in der Swagger-Datei benutzt Feld-IDs (`E`, `G`) direkt am Element, die anderen Beispiele Feldnamen unter `fields`. Welche Schreibweise in welcher Instanz gilt, vor dem ersten Schreiben an einem einzelnen Test-Datensatz prüfen. Nicht verifiziert.

## Abfragen (Nr. 05 bis 07)

- `query` und `exec` nehmen eine **Ninox-Formel** als Text, z. B. `(select Contact).'First Name'`.
- `query` ist schreibgeschützt, `exec` darf Daten ändern (z. B. Datensätze anlegen, `users()` abfragen).
- Antwort ist ein Array.

Beispiele in Ninox Script siehe `ninox-script.md`.

## Was die API nicht bietet

Keine Endpunkte zum Anlegen oder Ändern von Datenbanken, Tabellen, Feldern, Ansichten (außer Teilen), Triggern oder Formeln. Siehe `schema-aenderungen.md`.
