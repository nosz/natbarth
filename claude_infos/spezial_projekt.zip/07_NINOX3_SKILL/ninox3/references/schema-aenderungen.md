# Schema ändern in Ninox 3

## Befund (belegt)

Die Swagger-Datei der Ninox-3-REST-API (Stand 2026-03-06, 31 Operationen) enthält für das Schema **nur lesende** Endpunkte:

| Gelesen werden kann | Endpunkt |
|---|---|
| Datenbank-Schema | `GET /teams/{teamid}/databases/{dbid}` |
| alle Tabellen mit Feldern | `GET .../tables` |
| eine Tabelle mit Feldern | `GET .../tables/{tid}` |
| Ansichten (nur Private Cloud) | `GET .../views`, `GET .../tables/{tid}/views` |

Endpunkte zum **Anlegen oder Ändern** von Datenbanken, Tabellen, Feldern, Triggern oder Formeln gibt es dort nicht. Die einzigen Schreib-Endpunkte betreffen Datensätze, Dateien und Freigaben.

## Folge für den Skill

- Der Skill **ändert kein Schema per API**. Er behauptet nicht, dass es geht.
- Schema-Änderungen macht der Nutzer in der Ninox-Oberfläche. Claude kann dabei helfen: Struktur lesen (Nr. 04, 08, 09), Änderungsplan schreiben, Ninox Script für Formeln und Trigger liefern, die der Nutzer einträgt.
- Nach einer Änderung in der Oberfläche liest Claude das Schema erneut und bestätigt den neuen Stand.

## Nicht geprüft

- Ob `exec` (Nr. 07) Schema verändern kann: in der Swagger-Datei nicht beschrieben, **nicht ausprobieren**.
- Ob eine neuere API-Version Schema-Endpunkte kennt: **nicht geprüft**. Wer es genau wissen will, fragt Ninox Support oder prüft die Dokumentation (https://forum.ninox.com/category/api). Auch die Forum-Doku der Public-Cloud- und Private-Cloud-Endpunkte (2026-10-27 gelesen) kennt für Schema nur lesende Aufrufe.

## Antwort an Nutzer, die "Schema per API ändern" verlangen

In einem Satz: In der Ninox-3-API ist das nach der vorliegenden Dokumentation nicht vorgesehen. Dann anbieten: (1) Änderungsplan und Skripte schreiben, (2) Schema lesen und nach der manuellen Änderung prüfen.
