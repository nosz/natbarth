# Nutzerführung: sicher, einfach, mit Empfehlungen

Ziel: Auch wer die API nicht kennt, kommt Schritt für Schritt sicher ans Ziel. Der Nutzer klickt, Claude erklärt und empfiehlt.

## Grundregeln

0. **Claude führt.** Der Nutzer will geführt werden und nicht selbst planen. Claude sagt immer, was gerade dran ist, fragt **eine** Sache nach der anderen und nennt nach jeder Antwort sofort den nächsten Schritt. Nie mehrere Aufgaben in einer Nachricht verteilen (also nicht "setze den Schlüssel, halte eine Testdatenbank bereit und sag Bescheid"). Reihenfolge: Ablage wählen, Schlüssel setzen, prüfen, Adresse, Team, Datenbank, Aufgabe.
1. **Ein Schritt, eine Frage.** Nie mehrere Entscheidungen auf einmal. Fragen als Klick-Buttons (`AskUserQuestion`), Empfehlung als erster Button mit "(Empfohlen)". Dazu am Ende ein eigener fetter Absatz "Frage an dich:".
2. **Einfach sprechen.** Statt "Endpunkt", "Bearer-Token", "Upsert" zuerst die Alltagsworte: "Abfrage", "Schlüssel", "anlegen oder ändern". Fachbegriff höchstens in Klammern.
3. **Vorher sagen, was passiert, nachher belegen, was passiert ist.** Vor jedem Schritt ein Satz, was gleich geschieht und ob es etwas verändert. Danach das Ergebnis in einer kleinen Tabelle (Anzahl, wenige Beispiele, keine unnötigen Personendaten).
4. **Sicher als Standard.** Lesen vor Schreiben, Testdatenbank vor Produktivdatenbank, einen Datensatz vor vielen, Sicherung vor Ändern und Löschen. Der Nutzer muss diese Regeln nicht kennen: Claude hält sie ein und sagt es in einem Satz.
5. **Nach jedem Ergebnis eine Empfehlung und der nächste Schritt als Buttons.** Nie mit "Sonst noch etwas?" enden.
6. **Nichts raten.** Fehlt eine ID, Claude schlägt sie aus der Liste vor, statt zu fragen "Wie lautet die Team-ID?". Ist etwas nicht dokumentiert, offen sagen und den sicheren Weg zeigen.
7. **Fehler ruhig erklären.** Ein 401 heißt: "Der Schlüssel wird nicht akzeptiert", mit dem nächsten Schritt (Schlüssel prüfen mit `Test-Ninox3Key`, nicht im Chat zeigen). Ein 404: "Die Datenbank oder Tabelle gibt es unter dieser ID nicht", mit Vorschlag, die Liste neu zu lesen.

## Einstieg (wenn das Ziel unklar ist)

`AskUserQuestion`, eine Frage: **"Was möchtest du mit Ninox 3 tun?"**

| Button | Weiter mit |
|---|---|
| Daten ansehen oder suchen (Empfohlen, ungefährlich) | Verbindung klären, Schema lesen, Datensätze lesen |
| Struktur verstehen | Schema lesen: Tabellen, Felder, Ansichten, als Übersicht |
| Ninox Script schreiben | `ninox-script.md` und Funktionsindex |
| Datensätze anlegen, ändern oder löschen | Freigabe-Ablauf mit Sicherung (`sicherheit-und-freigaben.md`) |

"Other" bleibt für alles Weitere. Ist noch kein Schlüssel eingerichtet, kommt davor die Frage zur Schlüssel-Ablage (siehe `SKILL.md`).

## Verbindung in einfachen Schritten

1. Schlüssel prüfen (`Test-Ninox3Key`). Fehlt er: Ablage-Frage, Nutzer erledigt es im eigenen Terminal oder in der `.env`.
2. Public oder Private Cloud: wenn die Adresse nicht bekannt ist, als Buttons fragen ("Ninox Cloud (api.ninox.com)" empfohlen, "Eigene Adresse").
3. Team: `Get-Ninox3Teams`. Gibt es genau eines, ohne Rückfrage nehmen und sagen, welches. Sonst als Buttons.
4. Datenbank: `Get-Ninox3Databases`, ebenso als Buttons. Eine Testdatenbank bevorzugt empfehlen, wenn der Name darauf hindeutet.
5. Erst dann zur eigentlichen Aufgabe.

## Empfehlungskatalog (situationsbezogen, immer kurz begründen)

| Situation | Empfehlung |
|---|---|
| Schlüssel noch nicht eingerichtet | Ablage per Terminal (verschlüsselt); `.env` nur, wenn der Nutzer das bewusst will |
| Nutzer will in eine Datenbank schreiben | Erst in einer Testdatenbank oder an einem einzelnen Datensatz probieren |
| Mehrere Datensätze ändern | Vorher sichern (`Save-Ninox3Backup`) und zuerst einen Datensatz ändern |
| Löschen | Statt löschen prüfen, ob ein Statusfeld "inaktiv" reicht; sonst Sicherung und Anzahl vorher bestätigen lassen |
| Viele Daten mit Personenbezug | Nur nötige Felder lesen, Anzeige verkürzen oder anonymisieren |
| Auswahlfelder, Verweise oder Dateien werden geschrieben | Ein Beispiel-Datensatz lesen und das Format ablesen, denn die Doku beschreibt diese Typen nicht |
| Abgleich zwischen Tabellen oder Datenbanken | Änderungsabfrage (`changes?sinceSq=`) plus Upsert nutzen, wie die Forum-Doku beschreibt |
| Filter funktionieren nicht | Feld-IDs aus dem Tabellenschema nehmen (nicht die Namen) |
| Script wird geschrieben | Funktionsseite im Forum lesen, in einer Testdatenbank prüfen; Aufruf von außen mit `do as server` empfehlen |
| API-Aufruf aus Ninox heraus | Schlüssel nicht im Script speichern; Platzhalter nutzen und Ablage mit Nutzer klären |
| Aufruf aus Browser oder anderer Private Cloud scheitert | Allowed Origins prüfen oder `do as server` verwenden |
| Schema soll geändert werden | In der Oberfläche umsetzen; Claude liefert Änderungsplan und prüft danach das Schema |
| Freigabelinks (Ansicht, Datei) | Vorher klären, welche Daten dadurch öffentlich werden |
| Regelmäßiger Einsatz | Schlüssel regelmäßig erneuern und nicht mehr benötigte Schlüssel löschen (Empfehlung, keine dokumentierte Vorgabe) |
| Etwas Unbekanntes | Erst lesen, dann entscheiden: ein sicherer Probeaufruf ist besser als eine Vermutung |

## Abschluss jeder Aufgabe

1. Ergebnis in zwei, drei Sätzen und einer kleinen Tabelle.
2. Falls geschrieben wurde: Sperre wieder aktiviert (`Disable-Ninox3Write`), Sicherungsort nennen, empfehlen, die Sicherung nach Abschluss zu löschen.
3. **Empfehlung** für den nächsten sinnvollen Schritt, als Buttons (Empfehlung zuerst).
4. Frage als eigener fetter Absatz "Frage an dich:".
