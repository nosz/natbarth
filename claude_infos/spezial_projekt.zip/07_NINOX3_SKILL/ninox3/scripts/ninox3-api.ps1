# Werkzeug fuer die Ninox-3-REST-API (api.ninox.com/v1 oder Private Cloud). Nur Ninox 3.
# Nutzung: Datei mit Punkt laden ( . .\ninox3-api.ps1 ), dann die Funktionen aufrufen.
# Das Token liegt DPAPI-verschluesselt im Benutzerprofil, nie im Chat, nie in Dateien.
# Schreibzugriffe sind gesperrt, bis Enable-Ninox3Write nach Freigabe des Nutzers aufgerufen wurde.

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$script:CfgDir   = Join-Path $env:LOCALAPPDATA 'Ninox3Skill'
$script:KeyFile  = Join-Path $script:CfgDir 'apikey.clixml'
$script:CfgFile  = Join-Path $script:CfgDir 'config.json'
$script:AuditLog = Join-Path $script:CfgDir 'audit.log'
$script:BackupDir = Join-Path $script:CfgDir 'backup'
$script:DefaultBase = 'https://api.ninox.com/v1'

function Initialize-Ninox3Dir {
    if (-not (Test-Path $script:CfgDir)) { New-Item -ItemType Directory -Path $script:CfgDir -Force | Out-Null }
}

# --- Konfiguration -----------------------------------------------------------

$script:EnvFile = Join-Path $script:CfgDir '.env'
$script:Placeholder = '<API_KEY>'

function Get-Ninox3Config {
    if (Test-Path $script:CfgFile) { return (Get-Content $script:CfgFile -Raw | ConvertFrom-Json) }
    return [pscustomobject]@{ BaseUrl = $script:DefaultBase; KeySource = 'terminal' }
}

function Save-Ninox3Config([string]$BaseUrl, [string]$KeySource) {
    Initialize-Ninox3Dir
    $cfg = Get-Ninox3Config
    $b = $script:DefaultBase; if ($cfg.BaseUrl) { $b = [string]$cfg.BaseUrl }
    $k = 'terminal'; if ($cfg.PSObject.Properties['KeySource'] -and $cfg.KeySource) { $k = [string]$cfg.KeySource }
    if ($BaseUrl)   { $b = $BaseUrl }
    if ($KeySource) { $k = $KeySource }
    @{ BaseUrl = $b; KeySource = $k } | ConvertTo-Json | Set-Content -Path $script:CfgFile -Encoding UTF8
}

function Set-Ninox3Key {
    # Ablage 2: Terminal. Im eigenen Terminal ausfuehren. Fragt das Token verdeckt ab,
    # speichert es DPAPI-verschluesselt im Benutzerprofil.
    Initialize-Ninox3Dir
    $secure = Read-Host -Prompt 'Ninox-3-Token (Eingabe verdeckt)' -AsSecureString
    $secure | Export-Clixml -Path $script:KeyFile
    Save-Ninox3Config -KeySource 'terminal'
    Write-Host "Token verschluesselt gespeichert: $script:KeyFile (Quelle: terminal)"
}

function Set-Ninox3EnvFile {
    # Ablage 1: .env. Legt NUR eine Vorlage mit Platzhalter an. Den Schluessel traegt der Nutzer
    # selbst im eigenen Editor ein. Claude schreibt und liest den Wert nie.
    # Die Datei liegt ausserhalb von OneDrive und Git (Benutzerprofil, nur fuer den Nutzer lesbar).
    Initialize-Ninox3Dir
    if (-not (Test-Path $script:EnvFile)) {
        Set-Content -Path $script:EnvFile -Value ('NINOX3_API_KEY=' + $script:Placeholder) -Encoding ASCII
        & icacls $script:EnvFile /inheritance:r /grant:r "$($env:USERNAME):(R,W)" | Out-Null
    }
    Save-Ninox3Config -KeySource 'env'
    Write-Host "Vorlage: $script:EnvFile (Quelle: env)"
    Write-Host "Naechster Schritt (du selbst): Datei im Editor oeffnen und $script:Placeholder durch den Schluessel ersetzen. Nicht im Chat zeigen."
}

function Get-Ninox3KeySource {
    $cfg = Get-Ninox3Config
    if ($cfg.PSObject.Properties['KeySource'] -and $cfg.KeySource) { return [string]$cfg.KeySource }
    return 'terminal'
}

function Get-Ninox3Token {
    # Intern. Gibt das Token nur im Speicher zurueck, nie in die Ausgabe.
    if ((Get-Ninox3KeySource) -eq 'env') {
        if (-not (Test-Path $script:EnvFile)) { throw 'Keine .env-Datei. Set-Ninox3EnvFile ausfuehren und den Schluessel selbst eintragen.' }
        $line = Get-Content $script:EnvFile | Where-Object { $_ -match '^\s*NINOX3_API_KEY\s*=' } | Select-Object -First 1
        if (-not $line) { throw 'NINOX3_API_KEY fehlt in der .env-Datei.' }
        $val = ($line -replace '^\s*NINOX3_API_KEY\s*=\s*', '').Trim().Trim('"').Trim("'")
        if (-not $val -or $val -eq $script:Placeholder) { throw 'In der .env steht noch der Platzhalter. Der Nutzer traegt den Schluessel selbst ein.' }
        return $val
    }
    if (-not (Test-Path $script:KeyFile)) { throw 'Kein Token gespeichert. Der Nutzer fuehrt Set-Ninox3Key im eigenen Terminal aus.' }
    $secure = Import-Clixml -Path $script:KeyFile
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Test-Ninox3Key {
    # Meldet nur, ob ein Schluessel gesetzt ist und ob die API ihn akzeptiert. Zeigt ihn nie an.
    $src = Get-Ninox3KeySource
    try { $null = Get-Ninox3Token } catch { Write-Host "Quelle: $src. Kein nutzbarer Schluessel: $($_.Exception.Message)"; return $false }
    try { $t = Get-Ninox3Teams; Write-Host "Quelle: $src. Schluessel akzeptiert, Teams: $(@($t).Count)"; return $true }
    catch { Write-Host "Quelle: $src. Schluessel gesetzt, API meldet: $($_.Exception.Message)"; return $false }
}

function Set-Ninox3BaseUrl {
    param([Parameter(Mandatory)][string]$BaseUrl)
    $url = $BaseUrl.TrimEnd('/')
    if ($url -notmatch '^https://[^/\s]+/v1$') { throw 'BaseUrl muss https://<host>/v1 sein.' }
    if ($url -match 'go\.ninox\.com') { throw 'go.ninox.com ist Ninox 4 und gehoert nicht zu diesem Skill.' }
    Save-Ninox3Config -BaseUrl $url
    Write-Host "Basis-Adresse gesetzt: $url"
}

function Get-Ninox3BaseUrl {
    if (Test-Path $script:CfgFile) {
        $cfg = Get-Content $script:CfgFile -Raw | ConvertFrom-Json
        if ($cfg.BaseUrl) { return [string]$cfg.BaseUrl }
    }
    return $script:DefaultBase
}

function Enable-Ninox3Write  { $env:NINOX3_WRITE = '1'; Write-Host 'Schreiben freigeschaltet (nur nach Freigabe des Nutzers).' }
function Disable-Ninox3Write { Remove-Item Env:\NINOX3_WRITE -ErrorAction SilentlyContinue; Write-Host 'Schreiben gesperrt.' }

# --- Kern --------------------------------------------------------------------

function Invoke-Ninox3 {
    param(
        [Parameter(Mandatory)][ValidateSet('GET','POST','PUT','DELETE')][string]$Method,
        [Parameter(Mandatory)][string]$Path,
        $Body = $null
    )
    if ($Path -match 'go\.ninox\.com') { throw 'Ninox 4 ist nicht Teil dieses Skills.' }

    # Lesende POSTs: query und record (Suche). Alles andere ausser GET ist Schreiben.
    $isRead = ($Method -eq 'GET') -or ($Method -eq 'POST' -and $Path -match '/(query|record)(\?.*)?$')
    if (-not $isRead -and $env:NINOX3_WRITE -ne '1') {
        throw "Schreibzugriff gesperrt: $Method $Path. Erst Freigabe des Nutzers einholen, dann Enable-Ninox3Write."
    }

    $token = $null
    try {
        $token = Get-Ninox3Token
        $uri = (Get-Ninox3BaseUrl) + $Path
        $headers = @{ Authorization = "Bearer $token" }
        $args2 = @{ Method = $Method; Uri = $uri; Headers = $headers }
        if ($null -ne $Body) {
            $json = ConvertTo-Json -InputObject $Body -Depth 20 -Compress
            $args2.Body = [Text.Encoding]::UTF8.GetBytes($json)
            $args2.ContentType = 'application/json; charset=utf-8'
        }
        Initialize-Ninox3Dir
        Add-Content -Path $script:AuditLog -Value ('{0:s} {1} {2}' -f (Get-Date), $Method, $Path) -Encoding UTF8
        try {
            Invoke-RestMethod @args2
        } catch {
            $code = $null
            if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
            throw "Ninox-3-API Fehler $code bei $Method $Path"
        }
    } finally {
        $token = $null
    }
}

function ConvertTo-Ninox3Style([string]$Style) {
    if ($Style) { return "?style=$Style&choiceStyle=$Style" }
    return ''
}

# --- Lesen (frei) ------------------------------------------------------------

function Get-Ninox3Teams { Invoke-Ninox3 -Method GET -Path '/teams' }
function Get-Ninox3Databases { param([Parameter(Mandatory)][string]$TeamId) Invoke-Ninox3 -Method GET -Path "/teams/$TeamId/databases" }
function Get-Ninox3Schema { param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId) Invoke-Ninox3 -Method GET -Path "/teams/$TeamId/databases/$DbId" }
function Get-Ninox3Tables { param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId) Invoke-Ninox3 -Method GET -Path "/teams/$TeamId/databases/$DbId/tables" }
function Get-Ninox3Table { param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId) Invoke-Ninox3 -Method GET -Path "/teams/$TeamId/databases/$DbId/tables/$TableId" }

function Get-Ninox3Records {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,
          [hashtable]$Filters,[ValidateSet('','ids','names')][string]$Style = '')
    $p = "/teams/$TeamId/databases/$DbId/tables/$TableId/records"
    $q = @()
    if ($Style) { $q += "style=$Style"; $q += "choiceStyle=$Style" }
    if ($Filters) { $q += 'filters=' + [uri]::EscapeDataString((ConvertTo-Json -InputObject $Filters -Compress)) }
    if ($q.Count) { $p += '?' + ($q -join '&') }
    Invoke-Ninox3 -Method GET -Path $p
}

function Get-Ninox3Record {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)][string]$RecordId,
          [ValidateSet('','ids','names')][string]$Style = '')
    Invoke-Ninox3 -Method GET -Path ("/teams/$TeamId/databases/$DbId/tables/$TableId/records/$RecordId" + (ConvertTo-Ninox3Style $Style))
}

function Find-Ninox3Record {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)][hashtable]$Filters)
    Invoke-Ninox3 -Method POST -Path "/teams/$TeamId/databases/$DbId/tables/$TableId/record" -Body @{ filters = $Filters }
}

function Invoke-Ninox3Query {
    # Schreibgeschuetzte Ninox-Formel, z. B. "(select Contact).'First Name'"
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$Query)
    Invoke-Ninox3 -Method POST -Path "/teams/$TeamId/databases/$DbId/query" -Body @{ query = $Query }
}

function Get-Ninox3Views {
    # Nur Private Cloud / On-Premises
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId)
    Invoke-Ninox3 -Method GET -Path "/teams/$TeamId/databases/$DbId/views"
}

function Get-Ninox3Changes {
    # Aenderungen seit Sequenznummer (Forum-Doku, lesend). Ohne TableId: ganze Datenbank.
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[string]$TableId,[Parameter(Mandatory)][int]$SinceSq)
    $p = "/teams/$TeamId/databases/$DbId"
    if ($TableId) { $p += "/tables/$TableId" }
    Invoke-Ninox3 -Method GET -Path ($p + "/changes?sinceSq=$SinceSq")
}

function Save-Ninox3Backup {
    # Sichert Datensaetze lokal als JSON, bevor geaendert oder geloescht wird.
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[hashtable]$Filters)
    if (-not (Test-Path $script:BackupDir)) { New-Item -ItemType Directory -Path $script:BackupDir -Force | Out-Null }
    $data = Get-Ninox3Records -TeamId $TeamId -DbId $DbId -TableId $TableId -Filters $Filters
    $file = Join-Path $script:BackupDir ('{0}_{1}_{2:yyyyMMdd_HHmmss}.json' -f $DbId, $TableId, (Get-Date))
    ConvertTo-Json -InputObject $data -Depth 20 | Set-Content -Path $file -Encoding UTF8
    Write-Host "Sicherung: $file"
    return $file
}

# --- Schreiben (nur nach Freigabe, Enable-Ninox3Write) ----------------------

function New-Ninox3Records {
    # Body ist ein Array, z. B. @(@{ fields = @{ 'First name' = 'Andrea' } })
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)]$Records)
    Invoke-Ninox3 -Method POST -Path "/teams/$TeamId/databases/$DbId/tables/$TableId/records" -Body @($Records)
}

function Set-Ninox3Record {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)][string]$RecordId,[Parameter(Mandatory)][hashtable]$Fields)
    Invoke-Ninox3 -Method PUT -Path "/teams/$TeamId/databases/$DbId/tables/$TableId/records/$RecordId" -Body @{ fields = $Fields }
}

function Remove-Ninox3Record {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)][string]$RecordId)
    Invoke-Ninox3 -Method DELETE -Path "/teams/$TeamId/databases/$DbId/tables/$TableId/records/$RecordId"
}

function Remove-Ninox3Records {
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$TableId,[Parameter(Mandatory)][int[]]$RecordIds)
    Invoke-Ninox3 -Method DELETE -Path "/teams/$TeamId/databases/$DbId/tables/$TableId/records" -Body @($RecordIds)
}

function Invoke-Ninox3Exec {
    # Schreibfaehige Ninox-Formel. Nur nach Freigabe, Skripttext vorher dem Nutzer zeigen.
    param([Parameter(Mandatory)][string]$TeamId,[Parameter(Mandatory)][string]$DbId,[Parameter(Mandatory)][string]$Query)
    Invoke-Ninox3 -Method POST -Path "/teams/$TeamId/databases/$DbId/exec" -Body @{ query = $Query }
}
