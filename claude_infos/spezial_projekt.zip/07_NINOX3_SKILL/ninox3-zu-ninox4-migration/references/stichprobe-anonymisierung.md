# Testdaten: Stichprobe, Anonymisierung, Import (Phase 5)

Die Teststrecke importiert nur eine kleine, verknüpfungstreue Stichprobe, nie den ganzen Bestand. Der Vollimport ist eine spätere, getrennte Entscheidung.

## 1. Stichprobe wählen

```powershell
. .\scripts\ninox3-reader.ps1; . .\scripts\ninox3-stichprobe.ps1
$schema = Read-Ninox3Schema -DataDb arbeit\ohne\data.db
$s = Select-Ninox3Sample -DataDb arbeit\mit\data.db -Schema $schema -MainTypeId '<HAUPTTABELLE>' -Count 20 -Seed 42 -IncludeChildren
```

- **Haupttabelle:** die Tabelle, auf die die meisten Verweise zeigen (im Beispiel `B` "Master"). Aus `01_tabellen.csv` und den Verweisfeldern ableiten und dem Nutzer vorschlagen.
- **Verknüpfungstreu:** Alle Datensätze, auf die ausgewählte Datensätze verweisen, werden rekursiv ergänzt. Mit `-IncludeChildren` kommen Datensätze hinzu, die auf die Hauptdatensätze verweisen (eine Ebene, samt ihren Verweisen). Kontrolle: `DanglingRefs` muss leer sein, und jeder Verweis der Stichprobe zeigt auf einen Datensatz der Stichprobe.
- **Randfälle:** Je Kategorie werden gezielt Datensätze aufgenommen (viele leere Felder, Dateiwert, Sonderzeichen), der Rest zufällig mit festem `-Seed`. Gleicher Seed ergibt dieselbe Auswahl (reproduzierbar, für die Abnahme wichtig).
- **Überschreiben:** `-Ids 10317,10401` wählt Hauptdatensätze von Hand.
- Am Beispiel (20 Hauptdatensätze): 111 Verweise, alle aufgelöst, Stichprobe aus 7 Tabellen.

## 2. Personenbezug klären und anonymisieren

Standard: **anonymisieren** (`anonymize: true`). Ausnahme nur auf ausdrückliche Anweisung des Nutzers, mit Vermerk im Protokoll.

1. `Get-Ninox3PiiCandidates -Schema $schema` listet Textfelder, die nach Beschriftung, Freitext oder HTML personen- oder firmenbezogen aussehen. Das ist ein **Vorschlag**: dem Nutzer die Liste zeigen (Tabelle, Beschriftung, Grund), ergänzen und bestätigen lassen. Zusätzlich prüfen: Auswahlfelder mit Firmennamen, Dateinamen (`file`), Berichte mit Klartext.
2. `Invoke-Ninox3Anonymize -Sample $s -Fields <bestätigte Schlüssel "T.F"> -Schema $schema`. Mit `-Schema` werden Dateifelder erkannt: Dateinamen werden zu `datei-N.<Endung>`. Gleicher Originalwert ergibt überall denselben Ersatz, E-Mail-Form bleibt E-Mail-Form (`personN@example.invalid`), Telefonform bleibt Telefonform. Zahlen, Datumswerte, Verweise und Statuswerte bleiben, damit Formeln und Abnahme aussagekräftig bleiben. Die Zuordnung Original zu Ersatz wird nicht gespeichert.
3. **Restprüfung:** `Test-Ninox3SampleForPii` zählt E-Mail- und Telefonmuster je Feld. Treffer: Feld prüfen, in die Feldliste aufnehmen, wiederholen. Ziel: keine Treffer.
4. **Einbettungen:** Echtdaten, die fest in Formeln stehen (im Beispiel Firmenadressen in `if … like`-Ketten), erfasst die Datenanonymisierung nicht. Sie in der Lückenliste als "Echtdaten in Formel" führen und mit dem Nutzer entscheiden, ob die Formel im Testmodul in anonymisierter Form gebaut wird.
5. Dateinamen in `file`-Feldern können Personen- oder Firmenbezug enthalten (z. B. Rechnungsnummern). Standard: durch neutrale Namen ersetzen.

## 3. Umwandeln

```powershell
$mapping = Import-Csv ergebnis\06_mapping_vorschlag.csv -Delimiter ';' | Where-Object Freigabe -eq 'freigegeben'
$payload = ConvertTo-Ninox4Payload -Sample $s -Schema $schema -Mapping $mapping -DateFormat '<geprüftes Format>'
```

Ergebnis je Ninox-4-Tabelle: Liste von `{ altId, werte, refs }`. Formel- und Rückverweisfelder entfallen, Auswahl-IDs sind zu Labels geworden, Verweise stehen getrennt in `refs`. Mit `Save-Ninox3Json` nach `arbeit\` speichern (enthält trotz Anonymisierung Struktur und Reste: nicht versionieren).

## 4. Probeimport

Vor dem Import der Stichprobe **einen** Datensatz mit je einem Feld pro Typ schreiben (Zahl, Text, Auswahl, Datum, Zeitstempel, Mehrfachauswahl, Datei als Name), zurücklesen und mit der Quelle vergleichen. Bekannt (beobachtet): Datum `yyyy-MM-dd` ist richtig, das deutsche Format `dd.MM.yyyy` ergibt den falschen Tag; Zeitstempel werden als UTC gespeichert. Zu klären bleibt vor allem die Form der Mehrfachauswahl und der Dateifelder. Probedatensatz danach entfernen oder zählen und im Protokoll vermerken.

## 5. Import in zwei Durchgängen

1. Tabellen in Abhängigkeitsreihenfolge (Ziele von Verweisen zuerst). Je Tabelle `POST .../records` mit `{"records": [ ... ]}`. Nutzlast unter etwa 6 MB halten, im Zweifel in Teilen senden. Antwort `data.ids` auf Anzahl und Reihenfolge prüfen und die Zuordnung `altId` zu neuer ID in `arbeit/idmap_<tabelle>.json` ablegen. Anzahl neu angelegter Datensätze gleich Quellzeilen, sonst stoppen.
2. Verweise: je Datensatz `PATCH .../records` mit `{"id": <neue ID als Zahl>, "<feld>": "<neue Ziel-ID als String>"}`. Die Ziel-ID aus der Zuordnung der Zieltabelle holen. Verweise ohne Zuordnung nicht raten, sondern melden.
3. Anschließend je Tabelle Zeilenzahl zurücklesen und in die Abnahme übernehmen (`abnahme.md`).
   Danach die Pflicht setzen (`PATCH .../fields/{feld}` mit `required: true` für die Felder, die in Ninox 3 Pflicht waren). Das geht auch bei leeren Altwerten. Zuvor zählen, wie viele Stichprobendatensätze einen leeren Pflichtwert haben, und als Befund festhalten.
4. Dateifelder: bleiben leer. Ninox 4 lehnt Dateinamen als Text ab und verlangt ein Datei-Objekt aus einem Upload (beobachtet 2026-10-06); der Upload-Weg gehört zum späteren Vollimport.

Die API-Aufrufe laufen über `Invoke-Ninox` des Builders (PowerShell, UTF-8-Bytes, `Authorization: Bearer <API_KEY>` aus `$env:NINOX_API_KEY`). Jeder schreibende Aufruf wird in `ergebnis/schreibprotokoll.csv` festgehalten (Zeit, Tabelle, Anzahl, Ergebnis), nie mit Datensatzinhalten.

## 6. Aufräumen

Am Projektende `arbeit/` löschen oder sicher verschlüsselt ablegen, wenn der Nachweis es verlangt. Entscheidung und Zeitpunkt im Protokoll festhalten.
