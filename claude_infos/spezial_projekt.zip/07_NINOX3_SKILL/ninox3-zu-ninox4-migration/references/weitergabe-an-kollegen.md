# Den Skill an Kolleginnen und Kollegen weitergeben

> **Überholt (2026-10-08).** Dieser Text beschreibt das frühere Paket `1_SKILL_zum_Weitergeben` (mit `START_HIER.txt`, `Installieren.ps1`). Das aktuelle Paket besteht nur aus dem Ordner `.claude` plus `LIESMICH.md` und `VERSION.txt`; die Schritte stehen in dessen `LIESMICH.md`. Die Prüfpunkte unten nur als Hintergrund lesen.

Kurz: **Nur den Ordner `1_SKILL_zum_Weitergeben` weitergeben**, vorher den Weitergabe-Check laufen lassen, der Kollege kopiert den Ordner `.claude` in seinen Bearbeitungsordner und startet mit einem Satz. Mehr braucht es nicht.

## 1. Vor der Weitergabe (Absender, 5 Minuten)

Der Weitergabeordner `1_SKILL_zum_Weitergeben` enthält den Ordner `.claude\skills` mit **drei Skills** (`ninox-start`, `ninox3-zu-ninox4-migration`, `ninox4-api-builder`), die Datei `START_HIER.txt`, das optionale Installationsskript `Installieren.ps1` und die Anleitung `LIESMICH_Installation.md`.

1. **Weitergabe-Check für jeden der drei Skills** (nur lesend, zeigt nie Inhalte). In PowerShell im Ordner `ninox3-zu-ninox4-migration`:

   ```powershell
   . .\scripts\ninox-support.ps1; . .\scripts\ninox-pruefungen.ps1
   foreach ($s in 'ninox-start','ninox3-zu-ninox4-migration','ninox4-api-builder') {
     $r = Test-NinoxSkillFuerWeitergabe -SkillDir "..\$s" -OhneSelbsttest:($s -ne 'ninox3-zu-ninox4-migration')
     "$s : Bestanden=$($r.Bestanden)"; $r.Pruefungen | Where-Object Ergebnis -ne 'ok' | Format-Table
   }
   ```

   Überall `Bestanden=True`: SKILL.md vollständig, keine Projekt- oder Datenordner, keine Daten- oder Archivdateien, kein Key, keine fremden E-Mail-Adressen.
2. **Selbsttest:** `. .\scripts\selftest.ps1; Invoke-Ninox3Selbsttest` muss mit `alle Pruefungen ok` enden (aktuell 77 von 77).
3. **Installationsprobe:** `powershell -NoProfile -ExecutionPolicy Bypass -File .\Installieren.ps1 -Ziel "$env:TEMP\probe"` im Weitergabeordner (schreibt nur in den Temp-Ordner).
4. **Weitergeben:** Den ganzen Ordner `1_SKILL_zum_Weitergeben` kopieren (Laufwerk, Teamablage, Mail) oder die Datei `ninox-skillpaket_v0.9.zip`, **nichts sonst**. Nie weitergeben: Ordner `arbeit` (echte Kundendaten), `.ninox`-Sicherungen, `soll_*.csv`, Ergebnisordner, Sicherungen, Konfigurationen, Keys.

## 2. Was der Kollege braucht

- Windows, PowerShell 5.1, Claude Code (Desktop-App oder Terminal).
- Den Skill `ninox4-api-builder`: **liegt im Paket** (unverändert übernommen). Bei größeren Arbeiten nutzt er außerdem den Skill `ninox` aus `anthropic-skills`, falls im Konto vorhanden.
- Für eine Migration: zwei Sicherungen seiner Ninox-3-Lösung (einmal ohne, einmal mit Datensätzen).
- Einen **Ninox-4-Testworkspace** und einen **eigenen** API-Key dafür. Der Key des Absenders wird nie weitergegeben; jeder legt seinen eigenen an (der Skill erklärt es Schritt für Schritt).
- Bei Fragen zu Datenschutz, Verträgen oder Sicherheitsvorfällen gelten die bekannten Wege (IT: it@ninox.com, Sicherheitsvorfälle sofort melden).

## 3. Installation (Kollege)

**Standard:** Ordner `.claude` aus dem Weitergabeordner in den eigenen Bearbeitungsordner kopieren (bei Rückfrage zusammenführen), Claude dort neu starten, `Ninox Start` schreiben. Kein Skript nötig. **Alternative für alle Projekte:** PowerShell öffnen (oder das Terminal `>_` in der Claude-App), in den Weitergabeordner wechseln, `powershell -NoProfile -ExecutionPolicy Bypass -File .\Installieren.ps1` ausführen (der Zusatz gilt nur für diesen einen Aufruf, weil Windows Skripte sonst oft blockiert), Claude neu starten (Einzelheiten in `LIESMICH_Installation.md`). Das Skript überschreibt nichts, prüft die Skills und führt den Selbsttest aus.
## 4. Start und Arbeitsweise mit dem Kollegen

Startsatz: **"Ninox Start"** (oder `/ninox-start`). Der Skill fragt als Erstes, was der Nutzer tun will (Ninox-3-App-Erstellung, derzeit nicht aktiv; Ninox-4-App-Erstellung; Migration), und übergibt dann an den passenden Skill. Von da an gilt für jede Nachricht:

1. **Genau eine Frage oder ein Schritt pro Nachricht.** Nie mehrere Fragen auf einmal, nie eine Aufgabenliste. Erst nach der Antwort kommt das Nächste.
2. **Zu jeder Entscheidung eine Empfehlung mit kurzer Begründung**, die Empfehlung zuerst. "ok" übernimmt sie; für Schreiben und Löschen braucht es ein ausdrückliches Ja.
3. **Einfach in der Sprache, professionell im Ergebnis:** kurze Sätze, Fachwörter einmal erklärt, jede Aufgabe für den Nutzer mit Wo (System und Workspace mit Klarnamen), Problem in einem Satz, Schritten und Erfolgskontrolle.
4. **Fortschritt zeigen** ("Schritt 3 von 6") und nach jeder Phase höchstens fünf Zeilen Zwischenstand.
5. **Ehrlich bleiben:** Was nicht belegt ist, wird als "nicht belegt" benannt (zum Beispiel die Formelwerte ohne Ninox-3-Export).

Der Kollege muss nichts Technisches wissen. Der Skill prüft selbst, was sich prüfen lässt, und lässt dem Kollegen nur, was nur er tun kann (Key erzeugen, Export machen, Entscheidungen treffen).

## 5. Wichtig für den Kollegen

- Der Skill schreibt nur nach ausdrücklicher Freigabe pro Phase, nur in neue, leere Module, und löscht nie ohne exakte Bestätigung.
- Die echten Daten bleiben lokal im Projektordner (`arbeit`). Dieser Ordner wird nie weitergegeben und am Ende nach Entscheidung des Nutzers gelöscht.
- Stand: Version 0.9, Teststrecke. Für eine produktive Vollmigration zuerst `stand-und-offene-punkte.md` lesen.
- Rückmeldungen und Fehler: an den Absender und, bei Ninox-Fehlern, über die fertigen Meldungen in `ergebnis/support/` an den Ninox Support.