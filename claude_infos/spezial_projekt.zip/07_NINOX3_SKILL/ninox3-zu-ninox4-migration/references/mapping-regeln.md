# Mapping-Regeln Ninox 3 nach Ninox 4

Jede Regel trägt einen Beleggrad: **belegt** (Quelle genannt), **beobachtet** (in der Praxis gesehen, nicht dokumentiert), **Vorschlag** (plausibel, nicht belegt, im Test klären). Quellen: `ninox`-Skill (`SKILL.md`, `references/field-types-and-values.md`), `ninox4-api-builder/references/ninox4-api-notizen.md`, OpenAPI. Bei Abweichung gilt die Live-OpenAPI.

## Namen: klar und lesbar

In Ninox 4 sind Modul-, Tabellen- und Feldnamen die technischen IDs (sie stehen in Pfaden, Nutzlasten und Formeln). Die sichtbare Bezeichnung steht in `labels`. Beides muss für Menschen verständlich sein, weil Formeln, Skripte und Support damit arbeiten.

| Regel | Beleg |
|---|---|
| Namen von Modul, Tabelle und Feld: `^[a-z0-9_]+$`, höchstens 100 Zeichen | belegt (`ninox`-Skill) |
| Die Original-Beschriftung bleibt als `labels` (Spalte `Ninox4Label`), damit die Oberfläche unverändert lesbar bleibt | belegt (`labels` ist Pflicht beim Anlegen) |
| Name = Beschriftung in Kleinbuchstaben, ä/ö/ü/ß als ae/oe/ue/ss, Wortgrenzen als `_` (z. B. "Lieferdatum" zu `lieferdatum`, "Kunde Name" zu `kunde_name`) | Vorschlag (Skript `Convert-ToNinox4Name`) |
| Nie die internen Ninox-3-IDs (`O2`, `D1`) als Namen, nie Zufallskürzel | Festlegung dieses Skills |
| Doppelte Beschriftung in einer Tabelle: laufende Nummer (`datum`, `datum_2`) und Meldung in `Namenshinweis`; der Nutzer vergibt in Phase 2 einen unterscheidbaren Namen (z. B. `lieferdatum`, `abholdatum`) | Festlegung dieses Skills |
| Leere Beschriftung: `feld_1`, `feld_2` und Meldung; der Nutzer benennt sie | Festlegung dieses Skills |
| Warnung bei: höchstens 2 Zeichen, nummerierte Namen, mehr als 40 Zeichen, Namen wie die Schlüsselwörter `if`, `then`, `end`, `select` (Kollision unbelegt). `date`, `number` und `id` sind im Test als Feldnamen akzeptiert und rechnen in Formeln korrekt | Festlegung dieses Skills, Test 2026-10-06 |
| Beim Umbenennen eines Feldes alle Formeln mit dem alten Namen vorher anpassen | belegt (`ninox`-Skill) |

**Ablauf:** Der Vorschlag entsteht automatisch (`New-Ninox3MappingProposal`). `Test-Ninox4Names` meldet Fehler (müssen behoben werden: falsches Muster, doppelt, leer) und Warnungen (Entscheidung des Nutzers). In Phase 2 zeigt der Skill die Warnungen, schlägt bessere Namen vor und trägt freigegebene Änderungen in die Mapping-Datei ein. Erst danach wird gebaut. Weil Formeln die Namen verwenden, wird die Formelanalyse nach jeder Namensänderung neu erzeugt. Datensatz-IDs sind etwas anderes: sie vergibt Ninox 4 selbst.

**Oberfläche und interner Name sind getrennt.** Die Anwender sehen das Label, nicht den internen Namen. Standard: Label = Original-Beschriftung aus Ninox 3, die Oberfläche bleibt also vertraut. Ninox-3-Kürzel (`O2`) sind nie sichtbar und entfallen. Bleiben Beschriftungen selbst kryptisch (Fachkürzel wie "PO", "SO"), bietet der Skill in Phase 2 eine **optionale** Spalte `Ninox4LabelVorschlag` an: Er schlägt dort nur für die gewarnten Felder (sehr kurz, nummeriert) eine ausgeschriebene Bezeichnung vor (z. B. "Einkaufsbestellung (PO)"). Gebaut wird `Ninox4LabelVorschlag`, wenn der Nutzer sie ausgefüllt oder freigegeben hat, sonst `Ninox4Label`. Ohne Entscheidung des Nutzers bleibt die Spalte leer, weil die Anwender die alten Begriffe kennen. Wie Ninox 4 das Label auf der Oberfläche zeigt, ist im Test-Workspace zu bestätigen.

**Gute Namen in der Praxis:** Fachbegriff vor Abkürzung (`kunde` statt `kd`), Bedeutung vor Position (`lieferdatum` statt `datum_2`), Verweisfelder nach dem Ziel benennen (`kunde`, nicht `kunde_ref`), Wahrheitswerte als Aussage (`rechnung_bezahlt`). Bleiben Abkürzungen der Fachanwender üblich (z. B. `po`, `so`), diese bewusst beibehalten und im Plan als solche bestätigen lassen.

## Feldtypen

| Ninox 3 (`base`) | Ninox 4 (`type`, `variant`) | Beleg / Hinweis |
|---|---|---|
| `string` | `string`, `text`; mehrzeilig (`stringMultiline`) `multiline-text` | belegt |
| `number` | `number` | belegt |
| `boolean` | `boolean` | belegt |
| `date` | `date` | belegt |
| `timestamp` | `timestamp` | belegt |
| `choice` | `choice` mit `options` | belegt; Optionen vollständig bei Anlage angeben |
| `multi` | `multi` | belegt; Schreibform Array von Strings, Quellform im Export prüfen |
| `file` | `file` | belegt; Schreiben im JSON-Weg nur als String |
| `ref` | `reference` mit `refTableName` | belegt; Verweise gelten nur innerhalb eines Moduls |
| `rev` | `reverse`, aber **nicht einzeln anlegen** | beobachtet: Ninox erzeugt den Rückverweis automatisch mit dem Verweisfeld; danach nur umbenennen (`PATCH` name und labels). Ein einzeln angelegtes `reverse`-Feld erzeugt ein zusätzliches, getrenntes Verweisfeld |
| Feld mit `fn` | `function` mit `expression` | belegt (`ninox`-Skill, live geprüft); Rückgabetyp aus Ninox-3-Basis ableiten |
| `link` | `string` mit `variant: url` | Vorschlag, unbelegt |
| `html` | `html` (steht im Feldtyp-Enum der OpenAPI 1.0.0) | Typ belegt, Entsprechung des Ninox-3-Feldes ungeprüft, Mapping-Status `ungeklaert` |

Die Felder `type`, `variant` und `refTableName` lassen sich laut `ninox`-Skill nicht per PATCH ändern. Ein Fehler beim Typ heißt: Feld löschen und neu anlegen (nur im leeren Zielmodul, nie mit Echtdaten).

## Eigenschaften

| Ninox 3 | Ninox 4 | Beleg |
|---|---|---|
| `required` | `required`, aber **nach dem Import setzen** | belegt; beobachtet: wird beim Anlegen erzwungen, nachträgliches Setzen geht auch bei leeren Altwerten |
| `hasIndex` | `index` | belegt (PATCH-Felder) |
| `globalSearch` | `search` | belegt |
| `readRoles`/`writeRoles` am Feld | gleichnamige Arrays; Rolle `user` ist laut OpenAPI ein veralteter Alias für `editor` | belegt für Format; Rollenzuordnung ist Vorschlag und braucht Freigabe |
| Tabellenrechte | `readRoles`/`writeRoles`/`createRoles`/`deleteRoles`; zusätzlich Zugriffsausdrücke `canRead`/`canWrite`/`canCreate`/`canDelete` | belegt für Format (OpenAPI 1.0.0) |
| `cascade` (kaskadierendes Löschen) | keine belegte Entsprechung | Lücke |
| Standardwerte (`numberDefault`, `choiceDefault`, ...) | `defaultValue` am Feld (Wert oder Skriptausdruck; bei Auswahl das Label) | belegt in der OpenAPI; beobachtet: wird beim Anlegen per API nicht angewendet, beim Import also alle Werte ausdrücklich schreiben |
| `visibility` (Sichtbarkeitsausdruck) | `canRead`/`canWrite` regeln den Zugriff, nicht die Anzeige; keine belegte Entsprechung | Lücke |
| Trigger (`afterUpdate`) | Feld `onUpdate`, Tabelle `onCreate`/`onUpdate`/`onDelete` (Skriptausdruck) | belegt in der OpenAPI; Übersetzung wie Formel (`formeln.md`), im Test prüfen; Hinweis: Änderungen über die API lösen keine Trigger aus (`ninox4-api-notizen.md`, beobachtet) |

## Auswahlfelder

Ninox 3 speichert in Datensätzen die **Wert-ID** (z. B. `"2"`), Ninox 4 erwartet beim Schreiben das **Label** (`ninox`-Skill: label-sensitiv, Schreibweise inklusive Leerzeichen und Großschreibung). Die Umwandlung geschieht in `ConvertTo-Ninox4Payload` über `values.<ID>.caption`. Labels mit abschließendem Leerzeichen kommen in Quelldaten vor und müssen unverändert bleiben.

## Verweise und Datensatz-IDs

- Ninox 3 verweist per Nummer des Zieldatensatzes, Ninox 4 vergibt beim Anlegen **neue IDs** (Antwort `data.ids`, in Reihenfolge der Anfrage; vor Folgeschritten Anzahl gleich Quellzeilen prüfen).
- Deshalb zwei Durchgänge: erst alle Datensätze ohne Verweise anlegen und die Zuordnung alt zu neu je Tabelle lokal führen (`arbeit/idmap_<tabelle>.json`), dann Verweisfelder per PATCH setzen (Wert: String-ID des Zieldatensatzes).
- Reihenfolge der Tabellen nach Verweisabhängigkeit ordnen, Selbstverweise gesondert behandeln (Probe an Wegwerf-Tabelle, siehe `ninox`-Skill).
- Rückverweise (`reverse`, `function`) nie in Schreib-Nutzlasten aufnehmen. Rückverweise werden nicht angelegt, sondern nach dem Verweisfeld gesucht und umbenannt (`api-faehigkeiten.md`).

## Datum und Zeit

Ninox 3: Millisekunden seit 1970 (UTC). Ninox 4 (beobachtet): `date` als `yyyy-MM-dd`, `timestamp` als `yyyy-MM-ddTHH:mm:ss` (wird als UTC gespeichert). **Deutsches Format (`06.10.2026`) wird als Monat.Tag gelesen und ergibt den falschen Tag: nie verwenden.** Vor dem Import weiterhin **einen Testdatensatz** schreiben und zurücklesen, um Format und Zeitzone im Zielworkspace zu bestätigen. `ConvertTo-Ninox4Payload -DateFormat -TimestampFormat` übernimmt das Ergebnis. Zeitzonenabweichung ist ein Abnahmebefund (`abnahme.md`).

## Dateien

Ein Dateiname als Text wird von Ninox 4 **abgelehnt** (beobachtet 2026-10-06): erwartet wird ein Datei-Objekt (`documentId`, `documentVersionId`, `fileName`, `fileSize`, `fileType`), das ein Upload liefert (`files/upload-url`, `files/complete`, `POST .../records/{id}/files`). Die Ninox-3-Sicherung enthält keine Dateien, nur Namen. In der Teststrecke bleiben Dateifelder leer (`ConvertTo-Ninox4Payload` hält die Namen in `dateien`); Anhänge folgen im Vollimport, sofern es eine Quelle gibt.

## Mapping-Datei `06_mapping_vorschlag.csv`

Spalten: `TabelleId`, `Tabelle`, `FeldId`, `Beschriftung`, `Basis3`, `Ninox4Tabelle`, `Ninox4TabelleLabel`, `Ninox4Feld`, `Ninox4Label`, `Ninox4LabelVorschlag`, `Ninox4Typ`, `Ninox4Variante`, `Pflicht`, `Status`, `Freigabe`, `Namenshinweis`, `Hinweis`. Status: `automatisch` (Typ belegt zugeordnet), `formel` (Formelfeld, Übersetzung in Phase 4), `manuell`, `ungeklaert`. Die Hinweise nennen nur Schlüsselnamen und Längen, nie Werte aus der Lösung. `Freigabe` bleibt `offen`, bis der Nutzer den Plan freigibt; erst dann `freigegeben` setzen. Nur freigegebene Zeilen werden in Ninox 4 gebaut.
