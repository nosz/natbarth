# Dokumentationsmodul

Ein eigenes Modul `<ZIEL_MODUL>_migration_doku` im selben Workspace hält Inventar, Mapping, Lücken, Schreibprotokoll, Abnahme und Optimierung an einem Ort. Es ersetzt die lokalen Dateien nicht: Die lokalen Dateien in `ergebnis/` sind der Nachweis, das Modul ist die Arbeitsansicht.

## Regeln

- **Getrennt von der migrierten Anwendung.** Die App soll am Ende sauber live gehen. Das Dokumentationsmodul hat eigene Rechte und lässt sich nach dem Projekt archivieren.
- **Keine Echtdaten.** Nur Struktur, Zähler, IDs, Status, Beschriftungen. Keine Datensatzinhalte, keine Formeltexte mit eingebetteten Firmen- oder Personendaten.
- **Keine Verweise auf das Zielmodul.** Verweise gelten nur innerhalb eines Moduls (`ninox`-Skill). Tabellen- und Feldnamen des Ziels werden als Text gespeichert.
- Namen nach `^[a-z0-9_]+$`, Beschriftungen deutsch in `labels`.
- Anlage über `Invoke-Ninox` und `ninox`-Skill, mit Freigabe in Phase 3. Füllen per Datensatz-Batch, danach Zeilenzahl prüfen.

## Tabellen

| Tabelle | Zweck | Felder (Typ) |
|---|---|---|
| `uebersicht` | ein Datensatz je Projekt | projekt (string), quelle_ohne_daten (string), quelle_mit_daten (string), sicherung_stand (string), ziel_workspace (string), ziel_modul (string), phase (number), status (choice: in Arbeit, wartet auf Freigabe, abgeschlossen), aktualisiert (string) |
| `tabellen_inventar` | je Ninox-3-Tabelle | n3_id (string), n3_name (string), felder (number), formelfelder (number), datensaetze (number), n4_tabelle (string), status (choice: offen, gebaut, geprueft, luecke) |
| `felder_mapping` | je Ninox-3-Feld | n3_tabelle_id, n3_feld_id, n3_beschriftung, n3_basis (alle string), n4_tabelle, n4_feld, n4_label, n4_label_vorschlag, n4_typ, n4_variante (string), status (choice: automatisch, formel, manuell, ungeklaert), freigabe (choice: offen, freigegeben), namenshinweis, hinweis (multiline-text) |
| `luecken` | je nicht übernommenes oder unbelegtes Objekt | nr (number), kategorie (choice, siehe `luecken-katalog.md`), objekt (string), beschreibung (multiline-text), auswirkung (multiline-text), aufwand (choice: klein, mittel, gross), status (choice: offen, in Arbeit, erledigt, akzeptiert), verantwortlich (string), beleg (string) |
| `schreibprotokoll` | je schreibende Aktion | zeit (string), phase (number), aktion (string), ziel (string), anzahl (number), ergebnis (string), freigabe (string) |
| `abnahme` | je Prüfzeile | pruefung (choice: A Struktur, B Daten, C Formeln, v2), objekt (string), soll (string), ist (string), ergebnis (choice: bestanden, mit Befund, nicht bestanden, nicht belegt), ursache (multiline-text), beleg (string) |
| `optimierung` | je Vorschlag | nr (number), art (string), objekt (string), beobachtung (multiline-text), beleg (string), nutzen (string), aufwand (choice: klein, mittel, gross), risiko (string), entscheidung (choice: offen, umsetzen, spaeter, verworfen) |
| `entscheidungen` | Entscheidungen des Nutzers je Phase (ohne Personendaten) | datum, thema (string), phase (number), entscheidung (multiline-text) |
| `abweichungen` | Geprüfte Abweichungen zwischen Dokumentation und Verhalten sowie mutmaßliche API-Fehler. Nur Status geprüft, gemeldet, behoben; ein Verdacht bleibt lokal in `ergebnis/abweichungen.csv` | nr (number), titel, endpunkt, erwartet_quelle, beobachtet, gemeldet_am, api_version (string), bereich (choice: API, Formel, Oberfläche, Dokumentation), erwartet, tatsächlich, reproduktion, minimalbeispiel, gegenprobe, workaround (multiline-text), schwere (choice: blockierend, störend, kosmetisch), status (choice: geprüft, gemeldet, behoben) |

Datumswerte als Text im Format `yyyy-MM-dd HH:mm`, solange das Schreibformat für `date` und `timestamp` nicht per Probe festgestellt ist.

## Befüllung

| Quelle lokal | Tabelle im Modul |
|---|---|
| `01_tabellen.csv` | `tabellen_inventar` |
| `06_mapping_vorschlag.csv` | `felder_mapping` |
| Lückenliste (`ergebnis/09_luecken.csv`) | `luecken` |
| `ergebnis/schreibprotokoll.csv` | `schreibprotokoll` |
| Abnahmeergebnisse | `abnahme` |
| Optimierungsvorschläge | `optimierung` |
| `ergebnis/status.json` | `uebersicht` |

Bei Änderung einer lokalen Datei die Tabelle abgleichen (PATCH statt doppeltem Anlegen). Das Dokumentationsmodul wird nie für Datensatzinhalte verwendet.
