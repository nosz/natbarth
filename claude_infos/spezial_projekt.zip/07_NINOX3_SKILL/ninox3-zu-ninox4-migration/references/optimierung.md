# Optimierungsphase (Phase 7)

Nach der Abnahme der 1:1-Migration prüft der Skill, ob ein besseres Datenmodell möglich ist, und fragt, ob zusätzlich eine verbesserte Version gebaut werden soll. Die 1:1-Version bleibt unverändert, damit die Abnahme aussagekräftig bleibt und jederzeit ein Rückweg besteht. Optimierung ist eine Fachentscheidung: der Skill empfiehlt, was belegt ist, und baut nur, was freigegeben wird.

## 1. Befunde sammeln (schon ab Phase 1)

`07_befunde_optimierung.csv` enthält Beobachtungen aus dem Schema. Muster, die der Skill erkennt:

| Befund | Erkennung | Typischer Vorschlag |
|---|---|---|
| Lange Verzweigungsketten mit festen Werten in Formeln | viele `if`/`like` in einer Formel | Stammdatentabelle mit Verweis oder Nachschlagen statt Verzweigung |
| Auswahlfelder mit vielen festen Werten | 12 oder mehr Optionen | Stammdatentabelle mit Verweis, wenn die Liste gepflegt wird |
| Sehr breite Tabellen | 40 oder mehr Felder | Aufteilen nach Themen, Detailtabellen mit Verweis |
| Leere oder ungenutzte Tabellen | keine Datensätze (Datei "mit Daten") | Prüfen, ob sie entfallen können |
| Doppelte Beschriftungen in einer Tabelle | gleiche Beschriftung mehrfach | eindeutige Namen |

Weitere Muster dürfen ergänzt werden, wenn sie belegbar sind (z. B. mehrfach gepflegte gleiche Daten in mehreren Tabellen, Textfelder mit Listen, Felder ohne einen einzigen Wert).

## 2. Mit Daten belegen

Schema-Beobachtungen sind Hinweise, keine Belege. Vor jedem Vorschlag aus der Datei "mit Daten" zählen:

- Auswahlfeld: wie viele verschiedene Werte werden tatsächlich genutzt, wie viele Datensätze je Wert?
- Formel mit festen Werten: wie viele verschiedene Eingabewerte kommen in den Daten vor, wie viele Zweige treffen nie zu?
- Breite Tabelle: wie viele Felder sind in wie vielen Datensätzen gefüllt? Felder, die fast nie gefüllt sind, sind Kandidaten zum Auslagern.
- Verweise: gibt es Datensätze ohne Verweis, wo einer erwartet wird?

Zahlen nennen, keine Inhalte. Ohne Datenbeleg bleibt der Vorschlag als "Hinweis (nur Schema)" gekennzeichnet.

## 3. Vorschlagsliste

`ergebnis/optimierungsvorschlaege.md`, je Vorschlag:

| Nr | Art | Objekt | Beobachtung (mit Zahl) | Vorschlag | Nutzen | Aufwand | Risiko | Auswirkung auf Formeln/Daten | Beleg |

Priorisiert nach Nutzen zu Aufwand. Auswirkungen ausdrücklich nennen (welche Formeln, Ansichten, Importe ändern sich). Berechtigungen und Prozesse bleiben außen vor, solange der Nutzer sie nicht ausdrücklich einbezieht. Ablage zusätzlich in der Tabelle `optimierung` des Dokumentationsmoduls (`dokumodul.md`).

Optional vor der Entscheidung: `grilling` nutzen, um das neue Datenmodell zu hinterfragen.

## 4. Entscheidung

Nach der Liste genau eine Frage: "Soll zusätzlich eine verbesserte Version `<Modul>_v2` erstellt werden, und welche Vorschläge (Nummern) sollen umgesetzt werden?" Ohne ausdrückliches Ja wird nichts gebaut. Teilauswahl ist möglich. Die Entscheidung je Vorschlag (umsetzen, später, verwerfen) mit Datum in die Tabelle `optimierung`.

## 5. `_v2` bauen (nur nach Freigabe)

1. Neues, leeres Modul `<Modul>_v2` im selben Workspace (Name nach `^[a-z0-9_]+$`). Zielmodul der 1:1-Version nie verändern.
2. Aufbau wie Phase 3 bis 5, aber mit dem angepassten Mapping: eigene Datei `06_mapping_v2.csv`, Abweichungen zum 1:1-Mapping mit Spalte `Vorschlagsnummer`.
3. Formeln: eigene Fassung je betroffener Formel, Original und neue Fassung nebeneinander dokumentieren. Neue Logik als solche kennzeichnen.
4. Daten: dieselbe Stichprobe (gleicher Seed), gleiche Anonymisierung, Umwandlung nach dem v2-Mapping. Neue Stammdatentabellen aus den tatsächlich vorkommenden Werten befüllen.
5. Schreibprotokoll und Freigaben wie in den Phasen 3 bis 5.

## 6. Vergleich 1:1 gegen v2

- Struktur: welche Tabellen und Felder sind neu, geändert, entfallen (Tabelle).
- Ergebnisse: liefern die betroffenen Formeln in v2 dieselben Werte wie in der 1:1-Version für die Stichprobe? Abweichungen mit Ursache (beabsichtigt oder Fehler).
- Datenvollständigkeit: gleiche Datensatzzahlen, gleiche Verknüpfungen (bezogen auf die Vorschläge).
- Ergebnis in `ergebnis/vergleich_v2.md` und in `abnahme` (Art "v2").

Eine Umstellung der produktiven Nutzung auf v2 ist nicht Teil des Skills.

## Praktisch umgesetzt (Teststrecke)

Der einfachste Weg, _v2 zu bauen, ohne die Bauskripte zu verdoppeln: Unterordner `v2/` im Projekt (New-Ninox4V2Projekt) mit eigener `ninox.config.json` (Modulname <Modul>_v2), eigenem Mapping, eigener Feldliste und eigener Formelanalyse (Spalte ZuBauen ersetzt). Dann Invoke-Ninox4SchemaBuild, Invoke-Ninox4FormulaBuild, Invoke-Ninox4SampleImport -PayloadHook und Invoke-Ninox4Abnahme jeweils mit -ProjectDir <projekt>\v2. Ergebnis der Teststrecke: v2 hat 17 Tabellen und alle 46 Formeln; die Abnahme A und B bestehen; 38 Formeln liefern in beiden Versionen identische Werte, 3 weichen beabsichtigt ab (Adressen aus der Tabelle). Der Ordner `v2/arbeit` enthaelt Kopien der Daten und gehoert in die Aufraeumliste.
