# Abnahme (Phase 6)

Die Teststrecke gilt als bestanden, wenn drei Prüfungen belegt sind. Jede Prüfung hat ein eigenes Ergebnis: **bestanden**, **bestanden mit Befund**, **nicht bestanden** oder **nicht belegt** (wenn der Soll-Wert fehlt). "Nicht belegt" ist ehrlicher als ein "bestanden" ohne Grundlage.

## Prüfung A: Struktur (muss zu 100 % stimmen)

Soll: freigegebenes Mapping. Ist: Rücklesen aus Ninox 4 (`GET .../tables`, `.../fields`).

- Anzahl Tabellen und Felder je Tabelle.
- Typ und Variante je Feld, `required`, Indexe.
- Auswahlfelder: Optionen vollständig, Reihenfolge, Schreibweise.
- Verweise: Zieltabelle je `reference`, Rückverweise vorhanden.
- Formelfelder: Typ `function`, Ausdruck vorhanden.

Ergebnis je Zeile in `abnahme` (Dokumentationsmodul) und im Bericht. Abweichungen sind Befunde mit Ursache, kein stilles Korrigieren.

## Prüfung B: Daten der Stichprobe (Zeilenzahlen und Verknüpfungen 100 %)

Soll: anonymisierte Stichprobe (Zählung je Tabelle, `idmap_*.json`). Ist: Rücklesen aus Ninox 4 (`GET .../records`, Seiten zu je 100).

- Zeilenzahl je Tabelle gleich Stichprobe.
- Verknüpfungen: für jeden Verweis der Stichprobe zeigt der Ninox-4-Datensatz auf den Datensatz, der in der Zuordnung der Zieltabelle steht.
- Feld für Feld: Text, Zahl, Auswahl-Label, Datum, Zeitstempel, Dateiname. Zahlen exakt, Texte nach Entfernen von Zeilenende-Unterschieden gleich.
- Datum und Zeit: Abweichungen um Zeitzone oder Format als Befund mit Ursache, nicht pauschal als Fehler.
- Rückverweise: Anzahl der verknüpften Datensätze je Hauptdatensatz stimmt mit den Verweisen der Quelle überein.

## Prüfung C: Formeln

Ninox-3-Exporte enthalten **keine** Formelwerte (am Beispiel 0 von 46 Feldern). Der Skill kann daher nur mit einem Soll aus Ninox 3 vergleichen.

**Soll beschaffen (Nutzer):** In Ninox 3 für die Stichprobendatensätze die Formelspalten als CSV exportieren (z. B. aus einer Ansicht mit allen Formelfeldern; der Skill nennt die Datensatznummern der Stichprobe und die Spalten) und als `arbeit/soll_formeln_ninox3.csv` ablegen. Erste Spalte: Datensatznummer (`_id`).

**Vergleich:**
- Zahlen: gleich bis auf Rundung (Toleranz im Bericht nennen).
- Texte: nach Vereinheitlichung der Zeilenenden und Leerzeichen am Rand gleich.
- Datum und Zeit: Format und Zeitzone nach dem Probeimport.
- Abweichung: je Formel Ursache suchen (Rundung, Datumsformat, Zeitzone, Syntaxunterschied, anonymisierte Eingabe, leere Eingabe) und klassifizieren. Ursache unbekannt gilt als Befund "offen".

**Ohne Soll-Datei:** Prüfung C lautet "nicht belegt". Der Bericht nennt dann nur: Formeln laufen (Rücklesen), liefern plausible Werte (Stichprobe), Übereinstimmung mit Ninox 3 unbelegt.

**Anonymisierte Eingaben:** Formeln, die auf anonymisierte Textfelder zugreifen (z. B. `like`-Vergleiche gegen Firmennamen), ändern ihr Verhalten. Solche Formeln im Bericht kennzeichnen und nicht als Fehler werten.

## Bericht `ergebnis/abnahmebericht.md`

Vorlage (ohne Personendaten, nur Struktur und Zähler):

```markdown
# Abnahmebericht <Lösung>
Stand: <Datum> | Quelle: <Dateiname, Sicherungszeitpunkt> | Ziel: <Workspace-ID>/<Modul>
Stichprobe: <Haupttabelle>, <n> Datensätze, Seed <s>, anonymisiert: ja/nein

## Ergebnis
| Prüfung | Ergebnis | Befunde |
|---|---|---|
| A Struktur | bestanden / mit Befund / nicht bestanden | n |
| B Daten | ... | n |
| C Formeln | ... / nicht belegt | n |

## Befunde
| Nr | Prüfung | Objekt | Soll | Ist | Ursache | Status |

## Lücken (aus Lückenliste)
| Nr | Kategorie | Objekt | Behandlung | Aufwand |

## Nicht belegt / offene Punkte
- ...

## Freigabe
Datum, freigebende Person (Name im Chat angegeben), Hinweis auf spätere Vollmigration.
```

Dasselbe als Zeilen in der Tabelle `abnahme` des Dokumentationsmoduls (`dokumodul.md`). Freigabe der Phase erst, wenn alle Befunde entweder geklärt oder vom Nutzer ausdrücklich akzeptiert sind.

### Erfahrung aus der Teststrecke: Soll-Export prüfen, bevor man vergleicht

Die vom Nutzer aus Ninox 3 exportierten CSV-Dateien deckten die Stichprobe nicht ab (Shipping 888 von 13.276 Zeilen, 1 von 20 Stichprobendatensätzen und 5 von 18 Formelspalten; Accounting 455 Zeilen mit nur 101 verschiedenen Nummern, 0 von 20). Ursache: Ninox 3 exportiert, was die gewählte Ansicht zeigt (Filter und Spaltenauswahl), auch wenn man den Export über die Datenbank-Startseite versucht; die Nummernspalte `Nr` ist nicht in jeder Tabelle die Datensatznummer. **Vor dem Vergleich immer prüfen** (nur Zähler, keine Inhalte): Zeilenzahl gegen die Quelle, Anteil der Stichprobendatensätze im Export, Anteil der Formelspalten, Eindeutigkeit der Nummernspalte. Reicht der Export nicht, ehrlich "nicht belegt" melden und den Nutzer einen Export ohne Filter mit allen Formelspalten und der Datensatznummer erstellen lassen (zum Beispiel eine eigene Ansicht ohne Filter); ersatzweise die Stichprobe so wählen, dass sie im Export liegt.
