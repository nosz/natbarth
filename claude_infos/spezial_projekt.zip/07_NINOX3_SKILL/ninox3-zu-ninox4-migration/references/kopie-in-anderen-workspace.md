# Abschlussfrage: Apps in einen anderen Workspace kopieren

Am Anfang von Phase 8, **vor** dem Aufräumen, fragt der Skill genau einmal: **"Sollen die erstellten Apps (1:1-Version, `_v2`, ggf. Dokumentation) noch in einen anderen Workspace kopiert werden?"** Grund für die Reihenfolge: Die Kopie braucht `arbeit/` (Quelldaten, Zuordnungen) und einen Key für den Ziel-Workspace. Nach dem Löschen von `arbeit/` und dem Widerruf der Keys wäre sie nur mit Mehraufwand möglich. Antwort "nein": weiter mit dem Aufräumen. Antwort "ja": dieser Ablauf.

## Fragen an den Nutzer (eine nach der anderen)

1. **Ziel:** Adresse des Ziel-Workspace (aus der Browserzeile). Der Skill liest den **Klarnamen** (Workspace und Team) in der Oberfläche ab, nur lesend, und nennt ihn dem Nutzer. Die Workspace-ID ist der zweite Teil der Adresse (`go.ninox.com/<Team>/<Workspace>/...`).
2. **Testworkspace?** Ausdrückliche Bestätigung "Ziel ist ein Testworkspace, anonymisierte Daten sind okay". Der Skill schreibt nur in **neue, leere Module**, nichts wird verändert oder gelöscht. Vorhandene Apps im Ziel bleiben unberührt (im Ziel nennen).
3. **Von Hand verändert?** Hat der Nutzer die Apps nach dem Bau in Ninox von Hand geändert (Ansichten, Layout, Felder)? Nein: **Weg A**. Ja: **Weg B**.
4. **Welche Apps** kommen mit (1:1, `_v2`, Dokumentation)?
5. **Key für den Ziel-Workspace** (jeder Key gilt nur für einen Workspace). Anleitung: `fuehrung.md`, "Konkrete Anleitungen". Der neue Key ersetzt in der Benutzerumgebung den alten; der alte wird für das Aufräumen im Quell-Workspace wieder gebraucht (liegt in Bitwarden).

## Weg A (Standard): Skill im Ziel erneut laufen lassen

Geprüft, wiederholbar, Abnahme im Ziel inklusive. Dauer rund 15 bis 25 Minuten für zwei Apps.

1. Trockenlauf-Vorbereitung (lokal, schreibt nichts): `New-Ninox4ZielProjekt -ProjectDir <projekt> -WorkspaceId <id> -WorkspaceName <Klarname>` (Ordner `ziel/`), danach für `_v2` `New-Ninox4V2Projekt -ProjectDir <projekt>\ziel` (Ordner `ziel\v2`). Beide Ordner enthalten eigene Konfiguration, Mapping und Formelanalyse.
2. Ziel prüfen: `GET /modules` mit dem neuen Key (HTTP 200, vorhandene Module nennen). Trockenläufe `-Plan` für Schema, Formeln und Import je Ordner, dem Nutzer die Zahlen zeigen, **"ok" einholen**.
3. Pro App (1:1 zuerst, dann v2): `Set-NinoxFreigabe` (Phasen 3 bis 5, Ziel-Workspace und Modul), `Invoke-Ninox4SchemaBuild`, `Invoke-Ninox4FormulaBuild`, `Invoke-Ninox4SampleImport` (bei v2 mit `-PayloadHook`), danach die Pflichtfelder setzen **erst nach dem Import**, dann `Invoke-Ninox4Abnahme`.
4. Ergebnis je Ordner in `ziel/ergebnis/` und `ziel/v2/ergebnis/`; Links zu den Apps nennen (`go.ninox.com/<Team>/<Workspace>/<Modulkennung>`, die Kennung steht als `href` im App-Wechsler).

**Stolperfallen aus der Teststrecke:**
- Ninox legt beim **Öffnen** einer neuen, leeren App in der ersten Tabelle einen leeren Datensatz an. Der Import schreibt nur in leere Tabellen und bricht dann ab. Deshalb den Nutzer bitten, neue Apps erst zu öffnen, wenn der Skill den Import beendet hat. Ist es doch passiert: leeren Datensatz prüfen (alle Felder leer), dann nur mit ausdrücklichem Ja (Frage mit Auswahl, nicht "ok") per `DELETE .../records` mit `{"records":[<id>]}` löschen.
- Pflichtfelder (`required`) **nie vor dem Import** setzen. Ist es doch passiert: mit `PATCH .../fields/<feld>` und `{"required":false}` zurücknehmen, protokollieren, nach dem Import erneut setzen.
- Nach jedem Bau mit `Invoke-Ninox4Abnahme` gegenprüfen.

## Weg B: Gerüst und Daten aus Ninox 4 kopieren (nur wenn von Hand verändert wurde)

Die API kann das Gerüst einer App lesen und anwenden (`GET`/`PUT /modules/{modul}/definition`) und Datensätze per CSV importieren. Es gibt keinen Export-/Import-Befehl für ganze Apps. Weg B ist **nicht getestet**: zuerst mit einem kleinen Wegwerf-Modul ausprobieren, dem Nutzer das offen sagen, Datensätze mit neuen IDs und in zwei Durchgängen kopieren (wie `Invoke-Ninox4SampleImport`). Ob die Oberfläche von Ninox 4 selbst eine Kopierfunktion für Apps bietet, ist nicht belegt.

## Nach der Kopie

Ergebnis protokollieren (`entscheidungen.csv`, Phase 8) und weiter mit dem Aufräumen. `ziel/arbeit` und `ziel/v2/arbeit` enthalten Kopien der Ninox-3-Daten und kommen auf die Aufräumliste (zusammen mit `arbeit/` und `v2/arbeit`). Den Ziel-Key am Ende wie alle anderen widerrufen und die Benutzervariable löschen.