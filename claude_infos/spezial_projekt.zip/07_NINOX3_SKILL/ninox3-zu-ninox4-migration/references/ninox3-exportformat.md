# Aufbau der Ninox-3-Sicherung (.ninox)

Am Beispiel "Test-Export" verifiziert (Stand Oktober 2026). Andere Ninox-3-Versionen können abweichen: unbekannte Schlüssel meldet das Inventar in `WeitereSchluessel`.

## Archiv

Eine `.ninox`-Datei ist ein ZIP-Archiv:

| Eintrag | Inhalt |
|---|---|
| `data.db` | Schema, Ansichten und Datensätze, zeilenbasiert (siehe unten) |
| `settings.json` | Name, Symbol, Farbe, Rollen für Öffnen/Export/Import, Plugins |
| `backup.json` | Datenbank-ID, Name, Zeitstempel (ms), Benutzer-ID |
| `reports/<id>/report.json` | Druck-Layout (Tabelle `tid`, Papier, Objekte mit Text und `{Tabelle.Feld}`-Platzhaltern) |
| `reports/<id>/files/*` | Bilder der Berichte |
| `comments.db` | Kommentare (im Beispiel leer, 0 Bytes) |

Ohne-Daten-Variante: gleiche Struktur, `data.db` enthält nur Schema und Ansichten (im Beispiel 169 KB statt 18 MB).

## `data.db`

Eine Zeile je Eintrag, UTF-8, Zeilenumbrüche in Texten sind als JSON maskiert.

| Zeilenanfang | Bedeutung |
|---|---|
| `s:` | genau eine Schemazeile, JSON |
| `V<Id>:` | Ansicht (`id`, `type` = Tabellen-ID, `caption`, `mode`, `config.cols`, ...) |
| `U<TabellenId><Nr>:` | Datensatz. Tabellen-IDs bestehen aus Buchstaben (`B`, `AB`), die Nummer aus Ziffern, z. B. `UD10442` = Tabelle `D`, Datensatz 10442 |

Erkennung der Datensatzzeile: `^U([A-Za-z]+)(\d+):`.

## Schema (`s:`)

- Oberste Schlüssel: `seq`, `version`, `nextTypeId`, `types`, `afterOpenBehavior`, `fileSync`, `dateFix`, `compatibility`, `hideCalendar`, `hideSearch`, `hideDatabase`, `hideNavigation`, `knownDatabases`, `serverSideReadableIf`.
- `types.<TabellenId>`: `caption`, `fields`, `uis` (Layoutelemente wie Überschriften), Rechte (`readRoles`, `writeRoles`, `createRoles`, `deleteRoles`), `order`, `kind`, `icon`.
- `fields.<FeldId>`: `base` (Typ), `caption`, `order`, `required`, `hasIndex`, `globalSearch`, `fn` (Formel), `values` (Auswahl: Wert-ID zu `caption`/`order`), `refTypeId`/`refFieldId`/`cascade` (Verweise), `readRoles`/`writeRoles`, `visibility`, Standardwerte (`numberDefault`, `choiceDefault`, ...), Trigger (`afterUpdate`).
- Basistypen im Beispiel: `string`, `number`, `file`, `choice`, `date`, `rev`, `ref`, `multi`, `boolean`, `link`, `timestamp`, `html`.

## Datensätze

- Schlüssel: Feld-IDs, dazu Metadaten `_cd`/`_cu` (angelegt am/von) und `_md`/`_mu` (geändert am/von). Zeiten in Millisekunden seit 1970. Benutzer-IDs sind interne IDs, keine Namen.
- Werte: Zahlen als Zahl, Text als Text, Datum und Zeitstempel als Millisekunden, `choice` als Wert-ID in Textform (z. B. `"2"`), `ref` als Nummer des Zieldatensatzes, `file` als Dateiname.
- Leere Felder fehlen im Datensatz.

## Was nicht im Export steht (am Beispiel geprüft)

| Fehlt | Folge |
|---|---|
| Werte der Formelfelder (`fn`): 0 von 46 Feldern haben gespeicherte Werte | Kein Soll-Wert für den Formelvergleich aus der Datei; Export aus Ninox 3 nötig (`abnahme.md`) |
| Werte der Rückverweise (`rev`): 0 von 12 | Sie entstehen in Ninox 4 aus den Verweisen |
| Dateianhänge (Binärdaten) | Nur der Dateiname steht im Datensatz; Anhänge später gesondert |
| Benutzernamen | Nur interne Benutzer-IDs |

## Datenschutz

`data.db` und jeder Datensatz enthalten Personen- und Firmendaten. Entpackte Dateien gehören in `arbeit/`, nicht in Versionsverwaltung und nicht in Chat oder Berichte.
