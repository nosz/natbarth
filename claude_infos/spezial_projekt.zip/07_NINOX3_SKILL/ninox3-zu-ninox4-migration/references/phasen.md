# Phasen im Detail

Jede Phase hat Eingaben, Schritte, Ausgaben und (bei schreibenden Phasen) einen Freigabetext. Das Muster: erst zeigen, was passieren wird, dann Freigabe holen, dann ausführen, dann Ergebnis prüfen und protokollieren. Nach jeder Phase `ergebnis/status.json` aktualisieren.

## Inhalt
- Statusdatei `ergebnis/status.json`
- Phase 0: Voraussetzungen
- Phase 1: Inventar
- Phase 2: Migrationsplan (Freigabe)
- Phase 3: Schema (Freigabe, schreibt)
- Phase 4: Formeln (Freigabe, schreibt)
- Phase 5: Testdaten (Freigabe, schreibt)
- Phase 6: Abnahme (Freigabe)
- Phase 7: Optimierung (Freigabe)
- Live-Ansicht (optional, ab Phase 3)
- Phase 8: Abschluss und Aufräumen
- Später: Vollimport
- Fehler und Rückfall

## Statusdatei `ergebnis/status.json`

Keine Personendaten, keine Geheimnisse.

```json
{
  "projekt": "<name>",
  "quelle": { "ohneDaten": "sicherung/<name>_ohne_daten.ninox", "mitDaten": "sicherung/<name>_mit_daten.ninox" },
  "ziel": { "workspaceId": "<WORKSPACE_ID>", "modul": "<ZIEL_MODUL>", "dokuModul": "<DOKU_MODUL>" },
  "phase": 2,
  "phasen": {
    "0": { "stand": "abgeschlossen", "datum": "2026-10-06" },
    "1": { "stand": "abgeschlossen", "datum": "2026-10-06" },
    "2": { "stand": "wartet auf Freigabe" }
  },
  "freigaben": [ { "phase": 2, "text": "Freigabe im Chat", "datum": "..." } ],
  "stichprobe": { "haupttabelle": "B", "anzahl": 20, "seed": 42, "anonymisiert": true }
}
```

## Phase 0: Voraussetzungen

1. Prüfen, ob beide `.ninox`-Dateien vorhanden sind (`sicherung/`). Dateigröße nennen. Fehlt eine: den Nutzer bitten, sie in Ninox 3 zu sichern (einmal ohne, einmal mit Datensätzen) und abzulegen. Nicht weiterarbeiten.
2. `ninox.config.json`: Für Phase 0 bis 2 nicht nötig (nur Pfade und Projektordner). Spätestens vor Phase 3 lesen; fehlt der `migration`-Block, Werte erfragen (Pfad, Doku-Modul, Stichprobengröße, Anonymisierung) und eintragen. Keine Geheimnisse.
3. Builder prüfen (`Invoke-Ninox3Phase1` meldet `BuilderGefunden`): `ninox4-api-builder` mit `scripts/ninox-helpers.ps1` vorhanden? Für Phase 0 bis 2 nicht nötig, vor Phase 3 Pflicht.
4. Empfohlen: beide Dateien nach `sicherung/` kopieren (eingefrorener Stand), `.gitignore` aus `assets/gitignore-vorlage.txt` anlegen. Entpackt wird immer nach `arbeit/ohne` und `arbeit/mit`, nie in `sicherung/`.
5. Die Prüfung läuft im ersten Teil von `Invoke-Ninox3Phase1` (siehe Phase 1): gleiche Datenbank-ID, identisches Schema, Datei "ohne" ohne Datensätze, Datei "mit" mit Datensätzen. Ergebnis als Tabelle zeigen. Bei "nicht bestanden" stoppt die Funktion, dann die Ursache erklären (z. B. Sicherungen von verschiedenen Ständen).
6. Für Phase 3 ff.: nur "gesetzt/nicht gesetzt (Länge)" für `NINOX_API_KEY` prüfen, Verbindungstest mit `Get-NinoxModuleDefinition`, HTTP 401/403/404 erklären. Phase 1 und 2 brauchen keinen Zugang.

## Phase 1: Inventar

```powershell
. .\<skillordner>\scripts\ninox3-phase1.ps1
Invoke-Ninox3Phase1 -OhneDatei "<pfad>\<name>_ohne_daten.ninox" -MitDatei "<pfad>\<name>_mit_daten.ninox" -ProjectDir "<projektordner>"
```

Die Funktion entpackt beide Dateien, prüft das Paar (Phase 0), schreibt die **bereinigten** Ergebnisse nach `ergebnis/` (`01_tabellen.csv` bis `10_namenspruefung.csv`, `inventar_zusammenfassung.json`) und die **volle** Fassung (Formeltexte, Auswahlwerte, Rollennamen in `rollen.txt`) nach `arbeit/inventar/`. Zurück kommen nur Zähler. Nicht aus dem Terminal oder aus `arbeit/inventar/` Formeltexte in den Chat kopieren.

Dem Nutzer zeigen: Tabellen-, Feld-, Formel-, Trigger-, Rechte-, Ansichten- und Berichtszahlen, Zahl der Rollen (Namen nicht im Chat wiederholen; Formulierung: "In `arbeit/inventar/rollen.txt` stehen die N Rollennamen. Bitte prüfen, ob einer davon eine Person bezeichnet; das beeinflusst die Rechte-Gegenüberstellung."), Datensatzzahl je Tabelle, ignorierte Plugins, unbekannte Schlüssel (`WeitereSchluessel`), Größe von `comments.db` (größer als 0 heißt: Kommentare existieren, Lücke), Namensprüfung (Fehler, Warnungen). Keine Datensatzinhalte.

## Phase 2: Migrationsplan (Freigabe)

1. `06_mapping_vorschlag.csv` und `10_namenspruefung.csv` prüfen: Typen, Status (`automatisch`, `formel`, `manuell`, `ungeklaert`) und **Namen**. Dem Nutzer die Namenswarnungen zeigen (nummerierte, sehr kurze oder mit Schlüsselwörtern kollidierende Namen) und lesbare Namen vorschlagen; für kryptische Beschriftungen zusätzlich optional ausgeschriebene Labels in `Ninox4LabelVorschlag` (die Oberfläche bleibt sonst unverändert); Änderungen erst nach der Entscheidung des Nutzers in `Ninox4Tabelle`/`Ninox4Feld` der CSV eintragen (der Vorschlag selbst bleibt unverändert, bis der Nutzer entschieden hat) und `Test-Ninox4Names` erneut laufen lassen. Regeln: `mapping-regeln.md`. Danach die Formelanalyse mit dem geänderten Mapping neu erzeugen (`Invoke-Ninox3Phase1 ... -MappingFile`), weil die Rohübersetzung die Namen aus dem Mapping verwendet.
2. Lückenliste prüfen: `09_luecken.csv` wird in Phase 1 aus dem Inventar abgeleitet (Berichte, Ansichten, Rechte, Trigger, Layout, Anhänge, `html`-Felder, Kommentare, Standardwerte, Sichtbarkeit, Kaskaden, Plugins). Aufwand ist eine Schätzung; Beleggrad je Zeile prüfen und um Erkenntnisse aus Schritt 3 ergänzen (`luecken-katalog.md`).
3. Belegprüfung gegen die Live-OpenAPI: `Invoke-Ninox3Phase1 ... -PruefeApi` (oder `Get-NinoxOpenApi`/`Get-NinoxApiCapability` aus `scripts/ninox-openapi.ps1`) schreibt `ergebnis/11_api_faehigkeiten.csv` für Ansichten, Berichte, Trigger, Zugriffsausdrücke, Standardwerte, Rollen, `html`, `reverse`, Dateiupload. Die Spalte `Belegt` sagt nur, dass die Spezifikation es nennt; die Gleichwertigkeit mit Ninox 3 ist erst im Test-Workspace belegt. Wo die Spezifikation einer Referenzdatei oder einer Lückenzeile widerspricht, gilt die Spezifikation: Lückenzeile und Mapping im Plan korrigieren. Das Abrufen der öffentlichen Spezifikation ist ein lesender Aufruf ohne Key und ohne Zugriff auf Ninox-Daten und ist in Phase 2 erlaubt. Ist kein Netzwerkzugriff möglich oder verboten, die Punkte als "unbelegt" führen und das im Plan nennen. Ergebnis je Punkt: "per API anlegbar (belegt)", "nicht per API (belegt)", "unbelegt".
4. Rechte: Gegenüberstellung Ninox-3-Rollen zu Ninox-4-Rollen (Rollen-Arrays an Tabelle und Feld; Feldrolle `user` ist laut OpenAPI ein veralteter Alias für `editor`; benutzerdefinierte Rollen wie "Sales" haben keine belegte Entsprechung). Nichts anlegen, nur vorschlagen.
5. Befunde für Phase 7 aus `07_befunde_optimierung.csv` übernehmen, ohne Umsetzung.
6. Plan als Markdown in `ergebnis/migrationsplan.md` (Zusammenfassung, Mapping-Statistik, Lücken mit Aufwand, offene Fragen, Reihenfolge der Tabellen nach Verweisen).

**Freigabetext:** "Plan liegt vor: N Tabellen, M Felder, davon X automatisch zu bauen, F Formelfelder (Übersetzung erst in Phase 4), Y manuell, Z ungeklärt; L Lücken; Namenswarnungen: W (geprüft). Freigabe für Phase 3 (Schema im Modul `<ZIEL_MODUL>` des Workspaces `<WORKSPACE_ID>`)? Antworte mit Ja oder nenne Änderungen." Hinweis: "automatisch" heißt nur, dass der Typ belegt zugeordnet ist; Formelfelder zählen getrennt, weil ihre Übersetzung noch offen ist.

## Phase 3: Schema (Freigabe, schreibt)

Vor jeder schreibenden Phase: `Test-NinoxVorabpruefung` (zeigt in Klartext, was nicht stimmt, z. B. "Der Key gehört zu einem anderen Workspace"). Nach dem ausdrücklichen "Ja" des Nutzers: `Set-NinoxFreigabe` (Phase, Workspace, Module). Ohne diesen Eintrag lehnen die Bauskripte das Schreiben ab. Nach einem Abbruch: `Invoke-Ninox4SchemaBuild ... -Fortsetzen` ergänzt nur Fehlendes, verändert und löscht nichts.

Ablauf mit Skripten: `Invoke-Ninox4SchemaBuild ... -Plan` (Trockenlauf mit Zahlen zeigen), nach der Freigabe ohne `-Plan` bauen, danach `Invoke-Ninox4DokuModul`. Die Skripte setzen `Freigabe = freigegeben` im Mapping voraus, prüfen Namen und Vorhandensein der Module, schreiben `schreibprotokoll.csv` und prüfen das Ergebnis durch Zurücklesen (`schema_pruefung.csv`).

1. Freigabe mit Ziel-ID. Zielmodul muss neu und leer sein (`GET /modules`): existiert es mit Inhalt, stoppen und nach neuem Namen fragen.
2. Sicherung der Workspace-Lage: `Save-NinoxBackup` (Builder, Baustein E), falls das Modul existiert.
3. Reihenfolge: Modul, Tabellen, Felder ohne Verweise, dann `reference`-Felder (Zieltabelle muss existieren), dann die **automatisch entstandenen Rückverweise** finden und umbenennen (Feldliste der Zieltabelle vor und nach dem Verweisfeld vergleichen; `reverse`-Felder werden nicht einzeln angelegt), zuletzt `function`-Felder (Phase 4; Ninox prüft den Ausdruck beim Anlegen). Auswahloptionen bei Anlage vollständig angeben.
4. Felder ohne `required` anlegen (Pflicht wird erst nach dem Datenimport in Phase 5 per `PATCH` gesetzt, sonst scheitert der Import an Datensätzen mit leeren Pflichtwerten); `Pflicht` aus dem Mapping merken.
5. Nach jeder Tabelle zurücklesen und mit dem Mapping vergleichen (Feldanzahl, Typ, Optionen). Eine neue Tabelle kann kurz sichtbar und dann weg sein (Hinweis im `ninox`-Skill): Tabelle und Modul erneut lesen, bei Abweichung stoppen und fragen.
5. Dokumentationsmodul anlegen (`dokumodul.md`) und mit Inventar, Mapping und Lücken füllen. Nur Struktur, Zähler, IDs, Status.
6. Jede Schreibaktion in `ergebnis/schreibprotokoll.csv` (Zeit, Phase, Aktion, Ziel, Anzahl, Ergebnis) und im Dokumentationsmodul.

## Phase 4: Formeln (Freigabe, schreibt)

Ablauf in `formeln.md`. Kurz: Rohübersetzung aus `08_formel_analyse.csv` übernehmen, Syntaxunterschiede gegen `ninox`-Skill und docs.ninox.com prüfen, `function`-Feld mit `expression` anlegen, zurücklesen, Fehler (`expressionErrors`, leerer Ausdruck) melden. Vor dem ersten Einsatz eine Probe: legt die API fehlerhafte Formeln an oder lehnt sie ab? Ergebnis als "beobachtet" festhalten.

## Phase 5: Testdaten (Freigabe, schreibt)

Ablauf in `stichprobe-anonymisierung.md`. Kurz: Stichprobe wählen, PII-Kandidaten bestätigen lassen, anonymisieren, Restprüfung, Probeimport eines Datensatzes (Datumsformat, Auswahllabel, Verweis), dann Import in zwei Durchgängen (Datensätze ohne Verweise, dann Verweise per PATCH mit den neuen IDs).

## Phase 6: Abnahme (Freigabe)

Ablauf und Berichtsvorlage in `abnahme.md`. Ergebnis in `ergebnis/abnahmebericht.md` und im Dokumentationsmodul. Erst nach Freigabe gilt die Teststrecke als bestanden.

## Phase 7: Optimierung (Freigabe)

Ablauf in `optimierung.md`. Erst Vorschlagsliste, dann die Frage: "Soll zusätzlich eine verbesserte Version `<Modul>_v2` erstellt werden?" Ohne ausdrückliches Ja nichts bauen. Die 1:1-Version bleibt unverändert.

## Live-Ansicht (optional, ab Phase 3)

Vor Phase 3 genau eine Frage: "Möchtest du die Änderungen live im Browserfenster neben dem Chat mitverfolgen?" (Empfehlung Ja). Ablauf und Sicherheitsregeln im Skill `ninox-start`, `references/live-ansicht.md`: Der Nutzer meldet sich selbst an, Claude sieht keine Zugangsdaten. Nach Phase 3 die Startseite des Workspace zeigen (neue App noch **nicht** öffnen), nach Phase 5 (Import fertig) die App, nach Phase 6 den Abnahmebericht, nach Phase 7 `_v2`.

## Phase 8: Abschluss und Aufräumen

Immer nur ein Schritt pro Nachricht (siehe `fuehrung.md`). Liste: `Get-NinoxAufraeumListe`.
0. **Abschlussfrage vor allem Aufräumen:** "Sollen die erstellten Apps noch in einen anderen Workspace kopiert werden?" Ablauf bei Ja: `references/kopie-in-anderen-workspace.md`. Bei Nein weiter mit 1. Erst nach der Antwort aufräumen, weil die Kopie `arbeit/` und einen Key für den Ziel-Workspace braucht.
1. Test-Key in Ninox widerrufen (auch Keys ohne Ablauf oder mit "Rechteverwaltung"). Nutzer bestätigt.
2. Benutzervariable `NINOX_API_KEY` löschen (`[Environment]::SetEnvironmentVariable('NINOX_API_KEY', $null, 'User')`) und Bitwarden-Eintrag als widerrufen markieren. `Test-NinoxKeyHygiene` prüft, ob sie weg ist.
3. `Test-NoSecretLeak` über Projektordner und Skillordner: kein Key in Dateien.
4. `Test-ErgebnisFuerWeitergabe` über `ergebnis/` (mit Wortliste für Firmennamen, die der Nutzer nennt), bevor etwas weitergegeben wird.
5. Wegwerf-Module (`zz_probe_*`) und `arbeit/`: der Nutzer entscheidet über Löschen oder Behalten. Module nur über `Remove-Ninox4ModulKontrolliert` löschen (Bestätigung "Ja, loeschen", nur leere Projektmodule).
6. Abschlussbericht `ergebnis/phase_8_bericht.md` (Zahlen, Entscheidungen, offene Punkte, Supportmeldungen).

## Später: Vollimport

Nicht Teil dieses Skills in der Teststrecke. Der Skill hält fest, was dafür nötig ist (Reihenfolge, Batchgröße, Anhänge, Abnahmeplan), und fährt erst nach eigener, ausdrücklicher Freigabe fort. Datensatz-IDs vergibt Ninox 4 neu, die Zuordnung alt zu neu gehört in eine lokale Datei in `arbeit/`.

## Fehler und Rückfall

- API-Fehler: Meldung lesen, Ursache beheben, nie das Design ändern, damit ein Aufruf durchgeht. Bei 413 Nutzlast teilen.
- **Schreibtempo (vorbeugend):** Alle Bauskripte schreiben nacheinander und warten zwischen den Aufrufen (`-PauseMs`, Voreinstellung 300 ms, Formelfelder 600 ms). Die Pause passt sich an: nach einem Serverfehler doppelt so lang (bis 8 Sekunden), nach 5 Erfolgen in Folge wieder halb so lang bis zur Basis. Grund: höchstens 3 gleichzeitige Schreibvorgänge je Workspace, und Formelfelder werden beim Anlegen geprüft und berechnet. Bei Freigabetexten für schreibende Phasen die erwartete Dauer nennen ("einige Minuten, bewusst langsam").
- **Vorübergehende Serverfehler** (beobachtet 2026-10-06): `upstream connect error ... Connection refused`, `WORKSPACE_TRANSACTION_CONCURRENCY_LIMIT_EXCEEDED` (höchstens 3 gleichzeitige Schreibvorgänge je Workspace), 429, 502, 503, 504. Das sind keine Planfehler. Die Skripte warten mit steigender Pause (3, 6, 9 ... Sekunden, bis zu 6 Versuche je Aufruf), zeigen einmal den Hinweis "Ninox antwortet gerade nicht oder ist ausgelastet" und zählen die Wartefälle (`ServerWartezeiten`). Beim Anlegen vieler Formelfelder tritt das gehäuft auf, weil Ninox jede Formel beim Anlegen prüft und berechnet. Der Nutzer wird **immer** mit dem Standardtext aus `fuehrung.md` informiert, und bei anhaltender oder beendeter Störung bekommt er die fertige Supportmeldung (`ergebnis/support/<Zeitstempel>_support_meldung.txt`) als Codeblock zum Kopieren und Weitergeben an den Ninox Support. Die Skripte sind wiederaufnehmbar: bereits angelegte Felder werden übersprungen.
- Unerwartetes Verhalten (Tabelle verschwindet, Auswahlfeld liefert IDs statt Labels): stoppen, nicht löschen und neu anlegen, mit dem Nutzer klären.
- Zurück: Der Skill löscht nie Module oder Tabellen ohne ausdrücklichen Auftrag. Ein misslungenes Ziel wird verworfen und unter neuem Namen neu gebaut.
