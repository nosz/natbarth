# Formeln und Skripte übersetzen (Phase 4)

Grundsatz: **1:1 übersetzen**, nur ändern, was die Ninox-4-Syntax zwingend verlangt. Vereinfachungen (z. B. Adresslisten in eine Tabelle auslagern) sind ein getrennter Vorschlag in Phase 7. Nur so lässt sich später sagen, ob ein Unterschied im Ergebnis aus der Syntax oder aus einem Umbau stammt.

## Ablauf

1. **Analyse:** `Invoke-Ninox3Phase1` (oder `Export-Ninox3FormulaAnalysis -Schema -FieldRows -Mapping -Path -SafePath`) schreibt die volle Fassung `arbeit/inventar/08_formel_analyse_voll.csv` mit `Original` und `Rohuebersetzung` (Formeltexte, können Echtdaten enthalten, nur lokal) und die bereinigte Fassung `ergebnis/08_formel_analyse.csv` mit Status, Funktionen und Zählern. Die Funktion gibt nur eine Zusammenfassung zurück, nie Formeltexte. Je Formel: verwendete `Funktionen`, `Variablen`, aufgelöste `Felder`, `Unbekannt`, `Status` (`aufgeloest` oder `pruefen`). **Immer mit dem freigegebenen Mapping neu erzeugen**, bevor gebaut wird, weil die Rohübersetzung die Ninox-4-Namen daraus verwendet.
2. **Was die Rohübersetzung leistet:** Sie ersetzt Feld- und Tabellenkürzel (`O2`, `G.Y.A`, `select Q`) durch die Ninox-4-Namen aus dem Mapping. Sie löst Verweisketten Schritt für Schritt auf (`G` Verweis auf Tabelle `B`, dort Feld `Y`, ...), kennt `let`-Variablen, Funktionsaufrufe und Schlüsselwörter und lässt Zeichenketten unberührt.
3. **Was sie nicht leistet:** Syntaxunterschiede zwischen Ninox 3 und 4. Dafür jede in `Funktionen` genannte Funktion und jedes Konstrukt gegen den `ninox`-Skill (`references/scripting-and-formulas.md`) und docs.ninox.com prüfen. Was dort nicht belegt ist, als "unbelegt" markieren und im Test-Workspace ausprobieren.
4. **`Unbekannt`:** Jedes Token dieser Spalte klären, bevor die Formel gebaut wird: Variable, Tabelle, Funktion oder ein Muster, das die Analyse nicht kennt. Nicht raten. Zeilen mit `pruefen` werden nicht automatisch gebaut.
5. **Funktionsfeld anlegen:** `type: function`, `expression` (Schlüssel heißt `expression`, `script` wird abgelehnt). Zurücklesen und `expressionErrors` oder einen leeren Ausdruck melden.
6. **Prüfung beim Anlegen (beobachtet 2026-10-06):** Ninox lehnt Formeln mit Syntaxfehler oder unbekanntem Feld beim Anlegen ab und nennt Zeile und Spalte. Das Anlegen ist daher selbst die Syntaxprüfung: Fehlermeldung je Formel festhalten, Formel korrigieren (Reihenfolge der Felder prüfen: Formelfelder zuletzt, nach allen Feldern, auf die sie verweisen) oder als Lücke führen. Ob eine syntaktisch gültige Formel dasselbe **bedeutet** wie in Ninox 3, ist damit nicht belegt (siehe unten). `/script/exec` verschluckt laut Builder-Notizen Fehler und eignet sich nicht als Prüfung.
7. **Trigger** (`afterUpdate` u. ä.): Die API kennt sie (Feld `onUpdate`, Tabelle `onCreate`/`onUpdate`/`onDelete`, OpenAPI 1.0.0). Der Ausdruck wird wie eine Formel übersetzt und gesondert geprüft, siehe Lücken. Änderungen über die API lösen keine Trigger aus, Anlegen über die Oberfläche schon (beobachtet); der Datenimport löst sie also nicht aus.

## Formeln mit "like": Ninox meldet einen Fehler, legt das Feld aber an (beobachtet 2026-10-06)

Beim Anlegen von Formelfeldern mit dem Operator `like` per API antwortet Ninox mit `An unexpected error occurred in a workspace object operation`, **legt das Feld aber trotzdem an**, und die Formel rechnet korrekt (z. B. `if name like "Mueller" then 1 else 2 end` liefert 2). Das ist vermutlich ein Fehler auf Ninox-Seite und gehört dem Support gemeldet (Minimalbeispiel: Funktionsfeld mit `name like "x"` in einer beliebigen Tabelle anlegen). Folgen für den Skill:
1. `like` wird **1:1 beibehalten**. Die Umwandlung in `contains(A, B)` (`-LikeUmwandeln`) ist nur auf ausdrücklichen Wunsch möglich, weil `contains` Groß- und Kleinschreibung unterscheidet und die Bedeutung ändern kann (Dokumentation: `like` prüft "enthaltener Text", Groß-/Kleinschreibung dort nicht angegeben).
2. Nach genau dieser Fehlermeldung liest der Skill die Felder der Tabelle zurück: Existiert das Feld, gilt die Formel als angelegt (Protokoll: "OK (Ninox meldete Fehler, Feld existiert)", Zähler `AngelegtTrotzFehlermeldung`). Nie blind wiederholen und nie löschen.
3. Dem Nutzer sagen, dass Ninox hier eine irreführende Fehlermeldung liefert und was der Skill dazu geprüft hat.

**Die Zeichenlänge spielt keine Rolle, die Verschachtelungstiefe schon** (beobachtet 2026-10-06 mit erfundenen Formeln im Wegwerf-Modul): Eine flache Formel mit 3997 Zeichen wird in 1 Sekunde angelegt. Eine `if`-Kette bis 19 Ebenen wird sofort angelegt, ab 20 Ebenen dauert es Sekunden und Ninox meldet den irreführenden Fehler (Feld entsteht), ab 26 Ebenen folgt nach etwa 60 Sekunden eine Zeitüberschreitung ("upstream connect error"), in jeder Schreibweise (mit oder ohne `end`, mit oder ohne Klammern). An der echten Lösung gingen Ketten mit 17 Ebenen durch, die zwei mit 28 und 29 Ebenen nicht. Folgerungen für den Skill:
1. Die Analyse zählt die `if`-Ebenen (`Get-N3MaxIfDepth`, Spalte `Tiefe`). `Invoke-Ninox4FormulaBuild` versucht Formeln mit mehr als `-MaxTiefe` (18) Ebenen **nicht** und führt sie als "zu tief verschachtelt" (`ZuTiefVerschachtelt`). Nur nach ausdrücklicher Entscheidung des Nutzers mit `-TiefeIgnorieren` erzwingen (belastet den Server und endet vermutlich in der Zeitüberschreitung).
2. Dem Nutzer die Optionen mit Empfehlung vorlegen: (a) **Aufteilen in Teilformeln** (Hilfsfelder): Die Kette wird nach je etwa 15 Zweigen getrennt, der Rest steht in einem Hilfsfeld, auf das der letzte Zweig verweist; das Ergebnis bleibt gleich, die Struktur ändert sich (als Lücke und Hinweis dokumentieren). (b) In eine **Stammdatentabelle** auslagern (Vorschlag aus Phase 7, ändert das Datenmodell). (c) In der Ninox-Oberfläche anlegen, falls sie das annimmt (ungeprüft). (d) Als Lücke führen.
3. Der Fall ist als geprüfte Abweichung in `ergebnis/abweichungen.csv` erfasst und kann den Entwicklern gemeldet werden (`New-NinoxEntwicklerMeldung`, `New-NinoxSlackMeldung`).
## Stolperfallen aus der Praxis

Aus `ninox4-api-builder/references/ninox4-api-notizen.md` (beobachtet, nicht offiziell):

- Fehlendes `end` bei `if` führt zu stillem Abbruch.
- Zeilenumbruch in Texten: einen echten Umbruch in eine Variable legen, `"\n"` wirkt nicht. Ninox-3-Formeln enthalten oft echte Umbrüche in Zeichenketten; beim Übertragen als JSON maskiert, danach zurücklesen und vergleichen.
- In Schleifen ist `this` nicht nutzbar: vorher `let me := this`.
- Leere Skripte nicht als `null`, sondern als `""` übergeben.
- Auswahlfelder per Zahl (Index) setzen, nicht per Label, wenn der Ausdruck schreibt.

## Prüfung nach dem Anlegen

- Läuft die Formel (Feld lesbar, keine Fehlermeldung)? Beleg: Rücklesen eines Testdatensatzes.
- Liefert sie plausible Werte? Stichprobe aus Phase 5.
- Stimmt sie mit Ninox 3 überein? Nur mit Soll-Werten aus Ninox 3 belegbar (`abnahme.md`, Prüfung C). Ohne Soll-Werte steht im Bericht "nicht belegt", nicht "bestanden".

## Auflistung im Dokumentationsmodul

Je Formel eine Zeile in `felder_mapping` plus Eintrag in `luecken`, wenn etwas unbelegt blieb (Funktion, Syntax, Verhalten). Formeltext selbst nur dann ablegen, wenn er keine Echtdaten enthält. In der Beispieldatei stehen Firmenadressen fest in Formeln: solche Formeln als "Echtdaten in Formel" kennzeichnen und für die Dokumentation nur Länge und Struktur nennen.

## Operator `like` (Stand 2026-10-06 nachmittags)

- **Lösung (vom Nutzer genannt, mit Probefeldern bestätigt): `text(A) like B`.** Ninox 4 nimmt `like` per API nur an, wenn der **linke** Operand in `text()` steht, auch bei Textfeldern. Getestet und angelegt: `text(name) like "x"`, `text(auswahl) like "x"`, `text(zahl) like "1786"`, `text(zahl) like 1786`, `text(verweis.feld) like "x"`. Ohne `text()` (`name like "x"`, `verweis.feld like "x"`) antwortet die API mit HTTP 500 und legt das Feld nicht an. `like` bleibt damit erhalten, `contains` ist nicht nötig (und kann nur Text: `Undefined function: contains(choice,string)`).
- `-LikeUmwandeln` bei `Export-Ninox3FormulaAnalysis` schreibt `A like B` zu `text(A) like B` um. Die Bedeutung bleibt wie in Ninox 3, weil weiter `like` gilt.
- Am Vormittag legte Ninox 4 Formelfelder mit `like` ohne `text()` noch an und meldete dabei einen Fehler; das ist nachmittags nicht mehr so. Als Abweichung Nr. 5 erfasst (die allgemeine 500-Meldung nennt den Grund nicht, andere Formelfehler haben genaue Texte).
- **Lehre:** Die Ninox-4-Fehlermeldungen beim Anlegen sind brauchbar, wenn man den Text vollständig liest (`formel_fehler.csv`). Nie nur den Vermerk "Feld besteht trotzdem" des Bauskripts glauben: nach dem Bauen die Felder zurücklesen (Abnahme A).