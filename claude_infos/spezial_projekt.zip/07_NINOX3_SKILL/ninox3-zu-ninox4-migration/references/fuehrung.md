# Den Nutzer führen: ein Schritt nach dem anderen

Ziel: Auch wer Ninox, PowerShell und API nicht kennt, soll die Migration sicher durchlaufen, ohne überfordert zu sein. Der Skill ist professionell im Ergebnis und einfach im Umgang. Die Technik bleibt in den Dateien, im Gespräch steht nur, was der Nutzer jetzt wissen oder tun muss.

## Inhalt
- Grundregeln
- Nachrichtenmuster
- Erste Schritte (Einstieg)
- Entscheidungen in Phase 2: Reihenfolge
- Wenn etwas laut Dokumentation gehen müsste, aber nicht geht
- Abschluss (Phase 8)
- Standardtexte für Sonderfälle
- Konkrete Anleitungen (immer mit Schritten, nie nur "setz den Key")

## Grundregeln

1. **Immer nur ein Schritt oder eine Frage pro Nachricht.** Nie mehrere Fragen gleichzeitig, nie eine Liste von Aufgaben, die der Nutzer abarbeiten soll. Erst wenn der Nutzer geantwortet hat, kommt der nächste Schritt.
2. **Fortschritt zeigen:** "Schritt 2 von 6" oder "Phase 2 von 7". So weiß der Nutzer, wo er steht und wie viel noch kommt.
3. **Jede Entscheidungsfrage hat eine Empfehlung mit kurzer Begründung** (ein bis drei Sätze), dazu die möglichen Antworten. Die Empfehlung steht zuerst. Der Nutzer kann mit "ok" die Empfehlung übernehmen. "Ok" auf eine Entscheidungsfrage gilt als Übernahme der Empfehlung. Für **schreibende Phasen** (Phase 3 bis 7) braucht es trotzdem ein klares "Ja" auf die genannte Aktion mit Workspace und Modul.
4. **Einfache Sprache.** Kurze Sätze, keine unerklärten Fachwörter. Kommt ein Fachwort vor (z. B. "Mapping", "API", "Trigger"), einmal in einem Halbsatz erklären. Dateinamen und Befehle nur nennen, wenn der Nutzer sie gerade braucht.
5. **Möglichst wenig fragen.** Was sich aus Dateien, Konfiguration oder früheren Antworten ergibt, nicht erneut fragen. Sinnvolle Standardwerte vorschlagen (Stichprobe 20, Anonymisierung an, Namen aus Beschriftungen) und nur dort fragen, wo eine Entscheidung nötig ist.
6. **Zwischenstände knapp:** Nach jeder Phase höchstens fünf Zeilen: was gemacht wurde (Zahlen), was auffällt, was als Nächstes kommt, eine Frage. Details nur auf Wunsch ("Möchtest du Details dazu?").
7. **Selbst prüfen, was man prüfen kann** (Dateien vorhanden, Variable gesetzt, Verbindung), statt den Nutzer zu fragen. Dem Nutzer nur das überlassen, was nur er tun kann (Key erzeugen, Datei exportieren, Entscheidungen).
8. **Fehler ruhig und lösungsorientiert:** sagen, was passiert ist, was es bedeutet, was der nächste Schritt ist. Keine Fehlerlisten, keine Vorwürfe.
9. **Sicherheit ohne Belehrung:** Die Regeln (Key nie im Chat, nur Testumgebung) einmal an der passenden Stelle erklären, nicht bei jeder Nachricht wiederholen.
10. **Rückfrage bei Unklarem:** Kommt eine Antwort wie "o" oder "k", die nicht eindeutig ist, kurz nachfragen, wenn es um etwas Schreibendes geht. Bei reinen Lese- oder Entwurfsschritten genügt es, die Deutung zu nennen ("Ich lese das als ok").

## Nachrichtenmuster

**Frage mit Empfehlung**
```
Schritt 3 von 6: <Kurztitel>
<Eine Frage in einem Satz?>
Empfehlung: <Antwort>. Grund: <ein bis zwei Sätze>.
Du kannst mit "ok" zustimmen oder etwas anderes schreiben.
```

**Aufgabe für den Nutzer (nur eine)**
```
Schritt 4 von 6: <Kurztitel>
Bitte tue Folgendes: <genau eine Aufgabe, ggf. mit einem Befehl>.
Sag mir "fertig", dann prüfe ich es.
```

**Phasenabschluss**
```
Phase <n> ist fertig.
- <Zahl/Ergebnis 1>
- <Zahl/Ergebnis 2>
- Auffällig: <maximal ein Punkt>
Als Nächstes: <Phase n+1 in einem Satz>. Soll ich starten? (Ja/Nein)
```

## Erste Schritte (Einstieg)

Beim ersten Kontakt oder bei "Erste Schritte" führt der Skill durch diese Schritte. Immer nur einen zeigen, auf die Rückmeldung warten und, wo möglich, selbst prüfen.

| # | Schritt | Wer | Prüfung durch den Skill |
|---|---|---|---|
| 1 | Projektordner festlegen (Vorschlag: neuer Ordner mit dem Namen der Lösung) | Nutzer nennt Pfad | Ordner existiert oder wird angelegt |
| 2 | Die zwei Sicherungsdateien der Ninox-3-Lösung bereitstellen (einmal ohne, einmal mit Datensätzen) | Nutzer | beide Dateien vorhanden, Größen nennen |
| 3 | Analyse starten (Phase 0 und 1, läuft lokal, schreibt nichts nach Ninox) | Skill | Sicherungspaar bestanden, Zahlen |
| 4 | Plan durchgehen: Namen, Lücken, offene Punkte, eine Entscheidung nach der anderen (Phase 2) | Nutzer entscheidet | Mapping und Namensprüfung ohne Fehler |
| 5 | Plan freigeben | Nutzer | ausdrückliches Ja |
| 6 | Test-Workspace: Workspace-ID und Name des neuen, leeren Moduls nennen | Nutzer | Konfiguration ohne Geheimnisse angelegt |
| 7 | Key erzeugen, in Bitwarden speichern, im eigenen Terminal laden (ein Teilschritt pro Nachricht) | Nutzer | Variable gesetzt (nur Länge), Verbindungstest |
| 8 | Aufbau in Ninox 4 (Phase 3 bis 6), je Phase eine Freigabe | Skill, Nutzer gibt frei | Rücklesen nach jedem Schritt |
| 9 | Verbesserungsvorschläge ansehen und entscheiden (Phase 7) | Nutzer | Entscheidung je Vorschlag |

Schritte 1 bis 5 brauchen keinen Ninox-4-Zugang. Wer nur wissen will, was eine Migration umfasst, kann nach Schritt 4 aufhören.

## Entscheidungen in Phase 2: Reihenfolge

Jede als eigene Frage mit Empfehlung (Muster oben), in dieser Reihenfolge, und nur, wenn es etwas zu entscheiden gibt:

1. Rollennamen: Bezeichnet einer eine Person? (Hinweis auf `arbeit/inventar/rollen.txt`, nicht im Chat nennen.)
2. Namen: Warnungen der Namensprüfung, eine Gruppe nach der anderen (nummerierte, sehr kurze, Schlüsselwörter). Empfehlung: Vorschlag übernehmen, sprechende Namen nur dort ändern, wo es die Anwender verwirrt.
3. Labels: Soll der Skill für kryptische Beschriftungen ausgeschriebene Bezeichnungen vorschlagen? Empfehlung: ja, nur als Vorschlag.
4. Lückenliste: Welche Lücken sind akzeptiert, welche sollen nachgebaut werden? Nach Kategorie, nicht Zeile für Zeile (Berichte, Ansichten, Rechte, Anhänge, ...).
5. Rechte: Gegenüberstellung freigeben oder später klären.
6. Zusammenfassung und Freigabe von Phase 3.

Jede Entscheidung sofort festhalten (`Add-Ninox3Decision`, bei Lücken `Add-Ninox3GapRow`, siehe `scripts/ninox3-entscheidungen.ps1`), damit der Plan nachvollziehbar bleibt und bei Unterbrechung nichts verloren geht. Keine Personennamen ins Protokoll schreiben.

## Wenn etwas laut Dokumentation gehen müsste, aber nicht geht

1. **Nicht gleich "Fehler" sagen.** Dem Nutzer in einem Satz sagen, was auffällt ("Laut Dokumentation sollte X gehen, bei uns kommt Y. Ich prüfe, ob das ein Fehler von uns oder von Ninox ist.").
2. Die Prüfpunkte abarbeiten (siehe `SKILL.md`, Regel 13): Dokumentationsstelle suchen, im Wegwerf-Modul ein Minimalbeispiel bauen, zu einem späteren Zeitpunkt wiederholen, eine Gegenprobe machen, eigene Fehler und Serverstörungen ausschließen.
3. Ist alles erfüllt: sagen, dass es sich nach Prüfung um eine Abweichung bzw. einen mutmaßlichen Fehler auf Ninox-Seite handelt, und die **Meldung als Codeblock** zeigen: "Diese Meldung kannst du direkt an die Ninox-Entwickler oder den Support geben. Sie enthält das Minimalbeispiel, alles zum Nachstellen und was getan werden soll. Kein Key, keine Kundendaten." **Fundstelle ist Pflicht:** Eine Abweichung gilt erst als geprüft, wenn Workspace-ID, Modul, Tabelle und Feld des Beispiels (-Workspace -Modul -Tabelle -Feld, weitere vorhandene Beispielfelder in -Fundstellen) angegeben sind. Die Meldung setzt sie in Kopfzeile und curl-Beispiel ein; nur der Key bleibt Platzhalter. Den Speicherort nennen und anbieten, den Eintrag in die Tabelle `abweichungen` im Dokumentationsmodul zu übernehmen.
3b. **Pro Abweichung gibt es genau eine Datei** `ergebnis/support/<Zeitstempel>_meldung_<nr>_<kurztitel>.txt` (erst Englisch, dann Deutsch; Wo, Problem, erwartet laut Doku, Nachstellen, curl, Workaround). Sie ist schlicht gehalten und passt unverändert in Slack, Mail oder ein Ticket; es gibt keine getrennte Slack-Datei. `New-NinoxSlackMeldung` liefert dieselbe Datei. Den Inhalt als Codeblock zum Kopieren zeigen.
3a. Die Meldung ist **kurz** und liegt **auf Deutsch und auf Englisch** vor. Den englischen Text (Titel, Erwartung, tatsächliches Verhalten, Reproduktion, Gegenprobe, Workaround) schreibst du beim Erfassen selbst in sauberem, sachlichem Englisch; ohne ihn bleibt der Fall ein Verdacht. Alle Angaben, die die Entwickler zum Nachstellen brauchen, gehören hinein (Aufruf, Beispiel-Body, Antwort, Gegenprobe), nichts darüber hinaus.
4. Ist es nur ein Verdacht (Prüfpunkte offen): als Verdacht lokal festhalten, offene Prüfpunkte nennen, nichts melden.
5. Danach mit der Arbeit weitermachen, ggf. mit dem dokumentierten Workaround.

## Abschluss (Phase 8)

**Zuerst die Abschlussfrage, mit einer Auswahl (Ja oder Nein):** "Sollen die erstellten Apps noch in einen anderen Workspace kopiert werden?" (Ablauf: `kopie-in-anderen-workspace.md`). Erst danach aufräumen. Jeder Schritt einzeln, Muster "Aufgabe für den Nutzer": erst Key widerrufen ("sag mir fertig"), dann Variable löschen (Befehl im eigenen Terminal, der Skill prüft danach nur "gesetzt/nicht gesetzt"), dann Prüfungen des Skills (Geheimnis-Suche, Weitergabe) mit kurzem Ergebnis, zuletzt die Entscheidung über Wegwerf-Module und `arbeit/` (Löschen nur mit "Ja, loeschen").

## Standardtexte für Sonderfälle

- **Datei fehlt:** "Mir fehlt noch die Sicherung <ohne/mit> Datensätzen. Bitte erstelle sie in Ninox 3 und nenne mir den Pfad. Die Datei ohne Datensätze genügt für die Analyse, die mit Datensätzen brauche ich für die Testdaten."
- **Sicherungspaar passt nicht zusammen:** "Die beiden Dateien gehören nicht zum selben Stand (<Grund>). Bitte erstelle beide neu, kurz nacheinander."
- **Key im Chat:** Nicht verwenden. "Bitte behandle den Key als kompromittiert: in Ninox widerrufen, diese Unterhaltung löschen, neuen Key nur in Bitwarden speichern und it@ninox.com informieren. Danach laden wir den neuen Key im Terminal, ohne dass er im Chat auftaucht."
- **Variable nicht sichtbar:** "Ich sehe den Key in dieser Sitzung nicht. Das passiert, wenn er in einem anderen Fenster geladen wurde. Bitte starte die Sitzung aus dem Fenster, in dem du ihn geladen hast." (Notlösung nur auf Wunsch: kurzlebiger Test-Key als Benutzervariable, danach widerrufen.)
- **Ninox antwortet nicht oder ist ausgelastet** (Meldungen wie "upstream connect error", "Connection refused", "too many concurrent write transactions", HTTP 429, 502, 503, 504): Das ist ein Problem auf Serverseite und kein Fehler im Plan oder in der Formel. Dem Nutzer sagen: "Ninox antwortet gerade nicht oder ist ausgelastet. Das liegt nicht an deinen Daten oder an unserer Arbeit. Ich warte und versuche es automatisch erneut, das kann einige Minuten dauern. Bitte brich nichts ab." Die Skripte warten selbst und zeigen diesen Hinweis (Rückgabewert `ServerWartezeiten` größer 0). Nach mehreren erfolglosen Versuchen: anhalten, den Stand nennen (was ist angelegt, was fehlt), nichts löschen und neu anlegen, und fragen: "Soll ich es später noch einmal versuchen?" Läuft ein Skript länger als erwartet, im Hintergrund weiterlaufen lassen und dem Nutzer Bescheid geben, statt es abzubrechen. Erst bei anhaltenden Störungen den Ninox Support einschalten.

  **Pflicht bei jeder Serverstörung (nicht weglassen):**
  1. Dem Nutzer **sofort** sagen, dass der Ninox-Server gerade nicht antwortet bzw. nicht aufrufbar ist (Standardtext oben).
  2. Wenn die Störung anhält, der Vorgang abbricht oder beendet ist und Störungen aufgetreten sind (Rückgabewert `SupportMeldung` ist gefüllt): die Datei `ergebnis/support/<Zeitstempel>_support_meldung.txt` lesen und ihren Text dem Nutzer **vollständig als Codeblock** zeigen, mit dem Satz: "Diese Meldung kannst du kopieren und an den Ninox Support schicken. Sie enthält keinen Key und keine Kundendaten." Den Speicherort der Datei nennen.
  3. Danach fragen, ob der Vorgang später fortgesetzt werden soll. Nichts löschen, nichts neu anlegen.

  Aufbau der Supportmeldung (erzeugt `New-NinoxSupportMeldung`, kurz und zweisprachig, Deutsch und Englisch vollständig): Betreff mit Workspace-ID; Zeile **FUNDSTELLE / LOCATION** (Workspace-ID, Modul, Tabelle, Feld, damit die Entwickler den Fall sofort in der Oberfläche oder per Aufruf prüfen können; Feldnamen kommen über den Parameter -Feld der Bauskripte); Kurzsatz mit Zahl der fehlgeschlagenen und erfolgreichen Aufrufe und Art der Fehler; Zeitraum in lokaler Zeit und UTC; Workspace, Modul, API-Version; Beispielaufruf als `curl` mit Platzhalter für den Key; Originalmeldung von Ninox; Bitte um Prüfung auf Störung oder Auslastungsgrenze. Kein Key, keine Kundendaten.
- **Nutzer ist überfordert** ("zu viel", "verstehe ich nicht"): einen Schritt zurück, in zwei Sätzen erklären, was gerade passiert und warum, nur die nächste Frage stellen.

## Konkrete Anleitungen (immer mit Schritten, nie nur "setz den Key")

**Jeder Fachbegriff, der eine Handlung verlangt (Terminal, PowerShell, Befehl einfügen, Variable, Neustart), wird mit dem genauen Handgriff erklärt**: wo man klickt, was man tippt, was man dann sieht. Nie schreiben gib den Key dem Terminal oder lade die Variable, ohne diese Schritte. Jede Anleitung beginnt mit drei Zeilen in einfacher Sprache, auch für Nicht-IT-Leute verständlich: **Wo:** System und Workspace (Name und ID), **Problem:** was gerade nicht geht und warum es uns aufhält, **Zu tun:** was der Nutzer jetzt erledigt. Erst danach die Schritte. Wenn der Nutzer etwas selbst tun muss, gibt es **immer** eine nummerierte Anleitung mit genauen Klickwegen oder Befehlen, im Chat, ohne Verweis auf andere Dokumente. Pro Anleitung: Ziel in einem Satz, Schritte, woran man merkt, dass es geklappt hat, und "sag mir Bescheid, wenn fertig". Befehle in einem eigenen Codeblock, einer pro Block. Wenn ein Klickweg nicht sicher bekannt ist, das sagen und den Weg nach der Doku nennen.

### Anleitung: Ninox-4-API-Key (einfach und sicher)

**Wo:** Ninox 4 (go.ninox.com), Workspace **<Klarname aus workspaceName>** (ID `<WORKSPACE_ID>`). Der Klarname steht immer zuerst; steht er noch nicht als `workspaceName` in `ninox.config.json`, vorher den Nutzer fragen.
**Problem:** Der Skill braucht einen Schlüssel (API-Key), mit dem Ninox ihm erlaubt, in diesem Workspace zu arbeiten. Aktuell fehlt er oder wird abgelehnt.
**Zu tun:** Du erzeugst den Schlüssel in Ninox und gibst ihn **einmal** in einem eigenen Fenster ein. Ein kleines Programm prüft ihn und legt ihn verschlüsselt nur für dein Windows-Konto ab. Claude kommt nie damit in Berührung, du musst Claude nicht neu starten.

1. In Ninox 4 den Workspace **<Klarname>** öffnen. Zahnrad (Einstellungen), im Bereich WORKSPACE **"API & integrations"**, dann **"Create API key"**.
2. Name `migration_<Zweck>_7d`, **Ablauf in 7 Tagen**, Lese- und Schreibrecht, "Create API key". Den Key **sofort in Bitwarden speichern**. Er wird nur einmal angezeigt.
3. **Das Eingabefenster öffnen.** Am einfachsten **öffnet Claude es für dich**: Es erscheint das **Terminal-Fenster in der Claude-App** (Symbol `>_` oben rechts im Claude-Fenster) mit dem bereits eingetippten Befehl; du bestätigst nur die Rückfrage der App. Das Fenster ist deins, Claude liest dort **nichts mit**, solange du den Key eingibst.
   *Falls das nicht klappt:* Terminal-Symbol `>_` oben rechts im Claude-Fenster anklicken, oder ein normales Windows-PowerShell öffnen (Windows-Taste drücken, `PowerShell` tippen, Enter) und den Befehl aus dem Kasten unten einfügen (Rechtsklick fügt ein, dann Enter).
4. **Befehl** (Claude nennt ihn mit dem echten Pfad, `-ExecutionPolicy Bypass` gilt nur für diesen einen Aufruf und ändert keine Windows-Einstellung; ohne ihn blockiert Windows Skripte oft):

   `powershell -NoProfile -ExecutionPolicy Bypass -File "<Pfad zu ninox-start>\scripts\Key-einrichten.ps1"`
5. **Drei kurze Fragen beantworten**, eine nach der anderen: (1) die **ganze Adresse** des Workspace aus der Browserzeile einfügen (die komplette Adresse genügt), (2) wie lange der Key gilt (Enter = 7 Tage), (3) den Key aus Bitwarden einfügen. **Einfügen im Terminal immer mit der rechten Maustaste** (Strg+V funktioniert dort nicht immer). Der Name des Workspace wird nicht gefragt, Claude liest ihn später im Browserfenster ab. Bei (3) erscheint **nichts** auf dem Bildschirm, auch keine Sternchen. Das ist gewollt, damit niemand mitlesen kann.
6. Du siehst **"Fertig. Verbindung steht ..."**. Dann im Chat **"Key fertig"** schreiben. Claude prüft selbst (nur ja/nein, nie den Key) und schließt das Terminal-Fenster wieder.
Meldet das Programm "Ninox lehnt den Key ab (401)": falscher Workspace (jeder Key gilt nur für einen), abgelaufen oder widerrufen. Dann Schritt 1 und 2 für einen neuen Key wiederholen; der Nutzer verliert dabei nichts.

**Aufräumen am Ende:** `Remove-NinoxKey -WorkspaceId <id>` im PowerShell-Fenster (löscht die lokale Ablage) und den Key in Ninox widerrufen (selbe Seite "API & integrations", Key öffnen, widerrufen), den Bitwarden-Eintrag als widerrufen markieren.

*Ältere Variante (nur wenn die verschlüsselte Ablage nicht möglich ist):* Key in eine Benutzervariable `NINOX_API_KEY` schreiben. Das ist unverschlüsselt im Profil und nur für einen kurzlebigen Test-Key vertretbar; danach die Variable wieder löschen.
