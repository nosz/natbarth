# Lückenkatalog

Alles, was nicht 1:1 nach Ninox 4 übernommen wird, steht mit Grund in der Lückenliste (`ergebnis/09_luecken.csv`, Spalten wie Tabelle `luecken` im Dokumentationsmodul). Keine stille Auslassung. "Beleg" nennt die Quelle für die Aussage "geht nicht" oder "unbelegt".

## Standardbehandlung

| Kategorie | Erkennung im Inventar | Standardbehandlung | Beleggrad |
|---|---|---|---|
| Berichte (Druck-Layouts) | `05_berichte.csv` | Per API anlegbar (`POST .../tables/{t}/reports`); Layouts nachbauen und prüfen, bis dahin Lücke | API belegt (OpenAPI 1.0.0), Gleichwertigkeit ungeprüft |
| Ansichten | `04_ansichten.csv` | Per API anlegbar (`POST .../tables/{t}/views`, Typen Calendar bis Table); nachbauen und prüfen, bis dahin Lücke | API belegt (OpenAPI 1.0.0), Gleichwertigkeit ungeprüft |
| Rollen und Rechte | `Lesen`/`Schreiben` an Tabellen und Feldern, Rollenliste | Gegenüberstellung, Anlage nur mit Freigabe; Rollennamen können Personen sein | Rollen-Arrays und Zugriffsausdrücke belegt, Zuordnung benutzerdefinierter Rollen unbelegt |
| Trigger | Spalte `Trigger` | Ausdruck übersetzen und per `onUpdate`/`onCreate`/`onDelete` setzen, getrennt prüfen | API belegt, Syntax im Test |
| Layoutelemente (`uis`: Überschriften, Gruppen) | `Layoutelemente` in `01_tabellen.csv` | im Formular-/Seitenbau mit `ninox4-api-builder` | Builder-Skill |
| Anhänge (Datei- und Bildfelder) | Zahl der Dateifelder und der Datensätze mit Dateiname (`DateinamenInDatensaetzen`) | Feld anlegen, Anhänge später; Zahl der betroffenen Datensätze nennen | Export enthält keine Binärdaten (am Beispiel); Upload per API vorhanden |
| Berichtsbilder | `reports/*/files` | mit den Berichten nachbauen | - |
| `html`-Felder | Basis `html` | Typ `html` ist in der API vorhanden; Entsprechung prüfen | Typ belegt, Gleichwertigkeit ungeprüft |
| `link`-Felder | Basis `link` | als `string`/`url` vorschlagen, Zuordnung im Test klären | unbelegt |
| Standardwerte | Spalte `Standardwert` | `defaultValue` setzen, Wertumwandlung prüfen | API belegt |
| Sichtbarkeitsausdrücke | Spalte `Sichtbarkeit` | manuell; `canRead`/`canWrite` sind Zugriffs-, keine Sichtbarkeitsausdrücke | keine Entsprechung belegt |
| Kaskadierendes Löschen | Spalte `KaskadeLoeschen` | manuell oder per Skript klären | unbelegt |
| Kommentare | `comments.db` größer als 0 Bytes (im Beispiel 0) | gesondert klären | - |
| Plugins | `settings.json` `plugins` | "Ninext v3" ignorieren (nur Logging, nicht migrieren); andere Plugins als Lücke führen | Vorgabe des Nutzers |
| Echtdaten in Formeln | Formeln mit festen Firmen-/Personendaten (`like`-Ketten) | für Test anonymisiert bauen oder weglassen, mit Nutzer klären | - |
| Unbekannte Schlüssel | Spalte `WeitereSchluessel` | Mapping `ungeklaert`, Nutzer fragen | - |
| Formelvergleich ohne Soll | Prüfung C | "nicht belegt" | Export enthält keine Formelwerte |

## Aufwand schätzen

`klein` = wenige Minuten im Builder; `mittel` = Stunden oder Skriptarbeit; `gross` = eigenes Teilprojekt (z. B. 15 Druck-Layouts, 68 Ansichten). Die Zahlen kommen aus dem Inventar, die Einstufung ist eine Schätzung und wird so benannt.

## Format der Lückenzeile

`nr`, `kategorie`, `objekt` (z. B. "Bericht Shipping Label (Tabelle Shipping)"), `beschreibung`, `auswirkung` (was fehlt dem Nutzer ohne die Funktion?), `aufwand`, `status` (`offen`), `verantwortlich` (leer bis zugeteilt), `beleg` (Quelle der Aussage).
