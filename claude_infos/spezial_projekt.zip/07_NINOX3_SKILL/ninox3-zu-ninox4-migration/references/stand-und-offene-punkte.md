# Stand und offene Punkte

Version **0.9 (Teststrecke abgeschlossen)**, Stand 2026-10-06. Erster vollständiger Durchlauf Phase 0 bis 8 an der Lösung "Test-Export" (16 Tabellen, 55.642 Datensätze, 46 Formelfelder) mit einem Test-Workspace in Ninox 4. Der Skill ist **für Tests und Teststrecken einsetzbar, nicht für eine produktive Vollmigration freigegeben**, bis die Punkte unter "Vor einer Vollmigration" geklärt sind.

## Was belegt ist (Selbsttest 75 von 75, Durchlauf an der echten Lösung)

| Phase | Ergebnis im Test |
|---|---|
| 0 bis 2 | Inventar, Mapping, Lückenliste, Namen aus Beschriftungen |
| 3 Schema | 16 Tabellen, 156 Felder, 12 Verweise mit Rückverweisen, Rückzählung bestanden |
| 4 Formeln | 44 von 46 angelegt. 2 fehlen wegen Verschachtelungstiefe (28/29 `if`-Ebenen); `like` braucht `text()` links |
| 5 Daten | 109 Datensätze (anonymisierte, verknüpfungstreue Stichprobe), 111 Verweise, 52 Felder anonymisiert |
| 6 Abnahme | A Struktur bestanden mit Befund, B Daten bestanden, **C Formelwerte nicht belegt** |
| 7 Optimierung | 6 Vorschläge mit Datenbeleg; `_v2` mit Nr. 1 und 2 gebaut: 17 Tabellen, 46 von 46 Formeln, Abnahme A und B bestanden |
| 8 Abschluss | Prüfungen, Kopie in einen zweiten Workspace (Weg A) mit gleichem Ergebnis; Aufräumen der Zugangsdaten und Datenkopien ist Sache des Nutzers |

## Offen: Rückmeldung an Ninox (Entwickler und Support)

- **Meldung Nr. 2:** Formelfeld mit `if`-Kette ab ca. 26 Ebenen ergibt nach rund 60 s Zeitüberschreitung und kein Feld; ab ca. 20 Ebenen langsam. Meldung liegt in `ergebnis/support/` (englisch und deutsch), nicht versendet.
- **Meldung Nr. 5:** `like` ohne `text()` auf der linken Seite ergibt HTTP 500 und kein Feld; Workaround `text(A) like B`. Meldung liegt in `ergebnis/support/`, nicht versendet.
- **Verdacht Nr. 3:** `defaultValue` wird beim Anlegen von Datensätzen per API nicht angewendet. Gegenprobe in der Oberfläche fehlt; bleibt lokal, bis geprüft.
- Das Wegwerf-Modul `zz_probe_migration` (Quell-Workspace) belegt Nr. 5 und Nr. 2; erst nach dem Versand entfernen.

## Offen: fachlich, vor einer Vollmigration klären

1. **Prüfung C (Formelwerte gegen Ninox 3):** Die Sicherung enthält keine berechneten Werte (0 von 46). Ein Export aus Ninox 3 muss **ohne Filter, mit allen Formelspalten und der Datensatznummer** vorliegen. Die im Test gelieferten Exporte stammten aus Ansichten und deckten die Stichprobe nicht ab (Shipping 1 von 20). Offen ist auch, ob `like` in Ninox 3 Groß-/Kleinschreibung ignoriert.
2. **Mehrfachauswahl:** Kodierung in der Sicherung (Texte wie `f7` oder `3`) nicht belegt; die Felder bleiben im Import leer (35 Werte in der Stichprobe).
3. **Dateifelder:** Anhänge stehen nicht in der Sicherung, Ninox 4 braucht einen Upload. Der Weg gehört zum Vollimport (66 Werte in der Stichprobe leer).
4. **Notify Party (v2):** Das neue Feld `notify_party` in der Tabelle Consignee ist angelegt, aber leer; die fachliche Quelle ist ungeklärt.
5. **Standorte (v2):** In der Testversion anonymisiert (Standort-N). Bei der Vollmigration kommen Namen und Adressen aus den Quellwerten; Gleichheit mit den Ninox-3-Formeln ist nicht belegt.
6. **`clemen_pick_up` und `address`** (7 Zweige) blieben in v2 wie in der 1:1-Version, weil NET WEIGHT/KG das Feld mitnutzt; spätere Stufe.
7. **Zurückgestellt (Teststrecke):** Ansichten, Berichte, Layouts, Rechte, Trigger. Die API kann sie anlegen, Gleichwertigkeit ist nicht bewiesen.

## Offen: Skill selbst

- `Invoke-Ninox4SchemaBuild -Fortsetzen` ist nicht live erprobt.
- Weg B der Kopie in einen anderen Workspace (Gerüst und Daten direkt aus Ninox 4) ist nicht getestet.
- Ergebnisse der Abnahme (Tabelle `abnahme`) und der Optimierung (Tabelle `optimierung`) werden noch nicht automatisch ins Dokumentationsmodul geschrieben; nur die Tabelle `abweichungen` wird abgeglichen.
- Evals 2, 3, 5 und 6 sind nicht gelaufen; die Optimierung der Beschreibung (Auslösetreffer) ist nicht geprüft, weil Python fehlt.
- Das Dashboard und der Formularumbau (`dashboard-formulare.md`) sind Bausteine aus dem Test und noch kein Teil des Ablaufs.
- Nur Windows mit PowerShell 5.1 getestet.

## Offen: Aufräumen im Testprojekt (Nutzer)

Keys widerrufen (Quell- und Ziel-Workspace, auch alte Keys ohne Ablauf), Benutzervariable `NINOX_API_KEY` löschen, Bitwarden-Einträge als widerrufen markieren, die Ordner `arbeit` löschen (im Testprojekt: `2_PROJEKT_<Name>_INTERN\arbeit`, `...\v2\arbeit`, `...\ziel\arbeit`, `...\ziel\v2\arbeit` und `3_SKILL_ENTWICKLUNG_INTERN\eval_laeufe_mit_datenkopien`; sie enthalten Kopien der Ninox-3-Daten und tragen ein Warnschild), eigene Kopien der Exportdateien im Downloads-Ordner löschen, `zz_probe_migration` nach dem Versand der Meldungen entfernen. Die Apps im Ziel-Workspace "Test-Export Test" bleiben.

## Lehren, die in den Skill eingeflossen sind

Nach dem Bauen immer zurücklesen und mit der Abnahme prüfen (nicht dem Protokoll des Bauskripts glauben); Fehlermeldungen von Ninox beim Anlegen vollständig lesen; Klarnamen vor IDs im Gespräch; Aufgaben für Nutzer mit Wo, Problem, Schritten und Erfolgskontrolle; Löschen nur mit ausdrücklicher Auswahl oder exakter Zeile; Soll-Export vor dem Vergleich prüfen; leerer Datensatz beim Öffnen neuer Apps.

## Empfohlene Ordnerstruktur für Projekte und Weitergabe

Im Testprojekt bewährt: Der Hauptordner hat drei Bereiche, deren Name zeigt, ob man etwas weitergeben darf: `1_SKILL_zum_Weitergeben` (Skillordner, Paketdatei und Installationsanleitung, **nur das wird kopiert**), `2_PROJEKT_<Name>_INTERN` (Konfiguration, Ergebnisse, Sicherungen, Datenkopien in `arbeit`) und `3_SKILL_ENTWICKLUNG_INTERN` (Verbesserungsliste, alte Stände, Testläufe). Eine Übersicht `00_LIESMICH_Ordneruebersicht.md` liegt im Hauptordner. Ordner mit echten Kundendaten tragen die Datei `_VERTRAULICH_echte_Kundendaten_NICHT_WEITERGEBEN.txt`. Die Skripte brauchen nur `-ProjectDir`, der Projektordner darf also an beliebiger Stelle liegen.

## Skillpaket (Stand 2026-10-06)

Der Weitergabeordner enthält drei Skills: `ninox-start` (Einstieg mit der Frage Migration oder Arbeit in einer Ninox-4-Anwendung), `ninox3-zu-ninox4-migration` und `ninox4-api-builder` (unverändert vom Team übernommen), jetzt unter `.claude\skills` (zum Kopieren in den Bearbeitungsordner), dazu `START_HIER.txt`, `Installieren.ps1` (optional) und `LIESMICH_Installation.md`. Getestet: Installation in einen Temp-Ordner (Erstinstallation und zweiter Lauf ohne Überschreiben), Selbsttest 77 von 77, Weitergabe-Check aller Skills. **Nicht getestet:** das automatische Laden von `ninox-start` bei freien Sätzen ohne `/ninox-start`, und der Ablauf der Einstiegsfrage mit einer fremden Person.

## API-Key-Ablage (Stand 2026-10-06)

Der Key wird einmal im eigenen PowerShell-Fenster mit `Key-einrichten.ps1` (Skill `ninox-start`) unsichtbar eingegeben, gegen Ninox geprüft (Modulliste, nur lesend) und mit Windows-DPAPI verschlüsselt unter `%USERPROFILE%\.ninox\keys\<WorkspaceId>.key` abgelegt; daneben eine Metadatendatei ohne Key. Je Workspace ein Key, keine Umgebungsvariable, kein Neustart von Claude. Die Migrations-Skripte lesen die Ablage selbst (Workspace aus `ninox.config.json`), `ninox4-api-builder` bekommt den Key mit `Import-NinoxKey` nur für die laufende Sitzung. Getestet: Key-Selbsttest (13 von 13), Live-Verbindungsprüfung (richtiger Workspace, falscher Workspace, erfundener Key), Installation. **Grenzen:** Die DPAPI-Datei ist an Konto und Rechner gebunden (kein Umzug auf einen anderen Rechner, dort neu einrichten). Jedes Programm, das unter demselben Windows-Konto läuft, kann sie lesen; das ist derselbe Schutz wie bei einem Passwort-Tresor im angemeldeten Zustand, aber besser als eine Umgebungsvariable. Der Ablauf wurde noch nicht mit einer fremden Person erprobt.

## Einstiegsfrage (Stand 2026-10-06)

Der Einstieg `ninox-start` fragt zuerst: 1. **Ninox-3-App-Erstellung** (noch nicht aktiv, offen: Ziel, technischer Weg, Abgrenzung, siehe `ninox-start/references/ninox3-app-erstellung.md`; Hinweis: Ninox 3 könnte auch umgesetzt werden, da es dort ebenfalls eine API-Schnittstelle gibt, *"Ninox 3 could also be implemented, since an API interface exists there as well."*, API-Umfang noch zu prüfen), 2. **Ninox-4-App-Erstellung**, 3. **Migration**. Wird Punkt 1 gewählt, baut Claude nichts, sagt das offen und bietet Punkt 2 oder 3 an. **Nicht getestet** mit einer fremden Person.
