# Dashboard und Formulare in Ninox 4 bauen (Bausteine aus dem Test)

Optionale Bausteine nach der Migration, **nicht Teil des Pflichtablaufs**. Beobachtet am 2026-10-06 mit der OpenAPI 1.0.0 und im Browser geprüft. Immer erst fragen, in welcher App und welchem Workspace gebaut werden soll; geschrieben wird nur in die genannte App, gelöscht wird nichts.

## Dashboard (eigene Seite)

- Seite: `POST /modules/{modul}/components` mit `type: Page`, `name`, `labels`, `gap`, `padding`. Ein `parentId` ist für eine freie Seite nicht nötig. Die Seite steht im Menü zuerst.
- Symbol der Seite: `icon: { icon, color, filling }`. **Namen aus "Material Symbols" mit Unterstrich** (z. B. `monitoring`, `bar_chart`, `dashboard`), nicht mit Bindestrich. Bei Apps (Module) gelten Namen mit Bindestrich (`truck`, `rocket-launch`). Ein falscher Name wird akzeptiert und zeigt nur einen Rest.
- Kennzahlen: `MetricCardComponent` mit `tableName`, `aggregation` (`count`, `sum`, `avg`, ...), bei `sum` zusätzlich `fieldName`. `display` verlangt **alle vier**: `color`, `format` (`number`, `compact`, `currency`, `percentage`), `icon`, `trend` (`format`, `isShown`).
- Diagramme: `ChartComponent` mit `tableName`, `height` (z. B. 300) und `chartConfig`: `chartType` (`bar`, `line`, `pie`, `funnel`, `ranking`, `board`), `dataSets` (`fieldName`, `aggregation`, `color`, `labels`), `xAxis` (`fieldName`, `groupBy` `daily|weekly|yearly|none`), `donut`, `limit` (nur Ranking), `legend`, `tooltips`. Ein `PATCH` mit `chartConfig` ersetzt die ganze Konfiguration: immer die vollständige senden. Ein Diagramm über ein selten gefülltes Feld zeigt "Leer"/"Empty" (Ninox-Bezeichnung nach Sprache des Profils, nicht änderbar): besser ein gut gefülltes Feld wählen.
- Tabelle: `TableComponent` mit `tableName`, `height` und `view: { columns: [{ field, order, labels }], sort: { fieldName, direction } }`. Ohne `view` zeigt sie alle Standardspalten.
- Raster: `Container` mit `arrangement: grid` und `gridPreset` (z. B. `repeat(5, minmax(0,1fr))`), `gap: gap-4`.
- Texte (`Text`): `content` höchstens 100 Zeichen je Eintrag; **Markdown wird nicht gerendert** (kein `##`). Größe über `quickStyle` (`title-lg`, `title-md`, `title-sm`, `body-md`, `body-sm`).
- Ehrlich beschriften: Bei Testdaten steht auf dem Dashboard, dass die Zahlen aus einer anonymisierten Stichprobe stammen.

## Formular aufräumen (Beispiel: Tabelle MASTER VIEW)

1. Ist-Zustand lesen (`GET /modules/{modul}`, Komponenten nach `parentId`). Felder liegen als `FieldComponent` direkt unter der Seite.
2. Abschnitte als `Container` mit Rahmen (`border`, `padding`, `background`), darin ein Raster mit zwei Spalten-Containern (`arrangement: ttb`). So bleibt die Reihenfolge ohne Neuanlegen: die Reihenfolge hängt an der alten `order`, daher zusammengehörige Felder so in die Spalten verteilen, dass die Zeilen stimmen.
3. Felder per `PATCH /components/{id}` mit `parentId` verschieben und mit `labels` lesbar beschriften (die Feldbeschriftung der Tabelle bleibt unberührt).
4. Im Browser prüfen (etwa 8 Sekunden warten).

## Sprache und Datumsformat

Das Anzeigeformat von Datumsfeldern (`tt.mm.jjjj` oder `mm/dd/yyyy`) und Bezeichnungen wie "Leer" hängen an der **Sprache des Ninox-Profils** (Profilmenü unten links, "Sprache ändern"). Per API gibt es kein Datumsformat. Ändern nur mit ausdrücklichem Ja des Nutzers; die Einstellung gilt für alle Workspaces des Nutzers. Gespeichert wird unabhängig davon als `yyyy-MM-dd`.