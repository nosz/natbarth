# Was die Ninox-4-API kann (belegt) und was noch zu klären ist

Quelle: öffentliche OpenAPI-Beschreibung `https://go.ninox.com/api/docs-json`, "Ninox Public API 1.0.0", gelesen am 2026-10-06 (30 Pfade). Die Live-Spezifikation hat Vorrang vor dieser Datei: `Invoke-Ninox3Phase1 -PruefeApi` oder `Get-NinoxApiCapability` (in `scripts/ninox-openapi.ps1`) liest sie neu und schreibt `ergebnis/11_api_faehigkeiten.csv`. Das Lesen der Spezifikation braucht keinen Key.

**Wichtig:** "Belegt" heißt hier: die Spezifikation nennt die Möglichkeit. Es heißt **nicht**, dass sich eine Ninox-3-Funktion damit gleichwertig nachbauen lässt. Das ist erst im Test-Workspace belegt.

## Belegt in der Spezifikation

| Bereich | Fundstelle |
|---|---|
| Ansichten anlegen und lesen | `POST/GET .../tables/{t}/views`; Typen Calendar, Chart, Gallery, Gantt, Kanban, List, Maps, Pivot, Table; Spalten, Filter, Gruppierung, Sortierung, bedingte Formatierung, Diagramm-/Gantt-/Pivot-Konfiguration |
| Berichte anlegen und lesen | `POST/GET .../tables/{t}/reports`; Papiergröße, Ränder, Layoutobjekte (`objects`) oder automatisch aus den Feldern; `reports/{id}/print` |
| Trigger | Tabelle `onCreate`, `onUpdate`, `onDelete`; Feld `onUpdate` |
| Zugriffsausdrücke | Tabelle `canRead`, `canWrite`, `canCreate`, `canDelete`; Feld `canRead`, `canWrite` |
| Rollen | `readRoles`, `writeRoles`, `createRoles`, `deleteRoles` (Tabelle), `readRoles`, `writeRoles` (Feld); Feldrolle `user` ist ein veralteter Alias für `editor` |
| Standardwert | Feld `defaultValue` (Wert oder Skriptausdruck `{ $nx: <Skript> }`; bei Mehrfachauswahl Array von Options-IDs) |
| Feldtypen | string, html, number, boolean, choice, dchoice, multi, dmulti, file, date, timestamp, time, timeinterval, appointment, icon, color, user, reference, reverse, function |
| Formelfeld | `type: function` mit `expression` |
| Rückverweis | `type: reverse` mit `refTableName` |
| Dateiupload | `POST .../records/{id}/files`; `files/upload-url` und `files/complete` |
| Modulfunktionen | `.../modules/{m}/functions/{name}` (GET, PATCH, DELETE) |
| Moduldefinition | `GET/PUT .../modules/{m}/definition` |
| Komponenten (Seiten) | `POST .../modules/{m}/components`, `GET/PATCH/DELETE /components/{id}` |
| Feldanzeige | Feld `showInTable` |

## Im Test-Workspace beobachtet (2026-10-06)

Geprüft in einem eigenen Wegwerf-Modul mit erfundenen Daten, jeweils zurückgelesen und in der Oberfläche angesehen. Das ist **beobachtet, nicht dokumentiert**; im eigenen Workspace kurz gegenprüfen, wenn sich die Ninox-Version ändert.

| Thema | Beobachtung | Folge für die Migration |
|---|---|---|
| Fehlerhafte Formel | Syntaxfehler (`if menge then`) und unbekanntes Feld werden **beim Anlegen abgelehnt**, mit Meldung samt Zeile und Spalte ("Field not found: …") | Das Anlegen ist zugleich eine Prüfung. Formelfelder zuletzt anlegen, nach allen Feldern, die sie benutzen. Fehlermeldung je Formel festhalten |
| Schreiben in Formelfeld | Wird abgelehnt ("read-only") | Formelfelder nie in Datensatz-Nutzlasten (macht `ConvertTo-Ninox4Payload`) |
| Datum | Die API liest Datumstexte wie JavaScript `Date` (steht in der Fehlermeldung). `2026-10-06` und `10/13/2026` werden angenommen, `13.10.2026` und `13-10-2026` abgelehnt, und **`06.10.2026` wird als 10. Juni gespeichert** (Monat.Tag). Das ist **kein Fehler von Ninox**, aber eine Falle. Millisekunden seit 1970 werden angenommen | **Immer `yyyy-MM-dd`** senden, nie das deutsche Format |
| Zeitstempel | `2026-10-06T12:30:00` und mit `Z` werden als UTC gespeichert (`2026-10-06 12:30:00+00`); die Oberfläche zeigt die lokale Zeit (14:30) | Ninox-3-Zeitstempel (Millisekunden UTC) passen; Anzeigeunterschiede sind kein Fehler |
| Auswahlfeld | Label wird gespeichert; Kleinschreibung (`aktiv`) wird zu `Aktiv` normalisiert; die ID (`1`) wird zum Label; Optionen bekommen IDs | Beim Import das Label schreiben (Skript tut das) |
| Standardwert | `defaultValue` wird gespeichert, aber **beim Anlegen per API nicht angewendet** (Datensatz ohne Wert blieb leer) | Beim Import alle Werte explizit schreiben; Standardwert nur für künftige Eingaben in der Oberfläche |
| Verweisfeld | Wert ist die Datensatz-ID als Text (`kunde = "1"`) | wie geplant (zwei Durchgänge) |
| Rückverweis | Beim Anlegen des Verweisfeldes erzeugt Ninox in der Zieltabelle **automatisch** den Rückverweis (Name = Name der Quelltabelle, Label = deren Label). Ein zusätzlich angelegtes `reverse`-Feld mit `refTableName` erzeugt dagegen ein **neues, getrenntes Verweisfeld** in der Quelltabelle (ein zweites Paar) | Ninox-3-`rev`-Felder **nicht** anlegen. Nach dem Verweisfeld den automatischen Rückverweis finden (Feldliste vorher/nachher vergleichen) und per `PATCH` auf Name und Label des Mappings umbenennen. Mehrere Verweise zwischen denselben zwei Tabellen sind nicht getestet |
| Ansichten | `POST .../views` mit `type: Table` und `columns: [{field, order}]` funktioniert; Ninox legt je Tabelle selbst eine "Table view" an, die eigene Ansicht erscheint als weiterer Reiter | Ansichten sind anlegbar; die Gleichwertigkeit mit Ninox 3 bleibt Prüfsache |
| Berichte | `POST .../reports` nur mit Name erzeugt ein automatisches Layout aus den Feldlabels | Berichtsnachbau braucht `objects`; Auto-Layout ist ein Anfang |
| Feldnamen wie Schlüsselwörter | Die Namen `date`, `number` und `id` werden als Feldnamen angenommen; Formeln wie `number + 1` (ergibt 6) und `year(date)` (ergibt 2026) rechnen korrekt | Keine Warnung für diese Namen nötig. Weitere Schlüsselwörter (`if`, `end`, `select` u. ä.) sind nicht getestet |
| Pflichtfeld | Wird beim Anlegen per API **erzwungen** (Datensatz ohne Wert wird abgelehnt). Nachträglich auf Pflicht setzen (`PATCH required`) ist erlaubt, auch wenn Datensätze mit leerem Wert existieren; sie bleiben änderbar, neue ohne Wert werden abgelehnt | Felder zuerst ohne Pflicht anlegen, Daten importieren, danach Pflicht setzen. Quelldatensätze mit leerem Pflichtwert als Befund zählen |
| Standardwert "heute" | `defaultValue` als `{ "$nx": "today()" }` wird angenommen | Ninox-3-`dateDefault=today` lässt sich so übertragen |
| Weitere Typen | `html`, `string` mit `variant: url`, Zahl- und Ja/Nein-Standardwerte werden angenommen | wie geplant |
| Dateifeld | Ein Dateiname als Text wird **abgelehnt**; erwartet wird ein Datei-Objekt (`documentId`, `documentVersionId`, `fileName`, `fileSize`, `fileType`) aus dem Upload | Dateifelder bleiben in der Teststrecke leer; Anhänge später über den Upload-Weg |
| Formeln mit `like` | Ninox antwortet beim Anlegen mit "An unexpected error occurred in a workspace object operation", **legt das Feld aber an**; es rechnet korrekt. Formeln mit `=`, `contains(...)` und verschachteltem `if` melden keinen Fehler | Nach dieser Meldung nachsehen, ob das Feld existiert, nicht wiederholen. Dem Ninox Support melden (siehe `formeln.md`) |
| Verschachtelungstiefe von if | Ketten bis 19 Ebenen sofort; ab 20 Ebenen Sekunden und irreführender Fehler (Feld entsteht); ab 26 Ebenen Zeitueberschreitung nach ca. 60 s ('upstream connect error'). Unabhaengig von der Zeichenlaenge (flache Formel mit 3997 Zeichen: 1 s) und von der Schreibweise (end, Klammern). In der Dokumentation steht keine Grenze | Tiefe vor dem Anlegen zaehlen, ueber 18 Ebenen nicht versuchen (`formeln.md`); als gepruefte Abweichung erfasst |
| Standardwert bei Anlage per API | defaultValue wird beim Anlegen von Datensaetzen per API **nicht** angewendet (zwei Beobachtungen), obwohl die API-Beschreibung das Gegenteil sagt. Verdacht, da die Anlage in der Oberflaeche noch nicht geprueft ist | Beim Import alle Werte ausdruecklich senden |
| Workspace-Klarname | Der Name des Workspace ist über die öffentliche API nicht lesbar (vom Nutzer bestätigt, 2026-10-06); nur die ID ist bekannt | Nutzer einmal fragen und als `workspaceName` in `ninox.config.json` eintragen; nie raten oder aus der ID ableiten |
| Last und Grenzen | Höchstens **3 gleichzeitige Schreibvorgänge je Workspace** (`WORKSPACE_TRANSACTION_CONCURRENCY_LIMIT_EXCEEDED`, Antwort "Please retry"); beim Anlegen von 46 Formelfeldern kamen zusätzlich Serverfehler "upstream connect error ... Connection refused". Das Anlegen eines Formelfeldes dauert merklich länger (Prüfung und Berechnung) | Schreibaufrufe nacheinander, nie parallel, mit Pause (Voreinstellung 300 ms, Formelfelder 600 ms), die sich nach Fehlern verlängert (`ninox-support.ps1`: `Set-NinoxSchreibtempo`); bei diesen Meldungen warten und denselben Aufruf wiederholen, nicht als Fehler werten |
| Einzeldatensatz | `GET .../records/{id}` gibt 404 | Datensätze über die Liste (mit `filter`) lesen |
| Oberfläche | Tabellen und Spalten zeigen die **Labels**, nicht die technischen Namen; Tabellen laden mit einigen Sekunden Verzögerung | Original-Beschriftung bleibt sichtbar; beim Browserprüfen etwa 5 Sekunden warten |

## Nicht in der Spezifikation (im Test-Workspace klären)

- Ob Ninox-3-Ansichten, -Berichte, -Rechte, -Trigger und -Standardwerte inhaltlich gleichwertig abbildbar sind.
- Zuordnung benutzerdefinierter Ninox-3-Rollen (z. B. "Sales") zu Ninox-4-Rollen.
- Entsprechung für Ninox-3-Sichtbarkeitsausdrücke (`canRead`/`canWrite` regeln den Zugriff, nicht die Anzeige) und kaskadierendes Löschen.
- Raten-Limits.

## Abweichung zu anderen Quellen

Der `ninox`-Skill (Stand seiner letzten Spezifikationsprüfung 2026-07-08) nennt Ansichten, Berichte und das Standardwert-/Trigger-Verhalten als nicht dokumentiert. Die heutige Spezifikation nennt sie. Maßgeblich ist immer die zuletzt gelesene Live-Spezifikation; der Skill vermerkt Abweichungen im Plan.
