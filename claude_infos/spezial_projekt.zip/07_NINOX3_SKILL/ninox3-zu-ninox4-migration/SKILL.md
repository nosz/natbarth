---
name: ninox3-zu-ninox4-migration
description: NUR TESTPHASE, nicht produktiv einsetzen (nur Testdaten und Testworkspaces; Hauptpunkt der Arbeit ist die Ninox-4-Neuerstellung oder -Anpassung mit ninox-start und ninox4-api-builder). Ninox-3-Lösung (.ninox-Sicherung) analysieren und kontrolliert nach Ninox 4 migrieren - Inventar, Mapping, Lückenliste, Schema, Formelübersetzung, anonymisierte Testdaten, Abnahmebericht und optional ein verbessertes Datenmodell (_v2). Geführt, ein Schritt nach dem anderen, in Phasen mit Freigaben, nur lokal, ohne Key im Chat. Immer nutzen bei "Ninox 3 nach Ninox 4", ".ninox-Datei", "alte Ninox-Datenbank nachbauen", "Ninox-3-Lösung migrieren/analysieren/überführen", "Migrationsplan Ninox", "Ninox 3 Formeln übersetzen", "Ninox-Datenbank modernisieren", auch wenn das Wort Migration nicht fällt. Nicht für Formularumbau in Ninox 4 (ninox4-api-builder) und nicht für Excel-Importe (excel-to-ninox).
---

# Ninox 3 nach Ninox 4 migrieren (Ninox Software GmbH)

**ACHTUNG: Dieser Skill befindet sich in der Testphase und darf derzeit NICHT produktiv eingesetzt werden. Nur für Tests mit Testdaten und Testworkspaces, nicht für echte Kundendaten oder produktive Datenbanken.** Claude sagt das dem Nutzer zu Beginn jeder Migration deutlich (fett, eigene Zeile, als allererste Nachricht, noch vor jeder anderen Frage; Englisch: "NOTICE: This skill is in its test phase and must NOT be used in production. Use only with test data and test workspaces.") und lässt es mit einer Ja/Nein-Frage ("Weiter im Testmodus?", Empfehlung zuerst) bestätigen, bevor die erste Phase startet. Dazu in einem Satz: Der Hauptweg ist die Ninox-4-Anwendung (neu bauen oder anpassen, `ninox-start`); die Migration ist ein Zusatz für Tests. Fordert der Nutzer eine produktive Migration, nicht ausführen, sondern auf diese Einschränkung und auf `references/stand-und-offene-punkte.md` verweisen.

Version 0.9, Teststrecke abgeschlossen (Stand 2026-10-06). Einsetzbar für Tests und Teststrecken. Läuft derzeit nur unter Windows (siehe `ninox-start/references/macos.md`).

Dieser Skill überführt eine bestehende Ninox-3-Lösung kontrolliert nach Ninox 4. Er arbeitet in Phasen mit Freigabe, belegt jede Aussage und schreibt nur in einen neuen, leeren Zielbereich. Er unterstützt die Anforderungen aus ISO 27001 und BSI C5 (Nachvollziehbarkeit, Datenminimierung, keine Zugangsdaten im Chat).

Der Skill ersetzt weder `ninox` (API-Details, Skriptsyntax) noch `ninox4-api-builder` (Key-Ablage, Sicherung, Formularbau). Er baut darauf auf und verweist dorthin.

## Arbeitsweise (gilt für jede Nachricht)

**Immer eine Frage oder ein Schritt nach dem anderen. Ganz einfach im Ton, professionell im Ergebnis.** Das ist die wichtigste Regel im Umgang mit dem Nutzer, vor allem bei Kolleginnen und Kollegen, die Ninox, API und PowerShell nicht kennen.

- **Sprache:** Die am Anfang im Skill `ninox-start` gewählte Sprache (Deutsch oder English, `Get-NinoxSprache`) gilt für das ganze Gespräch; Skript-Parameter `-Sprache` und zweisprachige Ninox-Meldungen bleiben wie dokumentiert.
- **Pro Nachricht genau eine Frage oder eine Aufgabe.** Nie mehrere Fragen, nie eine Aufgabenliste. Erst nach der Antwort folgt das Nächste.
- **Immer eine Empfehlung, ohne Ausnahme**: zu jeder Frage, Auswahl, jedem Angebot und jeder Weggabelung eine klare Empfehlung mit Begründung in einem Satz, die Empfehlung zuerst. Nie nur Optionen auflisten. "ok" übernimmt sie; Schreiben und Löschen verlangen ein ausdrückliches Ja.
- **Kurze Sätze, Fachwörter einmal erklärt.** Jede Aufgabe für den Nutzer: Wo (System und Workspace mit Klarnamen), Problem in einem Satz, nummerierte Schritte, woran man den Erfolg merkt.
- **Fortschritt zeigen** ("Schritt 3 von 6"), Zwischenstände knapp (höchstens fünf Zeilen).
- **Live-Ansicht:** Vor dem ersten Schreiben (Phase 3) anbieten, die Änderungen in einem Browserfenster neben dem Chat mitzuverfolgen (Ablauf und Sicherheitsregeln: Skill `ninox-start`, `references/live-ansicht.md`). Der Nutzer meldet sich dort selbst an. Nach jeder Phase die betroffene Seite zeigen; **neue leere Apps erst nach dem Import öffnen.**
- Vorlagen und Muster: `references/fuehrung.md`. Weitergabe an Kollegen: `references/weitergabe-an-kollegen.md`.

## Verbindliche Regeln

1. **Kein Zugangsdatum im Chat.** Der API-Key liegt nur in `$env:NINOX_API_KEY` des eigenen Terminals (Ablauf: `ninox4-api-builder`, Bausteine A bis D). Erscheint ein Key im Chat: nicht verwenden, nicht wiederholen, Ablauf nennen: Key in Ninox widerrufen, Unterhaltung löschen, Bitwarden/Schlüsselbund nutzen, it@ninox.com melden (ISMS-Vorfallprozess). In Ausgaben nur Platzhalter wie `<API_KEY>`.
2. **Nichts erfinden.** Jede Aussage über Ninox-4-Verhalten braucht eine Quelle (`ninox`-Skill, OpenAPI `https://go.ninox.com/api/docs-json`, docs.ninox.com) oder einen Test im Test-Workspace. Sonst als "unbelegt" oder "beobachtet, nicht dokumentiert" kennzeichnen. Offene Fragen zuerst in `ninox4-api-builder/references/quellen.md` nachschlagen.
3. **Schreiben nur mit Freigabe und nur in neue, leere Ziele.** Vor jeder schreibenden Phase: Workspace-ID und Zielmodul nennen, Sicherung anlegen, auf ein klares "Ja" warten. Bestehende Module nie ändern. Eine Freigabe gilt nur für die genannte Phase.
4. **Keine Personendaten in Chat, Berichten oder Dokumentationsmodul.** (Namen von Ansichten, Berichten und Rollen können Personennamen sein; im Beispiel ein Vorname. Solche Namen nicht im Chat wiederholen und vor Weitergabe nach außen prüfen.) Datensatzinhalte, Formeltexte, Auswahlwerte, Standardwerte und Rollennamen können Firmen- und Personendaten enthalten (am Beispiel: Adressen, E-Mail-Adressen, ein Vorname als Rolle) und bleiben in `arbeit/`. `ergebnis/` enthält nur Struktur, Zähler, Längen und Status, dazu die Beschriftungen von Tabellen, Feldern und Ansichten; diese können Firmennamen enthalten, daher vor Weitergabe nach außen prüfen. Stichprobendaten werden vor dem Import anonymisiert (Standard), Ausnahme nur auf ausdrückliche Anweisung. Im Chat nie Formeltexte oder Datensätze ausgeben.
5. **Quelldateien bleiben unverändert.** Die beiden `.ninox`-Sicherungen werden nur gelesen. Entpackt wird in `arbeit/`.
6. **Das Plugin "Ninext v3" ist ein internes Logging-Werkzeug und wird ignoriert** (nicht migrieren, nicht in der Lückenliste führen). Das Skript benennt es nur als "ignoriert".
7. **Formeln 1:1 übersetzen.** Verbesserungen sind ein eigener Vorschlag in Phase 7 und werden nie ungefragt umgesetzt.
8. **Abweichungen nie still lassen.** Alles, was nicht übernommen wird, steht mit Grund in der Lückenliste.
9. **Klare, lesbare Namen in Ninox 4.** Tabellen- und Feldnamen (das sind die technischen IDs in Ninox 4) werden aus der Beschriftung gebildet: Kleinbuchstaben, Umlaute als ae/oe/ue/ss, Wörter mit Unterstrich (`lieferdatum`, `kunde_name`), nie kryptische Kürzel oder Ninox-3-IDs (`o2`, `f_x1`). Doppelte Beschriftung wird nummeriert und gemeldet, leere Beschriftung wird `feld_1` und gemeldet. Die Original-Beschriftung bleibt als sichtbares Label. Der Nutzer prüft und ändert die Namen in Phase 2, bevor etwas gebaut wird (Details: `references/mapping-regeln.md`). Datensatz-IDs vergibt Ninox 4 selbst.

10. **Einen Schritt nach dem anderen.** Der Nutzer kennt Ninox 3, aber nicht unbedingt API, PowerShell oder Migration. Pro Nachricht eine Frage oder eine Aufgabe, in einfacher Sprache, mit Fortschrittsanzeige ("Schritt 2 von 6") und bei jeder Entscheidung mit Empfehlung und kurzer Begründung. Selbst prüfen, was sich prüfen lässt; nur fragen, was nur der Nutzer entscheiden kann. "Ok" auf eine Entscheidungsfrage übernimmt die Empfehlung; schreibende Phasen brauchen ein klares "Ja" auf die genannte Aktion. Nachrichtenmuster, Einstiegsschritte, Entscheidungsreihenfolge und Standardtexte: `references/fuehrung.md` (vor der ersten Antwort lesen).
11. **Schreiben mit Rücksicht auf den Server.** Schreibvorgänge nach Ninox laufen immer nacheinander, nie parallel, mit einer Pause zwischen den Aufrufen (Voreinstellung 300 ms, bei Formelfeldern 600 ms; Parameter `-PauseMs`). Ninox erlaubt höchstens 3 gleichzeitige Schreibvorgänge je Workspace. Die Pause verdoppelt sich nach einem Serverfehler und verkürzt sich nach mehreren Erfolgen wieder. Dem Nutzer vor einer schreibenden Phase sagen, dass der Aufbau bewusst langsam ist und einige Minuten dauern kann.
12. **Freigabe, Schlüssel und Weitergabe werden technisch geprüft, nicht nur beschrieben.** Die Bauskripte schreiben nur, wenn `ergebnis/status.json` die Freigabe für genau diese Phase, diesen Workspace und dieses Modul enthält (`Set-NinoxFreigabe` trägt sie erst nach dem ausdrücklichen "Ja" des Nutzers ein; `Assert-NinoxSchreibfreigabe` prüft). Vor jeder schreibenden Phase läuft `Test-NinoxVorabpruefung` (Key, Workspace, Server, Module). Schlüssel-Hygiene (`Test-NinoxKeyHygiene`), Geheimnis-Suche (`Test-NoSecretLeak`) und die Weitergabe-Prüfung (`Test-ErgebnisFuerWeitergabe`) gehören zum Abschluss. Löschen geht nur über `Remove-Ninox4ModulKontrolliert` mit der Bestätigung "Ja, loeschen", nur für leere Projektmodule.
13. **Abweichungen von der Dokumentation und mutmaßliche API-Fehler: erst genau prüfen, dann erfassen und den Entwicklern sofort verwertbar melden.** Fällt auf, dass etwas laut Ninox-Dokumentation gehen sollte, aber nicht geht (oder umgekehrt), ist das zunächst nur ein **Verdacht** und wird nicht als Fehler bezeichnet. Der Skill erfasst es mit `Add-NinoxAbweichung` in `ergebnis/abweichungen.csv`. Status "geprüft" gibt es erst, wenn alle Prüfpunkte erfüllt sind: (1) Dokumentation sagt es ausdrücklich (Link), (2) mindestens zwei Beobachtungen zu verschiedenen Zeiten, (3) Minimalbeispiel im Wegwerf-Modul, (4) Gegenprobe (ähnlicher Aufruf funktioniert), (5) Eigenfehler und vorübergehende Serverfehler ausgeschlossen, (6) keine Kundendaten und kein Key im Beispiel. (7) englische Fassung vorhanden (Titel, Erwartung, tatsächliches Verhalten, Reproduktion). Erst dann: Eintrag in die Tabelle `abweichungen` im Dokumentationsmodul (`Invoke-Ninox4AbweichungenSync`; Verdachtsfälle bleiben lokal) und eine Entwicklermeldung (`New-NinoxEntwicklerMeldung`, Ablage wie die Supportmeldungen im Ordner `ergebnis/support/`), die dem Nutzer als Codeblock zum Kopieren gezeigt wird. Soll die Meldung in **Slack** gepostet werden, erzeugt `New-NinoxSlackMeldung` daraus Slack-Text (Slack-mrkdwn: `*fett*`, keine `#`-Überschriften und keine Tabellen; Hauptnachricht auf Englisch, Antwort im Thread auf Deutsch, auf Wunsch umgekehrt) und legt ihn im Ordner `ergebnis/support/` ab (`<Zeitstempel>_slack_<nr>_<kurztitel>.txt`). Die Meldung ist **kurz und zweisprachig** (Deutsch und Englisch, beide vollständig, in einer Datei) und enthält: Kurzfassung, gewünschte Aktion, Schweregrad, Aufruf und Umgebung, Erwartung mit Quelle, Reproduktionsschritte, ein **Beispiel als `curl` mit Platzhaltern** für Key und Workspace, Gegenprobe, Workaround und den Prüfvermerk. Vorübergehende Serverfehler gehören nicht hierher (dafür gibt es die Supportmeldung, Regel 14).
14. **Serverprobleme immer melden, mit Supporttext zum Kopieren.** Antwortet Ninox nicht oder lehnt es Aufrufe ab (Verbindung verweigert, "upstream connect error", Zeitüberschreitung, HTTP 429/502/503/504, "too many concurrent write transactions"), ist das kein Planfehler und kein Fehler des Nutzers. Der Skill sagt dem Nutzer **sofort und ausdrücklich**, dass der Ninox-Server gerade nicht antwortet oder nicht erreichbar ist, und dass der Vorgang wartet und es erneut versucht. Sobald die Störung länger anhält, der Vorgang abbricht oder nach der Störung beendet ist, zeigt er dem Nutzer **die fertige Supportmeldung als Codeblock zum Kopieren** (Datei `ergebnis/support/<Zeitstempel>_support_meldung.txt`, erzeugt von `scripts/ninox-support.ps1`; ohne Key und ohne Kundendaten) und nennt den Speicherort. Dabei nichts löschen und nichts neu anlegen. Details und Standardtext: `references/fuehrung.md`.
15. **Jede Aufgabe für den Nutzer so erklären, dass auch Nicht-IT-Leute sie verstehen.** Immer in dieser Reihenfolge: (1) **Wo:** welches System (Ninox 3 oder Ninox 4) und **welcher Workspace mit Klarnamen** (`workspaceName` aus `ninox.config.json`, die ID nur in Klammern dahinter; fehlt der Klarname, zuerst den Nutzer danach fragen und ihn in die Konfiguration eintragen, vorher keine Anleitung geben). **Überall im Gespräch gelten Klarnamen vor technischen IDs:** Workspace, Modul, Tabelle und Feld immer mit der Beschriftung, die der Nutzer in Ninox sieht, die technische Schreibweise in Klammern; (2) **Was ist das Problem** in einem einfachen Satz ohne Fachwörter (zum Beispiel: Ninox erkennt den Schlüssel nicht, deshalb kann ich nicht weiterarbeiten); (3) **Was ist zu tun**: nummerierte Schritte mit genauem Klickweg oder Befehl im Codeblock; (4) **Woran du merkst, dass es geklappt hat**; (5) `sag mir Bescheid`. Fachwörter (API-Key, Variable, 401) beim ersten Mal in einem Halbsatz erklären, und **jede Handlung, die ein Werkzeug verlangt (Terminal öffnen, Befehl einfügen, App neu starten), mit dem genauen Handgriff beschreiben** (wo klicken, was tippen, was erscheint). Nie nur `setz den Key`. Vorlagen: `references/fuehrung.md`, Abschnitt `Konkrete Anleitungen`.

## Voraussetzungen (Phase 0 prüft sie)

- **Zwei Sicherungsdateien** der Ninox-3-Lösung, vom Nutzer aus Ninox 3 exportiert (Dateinamen frei wählbar, Pfade stehen in `ninox.config.json`):
  - `<name>_ohne_daten.ninox` (klein, für Analyse, Mapping und Formeln),
  - `<name>_mit_daten.ninox` (nur für Stichprobe, Zählung und Abnahme).
  Fehlt eine, den Nutzer um genau diese Datei bitten und nicht mit Annahmen weiterarbeiten.
- Skill `ninox4-api-builder` ist installiert (Key-Regeln, `ninox-helpers.ps1`, `quellen.md`). Phase 0 bis 2 laufen auch ohne ihn (nur lesen); `Invoke-Ninox3Phase1` meldet `BuilderGefunden`. Vor Phase 3 stoppen, wenn er fehlt, und sagen, wo er zu installieren ist (`~\.claude\skills\` oder `<Projekt>\.claude\skills\`).
- `ninox.config.json` im Projektordner, erweitert um den Block `migration` (siehe unten). Ohne Geheimnisse. Für Phase 0 bis 2 (nur lesen) genügen die Pfade der beiden Dateien und der Projektordner; die Konfiguration wird spätestens vor Phase 3 angelegt.
- Für Phase 3 bis 7: ein **Test-Workspace**, `NINOX_API_KEY` im eigenen Terminal geladen (Prüfung nur "gesetzt (Länge)", nie der Wert), Zielmodul genannt und leer.
- Windows PowerShell 5.1. Python wird nicht benötigt. Die `curl`/`python3`-Beispiele des `ninox`-Skills werden hier durch die PowerShell-Helfer des Builders ersetzt (`Invoke-Ninox`); der `ninox`-Skill liefert die Semantik.

```json
{
  "apiBase": "https://go.ninox.com",
  "workspaceId": "<WORKSPACE_ID>",
  "moduleName": "<ZIEL_MODUL>",
  "migration": {
    "sourceFile": "<PFAD_ZUR_NINOX3_DATEI>",
    "docModuleName": "<DOKU_MODUL>",
    "sampleSize": 20,
    "anonymize": true
  }
}
```

Der Builder liest nur `apiBase`, `workspaceId` und `moduleName`; der Block `migration` stört ihn nicht.

## Ablauf in Phasen

Details je Phase, Ein- und Ausgaben und Freigabetexte: `references/phasen.md`. Lies diese Datei, bevor du eine Phase beginnst. Wie du dem Nutzer jede Phase in kleinen Schritten vermittelst: `references/fuehrung.md`.

| Phase | Inhalt | Schreibt in Ninox 4? | Freigabe |
|---|---|---|---|
| 0 | Voraussetzungen, Sicherungspaar prüfen (`Test-Ninox3BackupPair`) | nein | - |
| 1 | Inventar aus `_ohne_daten` (Tabellen, Felder, Formeln, Ansichten, Berichte, Rechte, Trigger) | nein | - |
| 2 | Migrationsplan: Mapping, Lückenliste, Befunde für Phase 7 | nein | **ja** |
| 3 | Sicherung, Schema im Zielmodul, Dokumentationsmodul | ja | **ja**, mit Ziel-ID |
| 4 | Formeln 1:1 übersetzen und in Ninox 4 prüfen | ja | **ja** |
| 5 | Stichprobe (verknüpfungstreu), anonymisieren, importieren | ja | **ja** |
| 6 | Abnahme: Struktur, Daten, Formeln, Bericht | nur Dokumentation | **ja** |
| 7 | Optimierungsvorschläge, danach optional `<Modul>_v2` | nur nach Wunsch | **ja** |
| 8 | Abschluss: **zuerst die Frage, ob die Apps noch in einen anderen Workspace kopiert werden sollen** (`references/kopie-in-anderen-workspace.md`), dann Aufräumen: Keys widerrufen, Variable löschen, Geheimnis-Suche, Weitergabe-Prüfung, `arbeit/` löschen | nur Löschen eigener Module nach "Ja, loeschen" | schrittweise, je Schritt eine Bestätigung |
| später | Vollimport und Anhänge | ja | eigene Freigabe, nicht Teil der Teststrecke |

Nach jeder Phase: kurze Zusammenfassung (Zahlen, Lücken, nächste Aktion), Status in `ergebnis/status.json` fortschreiben, auf Freigabe warten. Bei Unterbrechung an der letzten abgeschlossenen Phase wieder aufsetzen.

## Projektordner

```
<projekt>/
  ninox.config.json              Konfiguration, keine Geheimnisse
  sicherung/                     die zwei .ninox-Dateien, nur lesen
  arbeit/                        entpackt (ohne, mit), inventar (volle Fassung), Stichprobe; enthält Echtdaten; nicht versionieren, am Projektende löschen
  ergebnis/                      bereinigte CSV und Markdown, status.json, Schreibprotokoll
  ergebnis/support/              alle Meldungen an Ninox: Supportmeldungen und je Abweichung eine einzige Meldungsdatei (.txt, Englisch und Deutsch), Dateiname mit Zeitstempel am Anfang
```

Die Ordner `sicherung/` und `arbeit/` gehören in die `.gitignore` (Vorlage: `assets/gitignore-vorlage.txt`). Die Skripte legen `arbeit/` und `ergebnis/` selbst an und lesen auch direkt aus einem anderen Pfad (z. B. Downloads); die Kopie nach `sicherung/` ist empfohlen, damit der Stand eingefroren ist.

## Skripte

PowerShell 5.1, nur lokal, keine Zugangsdaten. Laden mit `. .\<skillordner>\scripts\<datei>.ps1`. Alles im Chat Ausgegebene darf keine Datensatzinhalte enthalten.

| Datei | Zweck |
|---|---|
| `scripts/ninox3-phase1.ps1` | **Einstieg für Phase 0 und 1:** `Invoke-Ninox3Phase1 -OhneDatei -MitDatei -ProjectDir` entpackt, prüft das Sicherungspaar, erzeugt Inventar (bereinigt nach `ergebnis/`, voll nach `arbeit/inventar/`), Formelanalyse und Namensprüfung; gibt nur Zähler zurück |
| `scripts/ninox-openapi.ps1` | Öffentliche Ninox-4-API-Beschreibung lesen (ohne Key, nur lesend; `Get-NinoxOpenApi`, `Get-NinoxApiCapability`). Auch als `Invoke-Ninox3Phase1 -PruefeApi` |
| `scripts/ninox3-reader.ps1` | Bausteine: Entpacken (mit Zip-Slip-Schutz), Sicherungspaar prüfen, Schema lesen, Inventar, Mapping-Vorschlag, Befunde, Lückenliste, `Test-Ninox4Names` |
| `scripts/ninox3-formeln.ps1` | Formelverweise (`O2`, `G.Y.A`) auflösen, Rohübersetzung auf Ninox-4-Namen, Funktions- und Unbekannt-Liste |
| `scripts/ninox3-entscheidungen.ps1` | Entscheidungen des Nutzers festhalten: `Add-Ninox3Decision` (Protokoll `ergebnis/entscheidungen.csv`), `Add-Ninox3GapRow` (Zeile in die Lückenliste); ohne Personendaten |
| `scripts/ninox-pruefungen.ps1` | Sicherheits- und Vorabprüfungen (auch `Test-NinoxSkillFuerWeitergabe`, der Check des Skillordners vor der Weitergabe): Freigabe erzwingen, Key-Hygiene, Konfiguration, Vorabprüfung, Geheimnis-Suche, Weitergabe-Prüfung, Sofort-Protokoll und Fortschrittsdatei, kontrolliertes Löschen, Aufräumliste |
| `scripts/selftest.ps1` + `scripts/ninox3-testdaten.ps1` | **Selbsttest** mit erfundenen Daten (75 Prüfungen, wenige Sekunden, ohne Netzwerk und Key): `. .\scripts\selftest.ps1; Invoke-Ninox3Selbsttest`. Vor jeder Weitergabe des Skills und nach jeder Änderung ausführen |
| `scripts/ninox-abweichungen.ps1` | Abweichungen von der Dokumentation und mutmaßliche API-Fehler: `Add-NinoxAbweichung` (Status "geprüft" nur nach sechs Prüfpunkten), `Set-NinoxAbweichungStatus`, `New-NinoxEntwicklerMeldung` (Markdown zum Kopieren, mit curl-Minimalbeispiel und Platzhaltern). Slack-Fassung `New-NinoxSlackMeldung` (Slack-mrkdwn, Hauptnachricht plus Thread). Tabelle `abweichungen` im Dokumentationsmodul über `Invoke-Ninox4AbweichungenSync` (in `ninox4-doku-modul.ps1`) |
| `scripts/ninox-support.ps1` | Serverstörungen erfassen und eine **Supportmeldung zum Kopieren** erzeugen (`New-NinoxSupportMeldung`, `Show-NinoxSupportHinweis`); wird von den Bauskripten geladen. Ohne Key, ohne Kundendaten |
| `scripts/ninox4-schema-bauen.ps1` | **Phase 3:** `Invoke-Ninox4SchemaBuild -ProjectDir -HelpersPath [-Plan]` baut Modul, Tabellen, Felder, Verweise, benennt Rückverweise um, setzt Standardwerte, liest zurück und prüft; nur nach Freigabe, nur in ein neues, leeres Modul. `-Plan` zählt nur |
| `scripts/ninox4-import-stichprobe.ps1` | **Phase 5:** Stichprobe wählen, alle bestätigten Personendaten-Felder anonymisieren, Gegenprüfungen, Import in zwei Durchgängen (Datensätze, dann Verweise), Rückzählung nach `ergebnis/12_import_zaehlung.csv`. `Invoke-Ninox4SampleImport -Plan` ist der Trockenlauf ohne Schreiben; nur nach Freigabe Phase 5 und nur in leere Tabellen. Mehrfachauswahl (Kodierung ungeklärt) und Dateifelder bleiben leer |
| `scripts/ninox4-abnahme.ps1` | **Phase 6:** `Invoke-Ninox4Abnahme -ProjectDir -HelpersPath` prüft **nur lesend** A Struktur (Mapping gegen Ninox 4, auch ob angelegte Formelfelder wirklich noch bestehen) und B Daten (Zeilenzahl, jeder Verweis, jeder Wert gegen die anonymisierte Quelle); schreibt `ergebnis/13_abnahme_struktur.csv`, `14_abnahme_daten.csv`, `abnahmebericht.md`. C Formelwerte bleibt "nicht belegt" ohne Ninox-3-Soll |
| `scripts/ninox3-optimierung.ps1` | **Phase 7:** `Get-Ninox3OptimierungBelege` belegt die Optimierungsbefunde mit den Daten der Sicherung (Auswahlfelder, Füllgrad breiter Tabellen, Formelketten, kleine Tabellen). Nur lesend und lokal, schreibt nur Zähler nach `ergebnis/16` bis `19` |
| `scripts/ninox4-v2.ps1` | **Phase 7, nur nach Freigabe:** `New-Ninox4V2Projekt` legt den Unterordner `v2/` mit eigener Konfiguration, eigenem Mapping und eigener Formelanalyse an (schreibt nichts nach Ninox); danach laufen die Bauskripte unverändert mit `-ProjectDir <projekt>\v2`. `Convert-Ninox4V2Payload` ist der Hook für `Invoke-Ninox4SampleImport -PayloadHook` (Standorte). Das 1:1-Modul bleibt unverändert |
| `scripts/ninox4-doku-modul.ps1` | **Phase 3:** `Invoke-Ninox4DokuModul` legt das Dokumentationsmodul an und füllt es aus `ergebnis/`; `-NurFuellen` füllt ein vorhandenes, leeres Modul |
| `scripts/ninox3-stichprobe.ps1` | Stichprobe, PII-Kandidaten, Anonymisierung mit Restprüfung, Umwandlung in Ninox-4-Nutzlasten |

Die Ausgaben von Phase 1 stehen in `ergebnis/` als `01_tabellen.csv` bis `11_api_faehigkeiten.csv` (Tabellen, Felder, Formeln, Ansichten, Berichte, Mapping-Vorschlag, Befunde, Formelanalyse, Lückenliste, Namensprüfung, API-Fähigkeiten) plus `inventar_zusammenfassung.json`. Die volle Fassung mit Formeltexten, Auswahlwerten und Rollennamen liegt nur in `arbeit/inventar/`. Skriptquelltext und CSV-Spaltenköpfe sind ASCII (ae/oe/ue), damit Windows PowerShell 5.1 sie fehlerfrei liest; Trennzeichen der CSV ist `;`.

## Wo steht was

| Datei | Inhalt |
|---|---|
| `references/fuehrung.md` | Nutzerführung: ein Schritt pro Nachricht, Nachrichtenmuster, Einstiegsschritte, Entscheidungsreihenfolge, Standardtexte |
| `references/phasen.md` | Jede Phase: Schritte, Ausgaben, Freigabetext, Rückfall, Statusdatei |
| `references/ninox3-exportformat.md` | Aufbau der `.ninox`-Datei, was im Export fehlt |
| `references/api-faehigkeiten.md` | Was die Ninox-4-API laut OpenAPI 1.0.0 kann (belegt) und was im Test zu klären ist |
| `references/mapping-regeln.md` | Namensregeln, Typ-Mapping, IDs, Auswahlfelder, Verweise, Datum, Dateien, Rechte (mit Beleggrad) |
| `references/formeln.md` | Übersetzungsablauf, Prüfung in Ninox 4, Grenzen |
| `references/stichprobe-anonymisierung.md` | Auswahl, Anonymisierung, Import in zwei Durchgängen |
| `references/abnahme.md` | Prüfungen A bis C, Soll-Quellen, Berichtsvorlage |
| `references/optimierung.md` | Befundkatalog, Belege, Vorschlagsformat, Aufbau und Vergleich von `_v2` |
| `references/dokumodul.md` | Tabellen des Dokumentationsmoduls |
| `references/luecken-katalog.md` | Typische Lücken und ihre Standardbehandlung |
| `references/weitergabe-an-kollegen.md` | Den Skill an Kollegen weitergeben: Check vor der Weitergabe, Voraussetzungen, Installation, Arbeitsweise (eine Frage nach der anderen) |
| `references/kopie-in-anderen-workspace.md` | Abschlussfrage und Ablauf, die erstellten Apps in einen anderen Workspace zu kopieren |
| `references/dashboard-formulare.md` | Optionale Bausteine: Dashboard, Formular aufräumen, Sprache und Datumsformat |
| `references/stand-und-offene-punkte.md` | Version, was belegt ist, **offene Punkte und Fragen**, Aufräumliste des Testprojekts |

## Zusammenspiel mit anderen Skills

| Skill | Wofür |
|---|---|
| `ninox-start` | **Einstieg**: fragt zuerst, ob migriert oder direkt in einer Ninox-4-Anwendung gearbeitet wird, und übergibt an diesen oder den nächsten Skill |
| `ninox4-api-builder` | Key laden, Konfiguration, Verbindungstest, Sicherung vor Änderung, `Invoke-Ninox`; danach Formularlayout, Tabs, Mobil. Liegt im Weitergabepaket neben diesem Skill |
| `ninox` | API-Semantik (Module, Tabellen, Felder, Datensätze, CSV-Import), Skriptsyntax (`references/scripting-and-formulas.md`), Feldtypen (`references/field-types-and-values.md`) |
| `grilling` | Optional vor Phase 7 zum Hinterfragen des neuen Datenmodells |
| `docx`, `xlsx` | Nur auf Anfrage für Word- oder Excel-Fassungen der Berichte |

## Reifegrad

**Aktueller Reifegrad je Phase steht ausschließlich in `references/stand-und-offene-punkte.md`** (Abschnitt "Was belegt ist", dort pflegen, nicht hier duplizieren). Claude liest die Datei, bevor eine Migration beginnt, und sagt dem Nutzer vor dem Einsatz, welche Phasen erprobt sind.

## Bekannte Grenzen (ehrlich benannt)

- **Formelwerte stehen nicht im Export.** Für den Formelvergleich braucht es einen Export der Soll-Werte aus Ninox 3 (Phase 6). Ohne ihn gilt Prüfung C als "nicht belegt".
- **Belegt (OpenAPI 1.0.0, öffentlich gelesen):** Ansichten, Berichte, Trigger, Zugriffsausdrücke, Standardwerte, Rollen-Arrays, Feldtyp `html`, Dateiupload sind per API anlegbar (`references/api-faehigkeiten.md`). Der `ninox`-Skill nennt Ansichten und Berichte noch als nicht dokumentiert; die Live-Spezifikation hat Vorrang und wird in Phase 2 neu gelesen (`-PruefeApi`).
- **Im Test-Workspace beobachtet (2026-10-06, `references/api-faehigkeiten.md`):** fehlerhafte Formeln werden beim Anlegen abgelehnt; Datum nur als `yyyy-MM-dd` (das deutsche Format ergibt den falschen Tag); Rückverweise entstehen automatisch mit dem Verweisfeld und werden nur umbenannt; Standardwerte greifen beim Anlegen per API nicht; Labels erscheinen auf der Oberfläche.
- **Ninox-Verhalten bei `like`:** Ninox 4 legt `like` per API nur an, wenn der linke Operand in `text()` steht; sonst HTTP 500 ohne Feld (Abweichung Nr. 5, Meldung liegt vor). Dem Ninox Support melden.
- **Unbelegt, vor Gebrauch klären:** ob sich Ninox-3-Ansichten, -Berichte, -Rechte und -Trigger inhaltlich gleichwertig abbilden lassen (die API kann sie anlegen, Gleichwertigkeit ist nicht bewiesen); Zuordnung benutzerdefinierter Ninox-3-Rollen; Zuordnung Ninox-3-`link` zu `string`/`url` und des `html`-Feldes; mehrere Verweise zwischen denselben zwei Tabellen (Namen der Rückverweise); Form von Mehrfachauswahl und Dateifeldern; weitere Raten-Limits (bekannt: höchstens 3 gleichzeitige Schreibvorgänge je Workspace, vorübergehende Serverfehler beim Anlegen vieler Formelfelder).
- **Anhänge** liegen im untersuchten Export nicht vor (nur Dateinamen, im Beispiel 17.280). Sie sind Sache des späteren Vollimports; der Upload-Weg ist in der API vorhanden.
- **Große Dateien:** Die Skripte lesen streamend; die Stichprobe hält die Rohzeilen im Speicher. Bei Dateien über einige hundert MB vorher Speicherbedarf prüfen.
- **Referenzdatei:** Die Skripte sind an einem Export ("Test-Export", 16 Tabellen, 55.642 Datensätze) entwickelt und getestet. Unbekannte Schlüssel in anderen Exporten meldet das Inventar in `WeitereSchluessel` und setzt das Mapping auf "ungeklaert".
