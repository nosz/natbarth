# Liest die OEFFENTLICHE Ninox-4-API-Beschreibung (OpenAPI) und fasst zusammen, was die API kann.
# PowerShell 5.1. Kein API-Key, kein Zugriff auf Ninox-Daten; nur ein lesender Abruf der oeffentlichen Spezifikation
# (https://go.ninox.com/api/docs-json) oder Lesen einer lokal gespeicherten Kopie.
# Hinweis: ConvertFrom-Json scheitert in Windows PowerShell 5.1 an dieser Spezifikation; deshalb JavaScriptSerializer.
# Nutzung:  . .\scripts\ninox-openapi.ps1
#           $spec = Get-NinoxOpenApi -OutFile arbeit\openapi.json      (laedt und speichert)
#           $spec = Get-NinoxOpenApi -Path arbeit\openapi.json         (liest die Kopie)
#           Get-NinoxApiCapability -Spec $spec | Format-Table -Wrap

Add-Type -AssemblyName System.Web.Extensions

function Get-NinoxOpenApi {
    param([string]$Path, [string]$OutFile, [string]$Url = 'https://go.ninox.com/api/docs-json')
    if ($Path) { $raw = [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) }
    else {
        $r = Invoke-WebRequest -UseBasicParsing -Uri $Url
        $raw = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
        if ($OutFile) { New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutFile) | Out-Null; [IO.File]::WriteAllText($OutFile, $raw, (New-Object Text.UTF8Encoding($false))) }
    }
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer
    $ser.MaxJsonLength = [int]::MaxValue; $ser.RecursionLimit = 500
    return , $ser.DeserializeObject($raw)
}

function Get-NinoxApiCapability {
    # Liefert je Fachbereich: belegt (ja/nein), Fundstelle in der Spezifikation. Zeigt NUR, was die Spezifikation nennt;
    # ob die Abbildung einer Ninox-3-Funktion gelingt, ist damit nicht bewiesen (im Test-Workspace pruefen).
    param([Parameter(Mandatory)]$Spec)
    $paths = $Spec['paths'].Keys
    $schemas = $Spec['components']['schemas']
    $version = "$($Spec['info']['title']) $($Spec['info']['version'])"
    $hasPath = { param($rx, $m) @($paths | Where-Object { $_ -match $rx -and $Spec['paths'][$_].ContainsKey($m) }).Count -gt 0 }
    $props = { param($name) if ($schemas.ContainsKey($name) -and $schemas[$name].ContainsKey('properties')) { @($schemas[$name]['properties'].Keys) } else { @() } }
    $field = & $props 'CreateFieldBody'; $table = & $props 'CreateTableBody'; $view = & $props 'CreateViewBody'; $report = & $props 'CreateReportBody'
    $types = @(); if ($field -contains 'type') { $types = @($schemas['CreateFieldBody']['properties']['type']['enum']) }
    $viewTypes = @(); if ($view -contains 'type') { $viewTypes = @($schemas['CreateViewBody']['properties']['type']['enum']) }
    $row = { param($b, $ja, $stelle) [pscustomobject]@{ Bereich = $b; Belegt = [bool]$ja; Fundstelle = $stelle; Spezifikation = $version } }

    & $row 'Ansichten anlegen' (& $hasPath '/tables/\{tableName\}/views$' 'post') ("POST .../tables/{t}/views; Typen: " + ($viewTypes -join ', '))
    & $row 'Ansicht: Filter, Gruppierung, Sortierung' (($view -contains 'filter') -and ($view -contains 'groupBy') -and ($view -contains 'sort')) 'CreateViewBody: filter, groupBy, sort, columns, conditionalFormatting'
    & $row 'Berichte anlegen' (& $hasPath '/tables/\{tableName\}/reports$' 'post') 'POST .../tables/{t}/reports; Layoutobjekte (objects) oder automatisch aus den Feldern'
    & $row 'Trigger an Tabelle' (($table -contains 'onCreate') -and ($table -contains 'onUpdate') -and ($table -contains 'onDelete')) 'CreateTableBody: onCreate, onUpdate, onDelete'
    & $row 'Trigger an Feld' ($field -contains 'onUpdate') 'CreateFieldBody: onUpdate'
    & $row 'Zugriffsausdruecke (Tabelle)' (($table -contains 'canRead') -and ($table -contains 'canWrite')) 'CreateTableBody: canRead, canWrite, canCreate, canDelete'
    & $row 'Zugriffsausdruecke (Feld)' (($field -contains 'canRead') -and ($field -contains 'canWrite')) 'CreateFieldBody: canRead, canWrite'
    & $row 'Rollen (Tabelle/Feld)' (($table -contains 'readRoles') -and ($field -contains 'readRoles')) 'readRoles, writeRoles, createRoles, deleteRoles; Feldrolle "user" ist veralteter Alias fuer "editor" (laut Beschreibung)'
    & $row 'Standardwert am Feld' ($field -contains 'defaultValue') 'CreateFieldBody: defaultValue (Wert oder Skriptausdruck)'
    & $row 'Feldtyp html' ($types -contains 'html') ('Typen: ' + ($types -join ', '))
    & $row 'Feldtyp reverse (Rueckverweis)' ($types -contains 'reverse') 'type reverse mit refTableName; im Test beobachtet: ein einzeln angelegtes reverse-Feld erzeugt ein neues, getrenntes Verweisfeld; Rueckverweise entstehen automatisch mit dem Verweisfeld (references/api-faehigkeiten.md)'
    & $row 'Formelfeld (function)' (($types -contains 'function') -and ($field -contains 'expression')) 'type function mit expression'
    & $row 'Dateiupload an Datensatz' ((& $hasPath '/records/\{recordId\}/files$' 'post') -and (& $hasPath '/files/upload-url$' 'post')) 'POST .../records/{id}/files; files/upload-url und files/complete'
    & $row 'Modulskripte (Funktionen)' (& $hasPath '/functions/\{scriptName\}$' 'get') '.../modules/{m}/functions/{name}'
    & $row 'Moduldefinition lesen/schreiben' ((& $hasPath '/definition$' 'get') -and (& $hasPath '/definition$' 'put')) 'GET/PUT .../modules/{m}/definition'
    & $row 'Seiten/Komponenten' (& $hasPath '/components$' 'post') 'POST .../modules/{m}/components (siehe ninox4-api-builder)'
    & $row 'Layoutdetails fuer Felder (showInTable)' ($field -contains 'showInTable') 'CreateFieldBody: showInTable'
}
