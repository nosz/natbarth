﻿# Selbsttest des Skills: prueft alle lokalen Funktionen mit ERFUNDENEN Daten. Kein Netzwerk, kein Key, keine Kundendaten.
# PowerShell 5.1.  Nutzung:  . .\scripts\selftest.ps1 ; Invoke-Ninox3Selbsttest
# Ergebnis: Tabelle mit Pruefung, Ergebnis (ok/FEHLER), Detail; Rueckgabewert Bestanden = $true, wenn alles ok ist.
# Laeuft vor jeder Weitergabe des Skills und nach jeder Aenderung an den Skripten.

$script:SelftestDir = $PSScriptRoot
. (Join-Path $PSScriptRoot 'ninox3-reader.ps1')
. (Join-Path $PSScriptRoot 'ninox3-formeln.ps1')
. (Join-Path $PSScriptRoot 'ninox3-stichprobe.ps1')
. (Join-Path $PSScriptRoot 'ninox3-entscheidungen.ps1')
. (Join-Path $PSScriptRoot 'ninox-support.ps1')
. (Join-Path $PSScriptRoot 'ninox-pruefungen.ps1')
. (Join-Path $PSScriptRoot 'ninox-openapi.ps1')
. (Join-Path $PSScriptRoot 'ninox3-testdaten.ps1')
. (Join-Path $PSScriptRoot 'ninox-abweichungen.ps1')
. (Join-Path $PSScriptRoot 'ninox4-doku-modul.ps1')

function Invoke-Ninox3Selbsttest {
    $res = New-Object Collections.Generic.List[object]
    function Check($name, $ok, $detail = '') { $res.Add([pscustomobject]@{ Pruefung = $name; Ergebnis = $(if ($ok) { 'ok' } else { 'FEHLER' }); Detail = "$detail" }) }
    function Safe($name, [scriptblock]$b) { try { & $b } catch { Check $name $false ("Ausnahme: " + $_.Exception.Message.Substring(0, [Math]::Min(150, $_.Exception.Message.Length))) } }
    $tmp = Join-Path $env:TEMP ("ninox3-selbsttest-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Force -Path $tmp | Out-Null

    # 1. Skripte: Syntax und ASCII
    foreach ($f in Get-ChildItem $script:SelftestDir -Filter *.ps1) {
        $errs = $null; [void][Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$null, [ref]$errs)
        $na = @(Select-String -Path $f.FullName -Pattern '[^\x00-\x7F]').Count
        Check "Skript $($f.Name): Syntax und ASCII" ((@($errs).Count -eq 0) -and ($na -eq 0)) "Syntaxfehler $(@($errs).Count), Nicht-ASCII-Zeilen $na"
    }

    # 2. Beispiel erzeugen, Paar pruefen, Inventar
    $fx = $null; $o = $null; $m = $null; $schema = $null; $fields = $null; $mapping = $null
    Safe 'Beispiel erzeugen' {
        $script:fx = New-Ninox3Fixture -Ordner $tmp
        $script:o = Expand-Ninox3Archive -Path $script:fx.Ohne -Destination "$tmp\ohne"; $script:m = Expand-Ninox3Archive -Path $script:fx.Mit -Destination "$tmp\mit"
        Check 'Beispiel erzeugen und entpacken' ((Test-Path "$tmp\ohne\data.db") -and (Test-Path "$tmp\mit\data.db"))
        # Zip-Slip-Schutz: Archiv mit Pfad ausserhalb wird abgelehnt
        $evil = Join-Path $tmp 'boese.ninox'; $fs = [IO.File]::Create($evil); $z = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
        $en = $z.CreateEntry('../ausserhalb.txt'); $s = $en.Open(); $s.WriteByte(65); $s.Close(); $z.Dispose(); $fs.Close()
        $blocked = $false; try { $null = Expand-Ninox3Archive -Path $evil -Destination "$tmp\boese" } catch { $blocked = $true }
        Check 'Zip-Slip-Schutz' ($blocked -and -not (Test-Path (Join-Path $tmp 'ausserhalb.txt')))
    }
    $o = "$tmp\ohne"; $m = "$tmp\mit"
    Safe 'Sicherungspaar' {
        $p = Test-Ninox3BackupPair -DirOhne $o -DirMit $m
        Check 'Sicherungspaar passt' $p.Bestanden
        $q = Test-Ninox3BackupPair -DirOhne $o -DirMit $o
        Check 'Sicherungspaar: zwei Dateien ohne Daten werden abgelehnt' (-not $q.Bestanden)
    }
    Safe 'Inventar' {
        $r = Export-Ninox3Inventory -Dir $o -OutDir "$tmp\ergebnis" -RawDir "$tmp\arbeit\inventar" -DataDbMit "$m\data.db"
        Check 'Inventar: 2 Tabellen, 15 Felder, 2 Formeln' (($r.Tabellen -eq 2) -and ($r.Felder -eq 15) -and ($r.Formelfelder -eq 2)) "Tabellen $($r.Tabellen), Felder $($r.Felder), Formeln $($r.Formelfelder)"
        Check 'Inventar: Verweis, Rueckverweis, Dateifeld, 7 Datensaetze' (($r.Verweisfelder -eq 1) -and ($r.Rueckverweisfelder -eq 1) -and ($r.Dateifelder -eq 1) -and ($r.Datensaetze -eq 7))
        Check 'Plugin Ninext wird ignoriert und nicht als Luecke gefuehrt' (($r.PluginsIgnoriert -match 'Ninext') -and -not (Import-Csv "$tmp\ergebnis\09_luecken.csv" -Delimiter ';' | Where-Object { $_.Kategorie -eq 'Plugin' }))
        $roh = Get-Content "$tmp\arbeit\inventar\03_formeln_voll.csv" -Raw -Encoding UTF8
        $sicher = (Get-ChildItem "$tmp\ergebnis" -File | ForEach-Object { Get-Content $_.FullName -Raw -Encoding UTF8 }) -join "`n"
        Check 'Bereinigte Ergebnisse enthalten keine Formeltexte oder E-Mail-Adressen' (($roh -match 'beispiel\.invalid') -and ($sicher -notmatch 'beispiel\.invalid')) 'volle Fassung enthaelt sie, ergebnis/ nicht'
    }
    $schema = Read-Ninox3Schema "$o\data.db"; $fields = @(Get-Ninox3FieldInventory $schema)
    $mapping = @(Import-Csv "$tmp\ergebnis\06_mapping_vorschlag.csv" -Delimiter ';' -Encoding UTF8)
    Safe 'Namen' {
        $names = @(Test-Ninox4Names -Mapping $mapping)
        Check 'Namensregeln: keine Fehler' (@($names | Where-Object { $_.Stufe -eq 'Fehler' }).Count -eq 0)
        Check 'Namen lesbar (aus Beschriftung, keine Ninox-3-IDs)' (@($mapping | Where-Object { $_.Ninox4Feld -match '^[a-z]$' }).Count -eq 0 -and (@($mapping | Where-Object { $_.Ninox4Feld -eq 'e_mail' }).Count -eq 1))
        Check 'Umlaut-Umsetzung' ((Convert-ToNinox4Name ("M" + [char]0xE4 + "rz " + [char]0xDF + "ig")) -eq 'maerz_ssig')
    }

    # 3. Formeln
    Safe 'Formeln' {
        $mapping | ForEach-Object { $_.Freigabe = 'freigegeben' }
        $s = Export-Ninox3FormulaAnalysis -Schema $schema -FieldRows $fields -Mapping $mapping -Path "$tmp\arbeit\inventar\08_formel_analyse_voll.csv" -SafePath "$tmp\ergebnis\08_formel_analyse.csv"
        Check 'Formelanalyse: beide Formeln aufgeloest' (($s.Formeln -eq 2) -and ($s.Aufgeloest -eq 2) -and ($s.Pruefen -eq 0))
        $rows = @(Import-Csv "$tmp\arbeit\inventar\08_formel_analyse_voll.csv" -Delimiter ';' -Encoding UTF8)
        $sum = $rows | Where-Object { $_.Beschriftung -eq 'Summe' }; $adr = $rows | Where-Object { $_.Beschriftung -eq 'Lieferadresse' }
        Check 'Formel Summe 1:1 mit Namen' ($sum.ZuBauen -eq 'menge * preis') $sum.ZuBauen
        Check 'Formel mit Adressdaten erkannt und mit Platzhaltern gebaut' (($adr.Anonymisiert -eq 'True') -and ($adr.ZuBauen -notmatch '@|\d{5}') -and ($adr.ZuBauen -match 'Wert 1'))
        Check 'Formel ohne Adressdaten bleibt unveraendert' ($sum.Anonymisiert -eq 'False')
        Check 'like bleibt standardmaessig unveraendert (keine Umwandlung)' (@($rows | Where-Object { [int]$_.LikeErsetzt -ne 0 }).Count -eq 0 -and $adr.ZuBauen -match '\blike\b')
        $a1 = (ConvertTo-N4LikeAlsContains '(x like "Abc")').Formel
        $a2 = (ConvertTo-N4LikeAlsContains 'if ((a.b = c) and (d.e.f like g)) then 1 else 2 end').Formel
        $a3 = ConvertTo-N4LikeAlsContains '(if (p like "x") then (if (q.r like "y") then 1 else 2 end) else lower(s) like lower(t) end)'
        $a4 = (ConvertTo-N4LikeAlsContains 'if (x = "a") then 1 else 2 end')
        Check 'like bekommt text() links (Zeichenkette, Feldpfad, Verschachtelung, Funktionsaufruf)' (($a1 -eq '(text(x) like "Abc")') -and ($a2 -eq 'if ((a.b = c) and (text(d.e.f) like g)) then 1 else 2 end') -and ($a3.Ersetzt -eq 3) -and ($a3.Formel -match 'text\(lower\(s\)\) like lower\(t\)') -and ($a4.Ersetzt -eq 0)) $a3.Formel
        $dKette = Get-N3MaxIfDepth '(if (a = 1) then 1 else (if (b = 2) then 2 else (if (c = 3) then 3 else 0)))'
        $dFlach = Get-N3MaxIfDepth 'if a then 1 else if b then 2 else if c then 3 else 0 end end end'
        $dText = Get-N3MaxIfDepth '"if if if" + x'
        $dZwei = Get-N3MaxIfDepth '(if a then 1 else 2) + (if b then 3 else 4)'
        Check 'Verschachtelungstiefe von if wird gezaehlt (Kette, else if, Zeichenketten zaehlen nicht, nebeneinander ist nicht verschachtelt)' (($dKette -eq 3) -and ($dFlach -eq 3) -and ($dText -eq 0) -and ($dZwei -eq 1)) "Kette $dKette, else-if $dFlach, Text $dText, zwei $dZwei"
        Check 'Platzhalter-Funktion: kurze Werte bleiben' ((ConvertTo-N3PlaceholderFormula '"ab" + "Teststrasse 1"') -eq '"ab" + "Wert 1"')
    }

    # 4. Stichprobe, Anonymisierung, Gegenpruefung, Nutzlast
    Safe 'Stichprobe' {
        $s1 = Select-Ninox3Sample -DataDb "$m\data.db" -Schema $schema -MainTypeId 'B' -Count 3 -Seed 7
        Check 'Stichprobe verknuepfungstreu (Kunden werden mitgenommen, keine Verweise ins Leere)' (($s1.Records.Contains('A')) -and ($s1.DanglingRefs.Count -eq 0)) $s1.Counts
        $s2 = Select-Ninox3Sample -DataDb "$m\data.db" -Schema $schema -MainTypeId 'B' -Count 3 -Seed 7
        Check 'Stichprobe reproduzierbar (gleicher Seed)' ($s1.Counts -eq $s2.Counts)
        $cand = @(Get-Ninox3PiiCandidates -Schema $schema)
        Check 'Personendaten-Kandidaten erkannt (E-Mail, Name, Strasse, Anhang)' (@($cand | Where-Object { $_.Schluessel -in 'A.D', 'A.A', 'A.B', 'B.H' }).Count -ge 3) (($cand | ForEach-Object { $_.Schluessel }) -join ',')
        $fl = @($cand | ForEach-Object { $_.Schluessel })
        $orig = Get-Ninox3PiiOriginale -Sample $s1 -Fields $fl
        $vorher = @(Test-Ninox3AnonymisiertOhneOriginale -Sample $s1 -Originale $orig)
        Check 'Gegenpruefung erkennt nicht anonymisierte Daten' ($vorher.Count -gt 0)
        $null = Invoke-Ninox3Anonymize -Sample $s1 -Fields $fl -Schema $schema
        $nachher = @(Test-Ninox3AnonymisiertOhneOriginale -Sample $s1 -Originale $orig)
        Check 'Nach der Anonymisierung kommt kein Originalwert mehr vor' ($nachher.Count -eq 0) "Treffer: $($nachher.Count)"
        Check 'Restpruefung E-Mail und Telefon' (@(Test-Ninox3SampleForPii -Sample $s1).Count -eq 0)
        $mp = @($mapping)
        $pl = ConvertTo-Ninox4Payload -Sample $s1 -Schema $schema -Mapping $mp
        $a = $pl['auftraege'][0]
        Check 'Nutzlast: Formelfeld und Dateifeld nicht in den Werten, Dateiname getrennt' ((-not $a.werte.Contains('summe')) -and (-not $a.werte.Contains('anhang')))
        Check 'Nutzlast: Datum als yyyy-MM-dd (nie dd.MM.yyyy)' ((@($pl['auftraege'] | Where-Object { $_.werte.Contains('lieferdatum') -and $_.werte['lieferdatum'] -match '^\d{4}-\d{2}-\d{2}$' }).Count -ge 1) -and (@($pl['auftraege'] | Where-Object { $_.werte.Contains('lieferdatum') -and $_.werte['lieferdatum'] -match '^\d{2}\.\d{2}\.\d{4}$' }).Count -eq 0))
        $k = $pl['kunden'] | Where-Object { $_.werte.Contains('status') } | Select-Object -First 1
        Check 'Nutzlast: Auswahl-ID wird zum Label' ($k.werte['status'] -in 'Aktiv', 'Inaktiv') $k.werte['status']
        Check 'Nutzlast: Verweis getrennt in refs' ($pl['auftraege'][0].refs.Contains('kunde') -or @($pl['auftraege'] | Where-Object { $_.refs.Contains('kunde') }).Count -ge 1)
    }

    # 5. Schreibtempo, Support, Fehlererkennung
    Safe 'Tempo' {
        Set-NinoxSchreibtempo -BasisMs 300; $v = @(Get-NinoxSchreibpause)
        Register-NinoxTransient; $v += Get-NinoxSchreibpause; 1..5 | ForEach-Object { Register-NinoxErfolg }; $v += Get-NinoxSchreibpause; 1..30 | ForEach-Object { Register-NinoxErfolg }; $v += Get-NinoxSchreibpause
        Check 'Schreibtempo: verdoppelt nach Fehler, verkuerzt nach Erfolgen, endet bei der Basis' (($v[1] -gt $v[0]) -and ($v[2] -lt $v[1]) -and ($v[3] -eq 300)) ($v -join ' -> ')
        Check 'Serverfehler werden erkannt, Formelfehler nicht' ((Test-NinoxTransientError 'upstream connect error ... Connection refused') -and (Test-NinoxTransientError 'too many concurrent write transactions') -and -not (Test-NinoxTransientError 'Field not found: abc'))
        Clear-NinoxStoerungen; Add-NinoxStoerung -Aktion 'Test' -Methode 'POST' -Pfad '/modules/x/tables/y/fields' -Meldung 'upstream connect error: Connection refused'
        $sm = New-NinoxSupportMeldung -ProjectDir $tmp -WorkspaceId 'abc123def456' -Modul 'x' -Aktion 'Test' -Erfolgreich 3
        Check 'Supportmeldung entsteht, nennt Workspace und Fehlerart, enthaelt keinen Key' (($sm.Text -match 'abc123def456') -and ($sm.Text -match 'Server nicht erreichbar') -and ($sm.Text -notmatch 'Bearer (?!<API_KEY>)') -and ($sm.Text -match 'Bearer <API_KEY>') -and ($sm.Text -match '=== ENGLISH ===') -and ($sm.Text -match 'Example request') -and (Test-Path $sm.Datei) -and ($sm.Datei -match '\\ergebnis\\support\\\d{8}_\d{6}_support_meldung\.txt$'))
        Clear-NinoxStoerungen
        Check 'Ohne Stoerung keine Supportmeldung' ($null -eq (New-NinoxSupportMeldung -ProjectDir $tmp -WorkspaceId 'x' -Aktion 'x'))
    }

    # 6. Sicherheitsfunktionen
    Safe 'Sicherheit' {
        $leak = Join-Path $tmp 'leak'; New-Item -ItemType Directory -Force -Path $leak | Out-Null
        Set-Content "$leak\a.txt" 'nichts hier' -Encoding UTF8; Set-Content "$leak\b.txt" 'Zeile mit FAKE-KEY-SELBSTTEST-0123456789 mittendrin' -Encoding UTF8
        $r = @(Test-NoSecretLeak -Pfade @($leak) -KeyWert 'FAKE-KEY-SELBSTTEST-0123456789')
        Check 'Geheimnis-Suche findet den Key in einer Datei, nicht in der anderen' ((@($r | Where-Object { $_.Ergebnis -like 'TREFFER*' }).Count -eq 1) -and ($r[0].Datei -like '*b.txt'))
        $r2 = @(Test-NoSecretLeak -Pfade @("$tmp\ergebnis") -KeyWert 'FAKE-KEY-SELBSTTEST-0123456789')
        Check 'Geheimnis-Suche: sauberes ergebnis/ ohne Treffer' ($r2[0].Ergebnis -eq 'kein Treffer')
        $pf = Join-Path $tmp 'weitergabe'; New-Item -ItemType Directory -Force -Path $pf | Out-Null
        Set-Content "$pf\x.csv" "Name;Wert`nA;info@beispiel.invalid`nB;Firma Beispielwort" -Encoding UTF8
        $w = Test-ErgebnisFuerWeitergabe -Pfad $pf -Woerter @('Beispielwort')
        Check 'Weitergabe-Pruefung findet E-Mail und Wortliste' ((-not $w.Bestanden) -and (@($w.Treffer | Where-Object { $_.Art -eq 'E-Mail-Adresse' }).Count -eq 1) -and (@($w.Treffer | Where-Object { $_.Art -eq 'Wortliste' }).Count -eq 1))
        $w2 = Test-ErgebnisFuerWeitergabe -Pfad "$tmp\ergebnis"
        Check 'Weitergabe-Pruefung: bereinigtes ergebnis/ des Beispiels besteht' $w2.Bestanden "Treffer: $(@($w2.Treffer).Count)"
        # Konfiguration
        $cp = Join-Path $tmp 'proj'; New-Item -ItemType Directory -Force -Path "$cp\ergebnis" | Out-Null
        Set-Content "$cp\ninox.config.json" '{"apiBase":"https://go.ninox.com","workspaceId":"abc123def456","moduleName":"mein_modul","migration":{"docModuleName":"mein_modul_doku","sampleSize":20}}' -Encoding UTF8
        Check 'Konfiguration gueltig' (@(Test-NinoxConfig -ProjectDir $cp | Where-Object { $_.Stufe -eq 'Fehler' }).Count -eq 0)
        Set-Content "$cp\ninox.config.json" '{"apiBase":"https://go.ninox.com","workspaceId":"X","moduleName":"Falsch Name","apiKey":"abcdefghijklmnop"}' -Encoding UTF8
        Check 'Ungueltige Konfiguration und enthaltenes Geheimnis werden gemeldet' (@(Test-NinoxConfig -ProjectDir $cp | Where-Object { $_.Stufe -eq 'Fehler' }).Count -ge 3)
        Set-Content "$cp\ninox.config.json" '{"apiBase":"https://go.ninox.com","workspaceId":"abc123def456","moduleName":"mein_modul","migration":{"docModuleName":"mein_modul_doku"}}' -Encoding UTF8
        # Freigabe
        $thrown1 = $false; try { Assert-NinoxSchreibfreigabe -ProjectDir $cp -Phase 3 -Modul 'mein_modul' } catch { $thrown1 = $true }
        Set-NinoxFreigabe -ProjectDir $cp -Phase 3 -WorkspaceId 'abc123def456' -Module @('mein_modul', 'mein_modul_doku') -Text 'Selbsttest'
        $ok2 = $true; try { Assert-NinoxSchreibfreigabe -ProjectDir $cp -Phase 3 -Modul 'mein_modul' } catch { $ok2 = $false }
        $thrown3 = $false; try { Assert-NinoxSchreibfreigabe -ProjectDir $cp -Phase 4 -Modul 'mein_modul' } catch { $thrown3 = $true }
        $thrown4 = $false; try { Assert-NinoxSchreibfreigabe -ProjectDir $cp -Phase 3 -Modul 'anderes_modul' } catch { $thrown4 = $true }
        Check 'Freigabe: ohne Freigabe wird abgelehnt, mit Freigabe erlaubt, andere Phase und anderes Modul abgelehnt' ($thrown1 -and $ok2 -and $thrown3 -and $thrown4)
        # Protokoll sofort
        Add-NinoxProtokollZeile -ProjectDir $cp -Phase 3 -Aktion 'Test 1' -Ziel 'x' -Anzahl 1 -Ergebnis 'OK'; Add-NinoxProtokollZeile -ProjectDir $cp -Phase 3 -Aktion 'Test 2; mit Semikolon' -Ziel 'y' -Anzahl 2 -Ergebnis 'OK'
        $pr = @(Import-Csv "$cp\ergebnis\schreibprotokoll.csv" -Delimiter ';' -Encoding UTF8)
        Check 'Protokoll wird sofort angehaengt (2 Zeilen, Semikolon im Text bleibt heil)' (($pr.Count -eq 2) -and ($pr[1].Aktion -eq 'Test 2; mit Semikolon'))
        Write-NinoxFortschritt -ProjectDir $cp -Phase 3 -Schritt 'Test' -Aktuell 2 -Gesamt 4
        Check 'Fortschrittsdatei' ((Get-Content "$cp\ergebnis\fortschritt.json" -Raw | ConvertFrom-Json).aktuell -eq 2)
        # Loeschen nur kontrolliert (ohne Netzwerk: Pruefungen greifen vorher)
        $t1 = $false; try { Remove-Ninox4ModulKontrolliert -ProjectDir $cp -HelpersPath 'x' -Modul 'mein_modul_doku' -Bestaetigt 'ok' } catch { $t1 = $_.Exception.Message -match 'Nicht bestaetigt' }
        $t2 = $false; try { Remove-Ninox4ModulKontrolliert -ProjectDir $cp -HelpersPath 'x' -Modul 'fremdes_modul' -Bestaetigt 'Ja, loeschen' } catch { $t2 = $_.Exception.Message -match 'gehoert nicht zu diesem Projekt' }
        Check 'Loeschen: ohne exakte Bestaetigung und fuer fremde Module abgelehnt' ($t1 -and $t2)
        $hy = @(Test-NinoxKeyHygiene); Check 'Key-Hygiene-Pruefung laeuft (ohne Wert auszugeben)' ($true) "$($hy.Count) Meldungen"
        Check 'Aufraeumliste vollstaendig' ((@(Get-NinoxAufraeumListe -ProjectDir $cp).Count) -ge 6)
    }

    # 6b. Abweichungen und Entwicklermeldung
    Safe 'Abweichungen' {
        $ap = Join-Path $tmp 'abw'; New-Item -ItemType Directory -Force -Path "$ap\ergebnis" | Out-Null
        $v = Add-NinoxAbweichung -ProjectDir $ap -Titel 'Verdachtsfall' -Bereich API -Endpunkt 'POST /modules/{m}/tables/{t}/fields' -Erwartet 'sollte gehen' -ErwartetQuelle 'https://docs.ninox.com/x' -Tatsaechlich 'Fehler 500' -Schwere stoerend -Reproduktion @('Schritt a', 'Schritt b') -MinimalRequest '{"name":"x"}' -Pruefung @{ DokuBeleg = $true; Wiederholung = $false } -Beobachtet @('2026-10-06 10:00')
        Check 'Abweichung mit offenen Pruefpunkten bleibt ein Verdacht' (($v.Status -eq 'Verdacht') -and ($v.Offen.Count -ge 4)) ($v.Offen -join ', ')
        $t1 = $false; try { $null = New-NinoxEntwicklerMeldung -ProjectDir $ap -Nr $v.Nr } catch { $t1 = $_.Exception.Message -match 'genauer Pruefung' }
        Check 'Fuer einen Verdacht entsteht keine Entwicklermeldung' $t1
        $t2 = $false; try { Set-NinoxAbweichungStatus -ProjectDir $ap -Nr $v.Nr -Status gemeldet } catch { $t2 = $_.Exception.Message -match 'nur ein Verdacht' }
        Check 'Ein Verdacht kann nicht als gemeldet markiert werden' $t2
        $ok = @{ DokuBeleg = $true; Wiederholung = $true; Minimalbeispiel = $true; Gegenprobe = $true; KeinEigenfehler = $true; KeineEchtdaten = $true }
        $g = Add-NinoxAbweichung -ProjectDir $ap -Titel 'Gepruefter Fall mit Sonderzeichen' -Bereich Formel -Endpunkt 'POST /modules/{m}/tables/{t}/fields' -Erwartet 'Feld wird ohne Fehler angelegt' -ErwartetQuelle 'https://docs.ninox.com/y' -Tatsaechlich 'Antwort 500, Feld existiert trotzdem' -Schwere stoerend -Reproduktion @('Feld anlegen', 'Antwort lesen', 'Feld lesen') -MinimalRequest '{ "name": "t", "type": "function", "expression": "a like b" }' -Modul 'zz_probe' -Tabelle 'probe_kunden' -Feld 't_like_text' -Fundstellen @('probe_kunden.t_like_if') -Gegenprobe 'Mit = funktioniert es' -Workaround 'Feld nach dem Fehler pruefen' -Beobachtet @('2026-10-06 10:00', '2026-10-06 11:30') -Pruefung $ok -Workspace 'abc123def456' -ApiVersion '1.0.0' -TitelEn 'Checked case with special characters' -ErwartetEn 'Field is created without an error' -TatsaechlichEn 'Response 500, field exists anyway' -ReproduktionEn @('Create field', 'Read response', 'Read field') -GegenprobeEn 'With = it works' -WorkaroundEn 'Check the field after the error'
        $ohneEn = Add-NinoxAbweichung -ProjectDir $ap -Titel 'Ohne englische Fassung' -Bereich API -Endpunkt 'GET /x' -Erwartet 'e' -ErwartetQuelle 'https://docs.ninox.com/z' -Tatsaechlich 't' -Schwere kosmetisch -Reproduktion @('a') -MinimalRequest '{}' -Beobachtet @('a', 'b') -Pruefung $ok
        Check 'Ohne englische Fassung bleibt es ein Verdacht (Pruefpunkt EnglischeFassung offen)' (($ohneEn.Status -eq 'Verdacht') -and ($ohneEn.Offen -contains 'EnglischeFassung'))
        Check 'Voll gepruefte Abweichung bekommt den Status geprueft' ($g.Status -eq 'geprueft')
        $m = New-NinoxEntwicklerMeldung -ProjectDir $ap -Nr $g.Nr
        Check 'Meldung (eine txt-Datei): Ort, Endpunkt, Platzhalter statt Key, Minimalbeispiel, englische Kurzfassung' (($m.Text -match '/api/v1/workspace/abc123def456/modules/zz_probe/tables/probe_kunden/fields') -and ($m.Text -match 'Where:\* workspace abc123def456') -and ($m.Text -match 'Wo:\* Workspace abc123def456') -and ($m.Text -match 'probe_kunden\.t_like_if') -and ($m.Text -match 'Bearer <API_KEY>') -and ($m.Text -match '=== DEUTSCH ===') -and ($m.Text -match '=== ENGLISH ===') -and ($m.Text -match 'Steps to reproduce') -and ($m.Text -match 'a like b') -and (Test-Path $m.Datei) -and ($m.Datei -match '\\ergebnis\\support\\\d{8}_\d{6}_meldung_\d{3}_.*\.txt$'))
        $t3 = $false; try { $null = Add-NinoxAbweichung -ProjectDir $ap -Titel 'x' -Bereich API -Endpunkt 'GET /x' -Erwartet 'e' -ErwartetQuelle 'q' -Tatsaechlich 't' -Schwere kosmetisch -Reproduktion @('r') -MinimalRequest 'Authorization: Bearer abcdef0123456789abcdef0123456789abcdef' } catch { $t3 = $_.Exception.Message -match 'Key aussieht' }
        Check 'Text mit Key-aehnlichem Inhalt wird abgelehnt' $t3
        $sl = New-NinoxSlackMeldung -ProjectDir $ap -Nr $g.Nr
        Check 'Slack-tauglich: kein Markdown-Fett, keine #-Ueberschriften, Codeblock und Platzhalter, nur EINE Datei' (($sl.Haupt -notmatch '\*\*') -and ($sl.Haupt -notmatch '(?m)^#') -and ($sl.Haupt -match '(?m)^\*\[Ninox Public API\]') -and ($sl.Haupt -match '```') -and ($sl.Haupt -match 'Bearer <API_KEY>') -and ($sl.Datei -eq $m.Datei) -and (@(Get-ChildItem (Split-Path $m.Datei) -File).Count -eq 1))
        Set-NinoxAbweichungStatus -ProjectDir $ap -Nr $g.Nr -Status gemeldet -Notiz 'Test'
        $z = @(Get-NinoxAbweichungen -ProjectDir $ap) | Where-Object { [int]$_.Nr -eq [int]$g.Nr }
        Check 'Status gemeldet mit Datum' (($z.Status -eq 'gemeldet') -and ($z.GemeldetAm -match '^\d{4}-\d{2}-\d{2}$'))
        $zeile = Convert-Ninox4AbweichungZeile $z
        Check 'Zeile fuer die Ninox-Tabelle: Status mit Umlaut-Label, Nummer als Zahl, nur gefuellte Felder' (($zeile['status'] -eq 'gemeldet') -and ($zeile['nr'] -is [double]) -and (-not $zeile.ContainsKey('workaround') -or $zeile['workaround'] -ne '') -and ($zeile['reproduktion'] -match "`n"))
        $def = Get-Ninox4AbweichungenDef
        Check 'Tabellendefinition abweichungen: 21 Felder, Auswahl mit richtigen Umlauten' (($def.f.Count -eq 21) -and (($def.f | Where-Object { $_[0] -eq 'status' })[2].options[0].name -eq ("gepr" + [char]0xFC + "ft")))
    }

    # 6c. Weitergabe-Check fuer den Skillordner (erfundener Mini-Skill)
    Safe 'Weitergabe-Check' {
        $sk = Join-Path $tmp 'miniskill'; New-Item -ItemType Directory -Force -Path "$sk\scripts" | Out-Null
        [IO.File]::WriteAllText("$sk\SKILL.md", "---`nname: mini`ndescription: test`n---`n# Mini`nKontakt it@ninox.com", (New-Object Text.UTF8Encoding($false)))
        [IO.File]::WriteAllText("$sk\scripts\selftest.ps1", '# test', (New-Object Text.UTF8Encoding($false)))
        $ok1 = Test-NinoxSkillFuerWeitergabe -SkillDir $sk
        Check 'Weitergabe-Check: sauberer Skillordner besteht' $ok1.Bestanden (($ok1.Pruefungen | Where-Object { $_.Ergebnis -ne 'ok' } | ForEach-Object { $_.Pruefung }) -join '; ')
        New-Item -ItemType Directory -Force -Path "$sk\arbeit" | Out-Null; [IO.File]::WriteAllText("$sk\daten.csv", 'a;b', (New-Object Text.UTF8Encoding($false)))
        [IO.File]::WriteAllText("$sk\notiz.md", ('privat: max.mustermann' + [string][char]64 + 'firma-xy.de'), (New-Object Text.UTF8Encoding($false)))
        $bad = Test-NinoxSkillFuerWeitergabe -SkillDir $sk
        $fehler = @($bad.Pruefungen | Where-Object { $_.Ergebnis -ne 'ok' })
        Check 'Weitergabe-Check: Datenordner, CSV-Datei und fremde E-Mail-Adresse werden gefunden' ((-not $bad.Bestanden) -and ($fehler.Count -ge 3)) "$($fehler.Count) Fehler"
    }
    # 7. OpenAPI-Lesen (offline mit Minimalspezifikation)
    Safe 'OpenAPI' {
        $mini = '{"openapi":"3.0.0","info":{"title":"Ninox Public API","version":"9.9.9"},"paths":{"/api/v1/workspace/{workspaceId}/modules/{moduleName}/tables/{tableName}/views":{"post":{}}},"components":{"schemas":{"CreateFieldBody":{"properties":{"type":{"enum":["string","html"]},"defaultValue":{}}}}}}'
        $pp = Join-Path $tmp 'mini.json'; [IO.File]::WriteAllText($pp, $mini); $sp = Get-NinoxOpenApi -Path $pp
        $cap = @(Get-NinoxApiCapability -Spec $sp)
        Check 'OpenAPI: Faehigkeiten werden aus einer Spezifikation gelesen (Ansichten ja, Berichte nein)' ((($cap | Where-Object { $_.Bereich -eq 'Ansichten anlegen' }).Belegt -eq $true) -and (($cap | Where-Object { $_.Bereich -eq 'Berichte anlegen' }).Belegt -eq $false))
    }

    # Aufraeumen des Temp-Ordners nur im eigenen Selbsttest-Ordner
    $ok = @($res | Where-Object { $_.Ergebnis -ne 'ok' }).Count -eq 0
    $res | Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Host
    Write-Host ("Selbsttest: {0} von {1} Pruefungen ok. Arbeitsordner: {2}" -f @($res | Where-Object { $_.Ergebnis -eq 'ok' }).Count, $res.Count, $tmp)
    return [pscustomobject]@{ Bestanden = $ok; Pruefungen = $res.Count; Fehler = @($res | Where-Object { $_.Ergebnis -ne 'ok' }).Count; Arbeitsordner = $tmp }
}
