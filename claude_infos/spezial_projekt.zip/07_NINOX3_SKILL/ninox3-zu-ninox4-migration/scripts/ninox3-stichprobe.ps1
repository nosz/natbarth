# Verknuepfungstreue Stichprobe, Anonymisierung und Umwandlung in Ninox-4-Nutzlasten (rein lokal).
# PowerShell 5.1. Setzt voraus:  . .\scripts\ninox3-reader.ps1   (zuerst laden)
# Enthaelt personenbezogene Daten NUR zur Laufzeit im Arbeitsspeicher bzw. in den Ausgabedateien,
# die der Aufrufer in einem lokalen, nicht versionierten Ordner ablegt. Nichts davon in Chat oder Doku ausgeben.

function Get-N3RefFields {
    param($Schema, [string]$TypeId)
    $out = @{}
    foreach ($f in $Schema['types'][$TypeId]['fields'].GetEnumerator()) {
        if ($f.Value['base'] -eq 'ref') { $out[$f.Key] = [string]$f.Value['refTypeId'] }
    }
    return , $out
}

function Select-Ninox3Sample {
    <#
      Waehlt $Count Datensaetze der Haupttabelle und ergaenzt alle Datensaetze, auf die sie verweisen (rekursiv),
      damit keine Verweise ins Leere zeigen. Mit -IncludeChildren kommen zusaetzlich Datensaetze anderer Tabellen
      hinzu, die auf die gewaehlten Hauptdatensaetze verweisen (eine Ebene, samt ihren Verweisen).
      Randfaelle (viele leere Felder, Dateiwert, Sonderzeichen) werden gezielt aufgenommen.
      -Ids ueberschreibt die Auswahl (Liste von Datensatz-Nummern der Haupttabelle).
    #>
    param(
        [Parameter(Mandatory)][string]$DataDb,
        [Parameter(Mandatory)]$Schema,
        [Parameter(Mandatory)][string]$MainTypeId,
        [int]$Count = 20,
        [int]$Seed = 42,
        [string[]]$Ids,
        [switch]$IncludeChildren)

    # Durchlauf 1: Rohzeilen je Datensatz merken ("T|Nr" -> JSON-Text), Parsen erst bei Bedarf.
    $raw = @{}; $idsByType = @{}
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.Length -gt 2 -and $l[0] -eq 'U' -and $l -match '^U([A-Za-z]+)(\d+):') {
                $t = $Matches[1]; $n = $Matches[2]
                $raw["$t|$n"] = $l.Substring($l.IndexOf(':') + 1)
                if (-not $idsByType.ContainsKey($t)) { $idsByType[$t] = New-Object Collections.Generic.List[string] }
                $idsByType[$t].Add($n)
            }
        }
    } finally { $sr.Close() }
    if (-not $idsByType.ContainsKey($MainTypeId)) { throw "Haupttabelle $MainTypeId hat keine Datensaetze in $DataDb" }

    $parsed = @{}
    $parse = { param($k) if (-not $parsed.ContainsKey($k)) { $parsed[$k] = $script:N3Json.DeserializeObject($raw[$k]) }; $parsed[$k] }

    $chosen = New-Object Collections.Generic.List[string]
    if ($Ids) {
        foreach ($i in $Ids) { if ($raw.ContainsKey("$MainTypeId|$i")) { $chosen.Add("$MainTypeId|$i") } else { throw "Datensatz $MainTypeId$i nicht gefunden" } }
    } else {
        $rng = New-Object Random($Seed)
        $dataFields = @($Schema['types'][$MainTypeId]['fields'].GetEnumerator() | Where-Object { -not $_.Value.ContainsKey('fn') -and $_.Value['base'] -ne 'rev' })
        $fileFields = @($dataFields | Where-Object { $_.Value['base'] -eq 'file' } | ForEach-Object { $_.Key })
        $scored = foreach ($n in $idsByType[$MainTypeId]) {
            $o = & $parse "$MainTypeId|$n"
            $empty = @($dataFields | Where-Object { -not $o.ContainsKey($_.Key) -or [string]::IsNullOrEmpty("$($o[$_.Key])") }).Count
            $hasFile = @($fileFields | Where-Object { $o.ContainsKey($_) -and $o[$_] }).Count -gt 0
            $special = $raw["$MainTypeId|$n"] -match '[^\u0000-\u007F]'
            [pscustomobject]@{ Key = "$MainTypeId|$n"; Empty = $empty; HasFile = $hasFile; Special = [bool]$special; Rnd = $rng.Next() }
        }
        $perEdge = [Math]::Max(1, [int][Math]::Ceiling($Count / 6))
        foreach ($edgeSet in @(
                ($scored | Sort-Object Empty -Descending | Select-Object -First $perEdge),
                ($scored | Where-Object HasFile | Sort-Object Rnd | Select-Object -First $perEdge),
                ($scored | Where-Object Special | Sort-Object Rnd | Select-Object -First $perEdge))) {
            foreach ($s in $edgeSet) { if ($chosen.Count -lt $Count -and -not $chosen.Contains($s.Key)) { $chosen.Add($s.Key) } }
        }
        foreach ($s in ($scored | Sort-Object Rnd)) { if ($chosen.Count -ge $Count) { break }; if (-not $chosen.Contains($s.Key)) { $chosen.Add($s.Key) } }
    }

    $mainKeys = @($chosen)
    $set = New-Object Collections.Generic.HashSet[string]
    foreach ($k in $chosen) { [void]$set.Add($k) }

    if ($IncludeChildren) {
        foreach ($t in $Schema['types'].Keys) {
            if ($t -eq $MainTypeId -or -not $idsByType.ContainsKey($t)) { continue }
            $refs = Get-N3RefFields -Schema $Schema -TypeId $t
            $toMain = @($refs.Keys | Where-Object { $refs[$_] -eq $MainTypeId })
            if ($toMain.Count -eq 0) { continue }
            foreach ($n in $idsByType[$t]) {
                $o = & $parse "$t|$n"
                foreach ($fk in $toMain) {
                    if ($o.ContainsKey($fk) -and $set.Contains("$MainTypeId|$($o[$fk])")) { [void]$set.Add("$t|$n"); break }
                }
            }
        }
    }

    # Verweise rekursiv aufloesen (Vorwaerts-Huelle)
    $dangling = New-Object Collections.Generic.List[string]
    $queue = New-Object Collections.Generic.Queue[string]
    foreach ($k in @($set)) { $queue.Enqueue($k) }
    while ($queue.Count -gt 0) {
        $k = $queue.Dequeue(); $t = $k.Split('|')[0]
        $o = & $parse $k
        $refs = Get-N3RefFields -Schema $Schema -TypeId $t
        foreach ($fk in $refs.Keys) {
            if (-not $o.ContainsKey($fk) -or $null -eq $o[$fk] -or "$($o[$fk])" -eq '') { continue }
            $target = "$($refs[$fk])|$($o[$fk])"
            if ($raw.ContainsKey($target)) { if ($set.Add($target)) { $queue.Enqueue($target) } }
            else { $dangling.Add("$k.$fk -> $target") }
        }
    }

    $records = [ordered]@{}
    foreach ($k in ($set | Sort-Object)) {
        $t, $n = $k.Split('|')
        if (-not $records.Contains($t)) { $records[$t] = New-Object Collections.Generic.List[object] }
        $records[$t].Add([ordered]@{ id = [int64]$n; werte = (& $parse $k) })
    }
    return [pscustomobject]@{
        MainTypeId = $MainTypeId; Seed = $Seed; MainRecords = $mainKeys.Count
        Records = $records
        Counts = ($records.Keys | ForEach-Object { "$_=$($records[$_].Count)" }) -join ', '
        DanglingRefs = @($dangling)
    }
}

function Get-Ninox3PiiCandidates {
    # Vorschlag, welche Textfelder personen- oder firmenbezogen sein koennten. Mensch entscheidet (Phase 5).
    param([Parameter(Mandatory)]$Schema)
    $rx = 'name|firma|company|kunde|customer|consignee|adress|address|stra(ss|ss)e|street|plz|zip|postal|ort\b|city|stadt|mail|telefon|phone|tel\b|fax|kontakt|contact|ansprech|notify|iban|bank|vat|ust|steuer|notiz|note|bemerk|comment|remark|sign'
    foreach ($t in $Schema['types'].GetEnumerator()) {
        foreach ($f in $t.Value['fields'].GetEnumerator()) {
            $d = $f.Value
            if ($d.ContainsKey('fn') -or $d['base'] -notin 'string', 'link', 'html', 'file') { continue }
            $cap = [string]$d['caption']
            $reason = @()
            if ($cap -match $rx -and $d['base'] -ne 'file') { $reason += 'Beschriftung' }
            if ($d.ContainsKey('stringMultiline') -and $d['stringMultiline']) { $reason += 'Freitext' }
            if ($d['base'] -eq 'html') { $reason += 'HTML-Text' }
            if ($d['base'] -eq 'file') { $reason += 'Dateiname'; $cap = $cap }
            if ($reason.Count -gt 0) {
                [pscustomobject]@{ Schluessel = "$($t.Key).$($f.Key)"; Tabelle = $t.Value['caption']; Beschriftung = $cap; Grund = ($reason -join '+') }
            }
        }
    }
}

function Invoke-Ninox3Anonymize {
    <#
      Ersetzt Textwerte der angegebenen Felder ("TabellenId.FeldId") durch Platzhalter. Gleicher Originalwert ergibt
      ueberall denselben Ersatzwert (Verknuepfungen und Gruppierungen bleiben erhalten). Die Zuordnung wird NICHT
      gespeichert, die Rueckrechnung ist nicht moeglich. Gibt nur Zaehler zurueck, nie Werte.
    #>
    # Mit -Schema werden Dateifelder erkannt: der Dateiname wird neutral (datei-N.ext, Endung bleibt), weil Dateinamen oft Rechnungs-
    # oder Personenbezug tragen.
    param([Parameter(Mandatory)]$Sample, [Parameter(Mandatory)][string[]]$Fields, $Schema)
    $map = @{}; $seq = @{}; $changed = @{}
    foreach ($tid in $Sample.Records.Keys) {
        $myFields = @($Fields | Where-Object { $_.StartsWith("$tid.") } | ForEach-Object { $_.Substring($tid.Length + 1) })
        if ($myFields.Count -eq 0) { continue }
        foreach ($rec in $Sample.Records[$tid]) {
            foreach ($fk in $myFields) {
                if (-not $rec.werte.ContainsKey($fk)) { continue }
                $v = $rec.werte[$fk]
                if ($v -isnot [string] -or $v -eq '') { continue }
                $mk = "$tid.$fk|$v"
                if (-not $map.ContainsKey($mk)) {
                    $seq["$tid.$fk"] = 1 + [int]$seq["$tid.$fk"]
                    $n = $seq["$tid.$fk"]
                    $isFile = $Schema -and $Schema['types'].ContainsKey($tid) -and $Schema['types'][$tid]['fields'].ContainsKey($fk) -and ($Schema['types'][$tid]['fields'][$fk]['base'] -eq 'file')
                    if ($isFile) { $ext = [IO.Path]::GetExtension($v); $map[$mk] = "datei-$n$ext" }
                    elseif ($v -match '^[^@\s]+@[^@\s]+\.[^@\s]+$') { $map[$mk] = "person$n@example.invalid" }
                    elseif ($v -match '^[\d\s\+\-\(\)\/\.]{6,}$') { $map[$mk] = ('+00 000 {0:0000}' -f $n) }
                    else { $map[$mk] = "Anon-$tid$fk-$n" }
                }
                $rec.werte[$fk] = $map[$mk]
                $changed["$tid.$fk"] = 1 + [int]$changed["$tid.$fk"]
            }
        }
    }
    return [pscustomobject]@{ ErsetzteWertePeFeld = (($changed.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ', '); VerschiedeneWerte = $map.Count }
}

function Get-Ninox3PiiOriginale {
    # Sammelt die Originalwerte der Personendaten-Felder VOR der Anonymisierung. Nur im Arbeitsspeicher halten: nie speichern, nie ausgeben.
    param([Parameter(Mandatory)]$Sample, [Parameter(Mandatory)][string[]]$Fields)
    $set = New-Object Collections.Generic.HashSet[string]
    foreach ($tid in $Sample.Records.Keys) {
        $my = @($Fields | Where-Object { $_.StartsWith("$tid.") } | ForEach-Object { $_.Substring($tid.Length + 1) })
        foreach ($rec in $Sample.Records[$tid]) {
            foreach ($fk in $my) { if ($rec.werte.ContainsKey($fk)) { $v = $rec.werte[$fk]; if ($v -is [string] -and $v.Trim().Length -ge 4) { [void]$set.Add($v.Trim()) } } }
        }
    }
    return , $set
}

function Test-Ninox3AnonymisiertOhneOriginale {
    # Prueft alle Textwerte der anonymisierten Stichprobe: kommt ein Originalwert noch vor (ganz oder als Teil, ab 6 Zeichen)?
    # Gibt nur Feldschluessel und Anzahl zurueck, nie Werte. Treffer in Nicht-Personendaten-Feldern koennen zufaellige Uebereinstimmungen sein.
    param([Parameter(Mandatory)]$Sample, [Parameter(Mandatory)]$Originale)
    $hits = @{}
    $orig = @($Originale | Where-Object { $_.Length -ge 4 })
    foreach ($tid in $Sample.Records.Keys) {
        foreach ($rec in $Sample.Records[$tid]) {
            foreach ($kv in $rec.werte.GetEnumerator()) {
                $v = $kv.Value
                if ($v -isnot [string] -or $v.Length -lt 4) { continue }
                $t = $v.Trim()
                $hit = $Originale.Contains($t)
                if (-not $hit) { foreach ($o in $orig) { if ($o.Length -ge 6 -and $v.IndexOf($o, [StringComparison]::Ordinal) -ge 0) { $hit = $true; break } } }
                if ($hit) { $k = "$tid.$($kv.Key)"; $hits[$k] = 1 + [int]$hits[$k] }
            }
        }
    }
    return ($hits.GetEnumerator() | Sort-Object Name | ForEach-Object { [pscustomobject]@{ Feld = $_.Name; Treffer = $_.Value } })
}

function Test-Ninox3SampleForPii {
    # Restpruefung: zaehlt E-Mail-aehnliche und Telefon-aehnliche Muster je Feld in der (anonymisierten) Stichprobe.
    param([Parameter(Mandatory)]$Sample)
    $hits = @{}
    foreach ($tid in $Sample.Records.Keys) {
        foreach ($rec in $Sample.Records[$tid]) {
            foreach ($kv in $rec.werte.GetEnumerator()) {
                if ($kv.Key.StartsWith('_')) { continue }
                $v = $kv.Value
                if ($v -isnot [string]) { continue }
                if ($v -match '[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}' -and $v -notmatch 'example\.invalid') { $hits["$tid.$($kv.Key) (E-Mail)"] = 1 + [int]$hits["$tid.$($kv.Key) (E-Mail)"] }
                if ($v -match '\(?\d{3}\)?[\s\-\.]\d{3}[\s\-\.]\d{4}') { $hits["$tid.$($kv.Key) (Telefon)"] = 1 + [int]$hits["$tid.$($kv.Key) (Telefon)"] }
            }
        }
    }
    return ($hits.GetEnumerator() | Sort-Object Name | ForEach-Object { [pscustomobject]@{ Feld = $_.Name; Treffer = $_.Value } })
}

function ConvertTo-Ninox4Payload {
    <#
      Wandelt die (anonymisierte) Stichprobe in Ninox-4-Datensatzlisten je Zieltabelle um, mit den Namen aus dem
      freigegebenen Mapping (CSV aus Phase 2). Nur lokal, schreibt nichts nach Ninox.
        - Formel- und Rueckverweisfelder entfallen (in Ninox 4 schreibgeschuetzt)
        - Auswahlfelder: Wert-ID -> Label
        - Datum/Zeit: Millisekunden -> Text im Format $DateFormat / $TimestampFormat (VOR dem Import per Testdatensatz
          pruefen, siehe references/mapping-regeln.md)
        - Verweisfelder werden in "refs" getrennt gehalten (zweiter Durchgang, weil Ninox 4 neue IDs vergibt)
        - Dateifelder: Ninox 4 verlangt ein Datei-Objekt (documentId, fileName, ...), also einen Upload. Der Dateiname steht
          nur in "dateien" und wird nicht geschrieben; die Felder bleiben im Test leer
    #>
    param(
        [Parameter(Mandatory)]$Sample, [Parameter(Mandatory)]$Schema, [Parameter(Mandatory)]$Mapping,
        [string]$DateFormat = 'yyyy-MM-dd', [string]$TimestampFormat = "yyyy-MM-dd'T'HH:mm:ss")
    $byField = @{}
    foreach ($m in $Mapping) { $byField["$($m.TabelleId).$($m.FeldId)"] = $m }
    $out = [ordered]@{}
    foreach ($tid in $Sample.Records.Keys) {
        $fields = $Schema['types'][$tid]['fields']
        $first = $Mapping | Where-Object { $_.TabelleId -eq $tid } | Select-Object -First 1
        $target = $first.Ninox4Tabelle
        $list = New-Object Collections.Generic.List[object]
        foreach ($rec in $Sample.Records[$tid]) {
            $vals = [ordered]@{}; $refs = [ordered]@{}; $files = [ordered]@{}
            foreach ($f in $fields.GetEnumerator()) {
                $fd = $f.Value
                if ($fd.ContainsKey('fn') -or $fd['base'] -eq 'rev') { continue }
                if (-not $rec.werte.ContainsKey($f.Key)) { continue }
                $v = $rec.werte[$f.Key]
                if ($null -eq $v -or "$v" -eq '') { continue }
                $m = $byField["$tid.$($f.Key)"]
                if (-not $m -or -not $m.Ninox4Feld) { continue }
                switch ($fd['base']) {
                    'choice' {
                        $vd = $fd['values']; $key = "$v"
                        if ($vd.ContainsKey($key)) { $vals[$m.Ninox4Feld] = $vd[$key]['caption'] }
                        else { $vals[$m.Ninox4Feld] = $null }
                    }
                    'date'      { $vals[$m.Ninox4Feld] = [DateTimeOffset]::FromUnixTimeMilliseconds([int64]$v).UtcDateTime.ToString($DateFormat, [Globalization.CultureInfo]::InvariantCulture) }
                    'timestamp' { $vals[$m.Ninox4Feld] = [DateTimeOffset]::FromUnixTimeMilliseconds([int64]$v).UtcDateTime.ToString($TimestampFormat, [Globalization.CultureInfo]::InvariantCulture) }
                    'ref'       { $refs[$m.Ninox4Feld] = [ordered]@{ ziel = [string]$fd['refTypeId']; id = [int64]$v } }
                    'multi'     { $vals[$m.Ninox4Feld] = $v }
                    'file'      { $files[$m.Ninox4Feld] = "$v" }   # Ninox 4 verlangt ein Datei-Objekt (Upload); Dateiname nur festhalten
                    default     { $vals[$m.Ninox4Feld] = $v }
                }
            }
            $list.Add([ordered]@{ altId = $rec.id; werte = $vals; refs = $refs; dateien = $files })
        }
        $out[$target] = $list
    }
    return $out
}

function Save-Ninox3Json {
    param([Parameter(Mandatory)]$Object, [Parameter(Mandatory)][string]$Path)
    [IO.File]::WriteAllText($Path, ($Object | ConvertTo-Json -Depth 10 -Compress), (New-Object Text.UTF8Encoding($false)))
}
