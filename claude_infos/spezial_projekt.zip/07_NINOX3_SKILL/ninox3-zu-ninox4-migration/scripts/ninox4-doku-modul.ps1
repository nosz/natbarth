# Dokumentationsmodul in Ninox 4 anlegen und aus den lokalen Ergebnisdateien fuellen (Phase 3, references/dokumodul.md).
# PowerShell 5.1. Schreibt nur in das neue Dokumentationsmodul, nie in das Ziel- oder ein anderes Modul.
# Nur Struktur, Zaehler, IDs, Status und Beschriftungen; keine Datensatzinhalte, keine Formeltexte.
# Nutzung:
#   . .\scripts\ninox4-doku-modul.ps1
#   Invoke-Ninox4DokuModul -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1

. (Join-Path $PSScriptRoot 'ninox-support.ps1')
. (Join-Path $PSScriptRoot 'ninox-pruefungen.ps1')
. (Join-Path $PSScriptRoot 'ninox-abweichungen.ps1')

function Get-Ninox4AbweichungenDef {
    # Tabelle "abweichungen": gepruefte Abweichungen zwischen Dokumentation und Verhalten sowie mutmassliche API-Fehler (nur Status geprueft, gemeldet, behoben).
    $ae = [string][char]0xE4; $ue = [string][char]0xFC
    # Texte mit Umlauten vorab bilden: in einem Array-Literal bindet das Komma staerker als das Plus.
    $oStoerend = "st" + [string][char]0xF6 + "rend"; $oGeprueft = "gepr" + $ue + "ft"; $oBereichUI = "Oberfl" + $ae + "che"; $lTatsaechlich = "Tats" + $ae + "chlich"
    $opt = { param($l) @{ type = 'choice'; options = @($l | ForEach-Object { @{ name = $_ } }) } }
    return @{ n = 'abweichungen'; l = "Abweichungen und API-Fehler"; f = @(
        @('nr', 'Nr', 'number'), @('titel', 'Titel', 'string'),
        @('bereich', 'Bereich', (& $opt @('API', 'Formel', $oBereichUI, 'Dokumentation'))),
        @('endpunkt', 'Betroffener Aufruf', 'string'), @('erwartet', 'Erwartet laut Dokumentation', 'multiline'), @('erwartet_quelle', 'Quelle (Link)', 'string'),
        @('tatsaechlich', $lTatsaechlich, 'multiline'),
        @('schwere', 'Schweregrad', (& $opt @('blockierend', $oStoerend, 'kosmetisch'))),
        @('status', 'Status', (& $opt @($oGeprueft, 'gemeldet', 'behoben'))),
        @('reproduktion', 'Reproduktion', 'multiline'), @('minimalbeispiel', 'Minimalbeispiel (Request)', 'multiline'), @('gegenprobe', 'Gegenprobe', 'multiline'),
        @('workaround', 'Workaround', 'multiline'), @('beobachtet', 'Beobachtet', 'string'), @('gemeldet_am', 'Gemeldet am', 'string'), @('api_version', 'API-Version', 'string'),
        @('workspace_id', 'Workspace-ID', 'string'), @('modul', 'Modul', 'string'), @('tabelle', 'Tabelle', 'string'), @('feld', 'Feld', 'string'), @('fundstellen', 'Weitere Beispiele', 'string')) }
}

function Convert-Ninox4AbweichungZeile {
    param($r)
    $ue = [string][char]0xFC; $ae = [string][char]0xE4
    $bereich = if ($r.Bereich -eq 'Oberflaeche') { "Oberfl${ae}che" } else { $r.Bereich }
    $schwere = if ($r.Schwere -eq 'stoerend') { "st" + [char]0xF6 + "rend" } else { $r.Schwere }
    $status = if ($r.Status -eq 'geprueft') { "gepr${ue}ft" } else { $r.Status }
    $o = @{ nr = [double]$r.Nr; titel = $r.Titel; bereich = $bereich; endpunkt = $r.Endpunkt; erwartet = $r.Erwartet; erwartet_quelle = $r.ErwartetQuelle; tatsaechlich = $r.Tatsaechlich
        schwere = $schwere; status = $status; reproduktion = ($r.Reproduktion -replace ' \| ', "`n"); minimalbeispiel = $r.MinimalRequest; gegenprobe = $r.Gegenprobe; workaround = $r.Workaround
        beobachtet = $r.Beobachtet; gemeldet_am = $r.GemeldetAm; api_version = $r.ApiVersion
        workspace_id = $r.Workspace; modul = $r.Modul; tabelle = $r.Tabelle; feld = $r.Feld; fundstellen = $r.Fundstellen }
    $out = @{}; foreach ($k in $o.Keys) { if ($null -ne $o[$k] -and "$($o[$k])" -ne '') { $out[$k] = $o[$k] } }
    return $out
}

function Invoke-Ninox4AbweichungenSync {
    # Legt die Tabelle "abweichungen" im bestehenden Dokumentationsmodul an (falls sie fehlt) und fuegt gepruefte Abweichungen ein
    # (Status geprueft, gemeldet, behoben; "Verdacht" bleibt lokal). Schreibt nur ins Dokumentationsmodul. Bereits vorhandene Nummern werden nicht doppelt angelegt.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$HelpersPath, [string]$Freigabe = 'Ja (Chat, Phase 3)', [int]$PauseMs = 400)
    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.migration.docModuleName
    Assert-NinoxSchreibfreigabe -ProjectDir $ProjectDir -Phase 3 -Modul $mod
    Set-Location $ProjectDir; $env:NINOX_API_KEY = Get-NinoxKeyWert; . $HelpersPath
    Clear-NinoxStoerungen; Set-NinoxSchreibtempo -BasisMs $PauseMs
    $rows = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir | Where-Object { $_.Status -in 'geprueft', 'gemeldet', 'behoben' })
    $def = Get-Ninox4AbweichungenDef
    $tabs = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$mod/tables"))['data'] | ForEach-Object { $_['name'] })
    $angelegt = $false
    if ($tabs -notcontains 'abweichungen') {
        $null = Invoke-Ninox -Method Post -Path "/modules/$mod/tables" -Body @{ name = $def.n; labels = @{ '' = $def.l }; hasGlobalSearch = $true; createRoles = @('admin', 'editor'); deleteRoles = @('admin'); readRoles = @('admin', 'editor'); writeRoles = @('admin', 'editor') }
        foreach ($f in $def.f) {
            Wait-NinoxSchreibpause
            $d = $f[2]; $b = @{ name = $f[0]; labels = @{ '' = $f[1] } }
            if ($d -is [string]) { if ($d -eq 'multiline') { $b['type'] = 'string'; $b['variant'] = 'multiline-text' } else { $b['type'] = $d } } else { $b['type'] = $d.type; $b['options'] = $d.options }
            $null = Invoke-Ninox -Method Post -Path "/modules/$mod/tables/abweichungen/fields" -Body $b
        }
        $angelegt = $true
        Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 3 -Aktion 'Tabelle anlegen (Abweichungen)' -Ziel "$mod.abweichungen" -Anzahl $def.f.Count -Ergebnis 'OK' -Freigabe $Freigabe
    }
    # fehlende Spalten im bestehenden Modul ergaenzen (z. B. nach einer Erweiterung der Tabellendefinition)
    $haveF = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$mod/tables/abweichungen/fields?limit=200"))['data'] | ForEach-Object { $_['name'] })
    $neuF = 0
    foreach ($f in $def.f) {
        if ($haveF -contains $f[0]) { continue }
        Wait-NinoxSchreibpause
        $dd = $f[2]; $b = @{ name = $f[0]; labels = @{ '' = $f[1] } }
        if ($dd -is [string]) { if ($dd -eq 'multiline') { $b['type'] = 'string'; $b['variant'] = 'multiline-text' } else { $b['type'] = $dd } } else { $b['type'] = $dd.type; $b['options'] = $dd.options }
        $null = Invoke-Ninox -Method Post -Path "/modules/$mod/tables/abweichungen/fields" -Body $b; $neuF++
    }
    $have = @{}; $off = 0
    while ($true) { $r = $ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$mod/tables/abweichungen/records?limit=100&offset=$off")); foreach ($x in $r['data']) { $have[[string][int]$x['values']['nr']] = $x }; if (-not $r['page_info']['has_more']) { break }; $off += 100 }
    $neu = 0; $akt = 0
    foreach ($r in $rows) {
        $z = Convert-Ninox4AbweichungZeile $r
        if ($have.ContainsKey([string][int]$r.Nr)) {
            $id = [int]$have[[string][int]$r.Nr]['id']; $cur = $have[[string][int]$r.Nr]['values']
            # vorhandene Zeile mit dem aktuellen lokalen Stand abgleichen (alle Felder ausser der Nummer)
            $upd = @{ id = $id }; foreach ($k in $z.Keys) { if ($k -ne 'nr') { $upd[$k] = $z[$k] } }
            Wait-NinoxSchreibpause; $null = Invoke-Ninox -Method Patch -Path "/modules/$mod/tables/abweichungen/records" -Body @{ records = @($upd) }; $akt++
        } else { Wait-NinoxSchreibpause; $null = Invoke-Ninox -Method Post -Path "/modules/$mod/tables/abweichungen/records" -Body @{ records = @($z) }; $neu++ }
    }
    if ($neu + $akt -gt 0) { Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 3 -Aktion 'Abweichungen abgleichen' -Ziel "$mod.abweichungen" -Anzahl ($neu + $akt) -Ergebnis "$neu neu, $akt aktualisiert" -Freigabe $Freigabe }
    return [pscustomobject]@{ Modul = $mod; TabelleNeuAngelegt = $angelegt; SpaltenErgaenzt = $neuF; NeuEingefuegt = $neu; Aktualisiert = $akt; NurLokalVerdacht = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir | Where-Object { $_.Status -eq 'Verdacht' }).Count }
}

function Invoke-Ninox4DokuModul {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$HelpersPath, [string]$Freigabe = 'Ja (Chat, Phase 3)', [int]$PauseMs = 300, [switch]$NurFuellen)
    $ErrorActionPreference = 'Stop'
    Clear-NinoxStoerungen; Set-NinoxSchreibtempo -BasisMs $PauseMs
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $e = Join-Path $ProjectDir 'ergebnis'
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.migration.docModuleName
    if ($mod -notmatch '^[a-z0-9_]+$') { throw "Doku-Modulname '$mod' ungueltig" }
    if ($mod -eq $cfg.moduleName) { throw 'Doku-Modul und Zielmodul muessen verschieden sein' }
    Assert-NinoxSchreibfreigabe -ProjectDir $ProjectDir -Phase 3 -Modul $mod
    Set-Location $ProjectDir
    $env:NINOX_API_KEY = Get-NinoxKeyWert
    . $HelpersPath
    function Call($method, $path, $body) {
        for ($i = 1; $i -le 6; $i++) {
            try {
                if ($method -ne 'Get') { Wait-NinoxSchreibpause } else { Start-Sleep -Milliseconds 100 }
                $res = Invoke-Ninox -Method $method -Path $path -Body $body
                if ($method -ne 'Get') { Register-NinoxErfolg }
                return $res
            }
            catch {
                $msg = $_.Exception.Message
                if (Test-NinoxTransientError $msg) {
                    Register-NinoxTransient
                    Add-NinoxStoerung -Aktion 'Dokumentationsmodul anlegen und fuellen (Phase 3)' -Methode $method -Pfad $path -Meldung $msg -Feld $(if ($body -is [hashtable] -and $body.ContainsKey('name')) { [string]$body['name'] } else { '' })
                    if ($i -lt 6) {
                        Write-Warning 'Ninox antwortet gerade nicht oder ist ausgelastet. Das Skript wartet und versucht es erneut. Bitte nicht abbrechen.'
                        Start-Sleep -Seconds (3 * $i); continue
                    }
                    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Dokumentationsmodul anlegen und fuellen (Phase 3 einer Migration)' -Stand 'Vorgang abgebrochen, mit -NurFuellen fortsetzen' -AktionEn 'creating and filling the documentation module (migration phase 3)' -StandEn 'stopped, to be resumed with -NurFuellen' -BeispielBody '{"records":[{"<field>":"<value>"}]}'
                    Show-NinoxSupportHinweis $sup
                }
                throw
            }
        }
    }
    $exist = @($ser.DeserializeObject((Call 'Get' '/modules' $null))['data'] | ForEach-Object { $_['name'] })
    if (($exist -contains $mod) -and -not $NurFuellen) { throw "Das Modul '$mod' existiert schon. Es wird nicht veraendert (mit -NurFuellen nur Datensaetze einfuegen, wenn die Tabellen leer sind)." }
    if (($exist -notcontains $mod) -and $NurFuellen) { throw "Das Modul '$mod' existiert nicht; -NurFuellen setzt es voraus." }

    $UE = [string][char]0xDC; $ue = [string][char]0xFC; $ae = [string][char]0xE4
    $S = 'string'; $N = 'number'; $M = 'multiline'
    # Texte mit Umlauten vorab bilden: in einem Array-Literal bindet das Komma staerker als das Plus.
    $lPruefung = "Pr${ue}fung"; $oGeprueft = "gepr${ue}ft"; $oLuecke = "L${ue}cke"; $oSpaeter = "sp${ae}ter"
    function Ch($labels) { @{ type = 'choice'; options = @($labels | ForEach-Object { @{ name = $_ } }) } }
    # Tabellen: Name, Label, Felder (Name, Label, Typ-Definition)
    $defs = @(
        @{ n = 'uebersicht'; l = "${UE}bersicht"; f = @(
            @('projekt', 'Projekt', $S), @('quelle_ohne_daten', 'Quelle ohne Daten', $S), @('quelle_mit_daten', 'Quelle mit Daten', $S), @('sicherung_stand', 'Sicherung Stand', $S),
            @('ziel_workspace', 'Ziel Workspace', $S), @('ziel_modul', 'Ziel Modul', $S), @('doku_modul', 'Doku Modul', $S), @('phase', 'Phase', $N),
            @('status', 'Status', (Ch @('In Arbeit', 'Wartet auf Freigabe', 'Abgeschlossen'))), @('aktualisiert', 'Aktualisiert', $S)) },
        @{ n = 'tabellen_inventar'; l = 'Tabellen Inventar'; f = @(
            @('n3_id', 'Ninox 3 ID', $S), @('n3_name', 'Ninox 3 Name', $S), @('felder', 'Felder', $N), @('formelfelder', 'Formelfelder', $N), @('datensaetze', "Datens${ae}tze", $N), @('n4_tabelle', 'Ninox 4 Tabelle', $S),
            @('status', 'Status', (Ch @('offen', 'gebaut', $oGeprueft, $oLuecke)))) },
        @{ n = 'felder_mapping'; l = 'Felder Mapping'; f = @(
            @('n3_tabelle_id', 'Ninox 3 Tabelle ID', $S), @('n3_feld_id', 'Ninox 3 Feld ID', $S), @('n3_beschriftung', 'Ninox 3 Beschriftung', $S), @('n3_basis', 'Ninox 3 Typ', $S),
            @('n4_tabelle', 'Ninox 4 Tabelle', $S), @('n4_feld', 'Ninox 4 Feld', $S), @('n4_label', 'Ninox 4 Label', $S), @('n4_typ', 'Ninox 4 Typ', $S), @('n4_variante', 'Ninox 4 Variante', $S),
            @('status', 'Status', (Ch @('automatisch', 'formel', 'manuell', 'ungeklaert'))), @('freigabe', 'Freigabe', (Ch @('offen', 'freigegeben'))), @('namenshinweis', 'Namenshinweis', $M), @('hinweis', 'Hinweis', $M)) },
        @{ n = 'luecken'; l = "L${ue}cken"; f = @(
            @('nr', 'Nr', $N), @('kategorie', 'Kategorie', $S), @('objekt', 'Objekt', $S), @('beschreibung', 'Beschreibung', $M), @('auswirkung', 'Auswirkung', $M),
            @('aufwand', 'Aufwand', (Ch @('klein', 'mittel', 'gross'))), @('status', 'Status', (Ch @('offen', 'geplant', 'zurueckgestellt', 'in Arbeit', 'erledigt', 'akzeptiert', 'kein Befund'))),
            @('verantwortlich', 'Verantwortlich', $S), @('beleg', 'Beleg', $M)) },
        @{ n = 'schreibprotokoll'; l = 'Schreibprotokoll'; f = @(
            @('zeit', 'Zeit', $S), @('phase', 'Phase', $N), @('aktion', 'Aktion', $S), @('ziel', 'Ziel', $S), @('anzahl', 'Anzahl', $N), @('ergebnis', 'Ergebnis', $S), @('freigabe', 'Freigabe', $S)) },
        @{ n = 'abnahme'; l = 'Abnahme'; f = @(
            @('pruefung', $lPruefung, (Ch @('A Struktur', 'B Daten', 'C Formeln', 'v2'))), @('objekt', 'Objekt', $S), @('soll', 'Soll', $S), @('ist', 'Ist', $S),
            @('ergebnis', 'Ergebnis', (Ch @('bestanden', 'mit Befund', 'nicht bestanden', 'nicht belegt'))), @('ursache', 'Ursache', $M), @('beleg', 'Beleg', $S)) },
        @{ n = 'optimierung'; l = 'Optimierung'; f = @(
            @('nr', 'Nr', $N), @('art', 'Art', $S), @('objekt', 'Objekt', $S), @('beobachtung', 'Beobachtung', $M), @('beleg', 'Beleg', $S), @('nutzen', 'Nutzen', $S),
            @('aufwand', 'Aufwand', (Ch @('klein', 'mittel', 'gross'))), @('risiko', 'Risiko', $S), @('entscheidung', 'Entscheidung', (Ch @('offen', 'umsetzen', $oSpaeter, 'verworfen')))) },
        @{ n = 'entscheidungen'; l = 'Entscheidungen'; f = @(
            @('datum', 'Datum', $S), @('phase', 'Phase', $N), @('thema', 'Thema', $S), @('entscheidung', 'Entscheidung', $M)) }
    )

    if (-not $NurFuellen) { $defs = @($defs) + @(Get-Ninox4AbweichungenDef) }
    if (-not $NurFuellen) { $null = Call 'Post' '/modules' @{ name = $mod; labels = @{ '' = "Dokumentation Migrationstest" }; openRoles = @('admin', 'editor') }; Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 3 -Aktion 'Modul anlegen (Dokumentation)' -Ziel $mod -Anzahl 1 -Ergebnis 'OK' -Freigabe $Freigabe }
    foreach ($d in $defs) {
        if ($NurFuellen) { break }
        $null = Call 'Post' "/modules/$mod/tables" @{ name = $d.n; labels = @{ '' = $d.l }; hasGlobalSearch = $true; createRoles = @('admin', 'editor'); deleteRoles = @('admin'); readRoles = @('admin', 'editor'); writeRoles = @('admin', 'editor') }
        foreach ($f in $d.f) {
            $def = $f[2]
            $body = @{ name = $f[0]; labels = @{ '' = $f[1] } }
            if ($def -is [string]) { if ($def -eq 'multiline') { $body['type'] = 'string'; $body['variant'] = 'multiline-text' } else { $body['type'] = $def } }
            else { $body['type'] = $def.type; $body['options'] = $def.options }
            $null = Call 'Post' "/modules/$mod/tables/$($d.n)/fields" $body
        }
    }

    function Add-Records($table, $rows) {
        $n = 0; $batch = New-Object Collections.Generic.List[object]
        foreach ($r in $rows) {
            $batch.Add($r)
            if ($batch.Count -ge 80) { $null = Call 'Post' "/modules/$mod/tables/$table/records" @{ records = $batch.ToArray() }; $n += $batch.Count; $batch.Clear() }
        }
        if ($batch.Count -gt 0) { $null = Call 'Post' "/modules/$mod/tables/$table/records" @{ records = $batch.ToArray() }; $n += $batch.Count }
        return $n
    }
    function Num($v) { if ("$v" -match '^-?\d+$') { return [double]$v } else { return $null } }
    function Drop-Null($h) { $o = @{}; foreach ($k in $h.Keys) { if ($null -ne $h[$k] -and "$($h[$k])" -ne '') { $o[$k] = $h[$k] } }; return $o }
    if ($NurFuellen) {
        foreach ($d in $defs) { $c = @($ser.DeserializeObject((Call 'Get' "/modules/$mod/tables/$($d.n)/records?limit=1" $null))['data']).Count; if ($c -gt 0) { throw "Tabelle $($d.n) ist nicht leer; -NurFuellen wuerde Duplikate erzeugen." } }
    }
    $sum = Get-Content (Join-Path $e 'inventar_zusammenfassung.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $counts = [ordered]@{}

    $counts['uebersicht'] = Add-Records 'uebersicht' @(Drop-Null @{ projekt = $sum.Datenbank; quelle_ohne_daten = (Split-Path $cfg.migration.sourceFile -Leaf); quelle_mit_daten = (Split-Path $cfg.migration.sourceFileWithData -Leaf); sicherung_stand = $sum.Sicherung;
        ziel_workspace = $cfg.workspaceId; ziel_modul = $cfg.moduleName; doku_modul = $mod; phase = 3; status = 'In Arbeit'; aktualisiert = (Get-Date -Format 'yyyy-MM-dd HH:mm') })
    $tab = @(Import-Csv (Join-Path $e '01_tabellen.csv') -Delimiter ';' -Encoding UTF8)
    $map = @(Import-Csv (Join-Path $e '06_mapping_vorschlag.csv') -Delimiter ';' -Encoding UTF8)
    $nm = @{}; foreach ($m in $map) { $nm[$m.TabelleId] = $m.Ninox4Tabelle }
    $counts['tabellen_inventar'] = Add-Records 'tabellen_inventar' @($tab | ForEach-Object { Drop-Null @{ n3_id = $_.TabelleId; n3_name = $_.Tabelle; felder = (Num $_.Felder); formelfelder = (Num $_.Formelfelder); datensaetze = (Num $_.Datensaetze); n4_tabelle = $nm[$_.TabelleId]; status = 'gebaut' } })
    $counts['felder_mapping'] = Add-Records 'felder_mapping' @($map | ForEach-Object { Drop-Null @{ n3_tabelle_id = $_.TabelleId; n3_feld_id = $_.FeldId; n3_beschriftung = $_.Beschriftung; n3_basis = $_.Basis3; n4_tabelle = $_.Ninox4Tabelle; n4_feld = $_.Ninox4Feld; n4_label = $_.Ninox4Label; n4_typ = $_.Ninox4Typ; n4_variante = $_.Ninox4Variante; status = $_.Status; freigabe = $_.Freigabe; namenshinweis = $_.Namenshinweis; hinweis = $_.Hinweis } })
    $gap = @(Import-Csv (Join-Path $e '09_luecken.csv') -Delimiter ';' -Encoding UTF8)
    $counts['luecken'] = Add-Records 'luecken' @($gap | ForEach-Object { Drop-Null @{ nr = (Num $_.Nr); kategorie = $_.Kategorie; objekt = $_.Objekt; beschreibung = $_.Beschreibung; auswirkung = $_.Auswirkung; aufwand = $_.Aufwand; status = $_.Status; verantwortlich = $_.Verantwortlich; beleg = $_.Beleg } })
    $log = Join-Path $e 'schreibprotokoll.csv'
    if (Test-Path $log) { $counts['schreibprotokoll'] = Add-Records 'schreibprotokoll' @(Import-Csv $log -Delimiter ';' -Encoding UTF8 | ForEach-Object { Drop-Null @{ zeit = $_.Zeit; phase = (Num $_.Phase); aktion = $_.Aktion; ziel = $_.Ziel; anzahl = (Num $_.Anzahl); ergebnis = $_.Ergebnis; freigabe = $_.Freigabe } }) }
    $dec = Join-Path $e 'entscheidungen.csv'
    if (Test-Path $dec) { $counts['entscheidungen'] = Add-Records 'entscheidungen' @(Import-Csv $dec -Delimiter ';' -Encoding UTF8 | ForEach-Object { Drop-Null @{ datum = $_.Datum; phase = (Num $_.Phase); thema = $_.Thema; entscheidung = $_.Entscheidung } }) }

    if (-not $NurFuellen) {
        $abw = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir | Where-Object { $_.Status -in 'geprueft', 'gemeldet', 'behoben' })
        $counts['abweichungen'] = Add-Records 'abweichungen' @($abw | ForEach-Object { Convert-Ninox4AbweichungZeile $_ })
    }
    foreach ($k in $counts.Keys) { Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 3 -Aktion 'Dokumentation fuellen' -Ziel "$mod.$k" -Anzahl $counts[$k] -Ergebnis 'OK' -Freigabe $Freigabe }
    Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 3 -Schritt 'Dokumentationsmodul gefuellt' -Aktuell $defs.Count -Gesamt $defs.Count -Status 'fertig'
    # Pruefung: Zeilenzahlen zurueckgelesen
    $chk = [ordered]@{}
    foreach ($d in $defs) {
        $c = 0; $off = 0
        while ($true) { $r = $ser.DeserializeObject((Call 'Get' "/modules/$mod/tables/$($d.n)/records?limit=100&offset=$off" $null)); $c += @($r['data']).Count; if (-not $r['page_info']['has_more']) { break }; $off += 100 }
        $chk[$d.n] = $c
    }
    $res = [ordered]@{ Modul = $mod; Tabellen = $defs.Count }
    foreach ($k in $chk.Keys) { $exp = if ($counts.Contains($k)) { $counts[$k] } else { 0 }; $res[$k] = "$($chk[$k]) von $exp" }
    return [pscustomobject]$res
}
