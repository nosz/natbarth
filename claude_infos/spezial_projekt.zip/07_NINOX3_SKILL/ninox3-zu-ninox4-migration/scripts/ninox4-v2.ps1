# Phase 7: verbesserte Version "<Modul>_v2" vorbereiten. Das Zielmodul der 1:1-Version wird nie veraendert.
# Idee: ein eigener Unterordner "v2" im Projekt mit eigener Konfiguration, eigenem Mapping und eigener Formelanalyse. Die vorhandenen Bauskripte
# (Phase 3 Schema, Phase 4 Formeln, Phase 5 Import, Phase 6 Abnahme) laufen dann unveraendert mit -ProjectDir <projekt>\v2.
# Umgesetzt sind die Vorschlaege Nr. 1 (Consignee statt 29-faches if: Verweis consignee2, Feld notify_party) und Nr. 2 (Tabelle Standorte fuer
# Pick Up Location und Delivery to Location). Dieses Skript schreibt NICHT nach Ninox, nur lokale Dateien.
# Nutzung: . .\scripts\ninox4-v2.ps1; New-Ninox4V2Projekt -ProjectDir <projekt>
#          Convert-Ninox4V2Payload (Hook fuer Invoke-Ninox4SampleImport -PayloadHook)

function Convert-N4V2Csv {
    param([string]$Path, [scriptblock]$Edit)
    $rows = @(Import-Csv $Path -Delimiter ';' -Encoding UTF8)
    $rows = & $Edit $rows
    @($rows) | Export-Csv $Path -NoTypeInformation -Delimiter ';' -Encoding UTF8
}

function New-Ninox4V2Projekt {
    param([Parameter(Mandatory)][string]$ProjectDir, [string]$Suffix = '_v2')
    $ErrorActionPreference = 'Stop'
    $v2 = Join-Path $ProjectDir 'v2'
    foreach ($d in 'ergebnis', 'arbeit\inventar', 'arbeit\ohne', 'arbeit\mit') { New-Item -ItemType Directory -Force -Path (Join-Path $v2 $d) | Out-Null }
    # Konfiguration: nur der Modulname aendert sich
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $cfg.moduleName = "$($cfg.moduleName)$Suffix"
    [IO.File]::WriteAllText((Join-Path $v2 'ninox.config.json'), ($cfg | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    # Quelldateien (Daten bleiben lokal)
    foreach ($f in 'arbeit\ohne\data.db', 'arbeit\mit\data.db', 'arbeit\inventar\02_felder_voll.csv', 'arbeit\inventar\08_formel_analyse_voll.csv', 'ergebnis\06_mapping_vorschlag.csv', 'ergebnis\inventar_zusammenfassung.json', 'ergebnis\09_luecken.csv') {
        Copy-Item (Join-Path $ProjectDir $f) (Join-Path $v2 $f) -Force
    }
    # Die Modulbeschriftung kommt aus der Zusammenfassung; mit Suffix, damit 1:1-Version und v2 in Ninox unterscheidbar sind
    $zf = Join-Path $v2 'ergebnis\inventar_zusammenfassung.json'
    if (Test-Path $zf) { $z = Get-Content $zf -Raw -Encoding UTF8 | ConvertFrom-Json; $z.Datenbank = ('{0} v2' -f $z.Datenbank); [IO.File]::WriteAllText($zf, ($z | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false))) }
    $st = Get-Content (Join-Path $ProjectDir 'ergebnis\status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $st.freigaben = @(); $st.phase = 2
    [IO.File]::WriteAllText((Join-Path $v2 'ergebnis\status.json'), ($st | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))

    # --- Mapping v2
    $mp = Join-Path $v2 'ergebnis\06_mapping_vorschlag.csv'
    Convert-N4V2Csv $mp {
        param($rows)
        $first = $rows[0]
        $mk = { param($tid, $tab, $fid, $lab, $basis, $n4t, $n4tl, $n4f, $n4l, $typ, $var, $hint)
            $r = [ordered]@{}; foreach ($p in $first.PSObject.Properties.Name) { $r[$p] = '' }
            $r['TabelleId'] = $tid; $r['Tabelle'] = $tab; $r['FeldId'] = $fid; $r['Beschriftung'] = $lab; $r['Basis3'] = $basis; $r['Ninox4Tabelle'] = $n4t; $r['Ninox4TabelleLabel'] = $n4tl
            $r['Ninox4Feld'] = $n4f; $r['Ninox4Label'] = $n4l; $r['Ninox4Typ'] = $typ; $r['Ninox4Variante'] = $var; $r['Pflicht'] = 'False'; $r['Status'] = 'automatisch'; $r['Freigabe'] = 'freigegeben'; $r['Hinweis'] = $hint
            [pscustomobject]$r }
        foreach ($r in $rows) {
            if ($r.TabelleId -eq 'D' -and $r.FeldId -eq 'B3') { $r.Ninox4Feld = ''; $r.Ninox4Typ = ''; $r.Ninox4Variante = ''; $r.Status = 'entfaellt (v2 Nr. 1)'; $r.Hinweis = 'v2 Nr. 1: Auswahl entfaellt, Quelle ist das Verweisfeld consignee2' }
            if ($r.TabelleId -eq 'D' -and $r.FeldId -in 'R2', 'Y2') { $r.Basis3 = 'ref'; $r.Ninox4Typ = 'reference'; $r.Ninox4Variante = ''; $r.Hinweis = 'v2 Nr. 2: Verweis auf Tabelle Standorte statt Auswahl' }
        }
        $neu = @(
            (& $mk 'ZS' 'Standorte' 'ZA' 'Name' 'string' 'standorte' 'Standorte' 'name' 'Name' 'string' 'text' 'v2 Nr. 2: neue Tabelle')
            (& $mk 'ZS' 'Standorte' 'ZB' 'Adresse' 'string' 'standorte' 'Standorte' 'adresse' 'Adresse' 'string' 'multiline-text' 'v2 Nr. 2: neue Tabelle')
            (& $mk 'ZS' 'Standorte' 'ZR1' 'Lieferungen Abholung' 'rev' 'standorte' 'Standorte' 'shipping_pick_up' 'Lieferungen Abholung' 'reverse' '' 'v2 Nr. 2: Rueckverweis')
            (& $mk 'ZS' 'Standorte' 'ZR2' 'Lieferungen Lieferort' 'rev' 'standorte' 'Standorte' 'shipping_delivery' 'Lieferungen Lieferort' 'reverse' '' 'v2 Nr. 2: Rueckverweis')
            (& $mk 'P' 'Consignee' 'ZN' 'Notify Party' 'string' 'consignee' 'Consignee' 'notify_party' 'Notify Party' 'string' 'multiline-text' 'v2 Nr. 1: neues Feld, ersetzt die Auswahl-Kette der Formel Consignee Notify Party; in der Testversion leer'))
        # Tabellen- und Beschriftungswerte der Consignee-Tabelle aus vorhandenen Zeilen uebernehmen
        $c = $rows | Where-Object { $_.TabelleId -eq 'P' } | Select-Object -First 1
        $neu[4].Ninox4Tabelle = $c.Ninox4Tabelle; $neu[4].Ninox4TabelleLabel = $c.Ninox4TabelleLabel; $neu[4].Tabelle = $c.Tabelle
        return @($rows) + $neu
    }
    # --- Felder v2 (Rohdaten fuer Verweisziele und Reihenfolge)
    $rp = Join-Path $v2 'arbeit\inventar\02_felder_voll.csv'
    Convert-N4V2Csv $rp {
        param($rows)
        $first = $rows[0]
        $mk = { param($tid, $tab, $fid, $lab, $basis, $mehr, $refT, $refF)
            $r = [ordered]@{}; foreach ($p in $first.PSObject.Properties.Name) { $r[$p] = '' }
            $r['TabelleId'] = $tid; $r['Tabelle'] = $tab; $r['FeldId'] = $fid; $r['Beschriftung'] = $lab; $r['Basis'] = $basis; $r['Pflicht'] = 'False'; $r['Mehrzeilig'] = $mehr; $r['IstFormel'] = 'False'
            $r['RefTabelleId'] = $refT; $r['RefFeldId'] = $refF
            [pscustomobject]$r }
        foreach ($r in $rows) {
            if ($r.TabelleId -eq 'D' -and $r.FeldId -in 'R2', 'Y2') { $r.Basis = 'ref'; $r.RefTabelleId = 'ZS'; $r.RefFeldId = ''; $r.AuswahlAnzahl = ''; $r.AuswahlWerte = ''; $r.Standardwert = ''; $r.StandardwertSchluessel = '' }
            if ($r.TabelleId -eq 'D' -and $r.FeldId -eq 'B3') { $r.Standardwert = ''; $r.StandardwertSchluessel = '' }
        }
        $neu = @(
            (& $mk 'ZS' 'Standorte' 'ZA' 'Name' 'string' 'False' '' '')
            (& $mk 'ZS' 'Standorte' 'ZB' 'Adresse' 'string' 'True' '' '')
            (& $mk 'ZS' 'Standorte' 'ZR1' 'Lieferungen Abholung' 'rev' '' 'D' 'R2')
            (& $mk 'ZS' 'Standorte' 'ZR2' 'Lieferungen Lieferort' 'rev' '' 'D' 'Y2')
            (& $mk 'P' 'Consignee' 'ZN' 'Notify Party' 'string' 'True' '' ''))
        return @($rows) + $neu
    }
    # --- Formeln v2: neue Fassung neben dem Original (Spalte Original bleibt), Bauvorlage ZuBauen ersetzt
    $fp = Join-Path $v2 'arbeit\inventar\08_formel_analyse_voll.csv'
    Convert-N4V2Csv $fp {
        param($rows)
        $neu = @{ 'D.R2' = 'pick_up_location.adresse'; 'D.Y2' = 'delivery_to_location.adresse' }
        foreach ($r in $rows) {
            $key = "$($r.TabelleId).$($r.FeldId)"
            if ($r.Beschriftung -eq 'Pick up Address') { $r.ZuBauen = 'pick_up_location.adresse'; $r.Tiefe = '0'; $r.Anonymisiert = 'False' }
            elseif ($r.Beschriftung -eq 'Delivery Address') { $r.ZuBauen = 'delivery_to_location.adresse'; $r.Tiefe = '0'; $r.Anonymisiert = 'False' }
            elseif ($r.Beschriftung -eq 'Consignee Address') { $r.ZuBauen = 'consignee2.consignee_address'; $r.Tiefe = '0'; $r.Anonymisiert = 'False' }
            elseif ($r.Beschriftung -eq 'Consignee Notify Party') { $r.ZuBauen = 'consignee2.notify_party'; $r.Tiefe = '0'; $r.Anonymisiert = 'False' }
        }
        return $rows
    }
    return [pscustomobject]@{ V2Ordner = $v2; Modul = $cfg.moduleName }
}

function Convert-Ninox4V2Payload {
    # Hook fuer Invoke-Ninox4SampleImport: macht aus den Auswahlwerten von pick_up_location und delivery_to_location Verweise auf die neue Tabelle
    # standorte. Die Standorte entstehen aus den tatsaechlich vorkommenden Werten, in der Testversion anonymisiert (Standort-N, Platzhalteradresse),
    # damit keine Echtdaten (Namen und Adressen von Firmen) in die Testversion gelangen.
    param([Parameter(Mandatory)]$Payload)
    $felder = 'pick_up_location', 'delivery_to_location'
    $nummer = @{}; $liste = New-Object Collections.Generic.List[object]
    foreach ($rec in $Payload['shipping']) {
        foreach ($f in $felder) {
            if (-not $rec['werte'].Contains($f)) { continue }
            $v = [string]$rec['werte'][$f]
            if (-not $nummer.ContainsKey($v)) {
                $n = $nummer.Count + 1; $nummer[$v] = $n
                $w = [ordered]@{ name = "Standort-$n"; adresse = "Adresse $n (Platzhalter)" }
                $liste.Add([ordered]@{ altId = [string]$n; werte = $w; refs = [ordered]@{}; dateien = [ordered]@{} })
            }
            $rec['werte'].Remove($f)
            $rec['refs'][$f] = [ordered]@{ ziel = 'ZS'; id = [int64]$nummer[$v] }
        }
    }
    $Payload['standorte'] = $liste
    return [pscustomobject]@{ Standorte = $liste.Count }
}

function New-Ninox4ZielProjekt {
    # Legt einen Projektunterordner fuer einen ANDEREN Workspace an (gleiche Quelle, gleiches Mapping, gleiche Formelanalyse, neue Konfiguration).
    # Danach laufen die Bauskripte unveraendert mit -ProjectDir <projekt>\<Name>. Schreibt nichts nach Ninox.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$WorkspaceId, [Parameter(Mandatory)][string]$WorkspaceName, [string]$Name = 'ziel')
    $ErrorActionPreference = 'Stop'
    $z = Join-Path $ProjectDir $Name
    foreach ($d in 'ergebnis', 'arbeit\inventar', 'arbeit\ohne', 'arbeit\mit') { New-Item -ItemType Directory -Force -Path (Join-Path $z $d) | Out-Null }
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $cfg.workspaceId = $WorkspaceId; $cfg | Add-Member -NotePropertyName workspaceName -NotePropertyValue $WorkspaceName -Force
    [IO.File]::WriteAllText((Join-Path $z 'ninox.config.json'), ($cfg | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    foreach ($f in 'arbeit\ohne\data.db', 'arbeit\mit\data.db', 'arbeit\inventar\02_felder_voll.csv', 'arbeit\inventar\08_formel_analyse_voll.csv', 'ergebnis\06_mapping_vorschlag.csv', 'ergebnis\inventar_zusammenfassung.json', 'ergebnis\09_luecken.csv') {
        Copy-Item (Join-Path $ProjectDir $f) (Join-Path $z $f) -Force
    }
    $st = Get-Content (Join-Path $ProjectDir 'ergebnis\status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $st.freigaben = @(); $st.phase = 2; $st.ziel.workspaceId = $WorkspaceId
    [IO.File]::WriteAllText((Join-Path $z 'ergebnis\status.json'), ($st | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]@{ Ordner = $z; WorkspaceId = $WorkspaceId; Modul = $cfg.moduleName }
}