# Erzeugt ein kleines, ERFUNDENES Ninox-3-Beispiel (zwei .ninox-Dateien) fuer Selbsttests. Enthaelt keine echten Daten.
# PowerShell 5.1.  Nutzung:  . .\scripts\ninox3-testdaten.ps1 ; New-Ninox3Fixture -Ordner <ordner>
# Inhalt: Tabelle A "Kunden" (Name, Strasse, Status mit Standardwert, E-Mail, Rueckverweis), Tabelle B "Auftraege" (Bestellnummer,
# Lieferdatum, Erfasst, Verweis auf Kunden, Menge, Preis, Formel Summe, Dateifeld, Notiz, Formel mit eingebetteter Adresse),
# 1 Ansicht, 1 Bericht, Plugin "Ninext v3" (wird ignoriert), 3 Kunden, 4 Auftraege.

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function New-Ninox3Fixture {
    param([Parameter(Mandatory)][string]$Ordner)
    New-Item -ItemType Directory -Force -Path $Ordner | Out-Null
    $schema = '{"seq":10,"version":1,"nextTypeId":3,"types":{' +
        '"A":{"caption":"Kunden","order":0,"kind":"table","uis":{},"readRoles":["admin","editor"],"fields":{' +
            '"A":{"base":"string","caption":"Name","order":0,"required":true,"hasIndex":true,"globalSearch":true},' +
            '"B":{"base":"string","caption":"Strasse","order":1,"stringMultiline":true},' +
            '"C":{"base":"choice","caption":"Status","order":2,"choiceDefault":"1","values":{"1":{"caption":"Aktiv","order":0},"2":{"caption":"Inaktiv","order":1}}},' +
            '"D":{"base":"string","caption":"E-Mail","order":3},' +
            '"E":{"base":"rev","caption":"Auftraege","order":4,"refTypeId":"B","refFieldId":"D"}}},' +
        '"B":{"caption":"Auftraege","order":1,"kind":"table","uis":{},"fields":{' +
            '"A":{"base":"string","caption":"PO","order":0},' +
            '"B":{"base":"date","caption":"Lieferdatum","order":1},' +
            '"C":{"base":"timestamp","caption":"Erfasst am","order":2},' +
            '"D":{"base":"ref","caption":"Kunde","order":3,"refTypeId":"A","refFieldId":"E","cascade":false},' +
            '"E":{"base":"number","caption":"Menge","order":4},' +
            '"F":{"base":"number","caption":"Preis","order":5,"numberDefault":2.5},' +
            '"G":{"base":"number","caption":"Summe","order":6,"fn":"E * F"},' +
            '"H":{"base":"file","caption":"Anhang","order":7},' +
            '"I":{"base":"string","caption":"Notiz","order":8,"stringMultiline":true},' +
            '"J":{"base":"string","caption":"Lieferadresse","order":9,"fn":"(if (D.D like \"info@beispiel.invalid\") then \"Teststrasse 1, 12345 Testort\" else (if (D.D like \"kontakt@muster.invalid\") then \"Musterweg 2, 54321 Musterstadt\" else \"-\" end) end)"}}}}}'
    $view = 'Vv1:{"id":"v1","type":"B","caption":"(all)","mode":"table","config":{"type":"B","cols":[{"expression":"A"},{"expression":"B"}]}}'
    $recK = @(
        'UA1:{"_cd":1791000000000,"A":"Beispiel GmbH","B":"Teststrasse 1\nTestort","C":"1","D":"info@beispiel.invalid"}',
        'UA2:{"_cd":1791000000001,"A":"Muster AG","B":"Musterweg 2","C":"2","D":"kontakt@muster.invalid"}',
        'UA3:{"_cd":1791000000002,"A":"Test KG"}')
    $recA = @(
        'UB1:{"A":"P-001","B":1791244800000,"C":1791246600000,"D":1,"E":3,"F":2.5,"H":"Rechnung 4711.PDF","I":"Erste Notiz"}',
        'UB2:{"A":"P-002","B":1791331200000,"D":1,"E":2,"F":4}',
        'UB3:{"A":"P-003","D":2,"E":10}',
        'UB4:{"A":"P-004","C":1791246600000}')
    $settings = '{"name":"Fixture Beispiel","icon":"database","rolesImport":["admin"],"plugins":[{"id":"ninext-v3","name":"Ninext v3","version":"3.1.2"}]}'
    $backup = '{"id":"fixture001","dbid":"fixturedb001","dbname":"Fixture Beispiel","timestamp":1791272553935,"user":"u1"}'
    $report = '{"id":"r1","tid":"B","caption":"Auftragsbericht","paperWidth":210,"paperHeight":297,"objects":[{"base":"text","x":10,"y":10,"w":50,"h":10,"text":"PO {A}"}]}'
    $nl = "`n"
    $mk = {
        param($pfad, $mitDaten)
        $db = 's:' + $schema + $nl + $view + $nl
        if ($mitDaten) { $db += (($recK + $recA) -join $nl) + $nl }
        if (Test-Path $pfad) { [IO.File]::Delete($pfad) }
        $fs = [IO.File]::Create($pfad); $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
        foreach ($e in @(@('data.db', $db), @('settings.json', $settings), @('backup.json', $backup), @('comments.db', ''), @('reports/r1/report.json', $report))) {
            $en = $zip.CreateEntry($e[0], [IO.Compression.CompressionLevel]::Optimal); $s = $en.Open()
            $b = (New-Object Text.UTF8Encoding($false)).GetBytes($e[1]); if ($b.Length -gt 0) { $s.Write($b, 0, $b.Length) }; $s.Close()
        }
        $zip.Dispose(); $fs.Close()
    }
    $ohne = Join-Path $Ordner 'fixture_ohne_daten.ninox'; $mit = Join-Path $Ordner 'fixture_mit_daten.ninox'
    & $mk $ohne $false; & $mk $mit $true
    return [pscustomobject]@{ Ohne = $ohne; Mit = $mit }
}
