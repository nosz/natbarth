# Einstiegspunkt fuer Phase 0 und 1: entpacken, Sicherungspaar pruefen, Inventar, Formelanalyse, Namenspruefung.
# PowerShell 5.1, rein lokal, kein Netzwerk, keine Zugangsdaten.
# Nutzung:
#   . .\ninox3-zu-ninox4-migration\scripts\ninox3-phase1.ps1
#   Invoke-Ninox3Phase1 -OhneDatei <pfad>_ohne_daten.ninox -MitDatei <pfad>_mit_daten.ninox -ProjectDir <projektordner>
#
# Ordnerlogik (siehe SKILL.md):
#   <projekt>\arbeit\ohne, arbeit\mit      entpackte Sicherungen (Echtdaten, lokal, nicht versionieren)
#   <projekt>\arbeit\inventar              volle Fassung mit Formeltexten, Auswahlwerten, Rollennamen (Echtdaten moeglich)
#   <projekt>\ergebnis                     bereinigte Ergebnisse: Struktur, Zaehler, Laengen, Status (keine Echtdaten)
# Die Funktion gibt nur Zaehler zurueck, nie Formeltexte oder Datensatzinhalte.

. (Join-Path $PSScriptRoot 'ninox3-reader.ps1')
. (Join-Path $PSScriptRoot 'ninox3-formeln.ps1')
. (Join-Path $PSScriptRoot 'ninox-openapi.ps1')

function Find-Ninox4ApiBuilder {
    # Sucht den Skill ninox4-api-builder neben diesem Skill, im Projekt und im Benutzerprofil. Gibt den Pfad oder $null zurueck.
    param([string]$ProjectDir)
    $cand = @(
        (Join-Path (Split-Path -Parent $PSScriptRoot) '..\ninox4-api-builder'),
        (Join-Path $HOME '.claude\skills\ninox4-api-builder'))
    if ($ProjectDir) { $cand += (Join-Path $ProjectDir '.claude\skills\ninox4-api-builder') }
    foreach ($c in $cand) { if (Test-Path -LiteralPath (Join-Path $c 'SKILL.md')) { return (Resolve-Path -LiteralPath $c).Path } }
    return $null
}

function Invoke-Ninox3Phase1 {
    param(
        [Parameter(Mandatory)][string]$OhneDatei,
        [Parameter(Mandatory)][string]$MitDatei,
        [Parameter(Mandatory)][string]$ProjectDir,
        [string]$MappingFile,          # optional: freigegebenes Mapping (CSV, Trennzeichen ;) fuer die Formelaufloesung
        [switch]$PruefeApi,           # oeffentliche OpenAPI (ohne Key, nur lesend) abrufen und Faehigkeiten zusammenfassen (Phase 2)
        [switch]$Force)                # vorhandene Entpack-Ordner ueberschreiben

    $arbeit = Join-Path $ProjectDir 'arbeit'
    $ergebnis = Join-Path $ProjectDir 'ergebnis'
    $inventar = Join-Path $arbeit 'inventar'
    $ohne = Expand-Ninox3Archive -Path $OhneDatei -Destination (Join-Path $arbeit 'ohne') -Force:$Force
    $mit = Expand-Ninox3Archive -Path $MitDatei -Destination (Join-Path $arbeit 'mit') -Force:$Force

    # Phase 0: Sicherungspaar
    $pair = Test-Ninox3BackupPair -DirOhne $ohne -DirMit $mit
    if (-not $pair.Bestanden) {
        Write-Warning 'Pruefung des Sicherungspaars nicht bestanden. Ursache klaeren, bevor weitergearbeitet wird.'
        return [pscustomobject]@{ Phase = 0; Bestanden = $false; Pruefungen = $pair.Pruefungen }
    }

    # Phase 1: Inventar (bereinigt nach ergebnis, voll nach arbeit\inventar)
    $summary = Export-Ninox3Inventory -Dir $ohne -OutDir $ergebnis -RawDir $inventar -DataDbMit (Join-Path $mit 'data.db')

    # Formelanalyse mit dem Mapping (Vorschlag oder freigegebene Fassung)
    $schema = Read-Ninox3Schema -DataDb (Join-Path $ohne 'data.db')
    $fields = @(Get-Ninox3FieldInventory -Schema $schema)
    $mapFile = if ($MappingFile) { $MappingFile } else { Join-Path $ergebnis '06_mapping_vorschlag.csv' }
    $mapping = @(Import-Csv -Path $mapFile -Delimiter ';' -Encoding UTF8)
    $fa = Export-Ninox3FormulaAnalysis -Schema $schema -FieldRows $fields -Mapping $mapping `
        -Path (Join-Path $inventar '08_formel_analyse_voll.csv') -SafePath (Join-Path $ergebnis '08_formel_analyse.csv')

    # Optional: Faehigkeiten der Ninox-4-API aus der oeffentlichen Spezifikation (kein Key)
    $api = $null
    if ($PruefeApi) {
        try {
            $spec = Get-NinoxOpenApi -OutFile (Join-Path $arbeit 'openapi.json')
            $cap = @(Get-NinoxApiCapability -Spec $spec)
            $cap | Export-Csv -Path (Join-Path $ergebnis '11_api_faehigkeiten.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
            $api = "$(@($cap | Where-Object Belegt).Count) von $($cap.Count) Bereichen belegt ($($cap[0].Spezifikation))"
        } catch { $api = "nicht abrufbar: $($_.Exception.Message)" }
    }

    # Namenspruefung
    $names = @(Test-Ninox4Names -Mapping $mapping)
    $names | Export-Csv -Path (Join-Path $ergebnis '10_namenspruefung.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8

    return [pscustomobject]@{
        Phase = 1; Bestanden = $true
        Sicherungspaar = ($pair.Pruefungen | ForEach-Object { "$($_.Pruefung): $($_.Ergebnis)" }) -join ' | '
        Inventar = $summary
        Formeln = $fa
        NamenFehler = @($names | Where-Object { $_.Stufe -eq 'Fehler' }).Count
        NamenWarnungen = @($names | Where-Object { $_.Stufe -eq 'Warnung' }).Count
        ApiFaehigkeiten = if ($api) { $api } else { 'nicht geprueft (-PruefeApi)' }
        BuilderGefunden = $(if (Find-Ninox4ApiBuilder -ProjectDir $ProjectDir) { 'ja' } else { 'nein (fuer Phase 3 bis 7 noetig, Phase 0 bis 2 laufen ohne)' })
        Ergebnisordner = $ergebnis
        VolleFassung = $inventar
    }
}
