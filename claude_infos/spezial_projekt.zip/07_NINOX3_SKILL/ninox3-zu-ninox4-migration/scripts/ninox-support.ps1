# Stoerungen der Ninox-API erfassen und eine Meldung fuer den Ninox Support erzeugen, die der Nutzer per Copy and Paste weitergeben kann.
# Ablage: eigener Ordner ergebnis\support\, Dateiname <yyyyMMdd_HHmmss>_support_meldung.txt (Zeitstempel am Anfang).
# PowerShell 5.1. Kein Netzwerkzugriff. Die Meldung enthaelt KEINEN API-Key und keine Datensatzinhalte: nur Zeitraum, Workspace-ID,
# Modul, Art der Aktion, Pfade der Aufrufe, Fehlermeldungen von Ninox und Zaehler.
# Wird von den Bauskripten (ninox4-schema-bauen, ninox4-doku-modul, ninox4-formeln-bauen) geladen.

$script:NinoxStoerungen = New-Object Collections.Generic.List[object]

# ---- Schreibtempo: Schreibvorgaenge nacheinander mit Pause, die sich der Lage anpasst
# Ninox erlaubt hoechstens 3 gleichzeitige Schreibvorgaenge je Workspace (beobachtet) und nimmt sich bei Formelfeldern Zeit fuer
# Pruefung und Berechnung. Deshalb: nie parallel schreiben, zwischen Aufrufen eine Pause; nach einem Serverfehler wird die Pause
# verdoppelt (bis zum Hoechstwert), nach mehreren Erfolgen in Folge wieder verkuerzt (bis zur Basis).
$script:NinoxPauseBasis = 300; $script:NinoxPauseMax = 8000; $script:NinoxPause = 300; $script:NinoxErfolgeInFolge = 0

function Set-NinoxSchreibtempo {
    param([int]$BasisMs = 300, [int]$MaxMs = 8000)
    $script:NinoxPauseBasis = [Math]::Max(0, $BasisMs); $script:NinoxPauseMax = [Math]::Max($BasisMs, $MaxMs)
    $script:NinoxPause = $script:NinoxPauseBasis; $script:NinoxErfolgeInFolge = 0
}
function Wait-NinoxSchreibpause { if ($script:NinoxPause -gt 0) { Start-Sleep -Milliseconds $script:NinoxPause } }
function Register-NinoxErfolg {
    $script:NinoxErfolgeInFolge++
    if ($script:NinoxErfolgeInFolge -ge 5 -and $script:NinoxPause -gt $script:NinoxPauseBasis) {
        $script:NinoxPause = [Math]::Max($script:NinoxPauseBasis, [int]($script:NinoxPause / 2)); $script:NinoxErfolgeInFolge = 0
    }
}
function Register-NinoxTransient {
    $script:NinoxErfolgeInFolge = 0
    $script:NinoxPause = [Math]::Min($script:NinoxPauseMax, [Math]::Max(1000, $script:NinoxPause * 2))
}
function Get-NinoxSchreibpause { return $script:NinoxPause }

function Test-NinoxTransientError {
    # Vorubergehende Serverfehler: kein Plan- oder Formelfehler, sondern Erreichbarkeit/Auslastung.
    param([string]$Msg)
    return [bool]($Msg -match 'upstream connect|Connection refused|concurrent write|CONCURRENCY_LIMIT|\b429\b|\b502\b|\b503\b|\b504\b|timed out|Timeout|Remoteserver|Basisverbindung|unable to connect|kann nicht hergestellt werden')
}

function Get-NinoxFehlertyp {
    param([string]$Msg)
    if ($Msg -match 'CONCURRENCY_LIMIT|concurrent write') { return 'Zu viele gleichzeitige Schreibvorgaenge (Limit 3)' }
    if ($Msg -match 'upstream connect|Connection refused') { return 'Server nicht erreichbar (upstream connect error / Connection refused)' }
    if ($Msg -match '\b429\b') { return 'Rate Limit (HTTP 429)' }
    if ($Msg -match '\b50[234]\b') { return 'Server-Fehler (HTTP 502/503/504)' }
    if ($Msg -match 'timed out|Timeout') { return 'Zeitueberschreitung' }
    return 'Verbindungsfehler'
}

function Add-NinoxStoerung {
    param([string]$Aktion, [string]$Methode, [string]$Pfad, [string]$Meldung, [string]$Feld = '')
    $m = if ($null -eq $Meldung) { '' } else { $Meldung }
    if ($m.Length -gt 400) { $m = $m.Substring(0, 400) }
    $script:NinoxStoerungen.Add([pscustomobject]@{ Zeit = (Get-Date); Aktion = $Aktion; Methode = $Methode; Pfad = $Pfad; Meldung = $m; Typ = (Get-NinoxFehlertyp $m); Feld = $Feld })
}

function Clear-NinoxStoerungen { $script:NinoxStoerungen.Clear() }

function New-NinoxSupportMeldung {
    # Erzeugt eine KURZE, ZWEISPRACHIGE Meldung (Deutsch und Englisch) fuer den Ninox Support/die Entwickler mit allem Noetigen:
    # Zeitraum, Workspace, Aktion, Fehlerarten mit Anzahl, Beispielaufruf (curl, Key als Platzhalter), Originalmeldung. Ohne Key, ohne Kundendaten.
    # Ablage: ergebnis\support\<yyyyMMdd_HHmmss>_support_meldung.txt. Gibt ein Objekt mit Datei und Text zurueck (oder $null ohne Stoerung).
    param(
        [Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$WorkspaceId, [string]$Modul = '',
        [Parameter(Mandatory)][string]$Aktion, [int]$Erfolgreich = -1, [string]$Stand = '',
        [string]$AktionEn = '', [string]$StandEn = '',      # englische Fassung von Aktion und Stand (sonst wird der deutsche Text uebernommen)
        [string]$BeispielBody = '')   # sicherer Beispiel-Body mit Platzhaltern, z. B. {"name":"<feld>","type":"function","expression":"<ausdruck>"}
    $ev = $script:NinoxStoerungen.ToArray()
    if ($ev.Count -eq 0) { return $null }
    $sorted = $ev | Sort-Object Zeit
    $first = $sorted[0].Zeit; $last = $sorted[$sorted.Count - 1].Zeit
    $off = [TimeZoneInfo]::Local.GetUtcOffset($first); $sign = if ($off -ge [TimeSpan]::Zero) { '+' } else { '-' }
    $fmt = 'yyyy-MM-dd HH:mm:ss'
    $typen = $ev | Group-Object Typ | Sort-Object Count -Descending
    $typDe = ($typen | ForEach-Object { "$($_.Count) x $($_.Name)" }) -join '; '
    $typEn = ($typen | ForEach-Object { "$($_.Count) x " + (Get-NinoxFehlertypEn $_.Name) }) -join '; '
    $e0 = $ev[0]
    $tabellen = @($ev | ForEach-Object { if ($_.Pfad -match '/tables/([^/]+)') { $Matches[1] } } | Select-Object -Unique)
    $felder = @($ev | ForEach-Object { $_.Feld } | Where-Object { $_ } | Select-Object -Unique)
    $tabTxt = if ($tabellen.Count -gt 0) { $tabellen -join ', ' } else { '-' }
    $feldTxt = if ($felder.Count -gt 0) { ($felder | Select-Object -First 8) -join ', ' + $(if ($felder.Count -gt 8) { ' ... (' + $felder.Count + ' Felder)' } else { '' }) } else { '-' }
    if ($felder.Count -gt 0 -and $BeispielBody) { $BeispielBody = $BeispielBody -replace '<field>|<feld>', $felder[0] }
    if (-not $AktionEn) { $AktionEn = $Aktion }; if (-not $StandEn) { $StandEn = $Stand }
    $pfad = '/api/v1/workspace/' + $WorkspaceId + ($e0.Pfad -replace '^/(api/v1/workspace/[^/]+/)?', '/')
    $body = if ($BeispielBody) { $BeispielBody } else { '{ ... }' }
    $curl = "curl -X $($e0.Methode) `"https://go.ninox.com$pfad`" -H `"Authorization: Bearer <API_KEY>`" -H `"Content-Type: application/json`" -d '$body'"
    $orig = ($ev | Select-Object -ExpandProperty Meldung | Select-Object -Unique | Select-Object -First 2) -join "`n  > "
    $erfDe = if ($Erfolgreich -ge 0) { " (erfolgreich: $Erfolgreich)" } else { '' }
    $erfEn = if ($Erfolgreich -ge 0) { " (successful: $Erfolgreich)" } else { '' }
    $sb = New-Object Text.StringBuilder
    [void]$sb.AppendLine("=== DEUTSCH ===")
    [void]$sb.AppendLine("Betreff: Ninox Public API: Server antwortet nicht bzw. lehnt Aufrufe ab (Workspace $WorkspaceId)")
    [void]$sb.AppendLine("Kurz: Bei $Aktion schlugen $($ev.Count) Aufrufe fehl$erfDe. Art: $typDe.")
    [void]$sb.AppendLine("Zeitraum: $($first.ToString($fmt)) bis $($last.ToString($fmt)) (UTC$sign$($off.ToString('hh\:mm'))), UTC: $($first.ToUniversalTime().ToString($fmt)) bis $($last.ToUniversalTime().ToString($fmt))")
    [void]$sb.AppendLine("FUNDSTELLE (sofort pruefbar): Workspace-ID $WorkspaceId | Modul $Modul | Tabelle(n) $tabTxt | Feld(er) $feldTxt | API: Ninox Public API 1.0.0 (Test-Workspace, keine Kundendaten)")
    if ($Stand) { [void]$sb.AppendLine("Stand: $Stand") }
    [void]$sb.AppendLine("Beispielaufruf (Key als Platzhalter):")
    [void]$sb.AppendLine("  $curl")
    [void]$sb.AppendLine("Antwort von Ninox (Auszug):")
    [void]$sb.AppendLine("  > $orig")
    [void]$sb.AppendLine("Bitte pruefen: Stoerung oder Auslastungsgrenze fuer diesen Workspace? Wir haben mit wachsender Wartezeit wiederholt. Kein Key, keine Kundendaten enthalten.")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("=== ENGLISH ===")
    [void]$sb.AppendLine("Subject: Ninox Public API: server not responding / rejecting calls (workspace $WorkspaceId)")
    [void]$sb.AppendLine("Summary: During `"$AktionEn`", $($ev.Count) calls failed$erfEn. Type: $typEn.")
    [void]$sb.AppendLine("Period: $($first.ToUniversalTime().ToString($fmt)) to $($last.ToUniversalTime().ToString($fmt)) UTC (local time UTC$sign$($off.ToString('hh\:mm')))")
    [void]$sb.AppendLine("LOCATION (ready to test): workspace ID $WorkspaceId | module $Modul | table(s) $tabTxt | field(s) $feldTxt | API: Ninox Public API 1.0.0 (test workspace, no customer data)")
    if ($StandEn) { [void]$sb.AppendLine("State: $StandEn") }
    [void]$sb.AppendLine("Example request (key as placeholder):")
    [void]$sb.AppendLine("  $curl")
    [void]$sb.AppendLine("Response from Ninox (excerpt):")
    [void]$sb.AppendLine("  > $orig")
    [void]$sb.AppendLine("Please check: outage, or a concurrency/rate limit on this workspace? We retried with increasing waits. No key and no customer data included.")
    $text = $sb.ToString()
    # Ablage: eigener Ordner ergebnis\support\
    $dir = Join-Path $ProjectDir 'ergebnis\support'
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    # Dateiname beginnt mit dem Zeitstempel (sortierbar): <yyyyMMdd_HHmmss>_support_meldung.txt
    $file = Join-Path $dir ((Get-Date -Format 'yyyyMMdd_HHmmss') + "_support_meldung.txt")
    [IO.File]::WriteAllText($file, $text, (New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]@{ Datei = $file; Text = $text; Aufrufe = $ev.Count }
}

function Get-NinoxFehlertypEn {
    param([string]$Typ)
    switch -Wildcard ($Typ) {
        'Zu viele*' { return 'too many concurrent write transactions (limit 3)' }
        'Server nicht erreichbar*' { return 'server unreachable (upstream connect error / connection refused)' }
        'Rate Limit*' { return 'rate limit (HTTP 429)' }
        'Server-Fehler*' { return 'server error (HTTP 502/503/504)' }
        'Zeitueberschreitung' { return 'timeout' }
        default { return 'connection error' }
    }
}
function Show-NinoxSupportHinweis {
    # Zeigt dem Nutzer die Meldung zum Kopieren. Pflicht, sobald Serverfehler aufgetreten sind.
    param($Meldung)
    if (-not $Meldung) { return }
    Write-Warning "Ninox hat zeitweise nicht geantwortet ($($Meldung.Aufrufe) Aufrufe betroffen). Eine fertige Meldung fuer den Ninox Support liegt hier: $($Meldung.Datei)"
    Write-Host ''
    Write-Host '----- Meldung fuer den Support (zum Kopieren) -----'
    Write-Host $Meldung.Text
    Write-Host '----- Ende der Meldung -----'
}
