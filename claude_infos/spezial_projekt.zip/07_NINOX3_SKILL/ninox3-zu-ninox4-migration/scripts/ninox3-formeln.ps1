# Analyse von Ninox-3-Formeln: ordnet jedes Token ein (Feld, Tabelle, Variable, Funktion, Schluesselwort, unbekannt)
# und erzeugt eine ROHUEBERSETZUNG der Feld- und Tabellenverweise auf die Ninox-4-Namen aus dem Mapping.
# Das ist Schritt 1 der Formeluebersetzung. Syntaxunterschiede zwischen Ninox 3 und 4 sind damit NICHT erledigt;
# sie werden in Phase 4 gegen den ninox-Skill und docs.ninox.com geprueft und in Ninox 4 getestet.
# PowerShell 5.1. Setzt voraus:  . .\scripts\ninox3-reader.ps1

$script:N3Keywords = @(
    'let', 'if', 'then', 'else', 'end', 'select', 'where', 'order', 'by', 'desc', 'asc', 'and', 'or', 'not', 'true', 'false',
    'like', 'in', 'for', 'do', 'var', 'this', 'me', 'null', 'as', 'server', 'switch', 'case', 'default', 'from', 'to', 'group',
    'contains', 'between', 'distinct', 'unique')
# Typnamen sind nur ohne Klammer Schluesselwoerter (mit Klammer sind es Funktionen, z. B. number(x)).
$script:N3SoftKeywords = @('text', 'number', 'date', 'time', 'datetime')
$script:N3Specials = @('_id', '_cd', '_cu', '_md', '_mu', 'record', 'database')

function Split-N3Formula {
    param([string]$Text)
    $rx = New-Object Text.RegularExpressions.Regex('"(?:[^"\\]|\\.)*"|''(?:[^''\\]|\\.)*''|//[^\r\n]*|/\*.*?\*/|[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|:=|\s+|.', [Text.RegularExpressions.RegexOptions]::Singleline)
    foreach ($m in $rx.Matches($Text)) {
        $v = $m.Value
        $kind = 'other'
        if ($v[0] -eq '"' -or ($v[0] -eq "'" -and $v.Length -gt 1)) { $kind = 'str' }
        elseif ($v.StartsWith('//') -or $v.StartsWith('/*')) { $kind = 'comment' }
        elseif ($v -match '^\s+$') { $kind = 'space' }
        elseif ($v -match '^[A-Za-z_]') { $kind = 'ident' }
        [pscustomobject]@{ Text = $v; Kind = $kind }
    }
}

function Resolve-Ninox3Formula {
    param(
        [Parameter(Mandatory)]$Schema, [Parameter(Mandatory)][string]$TypeId, [Parameter(Mandatory)][string]$Formula,
        [Parameter(Mandatory)]$Mapping)   # Mapping = Zeilen aus 06_mapping_vorschlag.csv (ggf. freigegeben)
    $fieldMap = @{}; $tableMap = @{}
    foreach ($m in $Mapping) { $fieldMap["$($m.TabelleId).$($m.FeldId)"] = $m.Ninox4Feld; $tableMap[$m.TabelleId] = $m.Ninox4Tabelle }
    $lets = @{}
    foreach ($m in [regex]::Matches($Formula, '\b(?:let|var)\s+([A-Za-z_][A-Za-z0-9_]*)')) { $lets[$m.Groups[1].Value] = $true }

    $tokens = @(Split-N3Formula -Text $Formula)
    $sig = @(0..($tokens.Count - 1) | Where-Object { $tokens[$_].Kind -notin 'space', 'comment' })
    $pos = @{}; for ($i = 0; $i -lt $sig.Count; $i++) { $pos[$sig[$i]] = $i }

    $found = @{ Feld = @{}; Tabelle = @{}; Variable = @{}; Funktion = @{}; Unbekannt = @{} }
    $out = New-Object Text.StringBuilder
    $depth = 0; $ctx = New-Object Collections.Generic.List[object]; $chain = $null; $prev = ''
    for ($i = 0; $i -lt $tokens.Count; $i++) {
        $t = $tokens[$i]; $rep = $t.Text
        if ($t.Kind -in 'space', 'comment', 'str') { [void]$out.Append($rep); continue }
        $p = $pos[$i]
        $next = if ($p + 1 -lt $sig.Count) { $tokens[$sig[$p + 1]].Text } else { '' }
        $curType = if ($ctx.Count -gt 0) { $ctx[$ctx.Count - 1].Type } else { $TypeId }

        if ($t.Kind -eq 'ident') {
            $name = $t.Text
            if ($prev -eq '.') {
                $fd = if ($chain) { $Schema['types'][$chain]['fields'] } else { $null }
                if ($fd -and $fd.ContainsKey($name)) {
                    $found.Feld["$chain.$name"] = $true; $rep = $fieldMap["$chain.$name"]
                    $b = $fd[$name]['base']; $chain = if ($b -in 'ref', 'rev') { [string]$fd[$name]['refTypeId'] } else { $null }
                } else { $found.Unbekannt[".$name"] = $true; $chain = $null }
            } else {
                $chain = $null
                if ($lets.ContainsKey($name)) { $found.Variable[$name] = $true }
                elseif ($script:N3Keywords -contains $name) { }
                elseif ($next -eq '(') { $found.Funktion[$name] = $true }
                elseif ($prev -eq 'select' -and $Schema['types'].ContainsKey($name)) {
                    $found.Tabelle[$name] = $true; $rep = $tableMap[$name]
                    $ctx.Add(@{ Depth = $depth; Type = $name })
                }
                elseif ($script:N3SoftKeywords -contains $name -or $script:N3Specials -contains $name) { }
                elseif ($Schema['types'][$curType]['fields'].ContainsKey($name)) {
                    $found.Feld["$curType.$name"] = $true; $rep = $fieldMap["$curType.$name"]
                    $b = $Schema['types'][$curType]['fields'][$name]['base']
                    $chain = if ($b -in 'ref', 'rev') { [string]$Schema['types'][$curType]['fields'][$name]['refTypeId'] } else { $null }
                }
                else { $found.Unbekannt[$name] = $true }
            }
        } else {
            if ($t.Text -ne '.') { $chain = $null }
            if ($t.Text -eq '(') { $depth++ }
            elseif ($t.Text -eq ')') {
                $depth--
                while ($ctx.Count -gt 0 -and $ctx[$ctx.Count - 1].Depth -gt $depth) { $ctx.RemoveAt($ctx.Count - 1) }
            }
        }
        $prev = $t.Text
        [void]$out.Append($rep)
    }
    [pscustomobject]@{
        Rohuebersetzung = $out.ToString()
        Felder      = ($found.Feld.Keys | Sort-Object) -join ', '
        Tabellen    = ($found.Tabelle.Keys | Sort-Object) -join ', '
        Variablen   = ($found.Variable.Keys | Sort-Object) -join ', '
        Funktionen  = ($found.Funktion.Keys | Sort-Object) -join ', '
        Unbekannt   = ($found.Unbekannt.Keys | Sort-Object) -join ', '
        Status      = if ($found.Unbekannt.Count -eq 0) { 'aufgeloest' } else { 'pruefen' }
    }
}

function ConvertTo-N4LikeAlsContains {
    # Anpassung fuer Ninox 4: A like B wird zu text(A) like B (siehe unten). Ohne text() lehnt Ninox 4 like per API mit 500 ab. Frueher am Tag legte Ninox 4 Formelfelder mit like an, meldete aber beim Anlegen per API
    # "An unexpected error occurred in a workspace object operation" (beobachtet 2026-10-06; das Feld existiert danach). Der Bauskript prueft
    # nach diesem Fehler, ob das Feld da ist. "A like B" prueft laut Dokumentation, ob A den Text B enthaelt; Ersatz waere contains(A, B),
    # das Gross- und Kleinschreibung unterscheidet und die Bedeutung aendern kann.
    # Operanden: Zeichenkette, Feldpfad (a.b.c), Funktionsaufruf oder Klammerausdruck. Gibt Text und Anzahl der Ersetzungen zurueck.
    param([Parameter(Mandatory)][string]$Formula)
    $text = $Formula; $count = 0
    for ($guard = 0; $guard -lt 500; $guard++) {
        $tk = @(Split-N3Formula -Text $text)
        $i = -1; for ($x = 0; $x -lt $tk.Count; $x++) { if ($tk[$x].Kind -eq 'ident' -and $tk[$x].Text -eq 'like') { $i = $x; break } }
        if ($i -lt 0) { break }
        # linker Operand
        $j = $i - 1; while ($j -ge 0 -and $tk[$j].Kind -in 'space', 'comment') { $j-- }
        if ($j -lt 0) { throw 'like ohne linken Operanden' }
        $ls = $j
        if ($tk[$j].Text -eq ')') {
            $d = 0; $k = $j; while ($k -ge 0) { if ($tk[$k].Text -eq ')') { $d++ } elseif ($tk[$k].Text -eq '(') { $d--; if ($d -eq 0) { break } }; $k-- }
            $ls = $k; if ($ls -gt 0 -and $tk[$ls - 1].Kind -eq 'ident') { $ls-- }
        } elseif ($tk[$j].Kind -eq 'ident') {
            while ($ls -ge 2 -and $tk[$ls - 1].Text -eq '.' -and $tk[$ls - 2].Kind -eq 'ident') { $ls -= 2 }
        }
        # rechter Operand
        $m = $i + 1; while ($m -lt $tk.Count -and $tk[$m].Kind -in 'space', 'comment') { $m++ }
        if ($m -ge $tk.Count) { throw 'like ohne rechten Operanden' }
        $re = $m
        $closeFrom = {
            param($from)
            $d = 0; $k = $from
            while ($k -lt $tk.Count) { if ($tk[$k].Text -eq '(') { $d++ } elseif ($tk[$k].Text -eq ')') { $d--; if ($d -eq 0) { return $k } }; $k++ }
            return $from
        }
        if ($tk[$m].Text -eq '(') { $re = & $closeFrom $m }
        elseif ($tk[$m].Kind -eq 'ident') {
            $re = $m
            while ($re + 2 -lt $tk.Count -and $tk[$re + 1].Text -eq '.' -and $tk[$re + 2].Kind -eq 'ident') { $re += 2 }
            if ($re + 1 -lt $tk.Count -and $tk[$re + 1].Text -eq '(') { $re = & $closeFrom ($re + 1) }
        }
        $left = (($tk[$ls..$j] | ForEach-Object { $_.Text }) -join '')
        $right = (($tk[$m..$re] | ForEach-Object { $_.Text }) -join '')
        $before = if ($ls -gt 0) { (($tk[0..($ls - 1)] | ForEach-Object { $_.Text }) -join '') } else { '' }
        $after = if ($re + 1 -lt $tk.Count) { (($tk[($re + 1)..($tk.Count - 1)] | ForEach-Object { $_.Text }) -join '') } else { '' }
        # Loesung (vom Nutzer genannt, am 2026-10-06 mit Probefeldern bestaetigt): Ninox 4 nimmt like nur an, wenn der LINKE Operand in text() steht (Text, Auswahl, Zahl, Verweispfad). So bleibt like erhalten und das Verhalten gleich; contains ist nicht noetig. Ohne text() liefert die API 500 und legt das Feld nicht an.
        $text = $before + 'text(' + $left + ') __like__ ' + $right + $after   # Platzhalter, damit die Schleife die Stelle nicht erneut findet
        $count++
    }
    $text = $text.Replace('__like__', 'like')
    return [pscustomobject]@{ Formel = $text; Ersetzt = $count }
}

function Get-N3MaxIfDepth {
    # Zaehlt die groesste Verschachtelung von if (auch "else if" und if in then/else-Zweigen, ausserhalb von Zeichenketten).
    # Beobachtet (2026-10-06): Ninox legt Ketten bis etwa 19 Ebenen sofort an, ab etwa 20 Ebenen dauert es Sekunden und meldet einen irrefuehrenden Fehler,
    # ab etwa 26 Ebenen kommt es zur Zeitueberschreitung (in jeder Schreibweise, mit oder ohne end und Klammern). Die Zeichenlaenge spielt keine Rolle
    # (flache Formel mit 4000 Zeichen: 1 Sekunde).
    param([Parameter(Mandatory)][string]$Formula)
    $tk = @(Split-N3Formula -Text $Formula | Where-Object { $_.Kind -in 'ident', 'other' })
    $frames = New-Object Collections.Generic.List[int]; $frames.Add(0)   # je Klammergruppe: Ebene des zuletzt geoeffneten if
    $max = 0; $prev = ''
    foreach ($x in $tk) {
        if ($x.Kind -eq 'other') {
            if ($x.Text -eq '(') { $frames.Add(0) } elseif ($x.Text -eq ')' -and $frames.Count -gt 1) { $frames.RemoveAt($frames.Count - 1) }
            $prev = $x.Text; continue
        }
        if ($x.Text -eq 'if') {
            $top = $frames.Count - 1
            $base = 0
            if (($prev -eq 'else' -or $prev -eq 'then') -and $frames[$top] -gt 0) { $base = $frames[$top] }
            else { for ($i = $top; $i -ge 0; $i--) { if ($frames[$i] -gt 0) { $base = $frames[$i]; break } } }
            $lvl = $base + 1; $frames[$top] = $lvl
            if ($lvl -gt $max) { $max = $lvl }
        }
        $prev = $x.Text
    }
    return $max
}
function Test-N3FormulaHasPersonalLiterals {
    # Erkennt Formeln mit eingebetteten Adress- oder Kontaktdaten (Strassen-, Ort-, E-Mail- und PLZ-Muster, mindestens 3 Treffer).
    # Heuristik: Codes und Kurzwerte (z. B. "791C") gelten nicht als Adressdaten. Das Ergebnis dem Nutzer zeigen.
    param([string]$Formula)
    # Nur Textwerte pruefen: Zahlen ausserhalb von Anfuehrungszeichen (z. B. 22000) sind keine Adressdaten.
    $lits = (([regex]::Matches($Formula, '"(?:[^"\\]|\\.)*"') | ForEach-Object { $_.Value }) -join ' ')
    return ([regex]::Matches($lits, '(Avenue|Street|Road|Boulevard|Lane|Drive|Terminal|Berth|Highway|Parkway|@|[0-9]{5})')).Count -ge 3
}

function ConvertTo-N3PlaceholderFormula {
    # Ersetzt Textwerte in Formeln durch neutrale Platzhalter ("Wert 1", "Wert 2", ...), gleicher Text ergibt gleichen Platzhalter.
    # Struktur, Feldverweise, Zahlen und kurze Werte (bis 3 Zeichen) sowie reine Leerzeichen/Zeilenumbrueche bleiben unveraendert.
    param([Parameter(Mandatory)][string]$Formula)
    $map = @{}
    $ev = [Text.RegularExpressions.MatchEvaluator] {
        param($m)
        $lit = $m.Value; $inner = $lit.Substring(1, $lit.Length - 2)
        if ($inner.Trim().Length -lt 4 -or $inner -notmatch '[A-Za-z0-9]') { return $lit }
        if (-not $map.ContainsKey($inner)) { $map[$inner] = 'Wert ' + ($map.Count + 1) }
        return '"' + $map[$inner] + '"'
    }
    return [regex]::Replace($Formula, '"(?:[^"\\]|\\.)*"', $ev)
}

function Export-Ninox3FormulaAnalysis {
    # Schreibt die volle Fassung nach -Path (enthaelt Formeltexte, nur lokal) und eine bereinigte Fassung nach -SafePath
    # (ohne Formeltexte und ohne Namen von Variablen). Gibt nur eine Zusammenfassung zurueck, nie Formeltexte.
    param([Parameter(Mandatory)]$Schema, [Parameter(Mandatory)]$FieldRows, [Parameter(Mandatory)]$Mapping,
          [Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$SafePath,
          [switch]$LikeUmwandeln)   # nur auf Wunsch: "like" zu contains() (aendert die Bedeutung bei Gross-/Kleinschreibung); Standard: 1:1 behalten
    $rows = foreach ($f in ($FieldRows | Where-Object { $_.IstFormel })) {
        $r = Resolve-Ninox3Formula -Schema $Schema -TypeId $f.TabelleId -Formula $f.Formel -Mapping $Mapping
        $personal = Test-N3FormulaHasPersonalLiterals -Formula $f.Formel
        $lk = if ($LikeUmwandeln) { ConvertTo-N4LikeAlsContains -Formula $r.Rohuebersetzung } else { [pscustomobject]@{ Formel = $r.Rohuebersetzung; Ersetzt = 0 } }
        $zuBauen = if ($personal) { ConvertTo-N3PlaceholderFormula -Formula $lk.Formel } else { $lk.Formel }
        [pscustomobject]@{
            TabelleId = $f.TabelleId; Tabelle = $f.Tabelle; FeldId = $f.FeldId; Beschriftung = $f.Beschriftung
            Status = $r.Status; Anonymisiert = $personal; Tiefe = (Get-N3MaxIfDepth -Formula $zuBauen); LikeErsetzt = $lk.Ersetzt; Funktionen = $r.Funktionen; Unbekannt = $r.Unbekannt; Felder = $r.Felder; Tabellen = $r.Tabellen; Variablen = $r.Variablen
            Original = $f.Formel; Rohuebersetzung = $r.Rohuebersetzung; ZuBauen = $zuBauen
        }
    }
    $rows = @($rows)
    $rows | Export-Csv -Path $Path -NoTypeInformation -Delimiter ';' -Encoding UTF8
    $rows | Select-Object TabelleId, Tabelle, FeldId, Beschriftung, Status, Anonymisiert, Tiefe, LikeErsetzt, Funktionen,
        @{ n = 'AnzahlFelder'; e = { @($_.Felder -split ', ' | Where-Object { $_ }).Count } },
        @{ n = 'AnzahlVariablen'; e = { @($_.Variablen -split ', ' | Where-Object { $_ }).Count } },
        @{ n = 'AnzahlUnbekannt'; e = { @($_.Unbekannt -split ', ' | Where-Object { $_ }).Count } } |
        Export-Csv -Path $SafePath -NoTypeInformation -Delimiter ';' -Encoding UTF8
    return [pscustomobject]@{
        Formeln = $rows.Count
        Aufgeloest = @($rows | Where-Object { $_.Status -eq 'aufgeloest' }).Count
        Pruefen = @($rows | Where-Object { $_.Status -eq 'pruefen' }).Count
        Funktionen = (($rows | ForEach-Object { $_.Funktionen -split ', ' } | Where-Object { $_ } | Sort-Object -Unique) -join ', ')
    }
}
