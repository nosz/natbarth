# Sicherheits- und Vorabpruefungen fuer die Migration (PowerShell 5.1). Gibt nie Geheimnisse oder Datensatzinhalte aus.
#   Get-NinoxKeyQuelle / Test-NinoxKeyHygiene   wo liegt der Key (nur ja/nein und Laenge), Warnung bei dauerhafter Ablage
#   Test-NinoxConfig                            ninox.config.json pruefen (Pflichtfelder, Muster, keine Geheimnisse)
#   Set-NinoxFreigabe / Test-NinoxFreigabe / Assert-NinoxSchreibfreigabe   Freigabe je Phase technisch erzwingen (status.json)
#   Test-NinoxVorabpruefung                     Key, Workspace, Server, Module, Freigabe vor jeder schreibenden Phase
#   Test-NoSecretLeak                           sucht den aktuellen Key-Wert in Dateien (meldet nur Dateinamen)
#   Test-ErgebnisFuerWeitergabe                 prueft ergebnis/ auf Personen- und Firmendaten vor der Weitergabe
#   Add-NinoxProtokollZeile / Write-NinoxFortschritt   sofort protokollieren, Fortschrittsdatei
#   Remove-Ninox4ModulKontrolliert              Loeschen nur mit ausdruecklicher Bestaetigung und nur leere, projekteigene Module
#   Get-NinoxAufraeumListe                      Checkliste fuer den Abschluss

# ---------------------------------------------------------------- Schluessel
function Get-NinoxKeyOrdnerLokal {
    if ($env:NINOX_KEY_ABLAGE) { return $env:NINOX_KEY_ABLAGE }
    return (Join-Path $env:USERPROFILE '.ninox\keys')
}

function Get-NinoxKeyWertAusAblage {
    # Nur intern verwenden, nie ausgeben. Liest den mit ninox-start (Key-einrichten.ps1) verschluesselt abgelegten Key (Windows-DPAPI,
    # nur fuer dieses Konto auf diesem Rechner lesbar). Workspace: Parameter, sonst ninox.config.json im Projektordner oder aktuellen Ordner.
    param([string]$WorkspaceId = '', [string]$ProjectDir = '')
    if (-not $WorkspaceId) {
        $dir = if ($ProjectDir) { $ProjectDir } else { (Get-Location).Path }; $cfg = Join-Path $dir 'ninox.config.json'
        if (Test-Path -LiteralPath $cfg) { try { $WorkspaceId = (Get-Content -LiteralPath $cfg -Raw -Encoding UTF8 | ConvertFrom-Json).workspaceId } catch { } }
    }
    if (-not $WorkspaceId) { return $null }
    $f = Join-Path (Get-NinoxKeyOrdnerLokal) "$WorkspaceId.key"
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try {
        $s = ConvertTo-SecureString (Get-Content -LiteralPath $f -Raw -Encoding UTF8).Trim()
        $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
    } catch { return $null }
}

function Get-NinoxAlleKeyWerte {
    # Nur intern verwenden, nie ausgeben: alle bekannten Keys (Ablage aller Workspaces und Umgebungsvariablen) fuer die Geheimnis-Suche.
    $l = New-Object Collections.Generic.List[string]
    $dir = Get-NinoxKeyOrdnerLokal
    if (Test-Path -LiteralPath $dir) { foreach ($f in Get-ChildItem -LiteralPath $dir -Filter '*.key' -File) { $k = Get-NinoxKeyWertAusAblage -WorkspaceId ([IO.Path]::GetFileNameWithoutExtension($f.Name)); if ($k -and -not $l.Contains($k)) { $l.Add($k) } } }
    foreach ($s in 'User', 'Process') { $v = [Environment]::GetEnvironmentVariable('NINOX_API_KEY', $s); if ($v -and -not $l.Contains($v)) { $l.Add($v) } }
    return $l.ToArray()
}

function Get-NinoxKeyQuelle {
    param([string]$ProjectDir = '')
    $p = [Environment]::GetEnvironmentVariable('NINOX_API_KEY', 'Process'); $u = [Environment]::GetEnvironmentVariable('NINOX_API_KEY', 'User'); $m = [Environment]::GetEnvironmentVariable('NINOX_API_KEY', 'Machine')
    $a = Get-NinoxKeyWertAusAblage -ProjectDir $ProjectDir
    [pscustomobject]@{
        InAblage = [bool]$a; LaengeAblage = if ($a) { $a.Length } else { 0 }
        ImProzess = [bool]$p; LaengeProzess = if ($p) { $p.Length } else { 0 }
        AlsBenutzervariable = [bool]$u; LaengeBenutzer = if ($u) { $u.Length } else { 0 }
        AlsComputervariable = [bool]$m
        ProzessGleichBenutzer = ([bool]$p -and [bool]$u -and ($p -ceq $u))
    }
}

function Get-NinoxKeyWert {
    # Nur intern verwenden, nie ausgeben. Reihenfolge: 1. verschluesselte Ablage fuer den Workspace der Konfiguration (genau der richtige Key),
    # 2. Benutzervariable (aktueller als ein geerbter Prozesswert), 3. Prozessvariable.
    param([string]$ProjectDir = '')
    $a = Get-NinoxKeyWertAusAblage -ProjectDir $ProjectDir; if ($a) { return $a }
    $u = [Environment]::GetEnvironmentVariable('NINOX_API_KEY', 'User'); if ($u) { return $u }
    return [Environment]::GetEnvironmentVariable('NINOX_API_KEY', 'Process')
}

function Test-NinoxKeyHygiene {
    param([string]$ProjectDir = '')
    $q = Get-NinoxKeyQuelle -ProjectDir $ProjectDir
    if (-not $q.InAblage -and -not $q.ImProzess -and -not $q.AlsBenutzervariable) { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'Kein Key gefunden. Im eigenen PowerShell-Fenster Key-einrichten.ps1 (Skill ninox-start) ausfuehren.' }; return }
    if ($q.AlsBenutzervariable -and -not $q.InAblage) { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = 'Der Key liegt dauerhaft und unverschluesselt als Windows-Benutzervariable im Profil. Besser: Key-einrichten.ps1 (verschluesselte Ablage) nutzen, danach die Variable loeschen. Nur fuer einen kurzlebigen Test-Key vertretbar.' } }
    if ($q.AlsBenutzervariable -and $q.InAblage) { [pscustomobject]@{ Stufe = 'Hinweis'; Meldung = 'Der Key liegt verschluesselt in der Ablage UND zusaetzlich als Benutzervariable. Die Benutzervariable ist nicht mehr noetig und sollte geloescht werden.' } }
    if ($q.AlsComputervariable) { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = 'Der Key ist fuer alle Benutzer dieses Rechners gesetzt (Computervariable). Entfernen.' } }
    if ($q.ImProzess -and $q.AlsBenutzervariable -and -not $q.ProzessGleichBenutzer) { [pscustomobject]@{ Stufe = 'Hinweis'; Meldung = 'Prozess- und Benutzervariable haben verschiedene Werte. Die Skripte verwenden die Ablage, sonst den Wert der Benutzervariable. Pruefen, ob das der richtige Key ist.' } }
    $len = if ($q.InAblage) { $q.LaengeAblage } else { [Math]::Max($q.LaengeProzess, $q.LaengeBenutzer) }
    if ($len -lt 20 -or $len -gt 120) { [pscustomobject]@{ Stufe = 'Hinweis'; Meldung = "Ungewoehnliche Key-Laenge ($len). Pruefen, ob der Key vollstaendig geladen wurde." } }
}
# ---------------------------------------------------------------- Konfiguration
function Test-NinoxConfig {
    param([Parameter(Mandatory)][string]$ProjectDir)
    $p = Join-Path $ProjectDir 'ninox.config.json'
    if (-not (Test-Path -LiteralPath $p)) { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'ninox.config.json fehlt' }; return }
    try { $c = Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json } catch { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'ninox.config.json ist kein gueltiges JSON' }; return }
    if ($c.apiBase -ne 'https://go.ninox.com') { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = "apiBase ist '$($c.apiBase)' (erwartet https://go.ninox.com)" } }
    if (-not $c.workspaceName) { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = 'workspaceName (Klarname des Workspace) fehlt in ninox.config.json: Der Nutzer muss in jeder Anleitung den Namen sehen, nicht nur die ID' } }
    if ($c.workspaceId -notmatch '^[a-z0-9]{8,20}$') { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'workspaceId fehlt oder hat ein ungueltiges Muster' } }
    if ($c.moduleName -notmatch '^[a-z0-9_]{1,100}$') { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'moduleName fehlt oder entspricht nicht ^[a-z0-9_]+$' } }
    if ($c.migration) {
        if ($c.migration.docModuleName -and $c.migration.docModuleName -notmatch '^[a-z0-9_]{1,100}$') { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'docModuleName ungueltig' } }
        if ($c.migration.docModuleName -and $c.migration.docModuleName -eq $c.moduleName) { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'docModuleName und moduleName muessen verschieden sein' } }
        foreach ($k in 'sourceFile', 'sourceFileWithData') { $v = $c.migration.$k; if ($v -and -not (Test-Path -LiteralPath $v)) { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = "$k zeigt auf eine nicht vorhandene Datei" } } }
        if ($c.migration.sampleSize -and ([int]$c.migration.sampleSize -lt 1 -or [int]$c.migration.sampleSize -gt 1000)) { [pscustomobject]@{ Stufe = 'Warnung'; Meldung = 'sampleSize ausserhalb von 1 bis 1000' } }
    }
    $json = Get-Content $p -Raw -Encoding UTF8
    if ($json -match '(?i)"[^"]*(api.?key|token|passw|secret)[^"]*"\s*:\s*"[^"]{8,}') { [pscustomobject]@{ Stufe = 'Fehler'; Meldung = 'Die Konfiguration enthaelt vermutlich ein Geheimnis. Entfernen und den Key widerrufen.' } }
}

# ---------------------------------------------------------------- Freigabe (technisch erzwingen)
function Set-NinoxFreigabe {
    # Erst aufrufen, NACHDEM der Nutzer im Chat ausdruecklich zugestimmt hat. Haelt Phase, Workspace und Module fest.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Phase, [Parameter(Mandatory)][string]$WorkspaceId,
          [Parameter(Mandatory)][string[]]$Module, [Parameter(Mandatory)][string]$Text)
    $f = Join-Path $ProjectDir 'ergebnis\status.json'
    $st = if (Test-Path $f) { Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json } else { [pscustomobject]@{ freigaben = @() } }
    $liste = @(); if ($st.PSObject.Properties.Name -contains 'freigaben') { $liste = @($st.freigaben) }
    $liste += [pscustomobject]@{ phase = $Phase; workspaceId = $WorkspaceId; module = @($Module); text = $Text; datum = (Get-Date -Format 'yyyy-MM-dd HH:mm') }
    if ($st.PSObject.Properties.Name -contains 'freigaben') { $st.freigaben = $liste } else { $st | Add-Member -NotePropertyName freigaben -NotePropertyValue $liste }
    New-Item -ItemType Directory -Force -Path (Split-Path $f) | Out-Null
    [IO.File]::WriteAllText($f, ($st | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
}

function Test-NinoxFreigabe {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Phase, [Parameter(Mandatory)][string]$WorkspaceId, [Parameter(Mandatory)][string]$Modul)
    $f = Join-Path $ProjectDir 'ergebnis\status.json'
    if (-not (Test-Path $f)) { return $false }
    $st = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not ($st.PSObject.Properties.Name -contains 'freigaben')) { return $false }
    foreach ($x in @($st.freigaben)) {
        if ($x.phase -eq $Phase -and $x.workspaceId -eq $WorkspaceId -and (@($x.module) -contains $Modul)) { return $true }
    }
    return $false
}

function Assert-NinoxSchreibfreigabe {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Phase, [Parameter(Mandatory)][string]$Modul)
    $c = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not (Test-NinoxFreigabe -ProjectDir $ProjectDir -Phase $Phase -WorkspaceId $c.workspaceId -Modul $Modul)) {
        throw "Keine Freigabe fuer Phase $Phase, Workspace $($c.workspaceId), Modul $Modul in ergebnis\status.json. Erst die ausdrueckliche Zustimmung des Nutzers im Chat einholen und mit Set-NinoxFreigabe festhalten."
    }
}

# ---------------------------------------------------------------- Vorabpruefung
function Test-NinoxVorabpruefung {
    # Prueft alles, was vor einer schreibenden Phase stimmen muss. Schreibt nichts. Gibt eine Tabelle mit Ergebnis und Hinweis zurueck.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$HelpersPath, [Parameter(Mandatory)][int]$Phase,
          [string[]]$ModuleMuessenFreiSein = @(), [string[]]$ModuleMuessenExistieren = @(), [int]$MaxAntwortMs = 5000)
    $rows = New-Object Collections.Generic.List[object]
    $add = { param($n, $ok, $h) $rows.Add([pscustomobject]@{ Pruefung = $n; Ergebnis = $(if ($ok) { 'ok' } else { 'FEHLER' }); Hinweis = $h }) }
    $cfgIssues = @(Test-NinoxConfig -ProjectDir $ProjectDir | Where-Object { $_.Stufe -eq 'Fehler' })
    & $add 'Konfiguration' ($cfgIssues.Count -eq 0) $(if ($cfgIssues.Count) { ($cfgIssues | ForEach-Object { $_.Meldung }) -join ' | ' } else { '' })
    $key = Get-NinoxKeyWert -ProjectDir $ProjectDir
    & $add 'Key gesetzt' ([bool]$key) $(if (-not $key) { 'Key-einrichten.ps1 (Skill ninox-start) im eigenen PowerShell-Fenster ausfuehren (geprueft wird nur ja/nein und die Laenge).' } else { "Laenge $($key.Length)" })
    if (-not $key -or $cfgIssues.Count) { return $rows }
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    & $add "Freigabe fuer Phase $Phase" (Test-NinoxFreigabe -ProjectDir $ProjectDir -Phase $Phase -WorkspaceId $cfg.workspaceId -Modul $cfg.moduleName) 'Ohne ausdrueckliche Zustimmung im Chat und Set-NinoxFreigabe wird nicht geschrieben.'
    Set-Location $ProjectDir; $env:NINOX_API_KEY = $key; . $HelpersPath
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $sw = [Diagnostics.Stopwatch]::StartNew(); $mods = $null
    try { $mods = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path '/modules'))['data'] | ForEach-Object { $_['name'] }); $ms = [int]$sw.Elapsed.TotalMilliseconds
        & $add 'Server antwortet, Key gilt fuer den Workspace' $true "$ms ms; $($mods.Count) Module"
        & $add 'Antwortzeit' ($ms -le $MaxAntwortMs) $(if ($ms -gt $MaxAntwortMs) { "Der Server ist langsam ($ms ms). Mit Pausen schreiben oder spaeter versuchen." } else { '' })
    } catch {
        $m = $_.Exception.Message
        $hint = if ($m -match 'not authorized for workspace') { 'Der Key gehoert zu einem anderen Workspace. Key im richtigen Workspace erzeugen und neu laden.' }
        elseif ($m -match '401|403|nicht autorisiert|Unauthorized|Forbidden') { 'Der Key fehlt, ist falsch, abgelaufen oder hat zu wenige Rechte.' }
        elseif ($m -match 'upstream connect|Connection refused|502|503|504|429|concurrent write') { 'Ninox antwortet gerade nicht oder ist ausgelastet. Spaeter erneut versuchen; bei Dauerstoerung die Supportmeldung (ninox-support.ps1) nutzen.' }
        elseif ($m -match '404') { 'Workspace-ID falsch (zweites Stueck der Ninox-Adresse).' }
        else { 'Unbekannter Fehler, siehe Meldung.' }
        & $add 'Server antwortet, Key gilt fuer den Workspace' $false "$hint ($($m.Substring(0, [Math]::Min(160, $m.Length))))"
        return $rows
    }
    foreach ($n in $ModuleMuessenFreiSein) { & $add "Modul '$n' ist frei" ($mods -notcontains $n) $(if ($mods -contains $n) { 'Das Modul existiert schon und wird nicht veraendert.' } else { '' }) }
    foreach ($n in $ModuleMuessenExistieren) { & $add "Modul '$n' existiert" ($mods -contains $n) '' }
    return $rows
}

# ---------------------------------------------------------------- Geheimnis-Suche
function Test-NoSecretLeak {
    # Sucht den aktuellen Key-Wert in allen Textdateien unter den Pfaden. Gibt nur Dateinamen zurueck, nie den Wert.
    param([Parameter(Mandatory)][string[]]$Pfade, [long]$MaxBytes = 80MB, [string]$KeyWert)
    $keys = if ($KeyWert) { @($KeyWert) } else { @(Get-NinoxAlleKeyWerte) }
    if ($keys.Count -eq 0) { [pscustomobject]@{ Datei = ''; Ergebnis = 'uebersprungen (kein Key gefunden)' }; return }
    $skip = '\.(ninox|skill|zip|png|jpg|jpeg|gif|pdf|exe|dll)$'
    $hits = 0
    foreach ($root in $Pfade) {
        foreach ($f in (Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue)) {
            if ($f.Name -match $skip -or $f.Length -gt $MaxBytes) { continue }
            try { $t = [IO.File]::ReadAllText($f.FullName) } catch { continue }
            foreach ($key in $keys) { if ($t.IndexOf($key, [StringComparison]::Ordinal) -ge 0) { $hits++; [pscustomobject]@{ Datei = $f.FullName; Ergebnis = 'TREFFER: enthaelt den Key' }; break } }
        }
    }
    if ($hits -eq 0) { [pscustomobject]@{ Datei = ''; Ergebnis = 'kein Treffer' } }
}

# ---------------------------------------------------------------- Weitergabe-Pruefung
function Test-ErgebnisFuerWeitergabe {
    # Prueft Dateien (ergebnis/) vor der Weitergabe nach aussen. Meldet Datei, Zeile und Art, nie den Treffertext.
    param([Parameter(Mandatory)][string]$Pfad, [string[]]$Woerter = @())
    $muster = [ordered]@{
        'E-Mail-Adresse' = '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
        'Telefonnummer' = '(\+\d{1,3}[ -]?)?\(?\d{2,4}\)?[ -]\d{3,4}[ -]\d{3,5}'
        'Adressmuster' = '\b\d{1,5} +[A-Z][a-z]+ +(Avenue|Street|Road|Boulevard|Lane|Drive|Strasse|Weg|Allee)\b|\b(Avenue|Street|Road|Boulevard)\b.*\b\d{5}\b'
        'API-Key-aehnlich' = '\b(?=[A-Za-z0-9_-]*[0-9])(?=[A-Za-z0-9_-]*[a-z])[A-Za-z0-9_-]{40,}\b'
    }
    $found = New-Object Collections.Generic.List[object]
    foreach ($f in (Get-ChildItem -LiteralPath $Pfad -Recurse -File | Where-Object { $_.Extension -in '.csv', '.md', '.txt', '.json' })) {
        $n = 0
        foreach ($line in [IO.File]::ReadLines($f.FullName)) {
            $n++
            foreach ($k in $muster.Keys) { if ([regex]::IsMatch($line, $muster[$k])) { $found.Add([pscustomobject]@{ Datei = $f.Name; Zeile = $n; Art = $k }) } }
            foreach ($w in $Woerter) { if ($w -and $line.IndexOf($w, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $found.Add([pscustomobject]@{ Datei = $f.Name; Zeile = $n; Art = 'Wortliste' }) } }
        }
    }
    return [pscustomobject]@{ Bestanden = ($found.Count -eq 0); Treffer = $found.ToArray() | Group-Object Datei, Art | ForEach-Object { [pscustomobject]@{ Datei = $_.Group[0].Datei; Art = $_.Group[0].Art; Anzahl = $_.Count; ErsteZeile = $_.Group[0].Zeile } } }
}

# ---------------------------------------------------------------- Protokoll sofort, Fortschritt
function Add-NinoxProtokollZeile {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Phase, [Parameter(Mandatory)][string]$Aktion, [string]$Ziel = '', $Anzahl = '', [string]$Ergebnis = '', [string]$Freigabe = '')
    $dir = Join-Path $ProjectDir 'ergebnis'; New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $f = Join-Path $dir 'schreibprotokoll.csv'
    $o = [pscustomobject]@{ Zeit = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); Phase = $Phase; Aktion = $Aktion; Ziel = $Ziel; Anzahl = $Anzahl; Ergebnis = $Ergebnis; Freigabe = $Freigabe }
    $csv = @($o | ConvertTo-Csv -NoTypeInformation -Delimiter ';')
    $enc = New-Object Text.UTF8Encoding($false)
    if (-not (Test-Path $f)) { [IO.File]::WriteAllText($f, ($csv[0] + "`r`n" + $csv[1] + "`r`n"), (New-Object Text.UTF8Encoding($true))) }
    else { [IO.File]::AppendAllText($f, ($csv[1] + "`r`n"), $enc) }
}

function Write-NinoxFortschritt {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Phase, [string]$Schritt, [int]$Aktuell = 0, [int]$Gesamt = 0, [string]$Status = 'laeuft', [string]$LetzterFehler = '')
    $f = Join-Path $ProjectDir 'ergebnis\fortschritt.json'
    $o = [ordered]@{ phase = $Phase; schritt = $Schritt; aktuell = $Aktuell; gesamt = $Gesamt; status = $Status; letzterFehler = $LetzterFehler; zeit = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
    [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
}

# ---------------------------------------------------------------- Kontrolliertes Loeschen
function Remove-Ninox4ModulKontrolliert {
    # Loescht ein Modul nur, wenn: Bestaetigung exakt 'Ja, loeschen'; Modulname gehoert zum Projekt (Ziel-, Doku- oder Probe-Modul zz_probe_*);
    # das Modul enthaelt 0 Datensaetze. Nichts anderes. Protokolliert.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$HelpersPath, [Parameter(Mandatory)][string]$Modul, [Parameter(Mandatory)][string]$Bestaetigt)
    if ($Bestaetigt -cne 'Ja, loeschen') { throw "Nicht bestaetigt. Loeschen braucht die ausdrueckliche Antwort des Nutzers 'Ja, loeschen' fuer das Modul '$Modul'." }
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $erlaubt = @($cfg.moduleName, $cfg.migration.docModuleName) | Where-Object { $_ }
    if (($erlaubt -notcontains $Modul) -and ($Modul -notmatch '^zz_probe_')) { throw "Das Modul '$Modul' gehoert nicht zu diesem Projekt (erlaubt: $($erlaubt -join ', '), zz_probe_*). Es wird nicht geloescht." }
    Set-Location $ProjectDir; $env:NINOX_API_KEY = Get-NinoxKeyWert; . $HelpersPath
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $mods = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path '/modules'))['data'] | ForEach-Object { $_['name'] })
    if ($mods -notcontains $Modul) { throw "Das Modul '$Modul' existiert nicht." }
    $summe = 0
    foreach ($t in @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$Modul/tables"))['data'] | ForEach-Object { $_['name'] })) {
        $summe += @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$Modul/tables/$t/records?limit=1"))['data']).Count
    }
    if ($summe -gt 0) { throw "Das Modul '$Modul' enthaelt Datensaetze. Abbruch, nichts geloescht. Module mit Daten nur von Hand oder mit dem Support loeschen." }
    $null = Invoke-Ninox -Method Delete -Path "/modules/$Modul"
    $nach = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path '/modules'))['data'] | ForEach-Object { $_['name'] })
    Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 0 -Aktion 'Modul loeschen (leer, bestaetigt)' -Ziel "$($cfg.workspaceId)/$Modul" -Anzahl 1 -Ergebnis $(if ($nach -notcontains $Modul) { 'OK' } else { 'FEHLER' }) -Freigabe 'Ja, loeschen (Chat)'
    return [pscustomobject]@{ Modul = $Modul; Geloescht = ($nach -notcontains $Modul); ModuleVerbleibend = ($nach -join ', ') }
}

# ---------------------------------------------------------------- Aufraeumen
function Get-NinoxAufraeumListe {
    param([string]$ProjectDir = '')
    $q = Get-NinoxKeyQuelle -ProjectDir $ProjectDir
    @(
        [pscustomobject]@{ Nr = 1; Schritt = 'Test-Key in Ninox widerrufen (Einstellungen, API und Integrationen, Key oeffnen, widerrufen). Auch alte Keys ohne Ablauf oder mit Rechteverwaltung.'; Wer = 'Nutzer'; Pruefung = 'nicht pruefbar, Nutzer bestaetigt' }
        [pscustomobject]@{ Nr = 2; Schritt = 'Abgelegten Key entfernen: Remove-NinoxKey -WorkspaceId <id> (Skill ninox-start, ninox-key.ps1) und, falls je gesetzt, die Benutzervariable NINOX_API_KEY loeschen: [Environment]::SetEnvironmentVariable(''NINOX_API_KEY'', $null, ''User'')'; Wer = 'Nutzer (eigenes Terminal)'; Pruefung = $(if ($q.InAblage) { 'Key noch in der Ablage' } elseif ($q.AlsBenutzervariable) { 'Benutzervariable noch gesetzt' } else { 'nichts mehr abgelegt' }) }
        [pscustomobject]@{ Nr = 3; Schritt = 'Key-Eintrag in Bitwarden loeschen oder als widerrufen markieren'; Wer = 'Nutzer'; Pruefung = 'nicht pruefbar, Nutzer bestaetigt' }
        [pscustomobject]@{ Nr = 4; Schritt = 'Wegwerf-Module (zz_probe_*) loeschen oder behalten, Entscheidung des Nutzers'; Wer = 'Nutzer entscheidet'; Pruefung = 'Remove-Ninox4ModulKontrolliert' }
        [pscustomobject]@{ Nr = 5; Schritt = 'Ordner arbeit/ (entpackte Sicherungen, volle Inventare, Stichprobe) loeschen oder verschluesselt ablegen'; Wer = 'Nutzer entscheidet'; Pruefung = $(if ($ProjectDir -and ((Test-Path (Join-Path $ProjectDir 'arbeit')) -or (Test-Path (Join-Path $ProjectDir 'v2\arbeit')))) { 'vorhanden (auch v2/arbeit mit Kopien der Daten)' } else { 'nicht vorhanden' }) }
        [pscustomobject]@{ Nr = 6; Schritt = 'Test-NoSecretLeak ueber Projektordner und Skillordner: kein Key in Dateien'; Wer = 'Skill'; Pruefung = 'Test-NoSecretLeak' }
        [pscustomobject]@{ Nr = 7; Schritt = 'ergebnis/ vor Weitergabe pruefen (Test-ErgebnisFuerWeitergabe), Pruefsumme der Abnahmeunterlagen festhalten'; Wer = 'Skill'; Pruefung = 'Test-ErgebnisFuerWeitergabe' }
    )
}

function Test-NinoxSkillFuerWeitergabe {
    # Prueft den SKILLORDNER vor der Weitergabe an Kollegen (nur lesend, gibt nie Dateiinhalte aus):
    # SKILL.md mit Name und Beschreibung, keine Projekt- oder Datenordner (arbeit, ergebnis, sicherung, v2, ziel), keine Daten- oder Archivdateien
    # (.db .csv .ninox .zip .xlsx), kein Key, keine fremden E-Mail-Adressen (erlaubt: it@ninox.com und erfundene Adressen mit .invalid/example),
    # Selbsttest vorhanden. Rueckgabe: Pruefungen und Gesamtergebnis Bestanden.
    param([Parameter(Mandatory)][string]$SkillDir, [switch]$OhneSelbsttest)
    $rows = New-Object Collections.Generic.List[object]
    $add = { param($p, $ok, $d) $rows.Add([pscustomobject]@{ Pruefung = $p; Ergebnis = $(if ($ok) { 'ok' } else { 'FEHLER' }); Detail = $d }) }
    if (-not (Test-Path -LiteralPath $SkillDir)) { throw "Skillordner nicht gefunden: $SkillDir" }
    $sm = Join-Path $SkillDir 'SKILL.md'
    $kopf = if (Test-Path $sm) { (Get-Content $sm -TotalCount 6 -Encoding UTF8) -join "`n" } else { '' }
    & $add 'SKILL.md mit name und description' (($kopf -match '(?m)^name:\s*\S') -and ($kopf -match '(?m)^description:\s*\S')) ''
    $bad = @('arbeit', 'ergebnis', 'sicherung', 'v2', 'ziel') | Where-Object { Test-Path -LiteralPath (Join-Path $SkillDir $_) }
    & $add 'keine Projekt- oder Datenordner im Skill' (@($bad).Count -eq 0) (@($bad) -join ', ')
    $files = @(Get-ChildItem -LiteralPath $SkillDir -Recurse -File -Force)
    $daten = @($files | Where-Object { $_.Extension -in '.db', '.csv', '.ninox', '.zip', '.xlsx' })
    & $add 'keine Daten- oder Archivdateien' ($daten.Count -eq 0) (@($daten | ForEach-Object { $_.Name }) -join ', ')
    $g = @(Test-NoSecretLeak -Pfade @($SkillDir) | Where-Object { $_.Ergebnis -ne 'kein Treffer' -and $_.Ergebnis -notlike 'uebersprungen*' })
    & $add 'kein Key und kein Geheimnis in den Dateien' ($g.Count -eq 0) ("$($g.Count) Treffer")
    $fremd = New-Object Collections.Generic.List[string]
    foreach ($f in ($files | Where-Object { $_.Extension -in '.md', '.ps1', '.json', '.txt' })) {
        foreach ($m in (Select-String -LiteralPath $f.FullName -Pattern '[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[a-z]{2,}' -AllMatches -Encoding UTF8)) {
            foreach ($x in $m.Matches) { if ($x.Value -notmatch '^it@ninox\.com$' -and $x.Value -notmatch '\.invalid$|@example\.') { $fremd.Add("$($f.Name)") } }
        }
    }
    & $add 'keine fremden E-Mail-Adressen (erlaubt: it@ninox.com und erfundene)' ($fremd.Count -eq 0) (($fremd | Select-Object -Unique) -join ', ')
    if (-not $OhneSelbsttest) { & $add 'Selbsttest vorhanden' (Test-Path (Join-Path $SkillDir 'scripts\selftest.ps1')) '' }
    return [pscustomobject]@{ Bestanden = (@($rows | Where-Object { $_.Ergebnis -ne 'ok' }).Count -eq 0); Pruefungen = $rows.ToArray() }
}