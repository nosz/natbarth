# Phase 7: Optimierungsbefunde mit Daten belegen. NUR LESEND und lokal (liest nur die Ninox-3-Sicherung), schreibt NUR Zaehler, nie Inhalte.
# Nutzung: . .\scripts\ninox3-reader.ps1; . .\scripts\ninox3-optimierung.ps1
#   Get-Ninox3OptimierungBelege -Schema $schema -DataDb <mit\data.db> -FormelAnalyse <arbeit\inventar\08_formel_analyse_voll.csv> -OutDir <ergebnis>
# Ergebnis: ergebnis\16_beleg_auswahlfelder.csv, 17_beleg_fuellgrad.csv, 18_beleg_formelketten.csv, 19_beleg_tabellen.csv (nur Zahlen und Feldbeschriftungen)

function Get-Ninox3OptimierungBelege {
    param([Parameter(Mandatory)]$Schema, [Parameter(Mandatory)][string]$DataDb, [Parameter(Mandatory)][string]$FormelAnalyse, [Parameter(Mandatory)][string]$OutDir,
          [int]$MinOptionen = 12, [int]$MinFelderBreit = 40, [int]$MinKette = 4)
    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.Web.Extensions
    $js = New-Object Web.Script.Serialization.JavaScriptSerializer; $js.MaxJsonLength = [int]::MaxValue
    $types = $Schema['types']
    $isData = { param($fd) -not $fd.ContainsKey('fn') -and $fd['base'] -ne 'rev' }

    # Formelketten: welche Felder stehen in langen Formeln (Spalte Felder, z. B. D.O2)?
    $fa = @(Import-Csv $FormelAnalyse -Delimiter ';' -Encoding UTF8 | Where-Object { [int]$_.LikeErsetzt -ge $MinKette -or [int]$_.Tiefe -ge $MinKette })
    $kettenFelder = @{}
    foreach ($r in $fa) { foreach ($k in @($r.Felder -split '[,; ]+' | Where-Object { $_ -match '^[A-Za-z]+\.[A-Za-z0-9]+$' })) { $kettenFelder[$k] = 1 } }

    # Durchgang ueber die Daten: Zaehler je Tabelle, je Feld (gefuellt), je Auswahl-/Kettenfeld (Wert)
    $recs = @{}; $filled = @{}; $vals = @{}
    $watch = @{}
    foreach ($t in $types.Keys) { foreach ($f in $types[$t]['fields'].GetEnumerator()) {
            $key = "$t.$($f.Key)"
            if ((& $isData $f.Value) -and ($f.Value['base'] -eq 'choice' -and $f.Value['values'].Count -ge $MinOptionen -or $kettenFelder.ContainsKey($key))) { $watch[$key] = 1; $vals[$key] = @{} } } }
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.Length -gt 2 -and $l[0] -eq 'U' -and $l -match '^U([A-Za-z]+)(\d+):') {
                $t = $Matches[1]; if (-not $types.ContainsKey($t)) { continue }
                $recs[$t] = 1 + [int]$recs[$t]
                $o = $js.DeserializeObject($l.Substring($l.IndexOf(':') + 1))
                foreach ($k in $o.Keys) {
                    $v = $o[$k]; if ($null -eq $v -or "$v" -eq '') { continue }
                    $fk = "$t.$k"; $filled[$fk] = 1 + [int]$filled[$fk]
                    if ($watch.ContainsKey($fk)) { $vv = "$v"; $vals[$fk][$vv] = 1 + [int]$vals[$fk][$vv] }
                }
            }
        }
    } finally { $sr.Close() }

    $lab = { param($t, $k) $types[$t]['fields'][$k]['caption'] }
    # 1. Auswahlfelder
    $A = foreach ($t in $types.Keys) { foreach ($f in $types[$t]['fields'].GetEnumerator()) {
            if ($f.Value['base'] -ne 'choice' -or $f.Value['values'].Count -lt $MinOptionen) { continue }
            $fk = "$t.$($f.Key)"; $n = [int]$filled[$fk]; $used = $vals[$fk].Count
            $top = if ($used -gt 0) { ($vals[$fk].Values | Measure-Object -Maximum).Maximum } else { 0 }
            [pscustomobject]@{ Tabelle = $types[$t]['caption']; Feld = $f.Value['caption']; Optionen = $f.Value['values'].Count; Verwendet = $used; NieGenutzt = $f.Value['values'].Count - $used
                Datensaetze = $recs[$t]; MitWert = $n; MitWertProzent = $(if ($recs[$t]) { [Math]::Round(100.0 * $n / $recs[$t], 1) } else { 0 }); HaeufigsterWertProzent = $(if ($n) { [Math]::Round(100.0 * $top / $n, 1) } else { 0 }) } } }
    $A | Sort-Object Optionen -Descending | Export-Csv (Join-Path $OutDir '16_beleg_auswahlfelder.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    # 2. Fuellgrad breiter Tabellen
    $B = foreach ($t in $types.Keys) {
        $df = @($types[$t]['fields'].GetEnumerator() | Where-Object { & $isData $_.Value }); if ($df.Count -lt $MinFelderBreit) { continue }
        $pcts = @($df | ForEach-Object { if ($recs[$t]) { 100.0 * [int]$filled["$t.$($_.Key)"] / $recs[$t] } else { 0 } })
        [pscustomobject]@{ Tabelle = $types[$t]['caption']; Datenfelder = $df.Count; Datensaetze = $recs[$t]; FelderNieGefuellt = @($pcts | Where-Object { $_ -eq 0 }).Count; FelderUnter5Prozent = @($pcts | Where-Object { $_ -gt 0 -and $_ -lt 5 }).Count
            Felder5Bis50Prozent = @($pcts | Where-Object { $_ -ge 5 -and $_ -lt 50 }).Count; FelderAb50Prozent = @($pcts | Where-Object { $_ -ge 50 }).Count } }
    @($B) | Export-Csv (Join-Path $OutDir '17_beleg_fuellgrad.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    # 3. Formelketten
    $C = foreach ($r in $fa) {
        $flds = @($r.Felder -split '[,; ]+' | Where-Object { $_ -match '^[A-Za-z]+\.[A-Za-z0-9]+$' -and $vals.ContainsKey($_) })
        $txt = ($flds | ForEach-Object { $t, $k = $_.Split('.'); "$(& $lab $t $k)=$($vals[$_].Count) verschiedene Werte" }) -join '; '
        [pscustomobject]@{ Tabelle = $r.Tabelle; Formel = $r.Beschriftung; IfZweige = [int]$r.Tiefe; LikeVergleiche = [int]$r.LikeErsetzt; GenutzteEingaben = $txt } }
    @($C) | Export-Csv (Join-Path $OutDir '18_beleg_formelketten.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    # 4. Tabellen: leer oder winzig
    $D = foreach ($t in $types.Keys) { if ([int]$recs[$t] -le 2) { [pscustomobject]@{ Tabelle = $types[$t]['caption']; Datensaetze = [int]$recs[$t]; Felder = $types[$t]['fields'].Count } } }
    @($D) | Export-Csv (Join-Path $OutDir '19_beleg_tabellen.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    return [pscustomobject]@{ Auswahlfelder = @($A).Count; BreiteTabellen = @($B).Count; Formelketten = @($C).Count; KleineTabellen = @($D).Count }
}
