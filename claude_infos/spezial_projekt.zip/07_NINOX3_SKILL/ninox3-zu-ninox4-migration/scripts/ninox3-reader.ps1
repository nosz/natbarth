# Liest Ninox-3-Sicherungen (.ninox) rein lokal und erzeugt Inventar, Mapping-Vorschlag und Befunde.
# PowerShell 5.1. Kein Netzwerkzugriff, keine Zugangsdaten, schreibt nur in den angegebenen Ausgabeordner.
# Nutzung:  . .\scripts\ninox3-reader.ps1
#
# Format (am Beispiel verifiziert, siehe references/ninox3-exportformat.md):
#   .ninox = ZIP mit data.db, settings.json, backup.json, reports/<id>/report.json
#   data.db = zeilenbasiert:  "s:{Schema-JSON}"  |  "V<id>:{Ansicht-JSON}"  |  "U<TabellenId><Nr>:{Datensatz-JSON}"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Web.Extensions

$script:N3Json = New-Object Web.Script.Serialization.JavaScriptSerializer
$script:N3Json.MaxJsonLength = [int]::MaxValue
$script:N3Json.RecursionLimit = 1000

# Schluessel, die nur die Darstellung betreffen (werden nicht einzeln gemeldet).
$script:N3PresentationKeys = @(
    'captions', 'order', 'tooltips', 'tooltip', 'uuid', 'formWidth', 'width', 'height', 'labelPosition',
    'stringAutocorrect', 'fileHandling', 'bgSize', 'choiceRenderer', 'multiRenderer', 'reverseRenderer',
    'referenceRenderer', 'referenceFormat', 'booleanRenderer', 'style', 'viewConfig', 'numberFormat',
    'dateCalendar', 'dateYearly', 'dateCalendarColor', 'dateCalendarFormat', 'linkPreview', 'nextChoiceId',
    'caption', 'base')
# Schluessel mit fachlicher Bedeutung, die der Skill gezielt auswertet.
$script:N3SemanticKeys = @(
    'required', 'hasIndex', 'globalSearch', 'fn', 'values', 'refTypeId', 'refFieldId', 'cascade',
    'readRoles', 'writeRoles', 'visibility', 'canWrite', 'fieldType', 'stringMultiline')

function Get-N3Value {
    param($Dict, [string]$Key, $Default = $null)
    if ($null -ne $Dict -and $Dict -is [Collections.IDictionary] -and $Dict.ContainsKey($Key)) { return $Dict[$Key] }
    return $Default
}

function ConvertTo-N3Text {
    param($Value)
    if ($null -eq $Value) { return '' }
    if ($Value -is [array]) { return ($Value -join ',') }
    return "$Value"
}

# ---------------------------------------------------------------- Archiv

function Expand-Ninox3Archive {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Destination,
        [switch]$Force)
    if (-not (Test-Path -LiteralPath $Path)) { throw "Datei nicht gefunden: $Path" }
    $dest = [IO.Path]::GetFullPath($Destination)
    if ((Test-Path -LiteralPath $dest) -and (Get-ChildItem -LiteralPath $dest -Force | Select-Object -First 1) -and -not $Force) {
        throw "Zielordner ist nicht leer: $dest (mit -Force erneut ausfuehren)"
    }
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $zip = [IO.Compression.ZipFile]::OpenRead((Resolve-Path -LiteralPath $Path).Path)
    try {
        foreach ($e in $zip.Entries) {
            if ([string]::IsNullOrEmpty($e.Name)) { continue }
            $target = [IO.Path]::GetFullPath((Join-Path $dest $e.FullName))
            # Zip-Slip: nichts ausserhalb des Zielordners schreiben
            if (-not $target.StartsWith($dest + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsicherer Pfad im Archiv: $($e.FullName)"
            }
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
        }
    } finally { $zip.Dispose() }
    return $dest
}

function Read-Ninox3Meta {
    param([Parameter(Mandatory)][string]$Dir, [string[]]$IgnorePlugins = @('ninext-v3'))
    $backup = $script:N3Json.DeserializeObject([IO.File]::ReadAllText((Join-Path $Dir 'backup.json'), [Text.Encoding]::UTF8))
    $settings = $script:N3Json.DeserializeObject([IO.File]::ReadAllText((Join-Path $Dir 'settings.json'), [Text.Encoding]::UTF8))
    $plugins = @(Get-N3Value $settings 'plugins' @())
    $ts = Get-N3Value $backup 'timestamp'
    [pscustomobject]@{
        Datenbank       = Get-N3Value $backup 'dbname'
        DatenbankId     = Get-N3Value $backup 'dbid'
        Sicherung       = if ($ts) { [DateTimeOffset]::FromUnixTimeMilliseconds([int64]$ts).ToString('yyyy-MM-dd HH:mm') } else { '' }
        Plugins         = (($plugins | ForEach-Object { Get-N3Value $_ 'name' }) -join ', ')
        PluginsIgnoriert = (($plugins | Where-Object { $IgnorePlugins -contains (Get-N3Value $_ 'id') } | ForEach-Object { Get-N3Value $_ 'name' }) -join ', ')
        PluginsSonstige = (($plugins | Where-Object { $IgnorePlugins -notcontains (Get-N3Value $_ 'id') } | ForEach-Object { Get-N3Value $_ 'name' }) -join ', ')
        RollenImport    = ConvertTo-N3Text (Get-N3Value $settings 'rolesImport')
        RollenExport    = ConvertTo-N3Text (Get-N3Value $settings 'rolesExport')
    }
}

# ---------------------------------------------------------------- Schema

function Read-Ninox3Schema {
    param([Parameter(Mandatory)][string]$DataDb)
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.StartsWith('s:')) { return , $script:N3Json.DeserializeObject($l.Substring(2)) }
        }
    } finally { $sr.Close() }
    throw "Keine Schemazeile (s:) in $DataDb gefunden. Ist das eine Ninox-3-Sicherung?"
}

function Get-Ninox3Roles {
    param([Parameter(Mandatory)]$Schema)
    $roles = @{}
    foreach ($t in $Schema['types'].GetEnumerator()) {
        foreach ($k in 'readRoles', 'writeRoles', 'createRoles', 'deleteRoles') {
            foreach ($r in @(Get-N3Value $t.Value $k @())) { $roles["$r"] = $true }
        }
        foreach ($f in $t.Value['fields'].GetEnumerator()) {
            foreach ($k in 'readRoles', 'writeRoles') { foreach ($r in @(Get-N3Value $f.Value $k @())) { $roles["$r"] = $true } }
        }
    }
    return @($roles.Keys | Sort-Object)
}

function Get-Ninox3TableInventory {
    param([Parameter(Mandatory)]$Schema, [hashtable]$RecordCounts = @{})
    foreach ($t in ($Schema['types'].GetEnumerator() | Sort-Object { [double](Get-N3Value $_.Value 'order' 0) })) {
        $d = $t.Value
        $fields = $d['fields']
        $fx = @($fields.Values | Where-Object { $_.ContainsKey('fn') }).Count
        $trig = @($d.Keys | Where-Object { $_ -match '^(after|before|on)[A-Z]' })
        [pscustomobject]@{
            TabelleId     = $t.Key
            Tabelle       = Get-N3Value $d 'caption'
            Felder        = $fields.Count
            Formelfelder  = $fx
            Datensaetze   = if ($RecordCounts.ContainsKey($t.Key)) { $RecordCounts[$t.Key] } else { '' }
            Layoutelemente = @(Get-N3Value $d 'uis' @{}).Count
            Lesen         = ConvertTo-N3Text (Get-N3Value $d 'readRoles')
            Schreiben     = ConvertTo-N3Text (Get-N3Value $d 'writeRoles')
            Anlegen       = ConvertTo-N3Text (Get-N3Value $d 'createRoles')
            Loeschen      = ConvertTo-N3Text (Get-N3Value $d 'deleteRoles')
            Trigger       = $trig -join ','
        }
    }
}

function Get-Ninox3FieldInventory {
    param([Parameter(Mandatory)]$Schema)
    $known = $script:N3PresentationKeys + $script:N3SemanticKeys
    $rows = New-Object Collections.Generic.List[object]
    foreach ($t in $Schema['types'].GetEnumerator()) {
        $tcap = Get-N3Value $t.Value 'caption'
        $sorted = $t.Value['fields'].GetEnumerator() | Sort-Object { [double](Get-N3Value $_.Value 'order' 0) }
        foreach ($f in $sorted) {
            $d = $f.Value
            $trigKeys = @($d.Keys | Where-Object { $_ -match '^(after|before|on)[A-Z]' })
            $defKeys = @($d.Keys | Where-Object { $_ -match 'Default$' })
            $other = @($d.Keys | Where-Object { ($known -notcontains $_) -and ($trigKeys -notcontains $_) -and ($defKeys -notcontains $_) })
            $vals = Get-N3Value $d 'values'
            $valText = ''
            $valCount = 0
            if ($vals -is [Collections.IDictionary]) {
                $valCount = $vals.Count
                $valText = (($vals.GetEnumerator() | Sort-Object { [double](Get-N3Value $_.Value 'order' 0) } |
                    ForEach-Object { "$($_.Key)=$(Get-N3Value $_.Value 'caption')" }) -join '|')
            }
            $rows.Add([pscustomobject]@{
                TabelleId     = $t.Key
                Tabelle       = $tcap
                FeldId        = $f.Key
                Beschriftung  = Get-N3Value $d 'caption'
                Basis         = Get-N3Value $d 'base'
                Pflicht       = [bool](Get-N3Value $d 'required' $false)
                Index         = [bool](Get-N3Value $d 'hasIndex' $false)
                Suche         = [bool](Get-N3Value $d 'globalSearch' $false)
                Mehrzeilig    = [bool](Get-N3Value $d 'stringMultiline' $false)
                IstFormel     = $d.ContainsKey('fn')
                Formel        = ConvertTo-N3Text (Get-N3Value $d 'fn')
                Trigger       = ($trigKeys | ForEach-Object { "$_=$(ConvertTo-N3Text $d[$_])" }) -join ' ; '
                TriggerNamen  = $trigKeys -join ','
                Standardwert  = ($defKeys | ForEach-Object { "$_=$(ConvertTo-N3Text $d[$_])" }) -join ' ; '
                StandardwertSchluessel = $defKeys -join ','
                FormelLaenge  = (ConvertTo-N3Text (Get-N3Value $d 'fn')).Length
                SichtbarkeitLaenge = (ConvertTo-N3Text (Get-N3Value $d 'visibility')).Length
                AuswahlAnzahl = $valCount
                AuswahlWerte  = $valText
                RefTabelleId  = ConvertTo-N3Text (Get-N3Value $d 'refTypeId')
                RefFeldId     = ConvertTo-N3Text (Get-N3Value $d 'refFieldId')
                KaskadeLoeschen = ConvertTo-N3Text (Get-N3Value $d 'cascade')
                Lesen         = ConvertTo-N3Text (Get-N3Value $d 'readRoles')
                Schreiben     = ConvertTo-N3Text (Get-N3Value $d 'writeRoles')
                Sichtbarkeit  = ConvertTo-N3Text (Get-N3Value $d 'visibility')
                WeitereSchluessel = $other -join ','
            })
        }
    }
    return $rows
}

# ---------------------------------------------------------------- Daten (streamend)

function Get-Ninox3RecordCounts {
    param([Parameter(Mandatory)][string]$DataDb)
    $counts = @{}
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.Length -gt 2 -and $l[0] -eq 'U' -and $l -match '^U([A-Za-z]+)\d+:') {
                $counts[$Matches[1]] = 1 + [int]$counts[$Matches[1]]
            }
        }
    } finally { $sr.Close() }
    return , $counts
}

function Get-Ninox3Views {
    param([Parameter(Mandatory)][string]$DataDb)
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.Length -lt 3 -or $l[0] -ne 'V') { continue }
            $i = $l.IndexOf(':')
            if ($i -lt 2) { continue }
            $o = $script:N3Json.DeserializeObject($l.Substring($i + 1))
            $cfg = Get-N3Value $o 'config' @{}
            [pscustomobject]@{
                AnsichtId  = Get-N3Value $o 'id'
                TabelleId  = Get-N3Value $o 'type'
                Name       = Get-N3Value $o 'caption'
                Modus      = if (Get-N3Value $o 'mode') { Get-N3Value $o 'mode' } else { 'ohne Angabe' }
                Diagramm   = Get-N3Value $o 'chartType'
                Spalten    = @(Get-N3Value $cfg 'cols' @()).Count
                Gruppiert  = $null -ne (Get-N3Value $cfg 'group')
                Rollen     = ConvertTo-N3Text (Get-N3Value $o 'readRoles')
            }
        }
    } finally { $sr.Close() }
}

function Get-Ninox3Reports {
    param([Parameter(Mandatory)][string]$Dir)
    $root = Join-Path $Dir 'reports'
    if (-not (Test-Path -LiteralPath $root)) { return }
    foreach ($d in Get-ChildItem -LiteralPath $root -Directory) {
        $f = Join-Path $d.FullName 'report.json'
        if (-not (Test-Path -LiteralPath $f)) { continue }
        $o = $script:N3Json.DeserializeObject([IO.File]::ReadAllText($f, [Text.Encoding]::UTF8))
        $imgs = Join-Path $d.FullName 'files'
        [pscustomobject]@{
            BerichtId = Get-N3Value $o 'id'
            TabelleId = Get-N3Value $o 'tid'
            Name      = Get-N3Value $o 'caption'
            Papier    = "$(Get-N3Value $o 'paperWidth') x $(Get-N3Value $o 'paperHeight')"
            Objekte   = @(Get-N3Value $o 'objects' @()).Count
            Bilder    = if (Test-Path -LiteralPath $imgs) { @(Get-ChildItem -LiteralPath $imgs -File).Count } else { 0 }
        }
    }
}


function Get-Ninox3FileValueCounts {
    # Zaehlt je Dateifeld, in wie vielen Datensaetzen ein Dateiname steht (Binaerdaten sind nicht im Export).
    param([Parameter(Mandatory)]$Schema, [Parameter(Mandatory)][string]$DataDb)
    $fileFields = @{}
    foreach ($t in $Schema['types'].GetEnumerator()) {
        $ff = @($t.Value['fields'].GetEnumerator() | Where-Object { $_.Value['base'] -eq 'file' } | ForEach-Object { $_.Key })
        if ($ff.Count -gt 0) { $fileFields[$t.Key] = $ff }
    }
    $counts = @{}
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.Length -gt 2 -and $l[0] -eq 'U' -and $l -match '^U([A-Za-z]+)\d+:') {
                $tid = $Matches[1]
                if (-not $fileFields.ContainsKey($tid)) { continue }
                $o = $script:N3Json.DeserializeObject($l.Substring($l.IndexOf(':') + 1))
                foreach ($fk in $fileFields[$tid]) {
                    if ($o.ContainsKey($fk) -and "$($o[$fk])" -ne '') { $counts["$tid.$fk"] = 1 + [int]$counts["$tid.$fk"] }
                }
            }
        }
    } finally { $sr.Close() }
    return , $counts
}
# ---------------------------------------------------------------- Mapping-Vorschlag

function Convert-ToNinox4Name {
    # Ninox-4-Namen muessen ^[a-z0-9_]+$ erfuellen, max. 100 Zeichen (Quelle: ninox-Skill, Schema admin).
    param([string]$Text, [string]$Fallback = 'feld')
    $s = $Text.ToLowerInvariant()
    $s = $s.Replace([string][char]0xE4, 'ae').Replace([string][char]0xF6, 'oe').Replace([string][char]0xFC, 'ue').Replace([string][char]0xDF, 'ss')
    $s = ($s.Normalize([Text.NormalizationForm]::FormD) -replace '\p{M}', '')
    $s = ($s -replace '[^a-z0-9]+', '_').Trim('_')
    if ([string]::IsNullOrEmpty($s)) { $s = $Fallback }
    if ($s.Length -gt 100) { $s = $s.Substring(0, 100).Trim('_') }
    return $s
}

# Namen, die mit Schluesselwoertern oder Systemfeldern kollidieren koennten (Kollision unbelegt: nur warnen, nicht umbenennen).
# Im Test akzeptiert und in Formeln korrekt: date, number, id (siehe references/api-faehigkeiten.md); text/time/datetime nicht getestet, daher ohne Warnung.
$script:N4ReservedNames = @('if', 'then', 'else', 'end', 'let', 'select', 'where', 'and', 'or', 'not', 'true', 'false', 'this', 'me', 'null',
    'record', 'database', 'id', 'for', 'do', 'var', 'like', 'in', 'from', 'to', 'as', 'by',
    'desc', 'asc', 'switch', 'case', 'default', 'contains', 'between', 'distinct', 'unique', 'order', 'group')

function New-Ninox3MappingProposal {
    # Liefert einen VORSCHLAG. Jede Zeile bleibt "offen", bis sie in Phase 2 freigegeben ist.
    param([Parameter(Mandatory)]$FieldRows, [Parameter(Mandatory)]$TableRows)
    # Namensregeln (lesbar, eindeutig): Name = Beschriftung als Kleinbuchstaben-Bezeichner (ae/oe/ue/ss, Unterstriche).
    # Kollision: laufende Nummer (name, name_2, name_3), nie die interne Ninox-3-ID. Leere Beschriftung: feld_1, feld_2, ...
    # Die Original-Beschriftung bleibt als Label (Spalte Ninox4Label) und ist in Ninox 4 die sichtbare Bezeichnung.
    $tableNames = @{}; $tableLabels = @{}; $used = @{}; $tNr = 0
    foreach ($t in $TableRows) {
        $tNr++
        $n = Convert-ToNinox4Name $t.Tabelle ('tabelle_' + $tNr)
        $base = $n; $i = 2
        while ($used.ContainsKey($n)) { $n = "${base}_$i"; $i++ }
        $used[$n] = $true; $tableNames[$t.TabelleId] = $n; $tableLabels[$t.TabelleId] = $t.Tabelle
    }
    $fieldUsed = @{}; $fNr = @{}
    foreach ($f in $FieldRows) {
        $tn = $tableNames[$f.TabelleId]
        $fNr[$f.TabelleId] = 1 + [int]$fNr[$f.TabelleId]
        $nameHint = New-Object Collections.Generic.List[string]
        $n = Convert-ToNinox4Name $f.Beschriftung ('feld_' + $fNr[$f.TabelleId])
        if ([string]::IsNullOrWhiteSpace($f.Beschriftung)) { $nameHint.Add('Beschriftung leer: Name nummeriert, bitte sprechenden Namen vergeben') }
        $base = $n; $i = 2
        while ($fieldUsed.ContainsKey("$tn.$n")) { $n = "${base}_$i"; $i++ }
        if ($i -gt 2) { $nameHint.Add('Beschriftung doppelt in der Tabelle: nummeriert, bitte unterscheidbar benennen') }
        $key = "$tn.$n"
        $fieldUsed[$key] = $true
        if ($script:N4ReservedNames -contains $n) { $nameHint.Add('Name entspricht einem Schluesselwort oder Systemnamen (Kollision unbelegt), Umbenennung erwaegen') }
        if ($n.Length -gt 40) { $nameHint.Add('Name laenger als 40 Zeichen: kuerzen fuer Lesbarkeit') }

        $typ = ''; $var = ''; $status = 'automatisch'; $hint = New-Object Collections.Generic.List[string]
        if ($f.IstFormel) {
            $typ = 'function'; $status = 'formel'
            $hint.Add('Formel 1:1 uebersetzen und pruefen (Phase 4); Rueckgabetyp der Ninox-3-Basis: ' + $f.Basis)
        } else {
            switch ($f.Basis) {
                'string'    { $typ = 'string'; $var = if ($f.Mehrzeilig) { 'multiline-text' } else { 'text' } }
                'number'    { $typ = 'number' }
                'boolean'   { $typ = 'boolean' }
                'date'      { $typ = 'date' }
                'timestamp' { $typ = 'timestamp' }
                'choice'    { $typ = 'choice'; $hint.Add('Optionen aus AuswahlWerte; Ninox 3 speichert die Wert-ID, Ninox 4 erwartet das Label') }
                'multi'     { $typ = 'multi'; $hint.Add('Optionen aus AuswahlWerte; Speicherform in Ninox 3 vor dem Import pruefen') }
                'file'      { $typ = 'file'; $hint.Add('Anhaenge sind nicht im Export; Feld wird angelegt, Anhaenge siehe Luecken') }
                'ref'       { $typ = 'reference'; $hint.Add("Verweis auf Tabelle $($f.RefTabelleId) ($($tableNames[$f.RefTabelleId])); gilt nur innerhalb eines Moduls") }
                'rev'       { $typ = 'reverse'; $hint.Add('NICHT einzeln anlegen: Ninox 4 erzeugt den Rueckverweis automatisch mit dem Verweisfeld; danach nur umbenennen (PATCH name und labels)') }
                'html'      { $typ = 'html'; $status = 'ungeklaert'; $hint.Add('Typ html ist in der OpenAPI vorhanden; Bedeutung des Ninox-3-html-Feldes pruefen') }
                'link'      { $typ = 'string'; $var = 'url'; $status = 'ungeklaert'; $hint.Add('Zuordnung Ninox-3-Link zu string/url ist nicht belegt') }
                default     { $typ = ''; $status = 'manuell'; $hint.Add("Basistyp '$($f.Basis)' ohne belegte Entsprechung") }
            }
        }
        if ($f.Trigger) { $status = 'manuell'; $hint.Add("Trigger vorhanden ($($f.TriggerNamen)); Ninox 4 getrennt pruefen") }
        if ($f.Lesen -or $f.Schreiben) { $hint.Add('Feldrechte vorhanden; nur mit Freigabe und Gegenueberstellung (Phase 2)') }
        if ($f.Sichtbarkeit) { $hint.Add('Sichtbarkeitsbedingung vorhanden') }
        if ($f.Standardwert) { $hint.Add("Standardwert vorhanden ($($f.StandardwertSchluessel))") }
        if ($f.WeitereSchluessel) { $status = 'ungeklaert'; $hint.Add("Unbekannte Schluessel: $($f.WeitereSchluessel)") }

        [pscustomobject]@{
            TabelleId = $f.TabelleId; Tabelle = $f.Tabelle; FeldId = $f.FeldId; Beschriftung = $f.Beschriftung; Basis3 = $f.Basis
            Ninox4Tabelle = $tn; Ninox4TabelleLabel = $tableLabels[$f.TabelleId]; Ninox4Feld = $n; Ninox4Label = $f.Beschriftung; Ninox4LabelVorschlag = ''
            Ninox4Typ = $typ; Ninox4Variante = $var
            Pflicht = $f.Pflicht; Status = $status; Freigabe = 'offen'; Namenshinweis = ($nameHint -join ' | '); Hinweis = ($hint -join ' | ')
        }
    }
}


function Test-Ninox4Names {
    # Prueft das Mapping auf Namensregeln (vor Phase 3): Muster, Laenge, Eindeutigkeit, Lesbarkeit.
    # Fehler (muessen behoben werden): ungueltiges Muster, doppelter Name, leerer Name.
    # Warnungen (Entscheidung des Nutzers): sehr kurze oder durchnummerierte Namen, Schluesselwoerter, ueber 40 Zeichen.
    param([Parameter(Mandatory)]$Mapping)
    foreach ($m in $Mapping) {
        $id = "$($m.Ninox4Tabelle).$($m.Ninox4Feld)"
        if (-not $m.Ninox4Feld) { [pscustomobject]@{ Stufe = 'Fehler'; Objekt = $id; Meldung = 'Feldname leer' }; continue }
        if ($m.Ninox4Feld -notmatch '^[a-z0-9_]+$') { [pscustomobject]@{ Stufe = 'Fehler'; Objekt = $id; Meldung = 'Feldname entspricht nicht ^[a-z0-9_]+$' } }
        if ($m.Ninox4Feld.Length -gt 100) { [pscustomobject]@{ Stufe = 'Fehler'; Objekt = $id; Meldung = 'Feldname laenger als 100 Zeichen' } }
        if ($m.Ninox4Tabelle -notmatch '^[a-z0-9_]+$') { [pscustomobject]@{ Stufe = 'Fehler'; Objekt = $id; Meldung = 'Tabellenname entspricht nicht ^[a-z0-9_]+$' } }
        if ($m.Ninox4Feld -match '^feld_\d+$' -or $m.Ninox4Feld -match '_\d+$') { [pscustomobject]@{ Stufe = 'Warnung'; Objekt = $id; Meldung = 'Name nummeriert, sprechenden Namen vergeben' } }
        elseif ($m.Ninox4Feld.Length -le 2) { [pscustomobject]@{ Stufe = 'Warnung'; Objekt = $id; Meldung = 'Name sehr kurz, Lesbarkeit pruefen' } }
        if ($script:N4ReservedNames -contains $m.Ninox4Feld) { [pscustomobject]@{ Stufe = 'Warnung'; Objekt = $id; Meldung = 'Name entspricht Schluesselwort oder Systemname (Kollision unbelegt)' } }
        if ($m.Ninox4Feld.Length -gt 40) { [pscustomobject]@{ Stufe = 'Warnung'; Objekt = $id; Meldung = 'Name laenger als 40 Zeichen' } }
    }
    $dups = $Mapping | Group-Object Ninox4Tabelle, Ninox4Feld | Where-Object { $_.Count -gt 1 }
    foreach ($d in $dups) { [pscustomobject]@{ Stufe = 'Fehler'; Objekt = $d.Name; Meldung = "Name $($d.Count)-mal vergeben" } }
}
# ---------------------------------------------------------------- Befunde fuer die Optimierungsphase

function Get-Ninox3Findings {
    # Nur Beobachtungen aus dem Schema. Belege aus den Daten (Phase 7) werden spaeter ergaenzt.
    param([Parameter(Mandatory)]$FieldRows, [Parameter(Mandatory)]$TableRows, [hashtable]$RecordCounts = @{})
    foreach ($f in ($FieldRows | Where-Object { $_.IstFormel })) {
        $likes = ([regex]::Matches($f.Formel, '\blike\b')).Count
        $ifs = ([regex]::Matches($f.Formel, '\bif\b')).Count
        if ($likes -ge 4 -or $ifs -ge 6) {
            [pscustomobject]@{ Art = 'Formel'; Objekt = "$($f.Tabelle).$($f.Beschriftung)"; Beobachtung = "Lange Verzweigungskette ($ifs if, $likes like, $($f.Formel.Length) Zeichen); Werte stehen fest in der Formel"; Vorschlag = 'Stammdatentabelle mit Verweis oder Nachschlagen statt Verzweigung'; Beleg = 'Schema' }
        }
    }
    foreach ($t in $TableRows) {
        if ($t.Felder -ge 40) {
            [pscustomobject]@{ Art = 'Tabelle'; Objekt = $t.Tabelle; Beobachtung = "$($t.Felder) Felder in einer Tabelle"; Vorschlag = 'Aufteilen nach Themen (z. B. Zahlung, Versand), Detailtabellen mit Verweis'; Beleg = 'Schema' }
        }
        if ($RecordCounts.Count -gt 0 -and -not $RecordCounts.ContainsKey($t.TabelleId)) {
            [pscustomobject]@{ Art = 'Tabelle'; Objekt = $t.Tabelle; Beobachtung = 'Keine Datensaetze'; Vorschlag = 'Pruefen, ob die Tabelle noch gebraucht wird'; Beleg = 'Daten' }
        }
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Basis -eq 'choice' -and $_.AuswahlAnzahl -ge 12 })) {
        [pscustomobject]@{ Art = 'Feld'; Objekt = "$($f.Tabelle).$($f.Beschriftung)"; Beobachtung = "Auswahlfeld mit $($f.AuswahlAnzahl) festen Werten"; Vorschlag = 'Als Stammdatentabelle mit Verweis fuehren, falls die Liste gepflegt wird'; Beleg = 'Schema' }
    }
    $dups = $FieldRows | Group-Object TabelleId, Beschriftung | Where-Object { $_.Count -gt 1 }
    foreach ($g in $dups) {
        [pscustomobject]@{ Art = 'Feld'; Objekt = "$($g.Group[0].Tabelle).$($g.Group[0].Beschriftung)"; Beobachtung = "Beschriftung $($g.Count)-mal in derselben Tabelle"; Vorschlag = 'Eindeutige Namen vergeben'; Beleg = 'Schema' }
    }
}

# ---------------------------------------------------------------- Lueckenliste

function Get-Ninox3GapList {
    # Leitet die Lueckenliste aus dem Inventar ab (Kategorien: references/luecken-katalog.md).
    # Aufwand ist eine Schaetzung, Status immer "offen". "Beleg" nennt, was die OpenAPI hergibt (references/api-faehigkeiten.md);
    # ob die Abbildung einer Ninox-3-Funktion gelingt, ist erst im Test-Workspace belegt.
    param(
        [Parameter(Mandatory)]$FieldRows, [Parameter(Mandatory)]$TableRows, $Views, $Reports, $Meta,
        [long]$CommentsBytes = 0, [hashtable]$RecordCounts = @{}, [hashtable]$FileCounts = @{})
    $rows = New-Object Collections.Generic.List[object]
    $add = {
        param($Kat, $Obj, $Beschr, $Ausw, $Aufw, $Beleg)
        $script:gapNr++
        $rows.Add([pscustomobject]@{ Nr = $script:gapNr; Kategorie = $Kat; Objekt = $Obj; Beschreibung = $Beschr; Auswirkung = $Ausw; Aufwand = $Aufw; Status = 'offen'; Verantwortlich = ''; Beleg = $Beleg })
    }
    $script:gapNr = 0
    $tname = @{}; foreach ($t in $TableRows) { $tname[$t.TabelleId] = $t.Tabelle }

    foreach ($r in @($Reports)) {
        $tn = if ($tname.ContainsKey($r.TabelleId)) { $tname[$r.TabelleId] } else { "Kuerzel $($r.TabelleId) nicht im Schema" }
        & $add 'Bericht' "Bericht '$($r.Name)' (Tabelle $tn)" "Druck-Layout mit $($r.Objekte) Objekten, $($r.Bilder) Bildern" 'Ausdruck/PDF fehlt, bis nachgebaut' 'mittel' 'API: Berichte anlegbar (POST .../tables/{t}/reports, OpenAPI 1.0.0); Abbildung der Ninox-3-Layouts ungeprueft'
    }
    $orphan = @(@($Views) | Where-Object { -not $tname.ContainsKey($_.TabelleId) })
    if ($orphan.Count -gt 0) {
        & $add 'Ansicht' 'Ansichten ohne Tabelle im Schema' "$($orphan.Count) Ansichten verweisen auf Kuerzel ohne Tabelle ($((($orphan | ForEach-Object { $_.TabelleId } | Sort-Object -Unique) -join ', ')))" 'Herkunft ungeklaert (Altlast oder Unterliste); ggf. nicht benoetigt' 'klein' 'Herkunft unbelegt, mit Nutzer klaeren'
    }
    foreach ($g in (@($Views) | Where-Object { $tname.ContainsKey($_.TabelleId) } | Group-Object TabelleId)) {
        $aufw = if ($g.Count -le 3) { 'klein' } else { 'mittel' }
        & $add 'Ansicht' "Ansichten der Tabelle $($tname[$g.Name])" "$($g.Count) Ansichten (Modi: $((($g.Group | ForEach-Object { $_.Modus } | Sort-Object -Unique) -join ', ')))" 'Darstellung, Filter und Gruppierung fehlen, bis nachgebaut' $aufw 'API: Ansichten anlegbar (POST .../tables/{t}/views, Typen Calendar bis Table, OpenAPI 1.0.0); Abbildung ungeprueft'
    }
    $tabRights = @($TableRows | Where-Object { $_.Lesen -or $_.Schreiben -or $_.Anlegen -or $_.Loeschen })
    $fldRights = @($FieldRows | Where-Object { $_.Lesen -or $_.Schreiben })
    if ($tabRights.Count -gt 0 -or $fldRights.Count -gt 0) {
        & $add 'Rechte' 'Rollen und Rechte' "$($tabRights.Count) Tabellen und $($fldRights.Count) Felder mit eigenen Rechten" 'Zugriff ohne Nachbau zu offen oder zu streng' 'mittel' 'API: readRoles/writeRoles/createRoles/deleteRoles an Tabelle und Feld, Feldrolle "user" ist Alias fuer "editor"; Zuordnung benutzerdefinierter Rollen unbelegt, nur mit Freigabe'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Trigger })) {
        & $add 'Trigger' "$($f.Tabelle).$($f.Beschriftung)" "Ninox-3-Trigger vorhanden ($($f.TriggerNamen))" 'Automatische Folgeaktion fehlt' 'mittel' 'API: Feld onUpdate und Tabelle onCreate/onUpdate/onDelete vorhanden; Syntax der Ausdruecke zu pruefen (formeln.md)'
    }
    foreach ($t in ($TableRows | Where-Object { $_.Layoutelemente -gt 0 })) {
        & $add 'Layout' "Tabelle $($t.Tabelle)" "$($t.Layoutelemente) Layoutelemente (Ueberschriften/Gruppen)" 'Formularaufbau fehlt' 'klein' 'Formularbau mit ninox4-api-builder (Komponenten-API)'
    }
    foreach ($g in ($FieldRows | Where-Object { $_.Basis -eq 'file' } | Group-Object Tabelle)) {
        $names = 0; foreach ($f in $g.Group) { $names += [int]$FileCounts["$($f.TabelleId).$($f.FeldId)"] }
        $cnt = if ($FileCounts.Count -gt 0) { "; $names Datensaetze mit Dateiname" } else { '' }
        & $add 'Anhang' "Tabelle $($g.Name)" "$($g.Count) Dateifelder$cnt; Anhaenge sind nicht im Export" 'Anhaenge fehlen im Ziel' 'mittel' 'Export enthaelt nur Dateinamen (am Beispiel geprueft); API: Upload vorhanden (records/{id}/files)'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Basis -eq 'html' })) {
        & $add 'html-Feld' "$($f.Tabelle).$($f.Beschriftung)" 'Feld vom Typ html' 'Bedeutung und Darstellung im Ziel pruefen' 'klein' 'API: Feldtyp html vorhanden; Entsprechung des Ninox-3-Feldes ungeprueft'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Basis -eq 'link' })) {
        & $add 'link-Feld' "$($f.Tabelle).$($f.Beschriftung)" 'Zuordnung zu string/url ist nicht belegt' 'Anzeige als Link evtl. abweichend' 'klein' 'Im Test klaeren'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Standardwert })) {
        & $add 'Standardwert' "$($f.Tabelle).$($f.Beschriftung)" "Standardwert vorhanden ($($f.StandardwertSchluessel))" 'Neue Datensaetze starten ohne Vorbelegung' 'klein' 'API: defaultValue am Feld vorhanden; Wertumwandlung (Auswahl-ID zu Label) pruefen'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Sichtbarkeit })) {
        & $add 'Sichtbarkeit' "$($f.Tabelle).$($f.Beschriftung)" "Sichtbarkeitsausdruck vorhanden ($($f.SichtbarkeitLaenge) Zeichen)" 'Feld ist immer sichtbar' 'klein' 'API: canRead/canWrite sind Zugriffsausdruecke, keine Sichtbarkeit; Entsprechung unbelegt'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.Basis -eq 'ref' -and "$($_.KaskadeLoeschen)" -eq 'True' })) {
        & $add 'Kaskade' "$($f.Tabelle).$($f.Beschriftung)" 'Kaskadierendes Loeschen in Ninox 3' 'Abhaengige Datensaetze bleiben beim Loeschen stehen' 'klein' 'Entsprechung unbelegt; ggf. ueber Tabellen-Trigger onDelete'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.IstFormel -and ([regex]::Matches($_.Formel, '\blike\b')).Count -ge 4 })) {
        & $add 'Echtdaten in Formel' "$($f.Tabelle).$($f.Beschriftung)" 'Formel enthaelt viele feste Vergleichswerte (moeglicherweise Firmen- oder Personendaten)' 'Anonymisierung der Daten greift hier nicht' 'klein' 'Mit Nutzer klaeren (Test anonymisiert bauen oder weglassen)'
    }
    foreach ($f in ($FieldRows | Where-Object { $_.WeitereSchluessel })) {
        & $add 'Unbekannte Schluessel' "$($f.Tabelle).$($f.Beschriftung)" "Unbekannt: $($f.WeitereSchluessel)" 'Eigenschaft nicht bewertet' 'klein' 'Nutzer fragen'
    }
    if ($CommentsBytes -gt 0) {
        & $add 'Kommentare' 'comments.db' "Datei enthaelt Daten ($CommentsBytes Bytes)" 'Kommentare gehen verloren' 'mittel' 'Export enthaelt Kommentare; Zielweg klaeren'
    }
    if ($Meta -and $Meta.PluginsSonstige) {
        foreach ($pl in @($Meta.PluginsSonstige -split ', ' | Where-Object { $_ })) {
            & $add 'Plugin' "Plugin $pl" 'Plugin in der Ninox-3-Loesung' 'Funktion des Plugins fehlt' 'mittel' 'Nutzer fragen'
        }
    }
    return $rows
}
# ---------------------------------------------------------------- Gesamtinventar

function Export-Ninox3Inventory {
    param(
        [Parameter(Mandatory)][string]$Dir,          # entpackte Sicherung OHNE Daten
        [Parameter(Mandatory)][string]$OutDir,           # bereinigte Ergebnisse (ohne Formeltexte, Auswahlwerte, Rollennamen)
        [Parameter(Mandatory)][string]$RawDir,           # volle Fassung mit moeglichen Echtdaten (nur lokal, nicht versionieren)
        [string]$DataDbMit,                           # optional: data.db der Sicherung MIT Daten (nur fuer Zaehlung)
        [string[]]$IgnorePlugins = @('ninext-v3'))
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    New-Item -ItemType Directory -Force -Path $RawDir | Out-Null
    $db = Join-Path $Dir 'data.db'
    $meta = Read-Ninox3Meta -Dir $Dir -IgnorePlugins $IgnorePlugins
    $schema = Read-Ninox3Schema -DataDb $db
    $counts = @{}
    if ($DataDbMit) { $counts = Get-Ninox3RecordCounts -DataDb $DataDbMit }
    $tables = @(Get-Ninox3TableInventory -Schema $schema -RecordCounts $counts)
    $fields = @(Get-Ninox3FieldInventory -Schema $schema)
    $views = @(Get-Ninox3Views -DataDb $db)
    $reports = @(Get-Ninox3Reports -Dir $Dir)
    $mapping = @(New-Ninox3MappingProposal -FieldRows $fields -TableRows $tables)
    $findings = @(Get-Ninox3Findings -FieldRows $fields -TableRows $tables -RecordCounts $counts)
    $cBytes = if (Test-Path -LiteralPath (Join-Path $Dir 'comments.db')) { (Get-Item -LiteralPath (Join-Path $Dir 'comments.db')).Length } else { 0 }
    $fileCounts = @{}
    if ($DataDbMit) { $fileCounts = Get-Ninox3FileValueCounts -Schema $schema -DataDb $DataDbMit }
    $gaps = @(Get-Ninox3GapList -FieldRows $fields -TableRows $tables -Views $views -Reports $reports -Meta $meta -CommentsBytes $cBytes -RecordCounts $counts -FileCounts $fileCounts)

    $csv = @{ Encoding = 'UTF8'; NoTypeInformation = $true; Delimiter = ';' }
    # Volle Fassung (kann Firmen- und Personendaten aus Formeln, Auswahlwerten, Rollen enthalten)
    $tables | Export-Csv -Path (Join-Path $RawDir '01_tabellen_voll.csv') @csv
    $fields | Export-Csv -Path (Join-Path $RawDir '02_felder_voll.csv') @csv
    $fields | Where-Object { $_.IstFormel } | Select-Object TabelleId, Tabelle, FeldId, Beschriftung, Basis, Formel |
        Export-Csv -Path (Join-Path $RawDir '03_formeln_voll.csv') @csv
    # Bereinigte Fassung fuer ergebnis/: Strukturdaten, Zaehler, Laengen
    $tables | Select-Object TabelleId, Tabelle, Felder, Formelfelder, Datensaetze, Layoutelemente,
        @{ n = 'RollenLesen'; e = { @($_.Lesen -split ',' | Where-Object { $_ }).Count } },
        @{ n = 'RollenSchreiben'; e = { @($_.Schreiben -split ',' | Where-Object { $_ }).Count } },
        @{ n = 'RollenAnlegen'; e = { @($_.Anlegen -split ',' | Where-Object { $_ }).Count } },
        @{ n = 'RollenLoeschen'; e = { @($_.Loeschen -split ',' | Where-Object { $_ }).Count } }, Trigger |
        Export-Csv -Path (Join-Path $OutDir '01_tabellen.csv') @csv
    $fields | Select-Object TabelleId, Tabelle, FeldId, Beschriftung, Basis, Pflicht, Index, Suche, Mehrzeilig, IstFormel,
        FormelLaenge, TriggerNamen, StandardwertSchluessel, SichtbarkeitLaenge, AuswahlAnzahl, RefTabelleId, RefFeldId, KaskadeLoeschen,
        @{ n = 'HatFeldrechte'; e = { [bool]($_.Lesen -or $_.Schreiben) } }, WeitereSchluessel |
        Export-Csv -Path (Join-Path $OutDir '02_felder.csv') @csv
    $fields | Where-Object { $_.IstFormel } | Select-Object TabelleId, Tabelle, FeldId, Beschriftung, Basis, FormelLaenge,
        @{ n = 'Verzweigungen'; e = { ([regex]::Matches($_.Formel, '\bif\b')).Count } } |
        Export-Csv -Path (Join-Path $OutDir '03_formeln.csv') @csv
    $tn = @{}; foreach ($x in $tables) { $tn[$x.TabelleId] = $x.Tabelle }
    $tabName = { if ($tn.ContainsKey($_.TabelleId)) { $tn[$_.TabelleId] } else { '(nicht im Schema)' } }
    $views | Select-Object AnsichtId, TabelleId, @{ n = 'Tabelle'; e = $tabName }, Name, Modus, Diagramm, Spalten, Gruppiert,
        @{ n = 'RollenAnzahl'; e = { @($_.Rollen -split ',' | Where-Object { $_ }).Count } } |
        Export-Csv -Path (Join-Path $OutDir '04_ansichten.csv') @csv
    $reports | Select-Object BerichtId, TabelleId, @{ n = 'Tabelle'; e = $tabName }, Name, Papier, Objekte, Bilder |
        Export-Csv -Path (Join-Path $OutDir '05_berichte.csv') @csv
    $mapping  | Export-Csv -Path (Join-Path $OutDir '06_mapping_vorschlag.csv') @csv
    $findings | Export-Csv -Path (Join-Path $OutDir '07_befunde_optimierung.csv') @csv
    $gaps | Export-Csv -Path (Join-Path $OutDir '09_luecken.csv') @csv

    $summary = [ordered]@{
        Datenbank = $meta.Datenbank; Sicherung = $meta.Sicherung
        PluginsIgnoriert = $meta.PluginsIgnoriert; PluginsSonstige = $meta.PluginsSonstige
        Tabellen = $tables.Count; Felder = $fields.Count
        Formelfelder = @($fields | Where-Object { $_.IstFormel }).Count
        FelderMitTrigger = @($fields | Where-Object { $_.Trigger }).Count
        FelderMitFeldrechten = @($fields | Where-Object { $_.Lesen -or $_.Schreiben }).Count
        Dateifelder = @($fields | Where-Object { $_.Basis -eq 'file' }).Count
        Verweisfelder = @($fields | Where-Object { $_.Basis -eq 'ref' }).Count
        Rueckverweisfelder = @($fields | Where-Object { $_.Basis -eq 'rev' }).Count
        FelderMitUnbekanntenSchluesseln = @($fields | Where-Object { $_.WeitereSchluessel }).Count
        Ansichten = $views.Count; Berichte = $reports.Count
        RollenAnzahl = @(Get-Ninox3Roles -Schema $schema).Count
        Datensaetze = if ($counts.Count -gt 0) { ($counts.Values | Measure-Object -Sum).Sum } else { 'nicht gezaehlt' }
        MappingStatus = (($mapping | Group-Object Status | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ', ')
        Befunde = $findings.Count
        DateinamenInDatensaetzen = if ($fileCounts.Count -gt 0) { ($fileCounts.Values | Measure-Object -Sum).Sum } else { 'nicht gezaehlt' }
        Luecken = $gaps.Count
        KommentareDbBytes = if (Test-Path -LiteralPath (Join-Path $Dir 'comments.db')) { (Get-Item -LiteralPath (Join-Path $Dir 'comments.db')).Length } else { 0 }
    }
    # Rollennamen koennen Personennamen sein: nur in der lokalen Fassung
    [IO.File]::WriteAllText((Join-Path $RawDir 'rollen.txt'), ((Get-Ninox3Roles -Schema $schema) -join [Environment]::NewLine), (New-Object Text.UTF8Encoding($false)))
    [IO.File]::WriteAllText((Join-Path $OutDir 'inventar_zusammenfassung.json'),
        $script:N3Json.Serialize($summary), (New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]$summary
}

# ---------------------------------------------------------------- Phase 0: Pruefung der beiden Sicherungen

function Get-N3SchemaHash {
    param([string]$DataDb)
    $sr = New-Object IO.StreamReader($DataDb, [Text.Encoding]::UTF8)
    try {
        while (($l = $sr.ReadLine()) -ne $null) {
            if ($l.StartsWith('s:')) {
                $sha = [Security.Cryptography.SHA256]::Create()
                return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($l))) -replace '-', '')
            }
        }
    } finally { $sr.Close() }
    return ''
}

function Test-Ninox3BackupPair {
    # Prueft, ob die Sicherung OHNE Daten und die Sicherung MIT Daten zur selben Loesung und zum selben Stand gehoeren.
    param([Parameter(Mandatory)][string]$DirOhne, [Parameter(Mandatory)][string]$DirMit)
    $a = Read-Ninox3Meta -Dir $DirOhne; $b = Read-Ninox3Meta -Dir $DirMit
    $ha = Get-N3SchemaHash (Join-Path $DirOhne 'data.db'); $hb = Get-N3SchemaHash (Join-Path $DirMit 'data.db')
    $cOhne = Get-Ninox3RecordCounts -DataDb (Join-Path $DirOhne 'data.db')
    $cMit = Get-Ninox3RecordCounts -DataDb (Join-Path $DirMit 'data.db')
    $nOhne = if ($cOhne.Count -gt 0) { ($cOhne.Values | Measure-Object -Sum).Sum } else { 0 }
    $nMit = if ($cMit.Count -gt 0) { ($cMit.Values | Measure-Object -Sum).Sum } else { 0 }
    $checks = @(
        [pscustomobject]@{ Pruefung = 'Gleiche Datenbank-ID'; Ergebnis = ($a.DatenbankId -eq $b.DatenbankId); Detail = "$($a.DatenbankId) / $($b.DatenbankId)" }
        [pscustomobject]@{ Pruefung = 'Schema in beiden Dateien identisch'; Ergebnis = ($ha -ne '' -and $ha -eq $hb); Detail = "Hash $($ha.Substring(0, [Math]::Min(12, $ha.Length))) / $($hb.Substring(0, [Math]::Min(12, $hb.Length)))" }
        [pscustomobject]@{ Pruefung = 'Datei OHNE Daten enthaelt keine Datensaetze'; Ergebnis = ($nOhne -eq 0); Detail = "$nOhne Datensaetze" }
        [pscustomobject]@{ Pruefung = 'Datei MIT Daten enthaelt Datensaetze'; Ergebnis = ($nMit -gt 0); Detail = "$nMit Datensaetze" }
        [pscustomobject]@{ Pruefung = 'Sicherungszeitpunkt (nur Hinweis)'; Ergebnis = $true; Detail = "$($a.Sicherung) / $($b.Sicherung)" }
    )
    return [pscustomobject]@{ Bestanden = (@($checks | Where-Object { -not $_.Ergebnis }).Count -eq 0); Pruefungen = $checks }
}