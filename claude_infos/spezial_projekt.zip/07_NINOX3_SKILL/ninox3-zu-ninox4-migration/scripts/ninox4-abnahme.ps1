# Phase 6: Abnahme. Prueft NUR LESEND (keine Schreibaufrufe, keine Freigabe noetig):
#   A Struktur: freigegebenes Mapping gegen das Ninox-4-Modul (Tabellen, Felder, Typ, Variante, Pflicht, Auswahl, Verweisziel, Formeln)
#   B Daten der Stichprobe: Zeilenzahl je Tabelle, jeder Verweis, jeder Wert gegen die anonymisierte Quelle (arbeit\stichprobe_payload.json, idmap_*.json)
# Prueftung C (Formelwerte) braucht ein Soll aus Ninox 3 und steht hier als "nicht belegt", solange arbeit\soll_formeln_ninox3.csv fehlt.
# Nutzung: . .\scripts\ninox4-abnahme.ps1; Invoke-Ninox4Abnahme -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1
# Ergebnis: ergebnis\13_abnahme_struktur.csv, ergebnis\14_abnahme_daten.csv, ergebnis\abnahmebericht.md. Es erscheinen nur Zaehler und Feldnamen, nie Datensatzinhalte.

. (Join-Path $PSScriptRoot 'ninox-pruefungen.ps1')

function Invoke-Ninox4Abnahme {
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][string]$HelpersPath)
    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $e = Join-Path $ProjectDir 'ergebnis'; $w = Join-Path $ProjectDir 'arbeit'
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.moduleName
    $map = @(Import-Csv (Join-Path $e '06_mapping_vorschlag.csv') -Delimiter ';' -Encoding UTF8)
    $raw = @(Import-Csv (Join-Path $w 'inventar\02_felder_voll.csv') -Delimiter ';' -Encoding UTF8)
    $rawBy = @{}; foreach ($r in $raw) { $rawBy["$($r.TabelleId).$($r.FeldId)"] = $r }
    $gaps = @(Import-Csv (Join-Path $e '09_luecken.csv') -Delimiter ';' -Encoding UTF8)
    Set-Location $ProjectDir
    $env:NINOX_API_KEY = Get-NinoxKeyWert
    . $HelpersPath
    function Get-Json($path) { Start-Sleep -Milliseconds 120; return $ser.DeserializeObject((Invoke-Ninox -Method Get -Path $path)) }
    $tName = @{}; foreach ($m in $map) { $tName[$m.TabelleId] = $m.Ninox4Tabelle }

    # ---------- A Struktur
    $A = New-Object Collections.Generic.List[object]
    function AddA($t, $f, $pr, $soll, $ist, $erg) { $A.Add([pscustomobject]@{ Tabelle = $t; Feld = $f; Pruefung = $pr; Soll = $soll; Ist = $ist; Ergebnis = $erg }) }
    $tablesIst = @((Get-Json "/modules/$mod/tables")['data'] | ForEach-Object { $_['name'] })
    $fieldsIst = @{}
    foreach ($t in @($map | ForEach-Object { $_.Ninox4Tabelle } | Select-Object -Unique)) {
        if ($tablesIst -notcontains $t) { AddA $t '' 'Tabelle vorhanden' 'ja' 'nein' 'Abweichung'; continue }
        AddA $t '' 'Tabelle vorhanden' 'ja' 'ja' 'ok'
        $fl = @((Get-Json "/modules/$mod/tables/$t/fields?limit=500")['data']); $d = @{}; foreach ($f in $fl) { $d[$f['name']] = $f }; $fieldsIst[$t] = $d
    }
    foreach ($m in $map) {
        if (-not $m.Ninox4Feld -or -not $m.Ninox4Typ) { continue }
        $t = $m.Ninox4Tabelle; $fn = $m.Ninox4Feld
        if (-not $fieldsIst.ContainsKey($t)) { continue }
        $f = $fieldsIst[$t][$fn]
        if ($null -eq $f) {
            $luecke = @($gaps | Where-Object { $_.Objekt -like "$t.$fn *" -or $_.Objekt -eq "$t.$fn" }).Count -gt 0
            AddA $t $fn 'Feld vorhanden' 'ja' 'nein' $(if ($luecke) { 'bekannte Luecke' } else { 'Abweichung' }); continue
        }
        AddA $t $fn 'Feld vorhanden' 'ja' 'ja' 'ok'
        $typOk = ($f['type'] -eq $m.Ninox4Typ); AddA $t $fn 'Typ' $m.Ninox4Typ $f['type'] $(if ($typOk) { 'ok' } else { 'Abweichung' })
        if ($m.Ninox4Variante) { $vIst = [string]$f['variant']; AddA $t $fn 'Variante' $m.Ninox4Variante $vIst $(if ($vIst -eq $m.Ninox4Variante) { 'ok' } else { 'Abweichung' }) }
        $rw = $rawBy["$($m.TabelleId).$($m.FeldId)"]
        if ($m.Basis3 -eq 'choice' -and $rw) {
            $soll = @($rw.AuswahlWerte -split '\|' | ForEach-Object { ($_ -split '=', 2)[-1] })
            $ist = @($f['options'] | Sort-Object { [int]$_['order'] } | ForEach-Object { $_['name'] })
            AddA $t $fn 'Auswahloptionen' "$($soll.Count)" "$($ist.Count)" $(if (($soll -join '|') -eq ($ist -join '|')) { 'ok' } else { 'Abweichung' })
        }
        if ($m.Basis3 -eq 'ref' -and $rw -and $tName.ContainsKey($rw.RefTabelleId)) {
            AddA $t $fn 'Verweisziel' $tName[$rw.RefTabelleId] ([string]$f['refTableName']) $(if ($f['refTableName'] -eq $tName[$rw.RefTabelleId]) { 'ok' } else { 'Abweichung' })
        }
        if ($m.Ninox4Typ -eq 'function') { $has = [bool]$f['expression']; AddA $t $fn 'Formel vorhanden' 'ja' $(if ($has) { 'ja' } else { 'nein' }) $(if ($has) { 'ok' } else { 'Abweichung' }) }
        $sollReq = ($m.Pflicht -eq 'True') -and ($m.Ninox4Typ -notin 'function', 'reverse', 'file')
        $istReq = [bool]$f['required']
        if ($sollReq -or $istReq) { AddA $t $fn 'Pflicht' $(if ($sollReq) { 'ja' } else { 'nein' }) $(if ($istReq) { 'ja' } else { 'nein' }) $(if ($sollReq -eq $istReq) { 'ok' } else { 'Befund' }) }
    }
    $A | Export-Csv (Join-Path $e '13_abnahme_struktur.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8

    # ---------- B Daten der Stichprobe
    $B = New-Object Collections.Generic.List[object]
    function AddB($t, $f, $pr, $n, $abw, $erg) { $B.Add([pscustomobject]@{ Tabelle = $t; Feld = $f; Pruefung = $pr; Geprueft = $n; Abweichungen = $abw; Ergebnis = $erg }) }
    $pl = $ser.DeserializeObject([IO.File]::ReadAllText((Join-Path $w 'stichprobe_payload.json'), [Text.Encoding]::UTF8))
    $norm = { param($x) if ($null -eq $x) { return '' }; if ($x -is [bool]) { return "$x".ToLowerInvariant() }; if ($x -is [ValueType] -and $x -isnot [bool]) { return ([double]$x).ToString('R', [Globalization.CultureInfo]::InvariantCulture) }; return (([string]$x) -replace "`r`n", "`n").Trim() }
    foreach ($t in $pl.Keys) {
        $idmap = $ser.DeserializeObject([IO.File]::ReadAllText((Join-Path $w "idmap_$t.json"), [Text.Encoding]::UTF8))
        $ist = @(); $off = 0
        while ($true) { $d = @((Get-Json "/modules/$mod/tables/$t/records?limit=100&offset=$off")['data']); $ist += $d; if ($d.Count -lt 100) { break }; $off += 100 }
        $byId = @{}; foreach ($r in $ist) { $byId[[string]$r['id']] = $r['values'] }
        AddB $t '' 'Zeilenzahl' $pl[$t].Count ([Math]::Abs($pl[$t].Count - $ist.Count)) $(if ($pl[$t].Count -eq $ist.Count) { 'ok' } else { 'Abweichung' })
        $feldAbw = @{}; $feldN = @{}; $refAbw = @{}; $refN = @{}
        foreach ($rec in $pl[$t]) {
            $nid = [string]$idmap[[string]$rec['altId']]; $vals = $byId[$nid]
            if ($null -eq $vals) { AddB $t '' 'Datensatz im Ziel' 1 1 'Abweichung'; continue }
            foreach ($k in $rec['werte'].Keys) {
                $feldN[$k] = 1 + [int]$feldN[$k]
                $soll = & $norm $rec['werte'][$k]; $istW = & $norm $vals[$k]
                $gleich = ($soll -eq $istW)
                if (-not $gleich -and $rec['werte'][$k] -is [ValueType] -and $vals[$k] -is [ValueType]) { $gleich = ([Math]::Abs([double]$rec['werte'][$k] - [double]$vals[$k]) -lt 1e-9) }
                if (-not $gleich -and $soll -match '^\d{4}-\d{2}-\d{2}[T ]\d' -and $istW -match '^\d{4}-\d{2}-\d{2}[T ]\d') {   # Zeitstempel: gleicher Zeitpunkt (UTC), nur andere Schreibweise
                    $d1 = [DateTimeOffset]::MinValue; $d2 = [DateTimeOffset]::MinValue
                    $st = [Globalization.DateTimeStyles]::AssumeUniversal
                    if ([DateTimeOffset]::TryParse($soll, [Globalization.CultureInfo]::InvariantCulture, $st, [ref]$d1) -and [DateTimeOffset]::TryParse($istW, [Globalization.CultureInfo]::InvariantCulture, $st, [ref]$d2)) { $gleich = ($d1.UtcDateTime -eq $d2.UtcDateTime) }
                }
                if (-not $gleich) { $feldAbw[$k] = 1 + [int]$feldAbw[$k] }
            }
            foreach ($k in $rec['refs'].Keys) {
                $z = $rec['refs'][$k]; $zt = $tName[[string]$z['ziel']]
                $refN[$k] = 1 + [int]$refN[$k]
                $erw = $null; if ($zt) { $zm = $ser.DeserializeObject([IO.File]::ReadAllText((Join-Path $w "idmap_$zt.json"), [Text.Encoding]::UTF8)); $erw = [string]$zm[[string]$z['id']] }
                if (([string]$vals[$k]) -ne $erw) { $refAbw[$k] = 1 + [int]$refAbw[$k] }
            }
        }
        foreach ($k in $feldN.Keys) { AddB $t $k 'Wert' $feldN[$k] ([int]$feldAbw[$k]) $(if ([int]$feldAbw[$k] -eq 0) { 'ok' } else { 'Befund' }) }
        foreach ($k in $refN.Keys) { AddB $t $k 'Verweis' $refN[$k] ([int]$refAbw[$k]) $(if ([int]$refAbw[$k] -eq 0) { 'ok' } else { 'Abweichung' }) }
    }
    $B | Export-Csv (Join-Path $e '14_abnahme_daten.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8

    # ---------- C Formeln
    $sollDatei = Join-Path $w 'soll_formeln_ninox3.csv'
    $cErg = if (Test-Path $sollDatei) { 'Soll vorhanden, Vergleich noch nicht ausgefuehrt' } else { 'nicht belegt' }

    # ---------- Auswertung
    $res = { param($rows, $col) $abw = @($rows | Where-Object { $_.$col -eq 'Abweichung' }).Count; $bef = @($rows | Where-Object { $_.$col -in 'Befund', 'bekannte Luecke' }).Count; if ($abw -gt 0) { 'nicht bestanden' } elseif ($bef -gt 0) { 'bestanden mit Befund' } else { 'bestanden' } }
    $aRes = & $res $A 'Ergebnis'; $bRes = & $res $B 'Ergebnis'
    $summary = [ordered]@{ Modul = $mod; A_Struktur = $aRes; A_Pruefungen = $A.Count; A_Abweichungen = @($A | Where-Object Ergebnis -eq 'Abweichung').Count; A_BekannteLuecken = @($A | Where-Object Ergebnis -eq 'bekannte Luecke').Count; A_Befunde = @($A | Where-Object Ergebnis -eq 'Befund').Count
        B_Daten = $bRes; B_Pruefungen = $B.Count; B_Abweichungen = @($B | Where-Object Ergebnis -eq 'Abweichung').Count; B_Befunde = @($B | Where-Object Ergebnis -eq 'Befund').Count; C_Formeln = $cErg }
    # Bericht (nur Zaehler und Feldnamen)
    $md = New-Object Text.StringBuilder; $ln = { param($x) [void]$md.AppendLine($x) }
    & $ln "# Abnahmebericht $($cfg.workspaceName) / $mod"
    & $ln "Stand: $(Get-Date -Format 'yyyy-MM-dd HH:mm') | Ziel: Workspace $($cfg.workspaceName) ($($cfg.workspaceId)), Modul $mod"
    & $ln ''; & $ln '## Ergebnis'; & $ln '| Pruefung | Ergebnis | Pruefungen | Abweichungen | Befunde / bekannte Luecken |'; & $ln '|---|---|---|---|---|'
    & $ln "| A Struktur | $aRes | $($summary.A_Pruefungen) | $($summary.A_Abweichungen) | $($summary.A_Befunde + $summary.A_BekannteLuecken) |"
    & $ln "| B Daten (Stichprobe) | $bRes | $($summary.B_Pruefungen) | $($summary.B_Abweichungen) | $($summary.B_Befunde) |"
    & $ln "| C Formelwerte | $cErg | - | - | - |"
    & $ln ''; & $ln '## Befunde und Abweichungen'; & $ln '| Pruefung | Tabelle | Feld | Art | Soll | Ist | Ergebnis |'; & $ln '|---|---|---|---|---|---|---|'
    foreach ($x in @($A | Where-Object { $_.Ergebnis -ne 'ok' })) { & $ln "| A | $($x.Tabelle) | $($x.Feld) | $($x.Pruefung) | $($x.Soll) | $($x.Ist) | $($x.Ergebnis) |" }
    foreach ($x in @($B | Where-Object { $_.Ergebnis -ne 'ok' })) { & $ln "| B | $($x.Tabelle) | $($x.Feld) | $($x.Pruefung) | $($x.Geprueft) geprueft | $($x.Abweichungen) Abweichungen | $($x.Ergebnis) |" }
    & $ln ''; & $ln '## Nicht belegt / offen'
    & $ln '- Formelwerte gegen Ninox 3: Soll-Datei fehlt (arbeit/soll_formeln_ninox3.csv); berechnete Werte stehen nicht in der Ninox-3-Sicherung.'
    & $ln '- Rueckverweise: nicht einzeln gezaehlt; sie ergeben sich aus den geprueften Verweisen.'
    & $ln '- Dateifelder und Mehrfachauswahl wurden nicht importiert (siehe Lueckenliste).'
    [IO.File]::WriteAllText((Join-Path $e 'abnahmebericht.md'), $md.ToString(), (New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]$summary
}
