# Phase 4: Formelfelder (type function) in Ninox 4 anlegen. Ninox prueft den Ausdruck beim Anlegen (beobachtet 2026-10-06) und lehnt
# Syntaxfehler und unbekannte Felder mit Zeile/Spalte ab. Formeln koennen auf andere Formelfelder verweisen: Mehrere Durchgaenge,
# Fehler "Field not found" werden im naechsten Durchgang erneut versucht.
# PowerShell 5.1. Schreibt nur in das Zielmodul, nur nach Freigabe fuer Phase 4. Gibt Zaehler zurueck, nie Formeltexte.
# Nutzung:
#   . .\scripts\ninox4-formeln-bauen.ps1
#   Invoke-Ninox4FormulaBuild -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1 [-Plan]
# Voraussetzung: ergebnis\08_formel_analyse.csv und arbeit\inventar\08_formel_analyse_voll.csv (aus Invoke-Ninox3Phase1 mit dem
# freigegebenen Mapping neu erzeugt). Spalte ZuBauen enthaelt die Formel mit Ninox-4-Namen (bei Adressdaten mit Platzhaltern).

. (Join-Path $PSScriptRoot 'ninox-support.ps1')
. (Join-Path $PSScriptRoot 'ninox-pruefungen.ps1')

function Invoke-Ninox4FormulaBuild {
    param(
        [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$HelpersPath,
        [string]$Freigabe = 'Ja (Chat, Phase 4)',
        [int]$MaxDurchgaenge = 8,
        [int]$PauseMs = 600,
        [int]$MaxTiefe = 18,          # Formeln mit mehr Klammerebenen werden NICHT versucht (Ninox laeuft ab ca. 20 Ebenen in Zeitueberschreitungen, beobachtet)
        [switch]$TiefeIgnorieren,     # trotzdem versuchen (nur nach ausdruecklicher Entscheidung des Nutzers)
        [int]$LangAb = 2500,          # Formeln ab dieser Laenge (Zeichen) gelten als lang: einzeln, mit langer Pause danach
        [int]$LangPauseSek = 20,          # Basispause zwischen Schreibaufrufen (Formelfelder werden von Ninox beim Anlegen geprueft und berechnet)
        [switch]$Plan)
    $ErrorActionPreference = 'Stop'
    Clear-NinoxStoerungen; Set-NinoxSchreibtempo -BasisMs $PauseMs
    $e = Join-Path $ProjectDir 'ergebnis'
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.moduleName
    $fa = @(Import-Csv (Join-Path $ProjectDir 'arbeit\inventar\08_formel_analyse_voll.csv') -Delimiter ';' -Encoding UTF8)
    $map = @(Import-Csv (Join-Path $e '06_mapping_vorschlag.csv') -Delimiter ';' -Encoding UTF8)
    if (@($map | Where-Object { $_.Freigabe -ne 'freigegeben' }).Count -gt 0) { throw 'Mapping ohne Freigabe.' }
    $mBy = @{}; foreach ($m in $map) { $mBy["$($m.TabelleId).$($m.FeldId)"] = $m }
    $todo = New-Object Collections.Generic.List[object]
    foreach ($f in ($fa | Where-Object { $_.Status -eq 'aufgeloest' })) {
        $m = $mBy["$($f.TabelleId).$($f.FeldId)"]
        if (-not $m) { continue }
        $label = if ($m.Ninox4LabelVorschlag) { $m.Ninox4LabelVorschlag } else { $m.Ninox4Label }
        $todo.Add([pscustomobject]@{ Tabelle = $m.Ninox4Tabelle; Feld = $m.Ninox4Feld; Label = $label; Ausdruck = $f.ZuBauen; Platzhalter = ($f.Anonymisiert -eq 'True'); Tiefe = [int]$f.Tiefe; Fehler = ''; Fertig = $false; Uebersprungen = $false })
    }
    $zuTief = @($todo | Where-Object { $_.Tiefe -gt $MaxTiefe })
    $summary = [ordered]@{ Modul = $mod; Formeln = $todo.Count; ZuTiefVerschachtelt = $zuTief.Count; DavonMitPlatzhaltern = @($todo | Where-Object { $_.Platzhalter }).Count; Nicht_aufgeloest = @($fa | Where-Object { $_.Status -ne 'aufgeloest' }).Count }
    if ($Plan) { $summary['Modus'] = 'Trockenlauf (nichts geschrieben)'; return [pscustomobject]$summary }

    Assert-NinoxSchreibfreigabe -ProjectDir $ProjectDir -Phase 4 -Modul $mod
    Set-Location $ProjectDir
    $env:NINOX_API_KEY = Get-NinoxKeyWert
    . $HelpersPath
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    foreach ($tn in ($todo | ForEach-Object { $_.Tabelle } | Select-Object -Unique)) {
        $have = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$mod/tables/$tn/fields?limit=500"))['data'] | ForEach-Object { $_['name'] })
        foreach ($x in ($todo | Where-Object { $_.Tabelle -eq $tn -and $have -contains $_.Feld })) { $x.Fertig = $true }
    }
    $schonDa = @($todo | Where-Object { $_.Fertig }).Count
    if (-not $TiefeIgnorieren) { foreach ($x in $todo) { if (-not $x.Fertig -and $x.Tiefe -gt $MaxTiefe) { $x.Fehler = "zu tief verschachtelt ($($x.Tiefe) Ebenen, Grenze $MaxTiefe): wird nicht versucht"; $x.Uebersprungen = $true } } }
    $logRows = New-Object Collections.Generic.List[object]
    $pass = 0; $progress = $true; $wartezeiten = 0; $hinweisGezeigt = $false; $trotzFehler = 0
    while ($progress -and $pass -lt $MaxDurchgaenge) {
        $pass++; $progress = $false; $done = 0
        # Kurze Formeln zuerst: lange (mehrere tausend Zeichen) koennen beim Anlegen Zeitueberschreitungen im Server ausloesen (beobachtet)
        foreach ($x in ($todo | Where-Object { -not $_.Fertig -and -not $_.Uebersprungen } | Sort-Object { $_.Ausdruck.Length })) {
            if ($x.Ausdruck.Length -ge $LangAb -and $done -gt 0) { Start-Sleep -Seconds $LangPauseSek }
            for ($try = 1; $try -le 6; $try++) {
                try {
                    Wait-NinoxSchreibpause
                    $null = Invoke-Ninox -Method Post -Path "/modules/$mod/tables/$($x.Tabelle)/fields" -Body @{ name = $x.Feld; labels = @{ '' = $x.Label }; type = 'function'; expression = $x.Ausdruck }
                    $x.Fertig = $true; $x.Fehler = ''; $progress = $true; $done++; Register-NinoxErfolg
                    # sofort protokollieren und Fortschritt festhalten
                    Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 4 -Aktion 'Formelfeld anlegen' -Ziel "$mod.$($x.Tabelle).$($x.Feld)" -Anzahl 1 -Ergebnis 'OK' -Freigabe $Freigabe
                    Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 4 -Schritt 'Formelfelder' -Aktuell @($todo | Where-Object { $_.Fertig }).Count -Gesamt $todo.Count
                    break
                } catch {
                    $msg = $_.Exception.Message
                    $short = if ($msg -match '"message":"(.*?)"\}') { $Matches[1] } else { $msg }
                    $x.Fehler = $short
                    # Vorubergehende Serverfehler (kein Formelfehler): warten und erneut versuchen
                    if (Test-NinoxTransientError $msg) {
                        $progress = $true; $wartezeiten++; Register-NinoxTransient
                        Add-NinoxStoerung -Aktion 'Formelfelder anlegen (Phase 4 einer Migration)' -Methode 'POST' -Pfad "/modules/$mod/tables/$($x.Tabelle)/fields" -Meldung $msg -Feld $x.Feld
                        if (-not $hinweisGezeigt) { Write-Warning 'Ninox antwortet gerade nicht oder ist ausgelastet (Serverseite, kein Fehler in der Formel). Das Skript wartet und versucht es erneut. Bitte nicht abbrechen. Am Ende liegt eine fertige Meldung fuer den Ninox Support bereit.'; $hinweisGezeigt = $true }
                        Start-Sleep -Seconds (3 * $try); continue
                    }
                    # Ninox meldet bei manchen Formeln (z. B. mit 'like') einen Fehler, OBWOHL das Feld angelegt wurde (beobachtet): erst nachsehen
                    if ($msg -match 'unexpected error occurred in a workspace object operation') {
                        Start-Sleep -Seconds 2
                        try {
                            $have2 = @($ser.DeserializeObject((Invoke-Ninox -Method Get -Path "/modules/$mod/tables/$($x.Tabelle)/fields?limit=500"))['data'] | ForEach-Object { $_['name'] })
                            if ($have2 -contains $x.Feld) {
                                $x.Fertig = $true; $x.Fehler = ''; $progress = $true; $done++; $trotzFehler++
                                Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 4 -Aktion 'Formelfeld anlegen' -Ziel "$mod.$($x.Tabelle).$($x.Feld)" -Anzahl 1 -Ergebnis 'OK (Ninox meldete Fehler, Feld existiert)' -Freigabe $Freigabe
                                break
                            }
                        } catch { }
                    }
                    # Pruefung ohne Fortschritt: bei 'existiert schon' als erledigt zaehlen
                    if ($msg -match 'already exists|existiert schon') { $x.Fertig = $true; $x.Fehler = ''; break }
                    break
                }
            }
        }
        Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 4 -Aktion "Formelfelder, Durchgang $pass beendet" -Ziel $mod -Anzahl $done -Ergebnis "$(@($todo | Where-Object { -not $_.Fertig }).Count) offen" -Freigabe $Freigabe
    }
    Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 4 -Schritt 'Formelfelder' -Aktuell @($todo | Where-Object { $_.Fertig }).Count -Gesamt $todo.Count -Status $(if (@($todo | Where-Object { -not $_.Fertig }).Count -eq 0) { 'fertig' } else { 'fertig mit offenen Formeln' })
    $summary['UebersprungenZuTief'] = @($todo | Where-Object { $_.Uebersprungen }).Count
    # Fehlerliste: nur Feldname und Meldung von Ninox, keine Formeltexte
    $todo | Where-Object { -not $_.Fertig } | Select-Object Tabelle, Feld, Platzhalter, Fehler | Export-Csv (Join-Path $e 'formel_fehler.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Formelfelder anlegen (Phase 4 einer Migration, POST .../tables/{tabelle}/fields mit type function)' -Erfolgreich @($todo | Where-Object { $_.Fertig }).Count -Stand "$(@($todo | Where-Object { $_.Fertig }).Count) von $($todo.Count) Formelfeldern vorhanden" -AktionEn 'creating formula fields (migration phase 4, POST .../tables/{table}/fields with type function)' -StandEn "$(@($todo | Where-Object { $_.Fertig }).Count) of $($todo.Count) formula fields present" -BeispielBody '{"name":"<field>","labels":{"":"<label>"},"type":"function","expression":"<expression>"}'
    Show-NinoxSupportHinweis $sup
    $summary['SupportMeldung'] = if ($sup) { $sup.Datei } else { '' }
    $summary['AngelegtTrotzFehlermeldung'] = $trotzFehler; $summary['ServerWartezeiten'] = $wartezeiten; $summary['SchonVorhanden'] = $schonDa; $summary['Durchgaenge'] = $pass; $summary['Angelegt'] = @($todo | Where-Object { $_.Fertig }).Count; $summary['Offen'] = @($todo | Where-Object { -not $_.Fertig }).Count
    return [pscustomobject]$summary
}
