# Phase 3: Schema in Ninox 4 aufbauen (Module, Tabellen, Felder, Verweise, Rueckverweise umbenennen, Standardwerte) und pruefen.
# PowerShell 5.1. Schreibt NUR in das neue, leere Zielmodul. Setzt voraus: Freigabe fuer Phase 3 im Chat, NINOX_API_KEY gesetzt,
# ninox.config.json im Projektordner, Mapping mit Freigabe = freigegeben, ninox4-api-builder (ninox-helpers.ps1).
# Nutzung:
#   . .\scripts\ninox4-schema-bauen.ps1
#   Invoke-Ninox4SchemaBuild -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1 -Plan     # Trockenlauf, schreibt nichts
#   Invoke-Ninox4SchemaBuild -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1            # bauen
# Formelfelder (function) entstehen erst in Phase 4; Pflicht (required) wird erst nach dem Datenimport gesetzt (siehe phasen.md).
# Die Funktion gibt nur Zaehler zurueck, nie Inhalte.

. (Join-Path $PSScriptRoot 'ninox-support.ps1')
. (Join-Path $PSScriptRoot 'ninox-pruefungen.ps1')

function ConvertTo-N4Number { param([string]$s) return [double]::Parse($s.Trim(), [Globalization.CultureInfo]::InvariantCulture) }

function Get-N4TableOrder {
    # Reihenfolge nach Verweisen: Ziele zuerst
    param($FieldRows, $TableIds)
    $deps = @{}; foreach ($t in $TableIds) { $deps[$t] = @() }
    foreach ($f in ($FieldRows | Where-Object { $_.Basis -eq 'ref' -and $_.RefTabelleId })) { if ($f.RefTabelleId -ne $f.TabelleId) { $deps[$f.TabelleId] += $f.RefTabelleId } }
    $order = New-Object Collections.Generic.List[string]; $left = New-Object Collections.Generic.List[string]; $TableIds | ForEach-Object { $left.Add($_) }
    while ($left.Count -gt 0) {
        $ready = @($left | Where-Object { @($deps[$_] | Where-Object { $order -notcontains $_ -and $_ }).Count -eq 0 })
        if ($ready.Count -eq 0) { $order.AddRange($left); break }
        foreach ($r in $ready) { $order.Add($r); [void]$left.Remove($r) }
    }
    return @($order)
}

function Invoke-Ninox4SchemaBuild {
    param(
        [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$HelpersPath,
        [string]$Freigabe = 'Ja (Chat, Phase 3)',
        [int]$PauseMs = 300,          # Basispause zwischen Schreibaufrufen
        [switch]$Fortsetzen,          # nach Abbruch: vorhandenes Modul weiterbauen, nur Fehlendes anlegen (nichts wird veraendert oder geloescht)
        [switch]$Plan)

    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $e = Join-Path $ProjectDir 'ergebnis'
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.moduleName
    $map = @(Import-Csv (Join-Path $e '06_mapping_vorschlag.csv') -Delimiter ';' -Encoding UTF8)
    $raw = @(Import-Csv (Join-Path $ProjectDir 'arbeit\inventar\02_felder_voll.csv') -Delimiter ';' -Encoding UTF8)
    $rawBy = @{}; foreach ($r in $raw) { $rawBy["$($r.TabelleId).$($r.FeldId)"] = $r }
    if (@($map | Where-Object { $_.Freigabe -ne 'freigegeben' }).Count -gt 0) { throw 'Das Mapping enthaelt Zeilen ohne Freigabe. Erst den Plan freigeben lassen (Spalte Freigabe = freigegeben).' }
    if ($mod -notmatch '^[a-z0-9_]+$') { throw "Modulname '$mod' ungueltig" }

    $tableIds = @($map | ForEach-Object { $_.TabelleId } | Select-Object -Unique)
    $order = Get-N4TableOrder -FieldRows $raw -TableIds $tableIds
    $tName = @{}; $tLabel = @{}
    foreach ($m in $map) { $tName[$m.TabelleId] = $m.Ninox4Tabelle; $tLabel[$m.TabelleId] = $m.Ninox4TabelleLabel }
    $isFormula = { param($m) $m.Status -eq 'formel' -or $m.Ninox4Typ -eq 'function' }
    $plain = @($map | Where-Object { -not (& $isFormula $_) -and $_.Basis3 -notin 'rev', 'ref' -and $_.Ninox4Typ })
    $refs = @($map | Where-Object { $_.Basis3 -eq 'ref' })
    $revs = @($map | Where-Object { $_.Basis3 -eq 'rev' })
    $fx = @($map | Where-Object { & $isFormula $_ })
    $summary = [ordered]@{ Modul = $mod; Tabellen = $order.Count; FelderNormal = $plain.Count; Verweisfelder = $refs.Count; Rueckverweise = $revs.Count; FormelfelderSpaeter = $fx.Count }
    if ($Plan) { $summary['Modus'] = 'Trockenlauf (nichts geschrieben)'; return [pscustomobject]$summary }

    Assert-NinoxSchreibfreigabe -ProjectDir $ProjectDir -Phase 3 -Modul $mod
    Set-Location $ProjectDir
    $env:NINOX_API_KEY = Get-NinoxKeyWert
    . $HelpersPath
    $errors = New-Object Collections.Generic.List[string]
    # Jede Schreibaktion sofort protokollieren (auch bei Abbruch nachvollziehbar) und den Fortschritt festhalten
    function Write-Log($aktion, $ziel, $anzahl, $ergebnis) { Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 3 -Aktion $aktion -Ziel $ziel -Anzahl $anzahl -Ergebnis $ergebnis -Freigabe $Freigabe }
    $script:Schritt = 0; $script:SchritteGesamt = 2 + 2 * $order.Count + $refs.Count
    function Step($text) { $script:Schritt++; Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 3 -Schritt $text -Aktuell $script:Schritt -Gesamt $script:SchritteGesamt }
    $script:Wartezeiten = 0; $script:HinweisGezeigt = $false; Clear-NinoxStoerungen; Set-NinoxSchreibtempo -BasisMs $PauseMs
    function Call($method, $path, $body) {
        for ($i = 1; $i -le 6; $i++) {
            try {
                if ($method -ne 'Get') { Wait-NinoxSchreibpause } else { Start-Sleep -Milliseconds 100 }
                $res = Invoke-Ninox -Method $method -Path $path -Body $body
                if ($method -ne 'Get') { Register-NinoxErfolg }
                return $res
            }
            catch {
                $msg = $_.Exception.Message
                if (Test-NinoxTransientError $msg) {
                    $script:Wartezeiten++; Register-NinoxTransient
                    Add-NinoxStoerung -Aktion 'Schema aufbauen (Phase 3 einer Migration)' -Methode $method -Pfad $path -Meldung $msg -Feld $(if ($body -is [hashtable] -and $body.ContainsKey('name')) { [string]$body['name'] } else { '' })
                    if ($i -lt 6) {
                        if (-not $script:HinweisGezeigt) { Write-Warning 'Ninox antwortet gerade nicht oder ist ausgelastet (Serverseite). Das Skript wartet und versucht es erneut. Bitte nicht abbrechen. Am Ende liegt bei Bedarf eine fertige Meldung fuer den Ninox Support bereit.'; $script:HinweisGezeigt = $true }
                        Start-Sleep -Seconds (3 * $i); continue
                    }
                    # Aufgegeben: Meldung fuer den Support erzeugen und zeigen, dann abbrechen
                    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Schema aufbauen (Phase 3 einer Migration)' -Stand 'Aufbau abgebrochen, nach der Stoerung fortsetzen' -AktionEn 'building the schema (migration phase 3)' -StandEn 'build stopped, to be resumed after the disruption' -BeispielBody '{"name":"<field>","labels":{"":"<label>"},"type":"<type>"}'
                    Show-NinoxSupportHinweis $sup
                }
                throw
            }
        }
    }
    function Get-Fields($table) { @($ser.DeserializeObject((Call 'Get' "/modules/$mod/tables/$table/fields?limit=500" $null))['data']) }

    # 1. Modul: nur anlegen, wenn es noch nicht existiert
    $exist = @($ser.DeserializeObject((Call 'Get' '/modules' $null))['data'] | ForEach-Object { $_['name'] })
    if (($exist -contains $mod) -and -not $Fortsetzen) { throw "Das Modul '$mod' existiert schon. Es wird nicht veraendert. Bitte einen neuen Namen waehlen oder mit -Fortsetzen nur Fehlendes ergaenzen." }
    if (($exist -notcontains $mod) -and $Fortsetzen) { throw "-Fortsetzen setzt ein vorhandenes Modul '$mod' voraus." }
    $sumFile = Join-Path $e 'inventar_zusammenfassung.json'
    $dbName = if (Test-Path $sumFile) { (Get-Content $sumFile -Raw -Encoding UTF8 | ConvertFrom-Json).Datenbank } else { $mod }
    $modLabel = "$dbName (Migrationstest)"
    if (-not $Fortsetzen) { $null = Call 'Post' '/modules' @{ name = $mod; labels = @{ '' = $modLabel }; openRoles = @('admin', 'editor') }; Write-Log 'Modul anlegen' $mod 1 'OK' }
    Step 'Modul'

    # 2. Tabellen
    $filesIn = @{}; foreach ($m in ($map | Where-Object { $_.Basis3 -eq 'file' })) { $filesIn[$m.TabelleId] = $true }
    $haveTables = if ($Fortsetzen) { @($ser.DeserializeObject((Call 'Get' "/modules/$mod/tables" $null))['data'] | ForEach-Object { $_['name'] }) } else { @() }
    foreach ($tid in $order) {
        if ($haveTables -contains $tName[$tid]) { continue }
        $body = @{ name = $tName[$tid]; labels = @{ '' = $tLabel[$tid] }; hasGlobalSearch = $true; createRoles = @('admin', 'editor'); deleteRoles = @('admin'); readRoles = @('admin', 'editor'); writeRoles = @('admin', 'editor') }
        if ($filesIn[$tid]) { $body['hasFiles'] = $true }
        try { $null = Call 'Post' "/modules/$mod/tables" $body; Write-Log 'Tabelle anlegen' "$mod.$($tName[$tid])" 1 'OK' }
        catch { $errors.Add("Tabelle $($tName[$tid]): $($_.Exception.Message)"); Write-Log 'Tabelle anlegen' "$mod.$($tName[$tid])" 1 'FEHLER' }
    }
    Step 'Tabellen'

    # 3. Normale Felder
    $pflicht = New-Object Collections.Generic.List[object]; $created = 0
    foreach ($tid in $order) {
        $haveF = if ($Fortsetzen) { @(Get-Fields $tName[$tid] | ForEach-Object { $_['name'] }) } else { @() }
        foreach ($m in ($plain | Where-Object { $_.TabelleId -eq $tid })) {
            if ($m.Pflicht -eq 'True') { $pflicht.Add([pscustomobject]@{ Tabelle = $m.Ninox4Tabelle; Feld = $m.Ninox4Feld }) }
            if ($haveF -contains $m.Ninox4Feld) { continue }
            $src = $rawBy["$($m.TabelleId).$($m.FeldId)"]
            $label = if ($m.Ninox4LabelVorschlag) { $m.Ninox4LabelVorschlag } else { $m.Ninox4Label }
            $body = @{ name = $m.Ninox4Feld; labels = @{ '' = $label }; type = $m.Ninox4Typ }
            if ($m.Ninox4Variante) { $body['variant'] = $m.Ninox4Variante }
            $opts = @{}
            if ($src -and $src.AuswahlWerte -and $m.Ninox4Typ -in 'choice', 'multi') {
                $list = @(); foreach ($p in ($src.AuswahlWerte -split '\|')) { $i = $p.IndexOf('='); if ($i -gt 0) { $opts[$p.Substring(0, $i)] = $p.Substring($i + 1); $list += @{ name = $p.Substring($i + 1) } } }
                if ($list.Count -gt 0) { $body['options'] = $list }
            }
            $def = $null
            if ($src -and $src.Standardwert) {
                foreach ($kv in ($src.Standardwert -split ' ; ')) {
                    $i = $kv.IndexOf('='); if ($i -lt 1) { continue }; $k = $kv.Substring(0, $i); $v = $kv.Substring($i + 1)
                    try {
                        switch ($k) {
                            'numberDefault' { $def = ConvertTo-N4Number $v }
                            'booleanDefault' { $def = ($v -eq 'True') }
                            'choiceDefault' { if ($opts.ContainsKey($v)) { $def = $opts[$v] } }
                            'dateDefault' { if ($v -eq 'today') { $def = @{ '$nx' = 'today()' } } }
                            'stringDefault' { $def = $v }
                        }
                    } catch { }
                }
            }
            if ($null -ne $def) { $body['defaultValue'] = $def }
            if ($src -and $src.Suche -eq 'True') { $body['search'] = $true }
            if ($src -and $src.Index -eq 'True') { $body['index'] = $true }
            $ok = $false
            foreach ($drop in @($null, 'index', 'defaultValue', 'search')) {
                if ($drop) { if (-not $body.ContainsKey($drop)) { continue }; $body.Remove($drop) }
                try { $null = Call 'Post' "/modules/$mod/tables/$($m.Ninox4Tabelle)/fields" $body; $ok = $true; if ($drop) { $errors.Add("Feld $($m.Ninox4Tabelle).$($m.Ninox4Feld): ohne $drop angelegt") }; break }
                catch { $last = $_.Exception.Message }
            }
            if ($ok) { $created++ } else { $errors.Add("Feld $($m.Ninox4Tabelle).$($m.Ninox4Feld): $last") }
        }
        Step "Felder $($tName[$tid])"
        Write-Log 'Felder anlegen' "$mod.$($tName[$tid])" @($plain | Where-Object { $_.TabelleId -eq $tid }).Count 'OK (Fehler siehe Zusammenfassung)'
    }

    # 4. Verweisfelder und automatisch entstehende Rueckverweise umbenennen
    $renamed = 0; $refCreated = 0
    $nameSets = @{}; foreach ($tid in $order) { $nameSets[$tName[$tid]] = @($plain + $refs + $revs | Where-Object { $_.TabelleId -eq $tid } | ForEach-Object { $_.Ninox4Feld }) }
    foreach ($m in $refs) {
        $tgt = $tName[[string]($rawBy["$($m.TabelleId).$($m.FeldId)"].RefTabelleId)]
        if (-not $tgt) { $errors.Add("Verweis $($m.Ninox4Tabelle).$($m.Ninox4Feld): Zieltabelle unbekannt"); continue }
        $label = if ($m.Ninox4LabelVorschlag) { $m.Ninox4LabelVorschlag } else { $m.Ninox4Label }
        $want = @($revs | Where-Object { $rawBy["$($_.TabelleId).$($_.FeldId)"].RefTabelleId -eq $m.TabelleId -and $rawBy["$($_.TabelleId).$($_.FeldId)"].RefFeldId -eq $m.FeldId })
        $refExists = $false
        if ($Fortsetzen) { $refExists = (@(Get-Fields $m.Ninox4Tabelle | ForEach-Object { $_['name'] }) -contains $m.Ninox4Feld) }
        $new = @()
        if ($refExists) {
            # Wiederaufnahme: ist der Rueckverweis schon richtig benannt? Sonst den einzigen unbenannten automatischen suchen
            $tf = Get-Fields $tgt
            if ($want.Count -eq 1 -and (@($tf | ForEach-Object { $_['name'] }) -contains $want[0].Ninox4Feld)) { Step "Verweis $($m.Ninox4Feld)"; continue }
            $expected = $nameSets[$tgt]
            $new = @($tf | Where-Object { $_['type'] -eq 'reverse' -and $_['refTableName'] -eq $m.Ninox4Tabelle -and $expected -notcontains $_['name'] })
        } else {
            $before = @(Get-Fields $tgt | ForEach-Object { $_['name'] })
            try { $null = Call 'Post' "/modules/$mod/tables/$($m.Ninox4Tabelle)/fields" @{ name = $m.Ninox4Feld; labels = @{ '' = $label }; type = 'reference'; refTableName = $tgt }; $refCreated++ }
            catch { $errors.Add("Verweis $($m.Ninox4Tabelle).$($m.Ninox4Feld): $($_.Exception.Message)"); continue }
            $new = @(Get-Fields $tgt | Where-Object { $before -notcontains $_['name'] -and $_['type'] -eq 'reverse' })
        }
        if ($new.Count -eq 1 -and $want.Count -eq 1) {
            $rl = if ($want[0].Ninox4LabelVorschlag) { $want[0].Ninox4LabelVorschlag } else { $want[0].Ninox4Label }
            try { $null = Call 'Patch' "/modules/$mod/tables/$tgt/fields/$($new[0]['name'])" @{ name = $want[0].Ninox4Feld; labels = @{ '' = $rl } }; $renamed++ }
            catch { $errors.Add("Rueckverweis in ${tgt}: Umbenennen von $($new[0]['name']) nach $($want[0].Ninox4Feld) fehlgeschlagen: $($_.Exception.Message)") }
        } elseif ($new.Count -ne 0 -or -not $refExists) { $errors.Add("Rueckverweis zu $($m.Ninox4Tabelle).$($m.Ninox4Feld): neue Felder $($new.Count), erwartet 1, Ninox-3-Gegenfelder $($want.Count): nicht umbenannt") }
        Step "Verweis $($m.Ninox4Feld)"
    }
    Write-Log 'Verweisfelder anlegen, Rueckverweise umbenennen' $mod $refCreated "$renamed umbenannt"
    # 5. Pflicht-Merkliste fuer Phase 5, Protokoll
    $pflicht | Export-Csv (Join-Path $e 'pflicht_nach_import.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8

    # 6. Pruefung: Rueckgelesenes Schema gegen das Mapping
    $chk = New-Object Collections.Generic.List[object]
    foreach ($tid in $order) {
        $have = @(Get-Fields $tName[$tid]); $names = @($have | ForEach-Object { $_['name'] })
        $expect = @($plain + $refs + $revs | Where-Object { $_.TabelleId -eq $tid } | ForEach-Object { $_.Ninox4Feld })
        $fxNames = @($fx | Where-Object { $_.TabelleId -eq $tid } | ForEach-Object { $_.Ninox4Feld })
        $missing = @($expect | Where-Object { $names -notcontains $_ }); $extra = @($names | Where-Object { $expect -notcontains $_ -and $fxNames -notcontains $_ })
        $chk.Add([pscustomobject]@{ Tabelle = $tName[$tid]; Erwartet = $expect.Count; Vorhanden = $names.Count; Fehlend = ($missing -join ', '); Zusaetzlich = ($extra -join ', '); Ergebnis = $(if ($missing.Count -eq 0 -and $extra.Count -eq 0) { 'bestanden' } else { 'Befund' }) })
    }
    $chk | Export-Csv (Join-Path $e 'schema_pruefung.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    $errors | Set-Content (Join-Path $e 'schema_fehler.txt') -Encoding UTF8
    $summary['FelderAngelegt'] = $created; $summary['VerweiseAngelegt'] = $refCreated; $summary['RueckverweiseUmbenannt'] = $renamed
    $summary['PruefungBestanden'] = @($chk | Where-Object { $_.Ergebnis -eq 'bestanden' }).Count; $summary['PruefungBefunde'] = @($chk | Where-Object { $_.Ergebnis -ne 'bestanden' }).Count
    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Schema aufbauen (Phase 3 einer Migration)' -Erfolgreich $created -Stand 'Aufbau beendet' -AktionEn 'building the schema (migration phase 3)' -StandEn 'build finished' -BeispielBody '{"name":"<field>","labels":{"":"<label>"},"type":"<type>"}'
    Show-NinoxSupportHinweis $sup
    $summary['SupportMeldung'] = if ($sup) { $sup.Datei } else { '' }
    Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 3 -Schritt 'Schema fertig' -Aktuell $script:SchritteGesamt -Gesamt $script:SchritteGesamt -Status $(if ($errors.Count -eq 0) { 'fertig' } else { 'fertig mit Befunden' })
    $summary['Fortsetzen'] = [bool]$Fortsetzen
    $summary['Fehler'] = $errors.Count; $summary['ServerWartezeiten'] = $script:Wartezeiten
    return [pscustomobject]$summary
}
