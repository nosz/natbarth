# Phase 5: anonymisierte, verknuepfungstreue Stichprobe in das Ninox-4-Zielmodul importieren (Testdaten, nie der Vollbestand).
# PowerShell 5.1. Schreibt NUR in das Zielmodul aus ninox.config.json und nur nach Freigabe fuer Phase 5 (Set-NinoxFreigabe).
# Nutzung:
#   . .\scripts\ninox4-import-stichprobe.ps1
#   Invoke-Ninox4SampleImport -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1 -Plan   # Trockenlauf: waehlt, anonymisiert, prueft, schreibt NICHTS nach Ninox
#   Invoke-Ninox4SampleImport -ProjectDir <projekt> -HelpersPath <...>\ninox-helpers.ps1          # importieren
# Ablauf: Stichprobe waehlen -> alle bestaetigten Personendaten-Felder anonymisieren -> Gegenpruefungen (Originalwerte, E-Mail/Telefon) ->
# Durchgang 1 (Datensaetze ohne Verweise, je Tabelle in Abhaengigkeitsreihenfolge, Zuordnung alt->neu in arbeit\idmap_<tabelle>.json) ->
# Durchgang 2 (Verweise per PATCH) -> Rueckzaehlung je Tabelle nach ergebnis\12_import_zaehlung.csv. Dateifelder bleiben leer, Pflicht wird NICHT gesetzt.
# Gibt nur Zaehler zurueck, nie Datensatzinhalte.

. (Join-Path $PSScriptRoot 'ninox3-reader.ps1')
. (Join-Path $PSScriptRoot 'ninox3-stichprobe.ps1')
. (Join-Path $PSScriptRoot 'ninox4-schema-bauen.ps1')   # laedt auch ninox-support.ps1 und ninox-pruefungen.ps1; liefert Get-N4TableOrder

function Invoke-Ninox4SampleImport {
    param(
        [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$HelpersPath,
        [string]$Freigabe = 'Ja (Chat, Phase 5)',
        [int]$PauseMs = 400,
        [int]$BatchSize = 50,
        [scriptblock]$PayloadHook,   # optional: bearbeitet die Nutzlast vor dem Schreiben (z. B. fuer _v2, siehe ninox4-v2.ps1)
        [switch]$Plan)

    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.Web.Extensions
    $ser = New-Object Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    $e = Join-Path $ProjectDir 'ergebnis'; $w = Join-Path $ProjectDir 'arbeit'
    $cfg = Get-Content (Join-Path $ProjectDir 'ninox.config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mod = $cfg.moduleName
    $status = Get-Content (Join-Path $e 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $mainType = [string]$status.stichprobe.haupttabelle; $count = [int]$status.stichprobe.anzahl; $seed = [int]$status.stichprobe.seed
    if (-not $mainType) { throw 'status.json enthaelt keine Haupttabelle der Stichprobe.' }
    if ($status.stichprobe.anonymisiert -ne $true -or $cfg.migration.anonymize -eq $false) { throw 'Die Stichprobe muss anonymisiert werden (anonymize=true). Eine Ausnahme verlangt eine ausdrueckliche Entscheidung des Nutzers mit Vermerk im Protokoll.' }
    $map = @(Import-Csv (Join-Path $e '06_mapping_vorschlag.csv') -Delimiter ';' -Encoding UTF8)
    if (@($map | Where-Object { $_.Freigabe -ne 'freigegeben' }).Count -gt 0) { throw 'Das Mapping enthaelt Zeilen ohne Freigabe.' }
    $dbOhne = Join-Path $w 'ohne\data.db'; $dbMit = Join-Path $w 'mit\data.db'

    # 1. Stichprobe waehlen
    $schema = Read-Ninox3Schema -DataDb $dbOhne
    $sample = Select-Ninox3Sample -DataDb $dbMit -Schema $schema -MainTypeId $mainType -Count $count -Seed $seed -IncludeChildren
    if (@($sample.DanglingRefs).Count -gt 0) { throw "Die Stichprobe enthaelt $(@($sample.DanglingRefs).Count) Verweise ins Leere. Abbruch." }

    # 2. Anonymisieren (alle bestaetigten Kandidaten) und pruefen
    $piiFields = @(Get-Ninox3PiiCandidates -Schema $schema | ForEach-Object { [string]$_.Schluessel })
    $originale = Get-Ninox3PiiOriginale -Sample $sample -Fields $piiFields
    $anon = Invoke-Ninox3Anonymize -Sample $sample -Fields $piiFields -Schema $schema
    $rest = @(Test-Ninox3AnonymisiertOhneOriginale -Sample $sample -Originale $originale)
    $originale = $null
    $pii = @(Test-Ninox3SampleForPii -Sample $sample)
    if ($rest.Count -gt 0) { throw "Nach der Anonymisierung kommen noch Originalwerte vor (Felder: $((@($rest | ForEach-Object { $_.Feld }) -join ', ')))." }
    if ($pii.Count -gt 0) { throw "Restpruefung: E-Mail- oder Telefonmuster gefunden (Felder: $((@($pii | ForEach-Object { $_.Feld }) -join ', ')))." }

    # 3. Umwandeln
    $payload = ConvertTo-Ninox4Payload -Sample $sample -Schema $schema -Mapping $map
    if ($PayloadHook) { $null = & $PayloadHook $payload }
    # Mehrfachauswahl: Die Kodierung in der Ninox-3-Sicherung (Texte wie "f7" oder "3") ist nicht belegt. Nicht raten: Felder auslassen und als Befund fuehren.
    $multiSkip = 0
    foreach ($m in @($map | Where-Object { $_.Basis3 -eq 'multi' })) {
        if (-not $payload.Contains($m.Ninox4Tabelle)) { continue }
        foreach ($r in $payload[$m.Ninox4Tabelle]) { if ($r['werte'].Contains($m.Ninox4Feld)) { $r['werte'].Remove($m.Ninox4Feld); $multiSkip++ } }
    }
    $tabellen = @($payload.Keys)
    $zaehl = foreach ($t in $tabellen) {
        $nRef = 0; foreach ($r in $payload[$t]) { $nRef += $r['refs'].Count }
        $nDat = 0; foreach ($r in $payload[$t]) { $nDat += $r['dateien'].Count }
        [pscustomobject]@{ Tabelle = $t; Datensaetze = $payload[$t].Count; Verweise = $nRef; DateifelderOffen = $nDat }
    }
    $summary = [ordered]@{ Modul = $mod; Haupttabelle = $mainType; Tabellen = $tabellen.Count; Datensaetze = ($zaehl | Measure-Object Datensaetze -Sum).Sum; Verweise = ($zaehl | Measure-Object Verweise -Sum).Sum
        AnonymisierteFelder = $piiFields.Count; VerschiedeneErsatzwerte = $anon.VerschiedeneWerte; OriginalwerteUebrig = 0; EmailTelefonTreffer = 0; DateifelderLeerBleibend = ($zaehl | Measure-Object DateifelderOffen -Sum).Sum; MehrfachauswahlWerteAusgelassen = $multiSkip }
    if (-not (Test-Path $w)) { New-Item -ItemType Directory -Force -Path $w | Out-Null }
    Save-Ninox3Json -Object $payload -Path (Join-Path $w 'stichprobe_payload.json')
    if ($Plan) { $summary['Modus'] = 'Trockenlauf (nichts nach Ninox geschrieben)'; $summary['Je Tabelle'] = (($zaehl | ForEach-Object { "$($_.Tabelle)=$($_.Datensaetze)" }) -join ', '); return [pscustomobject]$summary }

    # 4. Schreiben
    Assert-NinoxSchreibfreigabe -ProjectDir $ProjectDir -Phase 5 -Modul $mod
    Set-Location $ProjectDir
    $env:NINOX_API_KEY = Get-NinoxKeyWert
    . $HelpersPath
    function Write-Log($aktion, $ziel, $anzahl, $ergebnis) { Add-NinoxProtokollZeile -ProjectDir $ProjectDir -Phase 5 -Aktion $aktion -Ziel $ziel -Anzahl $anzahl -Ergebnis $ergebnis -Freigabe $Freigabe }
    $script:Wartezeiten = 0; $script:HinweisGezeigt = $false; Clear-NinoxStoerungen; Set-NinoxSchreibtempo -BasisMs $PauseMs
    function Call($method, $path, $body, $feld) {
        for ($i = 1; $i -le 6; $i++) {
            try {
                if ($method -ne 'Get') { Wait-NinoxSchreibpause } else { Start-Sleep -Milliseconds 100 }
                $res = Invoke-Ninox -Method $method -Path $path -Body $body
                if ($method -ne 'Get') { Register-NinoxErfolg }
                return $res
            }
            catch {
                $msg = $_.Exception.Message
                if (Test-NinoxTransientError $msg) {
                    $script:Wartezeiten++; Register-NinoxTransient
                    Add-NinoxStoerung -Aktion 'Stichprobe importieren (Phase 5 einer Migration)' -Methode $method -Pfad $path -Meldung $msg -Feld $feld
                    if ($i -lt 6) {
                        if (-not $script:HinweisGezeigt) { Write-Warning 'Ninox antwortet gerade nicht oder ist ausgelastet (Serverseite). Das Skript wartet und versucht es erneut. Bitte nicht abbrechen.'; $script:HinweisGezeigt = $true }
                        Start-Sleep -Seconds (3 * $i); continue
                    }
                    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Stichprobe importieren (Phase 5 einer Migration)' -Stand 'Import abgebrochen; bereits importierte Datensaetze bleiben, nichts wird geloescht' -AktionEn 'import a test sample (phase 5 of a migration)' -StandEn 'import aborted; imported records remain, nothing is deleted'
                    Show-NinoxSupportHinweis $sup
                }
                throw
            }
        }
    }
    function Get-Ids($resp) {
        $d = $ser.DeserializeObject($resp)['data']
        if ($d -is [System.Collections.IDictionary] -and $d.ContainsKey('ids')) { return @($d['ids']) }
        return @($d | ForEach-Object { if ($_ -is [System.Collections.IDictionary]) { $_['id'] } else { $_ } })
    }

    # Vorabcheck: das Zielmodul muss existieren und die Tabellen muessen leer sein (nichts doppelt importieren)
    $exist = @($ser.DeserializeObject((Call 'Get' '/modules' $null ''))['data'] | ForEach-Object { $_['name'] })
    if ($exist -notcontains $mod) { throw "Das Zielmodul '$mod' existiert nicht." }
    foreach ($t in $tabellen) {
        $probe = $ser.DeserializeObject((Call 'Get' "/modules/$mod/tables/$t/records?limit=1" $null ''))['data']
        if (@($probe).Count -gt 0) { throw "Die Tabelle '$t' enthaelt bereits Datensaetze. Der Import schreibt nur in leere Tabellen." }
    }

    $raw = @(Import-Csv (Join-Path $ProjectDir 'arbeit\inventar\02_felder_voll.csv') -Delimiter ';' -Encoding UTF8)
    $tName = @{}; foreach ($m in $map) { $tName[$m.TabelleId] = $m.Ninox4Tabelle }
    $order = Get-N4TableOrder -FieldRows $raw -TableIds @($map | ForEach-Object { $_.TabelleId } | Select-Object -Unique)
    $ordered = @($order | ForEach-Object { $tName[$_] } | Where-Object { $tabellen -contains $_ })
    $idmap = @{}   # Tabelle -> (altId -> neueId)
    $imp = @{}
    $script:Schritt = 0; $script:Gesamt = 2 * $ordered.Count + 1
    function Step($text) { $script:Schritt++; Write-NinoxFortschritt -ProjectDir $ProjectDir -Phase 5 -Schritt $text -Aktuell $script:Schritt -Gesamt $script:Gesamt }

    # Durchgang 1: Datensaetze ohne Verweise
    foreach ($t in $ordered) {
        $rows = $payload[$t].ToArray(); $idmap[$t] = @{}; $done = 0
        for ($o = 0; $o -lt $rows.Count; $o += $BatchSize) {
            $chunk = $rows[$o..([Math]::Min($o + $BatchSize, $rows.Count) - 1)]
            $list = New-Object Collections.Generic.List[object]
            foreach ($r in $chunk) { $h = [ordered]@{}; foreach ($k in $r['werte'].Keys) { if ($null -ne $r['werte'][$k]) { $h[$k] = $r['werte'][$k] } }; $list.Add($h) }
            $resp = Call 'Post' "/modules/$mod/tables/$t/records" @{ records = $list.ToArray() } ''
            $ids = @(Get-Ids $resp)
            if ($ids.Count -ne $chunk.Count) { Write-Log 'Datensaetze anlegen' "$mod.$t" $chunk.Count 'FEHLER (Anzahl der Antwort passt nicht)'; throw "Tabelle ${t}: $($chunk.Count) gesendet, $($ids.Count) Ids erhalten. Abbruch, nichts wird geloescht." }
            for ($i = 0; $i -lt $chunk.Count; $i++) { $idmap[$t][[string]$chunk[$i]['altId']] = [string]$ids[$i] }
            $done += $chunk.Count
        }
        Save-Ninox3Json -Object $idmap[$t] -Path (Join-Path $w "idmap_$t.json")
        Write-Log 'Datensaetze anlegen' "$mod.$t" $done 'OK'; $imp[$t] = $done
        Step "Durchgang 1: $t"
    }

    # Durchgang 2: Verweise setzen
    $refOk = 0; $refOffen = New-Object Collections.Generic.List[string]
    foreach ($t in $ordered) {
        $upd = New-Object Collections.Generic.List[object]
        foreach ($r in $payload[$t].ToArray()) {
            if ($r['refs'].Count -eq 0) { continue }
            $h = [ordered]@{ id = [int64]$idmap[$t][[string]$r['altId']] }; $n = 0
            foreach ($f in $r['refs'].Keys) {
                $z = $r['refs'][$f]; $zt = $tName[[string]$z['ziel']]
                if ($zt -and $idmap.ContainsKey($zt) -and $idmap[$zt].ContainsKey([string]$z['id'])) { $h[$f] = $idmap[$zt][[string]$z['id']]; $n++ }
                else { $refOffen.Add("$t.$f") }
            }
            if ($n -gt 0) { $upd.Add($h) }
        }
        for ($o = 0; $o -lt $upd.Count; $o += $BatchSize) {
            $chunk = $upd.GetRange($o, [Math]::Min($BatchSize, $upd.Count - $o))
            $null = Call 'Patch' "/modules/$mod/tables/$t/records" @{ records = $chunk.ToArray() } ''
            $refOk += $chunk.Count
        }
        if ($upd.Count -gt 0) { Write-Log 'Verweise setzen' "$mod.$t" $upd.Count 'OK' }
        Step "Durchgang 2: $t"
    }

    # Rueckzaehlung
    $rows = foreach ($t in $ordered) {
        $n = 0; $off = 0
        while ($true) {
            $d = $ser.DeserializeObject((Call 'Get' "/modules/$mod/tables/$t/records?limit=100&offset=$off" $null ''))['data']
            $n += @($d).Count; if (@($d).Count -lt 100) { break }; $off += 100
        }
        [pscustomobject]@{ Tabelle = $t; Quelle = $payload[$t].Count; ImZiel = $n; Ergebnis = $(if ($n -eq $payload[$t].Count) { 'OK' } else { 'ABWEICHUNG' }) }
    }
    $rows | Export-Csv -Path (Join-Path $e '12_import_zaehlung.csv') -NoTypeInformation -Delimiter ';' -Encoding UTF8
    Step 'Rueckzaehlung'
    $sup = New-NinoxSupportMeldung -ProjectDir $ProjectDir -WorkspaceId $cfg.workspaceId -Modul $mod -Aktion 'Stichprobe importieren (Phase 5 einer Migration)' -Stand 'Import beendet, es gab Stoerungen' -AktionEn 'import a test sample (phase 5 of a migration)' -StandEn 'import finished' -Erfolgreich ([int]($rows | Measure-Object ImZiel -Sum).Sum); if ($sup) { Show-NinoxSupportHinweis $sup }
    $summary['Modus'] = 'Import ausgefuehrt'; $summary['Importiert'] = (($rows | ForEach-Object { "$($_.Tabelle)=$($_.ImZiel)/$($_.Quelle)" }) -join ', ')
    $summary['VerweiseGesetzt'] = $refOk; $summary['VerweiseOhneZuordnung'] = $refOffen.Count; $summary['Abweichungen'] = @($rows | Where-Object { $_.Ergebnis -ne 'OK' }).Count
    $summary['Wartezeiten'] = $script:Wartezeiten; $summary['SupportMeldung'] = $(if ($sup) { $sup.Datei } else { '' })
    return [pscustomobject]$summary
}
