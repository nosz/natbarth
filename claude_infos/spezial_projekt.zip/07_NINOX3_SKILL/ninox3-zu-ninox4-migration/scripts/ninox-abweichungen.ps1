# Abweichungen zwischen Dokumentation und Verhalten von Ninox 4 sowie mutmassliche API-Fehler: genau pruefen, erfassen, an die Entwickler melden.
# PowerShell 5.1. Rein lokal (ausser Invoke-Ninox4AbweichungenSync). Enthaelt keinen Key und keine Kundendaten.
#
# Ablauf:  Verdacht  ->  Pruefliste (6 Punkte)  ->  Status "geprueft"  ->  Entwicklermeldung + Eintrag in die Tabelle "abweichungen" im Dokumentationsmodul.
# Ein Verdacht bleibt lokal in ergebnis\abweichungen.csv, bis ALLE Pruefpunkte erfuellt sind. Erst dann darf der Skill von einem Fehler sprechen,
# die Tabelle in Ninox fuellen und die Meldung zeigen.
#
# Pruefpunkte (alle Pflicht):
#   DokuBeleg        Die Dokumentation (Link) sagt ausdruecklich, dass es gehen sollte (Kurzfassung, kein langes Zitat)
#   Wiederholung     Mindestens 2 Beobachtungen zu verschiedenen Zeitpunkten
#   Minimalbeispiel  Kleinstes Beispiel in einem Wegwerf-Modul, das den Effekt allein zeigt
#   Gegenprobe       Ein aehnlicher Aufruf, der funktioniert (grenzt die Ursache ein)
#   KeinEigenfehler  Key, Rechte, Syntax, falsche Reihenfolge und vorubergehende Serverfehler sind ausgeschlossen
#   KeineEchtdaten   Das Beispiel enthaelt keine Kundendaten und keinen Key

$script:AbwPruefpunkte = @('DokuBeleg', 'Wiederholung', 'Minimalbeispiel', 'Gegenprobe', 'KeinEigenfehler', 'KeineEchtdaten')

function Get-NinoxAbweichungenPfad { param([string]$ProjectDir) return (Join-Path $ProjectDir 'ergebnis\abweichungen.csv') }

function Get-NinoxAbweichungen {
    param([Parameter(Mandatory)][string]$ProjectDir)
    $p = Get-NinoxAbweichungenPfad $ProjectDir
    if (Test-Path -LiteralPath $p) { return @(Import-Csv -Path $p -Delimiter ';' -Encoding UTF8) }
    return @()
}

function Save-NinoxAbweichungen {
    param([string]$ProjectDir, $Rows)
    $dir = Join-Path $ProjectDir 'ergebnis'; New-Item -ItemType Directory -Force -Path $dir | Out-Null
    @($Rows) | Export-Csv -Path (Get-NinoxAbweichungenPfad $ProjectDir) -NoTypeInformation -Delimiter ';' -Encoding UTF8
}

function Add-NinoxAbweichung {
    <#
      Erfasst eine Abweichung. Status wird nicht frei gewaehlt: "geprueft" nur, wenn alle sechs Pruefpunkte erfuellt sind und mindestens
      zwei Beobachtungszeitpunkte genannt wurden; sonst "Verdacht" (mit Liste der offenen Pruefpunkte).
      -Pruefung: Hashtable mit den Schluesseln DokuBeleg, Wiederholung, Minimalbeispiel, Gegenprobe, KeinEigenfehler, KeineEchtdaten (je $true/$false).
    #>
    param(
        [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$Titel,
        [Parameter(Mandatory)][ValidateSet('API', 'Formel', 'Oberflaeche', 'Dokumentation')][string]$Bereich,
        [Parameter(Mandatory)][string]$Endpunkt,                 # z. B. "POST /modules/{m}/tables/{t}/fields"
        [Parameter(Mandatory)][string]$Erwartet,                 # was laut Dokumentation passieren sollte
        [Parameter(Mandatory)][string]$ErwartetQuelle,           # Link zur Dokumentation
        [Parameter(Mandatory)][string]$Tatsaechlich,             # was wirklich passiert (Statuscode, Meldung)
        [Parameter(Mandatory)][ValidateSet('blockierend', 'stoerend', 'kosmetisch')][string]$Schwere,
        [Parameter(Mandatory)][string[]]$Reproduktion,           # Schritte
        [Parameter(Mandatory)][string]$MinimalRequest,           # Request-Body des Minimalbeispiels (ohne Key)
        [string]$Gegenprobe = '', [string]$Workaround = '', [string[]]$Beobachtet = @(), [hashtable]$Pruefung = @{},
        # Englische Fassung (Pflicht fuer den Status geprueft): Titel, Erwartet, Tatsaechlich, Reproduktion; Gegenprobe und Workaround falls vorhanden
        [string]$TitelEn = '', [string]$ErwartetEn = '', [string]$TatsaechlichEn = '', [string[]]$ReproduktionEn = @(), [string]$GegenprobeEn = '', [string]$WorkaroundEn = '', [string[]]$BeobachtetEn = @(),
        [string]$Workspace = '', [string]$ApiVersion = '',
        # FUNDSTELLE (Pflicht fuer geprueft): wo das Beispiel liegt, damit die Entwickler es sofort ansehen und nachstellen koennen
        [string]$Modul = '', [string]$Tabelle = '', [string]$Feld = '', [string[]]$Fundstellen = @())   # Fundstellen: weitere vorhandene Beispielfelder, z. B. 'probe_kunden.t_like_if'
    $offen = @(); foreach ($k in $script:AbwPruefpunkte) { if (-not ($Pruefung.ContainsKey($k) -and $Pruefung[$k] -eq $true)) { $offen += $k } }
    if (@($Beobachtet).Count -lt 2 -and $offen -notcontains 'Wiederholung') { $offen += 'Wiederholung (weniger als 2 Zeitpunkte genannt)' }
    if (-not ($TitelEn -and $ErwartetEn -and $TatsaechlichEn -and @($ReproduktionEn).Count -gt 0)) { $offen += 'EnglischeFassung' }
    if (-not ($Workspace -and $Modul -and $Tabelle -and $Feld)) { $offen += 'Fundstelle (Workspace-ID, Modul, Tabelle und Feld nennen)' }
    if (($Gegenprobe -and -not $GegenprobeEn) -or ($Workaround -and -not $WorkaroundEn)) { if ($offen -notcontains 'EnglischeFassung') { $offen += 'EnglischeFassung' } }
    $status = if ($offen.Count -eq 0) { 'geprueft' } else { 'Verdacht' }
    # Schutz: kein Key und keine offensichtlichen Geheimnisse in den Texten
    $alles = @($Titel, $Erwartet, $Tatsaechlich, ($Reproduktion -join ' '), $MinimalRequest, $Gegenprobe, $Workaround, $TitelEn, $ErwartetEn, $TatsaechlichEn, ($ReproduktionEn -join ' '), $GegenprobeEn, $WorkaroundEn) -join ' '
    if ($alles -match '(?i)bearer\s+[A-Za-z0-9._-]{16,}' -or $alles -match '\b(?=[A-Za-z0-9_-]*[0-9])(?=[A-Za-z0-9_-]*[a-z])[A-Za-z0-9_-]{40,}\b') { throw 'Der Text enthaelt etwas, das wie ein Key aussieht. Entfernen (Platzhalter <API_KEY> verwenden) und neu versuchen.' }
    $rows = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir)
    $nr = if ($rows.Count -gt 0) { ([int]($rows | ForEach-Object { [int]$_.Nr } | Measure-Object -Maximum).Maximum) + 1 } else { 1 }
    $new = [pscustomobject]@{
        Nr = $nr; Titel = $Titel; Bereich = $Bereich; Endpunkt = $Endpunkt; Erwartet = $Erwartet; ErwartetQuelle = $ErwartetQuelle; Tatsaechlich = $Tatsaechlich
        Schwere = $Schwere; Status = $status; Reproduktion = ($Reproduktion -join ' | '); MinimalRequest = ($MinimalRequest -replace '\s+', ' '); Gegenprobe = $Gegenprobe
        Workaround = $Workaround; Beobachtet = ($Beobachtet -join ' | '); OffenePruefpunkte = ($offen -join ', '); Workspace = $Workspace; ApiVersion = $ApiVersion; Modul = $Modul; Tabelle = $Tabelle; Feld = $Feld; Fundstellen = ($Fundstellen -join ' | ')
        TitelEn = $TitelEn; ErwartetEn = $ErwartetEn; TatsaechlichEn = $TatsaechlichEn; ReproduktionEn = ($ReproduktionEn -join ' | '); GegenprobeEn = $GegenprobeEn; WorkaroundEn = $WorkaroundEn; BeobachtetEn = ($BeobachtetEn -join ' | ')
        GemeldetAm = ''; Meldung = ''; Notiz = ''
    }
    Save-NinoxAbweichungen -ProjectDir $ProjectDir -Rows ($rows + $new)
    return [pscustomobject]@{ Nr = $nr; Status = $status; Offen = $offen }
}

function Set-NinoxAbweichungStatus {
    # Nach der Pruefung ("Verdacht" -> "geprueft" nur ueber Add-NinoxAbweichung) nur noch: gemeldet, behoben, kein Fehler.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Nr, [Parameter(Mandatory)][ValidateSet('gemeldet', 'behoben', 'kein Fehler')][string]$Status, [string]$Notiz = '', [string]$Meldung = '')
    $rows = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir); $hit = $false
    foreach ($r in $rows) { if ([int]$r.Nr -eq $Nr) {
        if ($r.Status -eq 'Verdacht' -and $Status -in 'gemeldet', 'behoben') { throw "Abweichung $Nr ist nur ein Verdacht (offen: $($r.OffenePruefpunkte)). Erst genau pruefen." }
        $r.Status = $Status; if ($Notiz) { $r.Notiz = $Notiz }; if ($Meldung) { $r.Meldung = $Meldung }; if ($Status -eq 'gemeldet') { $r.GemeldetAm = (Get-Date -Format 'yyyy-MM-dd') }; $hit = $true } }
    if (-not $hit) { throw "Abweichung $Nr nicht gefunden." }
    Save-NinoxAbweichungen -ProjectDir $ProjectDir -Rows $rows
}

function New-NinoxEntwicklerMeldung {
    # KURZE, ZWEISPRACHIGE Meldung fuer die Ninox-Entwickler (Deutsch und Englisch in einer Datei, zum Kopieren): sie sollen ohne Rueckfrage sehen,
    # was kaputt ist, wie man es nachstellt und was zu tun ist. Nur fuer geprueft/gemeldet/behoben. Enthaelt weder Key noch Kundendaten
    # (Platzhalter <API_KEY>, <WORKSPACE_ID>). Ablage: ergebnis\support\<yyyyMMdd_HHmmss>_entwicklermeldung_<nr>_<kurztitel>.md
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Nr)
    $r = @(Get-NinoxAbweichungen -ProjectDir $ProjectDir) | Where-Object { [int]$_.Nr -eq $Nr } | Select-Object -First 1
    if (-not $r) { throw "Abweichung $Nr nicht gefunden." }
    if ($r.Status -eq 'Verdacht' -or $r.Status -eq 'kein Fehler') { throw "Abweichung $Nr hat den Status '$($r.Status)'. Eine Meldung entsteht erst nach genauer Pruefung (offen: $($r.OffenePruefpunkte))." }
    $methode, $pfad = ($r.Endpunkt -split ' ', 2)
    # Echte Namen einsetzen (Workspace, Modul, Tabelle); uebrige {x} werden zu <x>
    $bt = [string][char]96
    $pfadEin = $pfad
    if ($r.Modul) { $pfadEin = $pfadEin.Replace('{moduleName}', $r.Modul).Replace('{m}', $r.Modul) }
    if ($r.Tabelle) { $pfadEin = $pfadEin.Replace('{tableName}', $r.Tabelle).Replace('{t}', $r.Tabelle) }
    $pfadEin = [regex]::Replace($pfadEin, '\{(\w+)\}', { param($m) '<' + $m.Groups[1].Value + '>' })
    $wsId = if ($r.Workspace) { $r.Workspace } else { '<WORKSPACE_ID>' }
    $weitere = if ($r.Fundstellen) { $r.Fundstellen -replace ' \| ', ', ' } else { '' }
    # API-Pfad wie in der Swagger-Oberflaeche (/api/v1/workspace/{workspaceId}/modules/{moduleName}/...) samt Kurzbeschreibung der Operation
    $apiPfad = '/api/v1/workspace/{workspaceId}' + (($pfad -replace '\{m\}', '{moduleName}') -replace '\{t\}', '{tableName}')
    $apiSumm = ''
    $specDatei = Join-Path $ProjectDir 'arbeit\openapi.json'
    if (Test-Path $specDatei) {
        try {
            Add-Type -AssemblyName System.Web.Extensions
            $sp = (New-Object Web.Script.Serialization.JavaScriptSerializer -Property @{ MaxJsonLength = [int]::MaxValue }).DeserializeObject([IO.File]::ReadAllText($specDatei, [Text.Encoding]::UTF8))
            $op = $sp['paths'][$apiPfad][$methode.ToLowerInvariant()]
            if ($op -and $op['summary']) { $apiSumm = ' (' + $op['summary'] + ')' }
        } catch { }
    }
    $apiZeile = "$methode $apiPfad$apiSumm"
    $sevEn = switch ($r.Schwere) { 'blockierend' { 'blocking' } 'stoerend' { 'disruptive' } default { 'cosmetic' } }
    $beobEn = if ($r.BeobachtetEn) { $r.BeobachtetEn } else { $r.Beobachtet }
    $curl = "curl -X $methode `"https://go.ninox.com/api/v1/workspace/$wsId$pfadEin`" -H `"Authorization: Bearer <API_KEY>`" -H `"Content-Type: application/json`" -d '$($r.MinimalRequest)'"
    $steps = { param($s) $i = 0; ($s -split ' \| ' | ForEach-Object { $i++; "  $i. $_" }) -join "`n" }
    $md = New-Object Text.StringBuilder
    $ln = { param($x) [void]$md.AppendLine($x) }
    # EINE einfache Textdatei: erst Englisch (Entwickler), dann Deutsch. Slack-tauglich (*fett*, ```Codeblock```), ohne Markdown-Ueberschriften.
    & $ln "*[Ninox Public API] $($r.TitelEn)*"
    & $ln "=== ENGLISH ==="
    & $ln "*Where:* workspace $($r.Workspace) | module $($r.Modul) | table $($r.Tabelle) | field $($r.Feld)$(if ($weitere) { ' | more: ' + $weitere })"
    & $ln "*API path:* $apiZeile"
    & $ln "*Problem:* $($r.TatsaechlichEn)"
    & $ln "*Expected per docs:* $($r.ErwartetEn) ($($r.ErwartetQuelle))"
    & $ln "*Steps to reproduce:*"; & $ln (& $steps $r.ReproduktionEn)
    & $ln '```'; & $ln $curl; & $ln '```'
    if ($r.WorkaroundEn) { & $ln "*Workaround:* $($r.WorkaroundEn)" }
    & $ln ''
    & $ln "=== DEUTSCH ==="
    & $ln "*$($r.Titel)*"
    & $ln "*Wo:* Workspace $($r.Workspace) | Modul $($r.Modul) | Tabelle $($r.Tabelle) | Feld $($r.Feld)$(if ($weitere) { ' | weitere: ' + $weitere })"
    & $ln "*API-Pfad:* $apiZeile"
    & $ln "*Problem:* $($r.Tatsaechlich)"
    & $ln "*Erwartet laut Doku:* $($r.Erwartet) ($($r.ErwartetQuelle))"
    & $ln "*Nachstellen:*"; & $ln (& $steps $r.Reproduktion)
    & $ln "(curl-Aufruf: siehe oben)"
    if ($r.Workaround) { & $ln "*Workaround:* $($r.Workaround)" }
    $text = $md.ToString()
    $slug = ($r.Titel.ToLowerInvariant() -replace '[^a-z0-9]+', '_').Trim('_'); if ($slug.Length -gt 40) { $slug = $slug.Substring(0, 40).Trim('_') }
    $dir = Join-Path $ProjectDir 'ergebnis\support'; New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $file = Join-Path $dir ("{0}_meldung_{1:000}_{2}.txt" -f (Get-Date -Format 'yyyyMMdd_HHmmss'), [int]$Nr, $slug)
    [IO.File]::WriteAllText($file, $text, (New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]@{ Datei = $file; Text = $text }
}

function ConvertTo-NinoxSlackText {
    # Wandelt Markdown (wie in den Entwicklermeldungen) in Slack-mrkdwn: **fett** -> *fett*, Ueberschriften -> *fett*, Codebloecke bleiben,
    # Zeilen mit Aufzaehlung -> Punkt, Links bleiben lesbar. Slack kennt keine Tabellen und keine #-Ueberschriften.
    param([Parameter(Mandatory)][string]$Markdown)
    $out = New-Object Collections.Generic.List[string]; $inCode = $false
    foreach ($line in ($Markdown -split "`r?`n")) {
        if ($line.StartsWith('```')) { $inCode = -not $inCode; $out.Add('```'); continue }
        if ($inCode) { $out.Add($line); continue }
        $l = $line
        if ($l -match '^#{1,6}\s+(.*)$') { $l = '*' + $Matches[1].Trim() + '*' }
        else {
            $l = [regex]::Replace($l, '\*\*(.+?)\*\*', '*$1*')          # **fett** -> *fett*
            $l = [regex]::Replace($l, '^\s*[-*]\s+', [string][char]0x2022 + ' ')   # Aufzaehlung -> Punkt
        }
        $out.Add($l)
    }
    return (($out -join "`n") -replace "`n{3,}", "`n`n").Trim()
}

function New-NinoxSlackMeldung {
    # Es gibt nur EINE Datei pro Abweichung (siehe New-NinoxEntwicklerMeldung); sie ist bereits Slack-tauglich und wird hier nur erneut geliefert.
    param([Parameter(Mandatory)][string]$ProjectDir, [Parameter(Mandatory)][int]$Nr)
    $m = New-NinoxEntwicklerMeldung -ProjectDir $ProjectDir -Nr $Nr
    return [pscustomobject]@{ Datei = $m.Datei; Haupt = $m.Text; Text = $m.Text }
}
