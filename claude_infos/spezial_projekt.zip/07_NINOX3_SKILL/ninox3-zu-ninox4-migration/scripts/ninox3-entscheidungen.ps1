# Haelt Entscheidungen des Nutzers in der Lueckenliste und im Entscheidungsprotokoll fest (rein lokal, keine Personendaten).
# PowerShell 5.1.  Nutzung:  . .\scripts\ninox3-entscheidungen.ps1

function Add-Ninox3GapRow {
    # Fuegt eine Zeile in ergebnis\09_luecken.csv ein (Nr wird fortgesetzt). Keine Namen von Personen eintragen.
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Kategorie, [Parameter(Mandatory)][string]$Objekt,
        [Parameter(Mandatory)][string]$Beschreibung, [string]$Auswirkung = '', [string]$Aufwand = 'klein',
        [string]$Beleg = 'Entscheidung des Nutzers')
    $rows = @(Import-Csv -Path $Path -Delimiter ';' -Encoding UTF8)
    $nr = if ($rows.Count -gt 0) { ([int]($rows | ForEach-Object { [int]$_.Nr } | Measure-Object -Maximum).Maximum) + 1 } else { 1 }
    $new = [pscustomobject]@{ Nr = $nr; Kategorie = $Kategorie; Objekt = $Objekt; Beschreibung = $Beschreibung; Auswirkung = $Auswirkung; Aufwand = $Aufwand; Status = 'offen'; Verantwortlich = ''; Beleg = $Beleg }
    ($rows + $new) | Export-Csv -Path $Path -NoTypeInformation -Delimiter ';' -Encoding UTF8
    return $nr
}

function Add-Ninox3Decision {
    # Protokolliert eine Entscheidung (ergebnis\entscheidungen.csv): Phase, Thema, Entscheidung, Datum. Ohne Personendaten.
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][int]$Phase, [Parameter(Mandatory)][string]$Thema, [Parameter(Mandatory)][string]$Entscheidung)
    $row = [pscustomobject]@{ Datum = (Get-Date -Format 'yyyy-MM-dd HH:mm'); Phase = $Phase; Thema = $Thema; Entscheidung = $Entscheidung }
    $rows = @(if (Test-Path -LiteralPath $Path) { Import-Csv -Path $Path -Delimiter ';' -Encoding UTF8 })
    ($rows + $row) | Export-Csv -Path $Path -NoTypeInformation -Delimiter ';' -Encoding UTF8
}
