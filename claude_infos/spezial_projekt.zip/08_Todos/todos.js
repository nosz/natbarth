// Spiegel von todos.json (ohne Grabsteine). Nicht von Hand aendern: wird von todos.ps1 erzeugt.
window.NX_TODOS = {
  "version": 1,
  "geaendert": "2026-10-28T17:48:50+01:00",
  "aufgaben": [
    { "id": 1793174400001, "text": "Outlook Abwesenheitseintrag entfernen", "done": false, "star": 0, "due": "2026-11-04", "zeit": "", "quelle": "sarah", "hinweis": "Gehört zum To-do 'Outlook Abwesenheitsnotiz eintragen'", "created": 1793174400001, "geaendert": 1793174400001, "erledigtAm": 0, "geloescht": false },
    { "id": 1793174400002, "text": "Leo Text Ninox4", "done": false, "star": 1, "due": "2026-11-04", "zeit": "", "quelle": "sarah", "hinweis": "", "created": 1793174400002, "geaendert": 1793206128874, "erledigtAm": 0, "geloescht": false },
    { "id": 1793183861325, "text": "aria update", "done": true, "star": 0, "due": "", "zeit": "", "quelle": "manuell", "hinweis": "", "created": 1793183861325, "geaendert": 1793183861325, "erledigtAm": 1793183861325, "geloescht": false },
    { "id": 1793186671491, "text": "notiz", "done": true, "star": 0, "due": "", "zeit": "", "quelle": "manuell", "hinweis": "", "created": 1793186671491, "geaendert": 1793186671491, "erledigtAm": 1793186671491, "geloescht": false },
    { "id": 1793205084397, "text": "seb skill klären", "done": false, "star": 1, "due": "2026-11-05", "zeit": "", "quelle": "manuell", "hinweis": "", "created": 1793205084397, "geaendert": 1793206129912, "erledigtAm": 0, "geloescht": false }
  ]
};
