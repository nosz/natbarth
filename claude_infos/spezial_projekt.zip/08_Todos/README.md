# Zentrale To-do-Liste

Genau eine Liste für alle Aufgaben und Erinnerungen von Norbert (auch für den nächsten Tag). Die Liste ist eine Datei im Projektordner; ein späterer Umzug nach Ninox ist vorbereitet (sauberes Datenmodell, eindeutige Ids, Zeitstempel je Aufgabe).

| | |
|---|---|
| **Ordner** | `08_Todos\` |
| **Einzige Wahrheit** | `todos.json` |
| **Spiegel für Seiten** | `todos.js` (`window.NX_TODOS`, ohne Grabsteine; `file://` kann keine JSON-Datei laden). Geschrieben von `todos.ps1` und von der To-do-App bei verbundenem Ordner |
| **Werkzeug für Agenten und Menschen** | `todos.ps1` |
| **Sicherungen** | `sicherung\` (die letzten 20 Stände von `todos.json`, automatisch vor jeder Schreibaktion) |
| **Oberfläche** | To-do-App `02_Erstellte_Apps\03_todo\index.html` |
| **Live-Ansichten (lesen nur)** | Sarahs Übersicht `05_Sarah_Erinnerungen\sarah-uebersicht.html`, Abschnitt Erinnerungen in den Favoriten, Zähler im Knopf To-dos, globale Suche im Organigramm |
| **Archiv** | `05_Sarah_Erinnerungen\erinnerungen.md` (seit 28.10.2026 keine eigene Liste von Sarah mehr, nichts liest sie) |

## Regeln

1. Es gibt nur diese eine Liste. Keine zweite Liste (auch nicht in Berichten, Notizen oder im Browser-Speicher allein führen).
2. Aufgaben und Erinnerungen werden nur über die To-do-App oder `todos.ps1` geändert, nie `todos.json` oder `todos.js` von Hand bearbeiten.
3. `todos.js` wird immer zusammen mit `todos.json` geschrieben (von `todos.ps1` oder von der To-do-App bei verbundenem Ordner). Weicht der Spiegel ab, heilt `todos.ps1 -Aktion Synchronisieren` (die App heilt ihn beim Lesen selbst, wenn der Ordner verbunden ist).
4. Keine Zugangsdaten, Tokens, Schlüssel oder Kundendaten in Aufgaben (Geheimnisse gehören in Bitwarden oder den System-Schlüsselbund). Die Prüfung lehnt typische Muster ab.
5. Personenbezogene Daten nur, wenn für die interne Aufgabe wirklich nötig (Datenminimierung, DSGVO).

## Schema (Version 1)

```json
{ "version": 1, "geaendert": "2026-10-28T16:58:10+01:00",
  "aufgaben": [ { "id": 1793183773743, "text": "...", "done": false, "star": 0,
                  "due": "2026-11-04", "zeit": "09:30", "quelle": "manuell",
                  "hinweis": "", "created": 1793183773743, "geaendert": 1793183773743,
                  "erledigtAm": 0, "geloescht": false } ] }
```

| Feld | Bedeutung |
|---|---|
| `id` | Zahl, eindeutig (Zeitstempel in ms beim Anlegen) |
| `text` | Aufgabe, 1 bis 300 Zeichen |
| `done` | erledigt (true/false) |
| `star` | 1 = wichtig, sonst 0 |
| `due` | Fälligkeit `JJJJ-MM-TT` oder leer |
| `zeit` | Uhrzeit `HH:MM` oder leer (ganztägig); nur zusammen mit `due` |
| `quelle` | `manuell`, `sarah` oder `import` |
| `hinweis` | freier Zusatz (z. B. Link), bis 500 Zeichen |
| `created`, `geaendert` | Zeitstempel in ms; `geaendert` steuert das Zusammenführen |
| `erledigtAm` | Zeitstempel in ms oder 0 |
| `geloescht` | Grabstein: gelöscht, bleibt 30 Tage in `todos.json`, damit Löschungen beim Zusammenführen nicht zurückkommen; danach bereinigt `todos.ps1` |

Zusammenführen: je `id` gewinnt die neuere `geaendert` ("letzter Schreiber gewinnt je Aufgabe"); bei Gleichstand gewinnt der Grabstein. Das gilt für `todos.ps1 -Quelldatei` und für die App.

## Für Agenten: todos.ps1

```powershell
.\08_Todos\todos.ps1 -Aktion Liste [-Alle] [-Json]
.\08_Todos\todos.ps1 -Aktion Hinzufuegen -Text "Angebot senden" -Faellig 2026-11-05 -Zeit 09:30 -Quelle sarah -Hinweis "Kunde wartet" [-Stern 1]
.\08_Todos\todos.ps1 -Aktion Aendern -Id <id> [-Text ...] [-Faellig ...] [-Zeit ...] [-Quelle ...] [-Hinweis ...] [-Stern 0|1]
.\08_Todos\todos.ps1 -Aktion Erledigen -Id <id>        # statt -Id geht auch genau ein exakter -Text
.\08_Todos\todos.ps1 -Aktion Wiederoeffnen -Id <id>
.\08_Todos\todos.ps1 -Aktion Loeschen -Id <id>         # Grabstein
.\08_Todos\todos.ps1 -Aktion Synchronisieren [-Quelldatei <datei.json>]   # zusammenführen, bereinigen, Spiegel neu
.\08_Todos\todos.ps1 -Aktion Pruefen                   # Exit-Code 1 bei Fehler
```

Jede Schreibaktion: Sicherung, Validierung (eindeutige Ids, ISO-Datum, Uhrzeit, Textlänge, Quelle, keine Zugangsdaten-/Token-Muster), atomares Schreiben (temp-Datei, dann ersetzen), danach `todos.js` neu. Bei einem Fehler wird nichts geschrieben (Exit-Code 1). Gleichzeitige Aufrufe warten aufeinander (Sperre). Erinnerungen von Sarah: `-Quelle sarah`.

## To-do-App und Verbindung

**Einmalig einrichten:** In der To-do-App auf "Ordner 08_Todos verbinden" klicken und den Ordner `08_Todos` wählen (Chrome/Edge, File System Access API). Der Browser merkt sich den Ordner; nach einem Neustart fragt er die Berechtigung neu ab (dann wieder auf die Schaltfläche klicken). Danach liest und schreibt die App `todos.json` und schreibt nach **jeder** Änderung den Spiegel `todos.js` im selben Ordner: gleicher Inhalt, gleiches Format und gleicher Zeitstempel wie bei `todos.ps1` (`todos.ps1 -Aktion Pruefen` meldet "Spiegel identisch"). Wählst du einen Ordner ohne `todos.json`, verbindet die App nicht und legt nichts an. Stimmt der Spiegel beim Verbinden oder beim Neu-Lesen (Fokus, alle 30 s) nicht, schreibt die App ihn neu. Kann der Spiegel nicht geschrieben werden, steht im Status "Spiegel todos.js nicht aktualisiert", `todos.json` wird trotzdem geschrieben.

**Rückfall "Nur Datei verbinden":** nur `todos.json` wird verbunden (so war es in Stufe 1). Dann gibt es einen Hinweis: Der Spiegel wird nur über `todos.ps1` oder die Ordnerverbindung aktualisiert. Ohne Verbindung zeigt die App den Spiegel `todos.js` und merkt sich Änderungen, bis du verbindest. Firefox und Safari können weder Ordner noch Dateien verbinden: dort Spiegel plus Sichern (Export) und Laden (Import).

**Live-Ansichten:** Sarahs Übersicht, die Erinnerungen in den Favoriten, der Zähler und die Suche lesen Spiegel plus Browser-Cache der App (zusammengeführt je `id` nach `geaendert`, Gelöschte nie). Sie aktualisieren sich beim Laden und bei Änderungen im Browser-Speicher; nach einer Änderung per `todos.ps1` zeigt eine bereits offene Seite sie erst nach Neuladen.
## Migration (28.10.2026)

Aus `05_Sarah_Erinnerungen\erinnerungen.md` (3 offene Erinnerungen, `quelle sarah`) und der Importdatei `00_Aktuell\todo-import\2026-10-28_1136_todo-import-outlook-abwesenheitsnotiz.json` (1 Aufgabe, `quelle manuell`). `erinnerungen.md` blieb zunächst unverändert (Stufe 1).
Stufe 2 (28.10.2026): `erinnerungen.md` ist jetzt Archiv (Hinweis und alte Tabelle als Verlauf), Sarah arbeitet nur noch über `todos.ps1`, Sarahs Übersicht und die Favoriten-Erinnerungen sind Live-Ansichten, die Suche liest To-dos und Erinnerungen live.