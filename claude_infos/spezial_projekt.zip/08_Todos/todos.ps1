﻿# todos.ps1 - Zentrale To-do-Liste (Nobbis Super-Firma). Einzige Wahrheit: todos.json in diesem Ordner.
# Fuer Agenten und Menschen. Jede Schreibaktion: Sicherung, Validierung, atomar schreiben (temp + ersetzen), danach todos.js (Spiegel) neu erzeugen.
#
# Beispiele:
#   .\todos.ps1 -Aktion Liste                       (offene Aufgaben)
#   .\todos.ps1 -Aktion Liste -Alle                 (auch erledigte)
#   .\todos.ps1 -Aktion Hinzufuegen -Text "Angebot senden" -Faellig 2026-11-05 -Zeit 09:30 -Quelle sarah -Hinweis "Kunde wartet"
#   .\todos.ps1 -Aktion Aendern -Id 1793183773743 -Faellig 2026-11-06 -Stern 1
#   .\todos.ps1 -Aktion Erledigen -Id 1793183773743
#   .\todos.ps1 -Aktion Wiederoeffnen -Id 1793183773743
#   .\todos.ps1 -Aktion Loeschen -Id 1793183773743   (Grabstein, kein hartes Loeschen)
#   .\todos.ps1 -Aktion Synchronisieren [-Quelldatei <andere.json>]   (zusammenfuehren, bereinigen, Spiegel neu)
#   .\todos.ps1 -Aktion Pruefen                      (Exit-Code 1 bei Fehler)
# Erledigen/Wiederoeffnen/Loeschen akzeptieren statt -Id auch genau einen exakten -Text.
# Keine Zugangsdaten, Tokens oder Kundendaten in Aufgaben ablegen (die Validierung lehnt typische Muster ab).
param(
  [Parameter(Mandatory)] [ValidateSet('Liste', 'Hinzufuegen', 'Aendern', 'Erledigen', 'Wiederoeffnen', 'Loeschen', 'Synchronisieren', 'Pruefen')] [string]$Aktion,
  [long]$Id = 0,
  [string]$Text,
  [string]$Faellig,
  [string]$Zeit,
  [string]$Quelle,
  [string]$Hinweis,
  [int]$Stern = -1,
  [switch]$Alle,
  [switch]$Json,
  [string]$Quelldatei,
  [string]$Ordner = $PSScriptRoot
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$Ordner = (Resolve-Path -LiteralPath $Ordner).Path.TrimEnd('\')
$dateiJson = Join-Path $Ordner 'todos.json'
$dateiJs = Join-Path $Ordner 'todos.js'
$sicherungOrdner = Join-Path $Ordner 'sicherung'
$QUELLEN = @('manuell', 'sarah', 'import')
$MAXTEXT = 300
$MAXHINWEIS = 500
$GRABSTEIN_TAGE = 30
$SICHERUNGEN = 20

$MUSTER = @(
  '(?i)\b(passwort|password|kennwort|passwd|pwd|secret|token|api[_ -]?key|apikey|zugangsdaten)\b\s*[:=]\s*(?=\S*\d)\S{8,}',
  '\bAKIA[0-9A-Z]{16}\b',
  '\bgh[pousr]_[A-Za-z0-9]{20,}',
  '\bxox[abprs]-[A-Za-z0-9-]{10,}',
  '\bsk-[A-Za-z0-9_-]{20,}',
  '\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.',
  '-----BEGIN [A-Z ]*PRIVATE KEY-----',
  '(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{20,}',
  '(?i)(server|data source|host)=[^;]+;.*(password|pwd)=',
  '(?i)\b(mongodb(\+srv)?|postgres(ql)?|mysql|redis|amqp)://[^\s:@/]+:[^\s@]+@',
  '(?i)[?&](access_)?token=[A-Za-z0-9._-]{16}'
)

function Stop-Fehler([string]$meldung, [int]$code = 1) {
  Write-Output ('FEHLER: ' + $meldung)
  exit $code
}

# ---------- Serialisierung (eigene, damit die Ausgabe stabil und lesbar ist) ----------
function ConvertTo-JsonText([string]$s) {
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('"')
  foreach ($ch in $s.ToCharArray()) {
    $n = [int]$ch
    if ($ch -eq '"') { [void]$sb.Append('\"') }
    elseif ($ch -eq '\') { [void]$sb.Append('\\') }
    elseif ($n -eq 10) { [void]$sb.Append('\n') }
    elseif ($n -eq 13) { [void]$sb.Append('\r') }
    elseif ($n -eq 9) { [void]$sb.Append('\t') }
    elseif ($n -lt 32 -or $n -eq 0x2028 -or $n -eq 0x2029) { [void]$sb.Append(('\u{0:x4}' -f $n)) }
    else { [void]$sb.Append($ch) }
  }
  [void]$sb.Append('"')
  $sb.ToString()
}
function Get-AufgabeZeile($t) {
  '{ "id": ' + $t.id + ', "text": ' + (ConvertTo-JsonText $t.text) + ', "done": ' + $(if ($t.done) { 'true' } else { 'false' }) +
  ', "star": ' + $t.star + ', "due": ' + (ConvertTo-JsonText $t.due) + ', "zeit": ' + (ConvertTo-JsonText $t.zeit) +
  ', "quelle": ' + (ConvertTo-JsonText $t.quelle) + ', "hinweis": ' + (ConvertTo-JsonText $t.hinweis) +
  ', "created": ' + $t.created + ', "geaendert": ' + $t.geaendert + ', "erledigtAm": ' + $t.erledigtAm +
  ', "geloescht": ' + $(if ($t.geloescht) { 'true' } else { 'false' }) + ' }'
}
function Get-DokumentText($liste, [string]$stempel) {
  $zeilen = @($liste | ForEach-Object { '    ' + (Get-AufgabeZeile $_) })
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append("{`n  `"version`": 1,`n  `"geaendert`": " + (ConvertTo-JsonText $stempel) + ",`n  `"aufgaben`": [")
  if ($zeilen.Count -gt 0) { [void]$sb.Append("`n" + ($zeilen -join ",`n") + "`n  ") }
  [void]$sb.Append("]`n}")
  $sb.ToString()
}

# ---------- Aufgaben normalisieren (alt und neu verstehen) ----------
function Get-Feld($o, [string]$name, $standard) {
  if ($o -is [System.Collections.IDictionary]) { if ($o.Contains($name) -and $null -ne $o[$name]) { return $o[$name] } return $standard }
  $p = $o.PSObject.Properties[$name]
  if ($p -and $null -ne $p.Value) { return $p.Value }
  $standard
}
function ConvertTo-Aufgabe($o) {
  $id = [long](Get-Feld $o 'id' 0)
  $created = [long](Get-Feld $o 'created' 0); if ($created -le 0) { $created = $id }
  $geaendert = [long](Get-Feld $o 'geaendert' 0); if ($geaendert -le 0) { $geaendert = $created }
  $done = [bool](Get-Feld $o 'done' $false)
  $erledigtAm = [long](Get-Feld $o 'erledigtAm' 0); if ($done -and $erledigtAm -le 0) { $erledigtAm = $geaendert }; if (-not $done) { $erledigtAm = 0 }
  $stern = if ([bool](Get-Feld $o 'star' 0)) { 1 } else { 0 }
  $q = [string](Get-Feld $o 'quelle' 'manuell'); if (-not $q) { $q = 'manuell' }
  [ordered]@{
    id = $id
    text = (([string](Get-Feld $o 'text' '')) -replace '[\r\n]+', ' ').Trim()
    done = $done
    star = $stern
    due = ([string](Get-Feld $o 'due' '')).Trim()
    zeit = ([string](Get-Feld $o 'zeit' '')).Trim()
    quelle = $q
    hinweis = (([string](Get-Feld $o 'hinweis' '')) -replace '[\r\n]+', ' ').Trim()
    created = $created
    geaendert = $geaendert
    erledigtAm = $erledigtAm
    geloescht = [bool](Get-Feld $o 'geloescht' $false)
  }
}

# ---------- Validierung ----------
function Test-Liste($liste) {
  $f = New-Object System.Collections.ArrayList
  $ids = @{}
  foreach ($t in $liste) {
    $k = 'Id ' + $t.id
    if ($t.id -le 0) { [void]$f.Add("$k ungueltig (muss eine positive Zahl sein)") }
    if ($ids.ContainsKey([string]$t.id)) { [void]$f.Add("$k doppelt vorhanden") }
    $ids[[string]$t.id] = $true
    if ($t.text.Length -lt 1) { [void]$f.Add("$k hat keinen Text") }
    if ($t.text.Length -gt $MAXTEXT) { [void]$f.Add("$k Text laenger als $MAXTEXT Zeichen ($($t.text.Length))") }
    if ($t.hinweis.Length -gt $MAXHINWEIS) { [void]$f.Add("$k Hinweis laenger als $MAXHINWEIS Zeichen") }
    if ($t.due -ne '') {
      $d = [datetime]::MinValue
      if ($t.due -notmatch '^\d{4}-\d{2}-\d{2}$' -or -not [datetime]::TryParseExact($t.due, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$d)) { [void]$f.Add("$k Faelligkeit '$($t.due)' ist kein gueltiges Datum (JJJJ-MM-TT)") }
    }
    if ($t.zeit -ne '' -and $t.zeit -notmatch '^([01]\d|2[0-3]):[0-5]\d$') { [void]$f.Add("$k Uhrzeit '$($t.zeit)' ungueltig (HH:MM)") }
    if ($t.zeit -ne '' -and $t.due -eq '') { [void]$f.Add("$k hat eine Uhrzeit, aber keine Faelligkeit") }
    if ($QUELLEN -notcontains $t.quelle) { [void]$f.Add("$k Quelle '$($t.quelle)' unbekannt (manuell|sarah|import)") }
    if ($t.created -le 0 -or $t.geaendert -le 0) { [void]$f.Add("$k ohne created/geaendert") }
    foreach ($feld in 'text', 'hinweis') {
      foreach ($m in $MUSTER) { if ($t[$feld] -match $m) { [void]$f.Add("$k $feld enthaelt ein Zugangsdaten-/Token-Muster (nicht speichern; Geheimnisse gehoeren in Bitwarden oder den System-Schluesselbund)"); break } }
    }
  }
  , $f
}

# ---------- Lesen ----------
function Read-Dokument([string]$pfad) {
  if (-not (Test-Path -LiteralPath $pfad)) { return $null }
  $roh = [IO.File]::ReadAllText($pfad, $utf8)
  if ($roh.Trim().Length -eq 0) { return @{ version = 1; geaendert = ''; aufgaben = @() } }
  try { $o = $roh | ConvertFrom-Json } catch { Stop-Fehler "$pfad ist kein gueltiges JSON ($($_.Exception.Message))" }
  if ($o -is [System.Array]) { $liste = @($o) }                    # alte Rohliste
  elseif ($o.PSObject.Properties['aufgaben']) { $liste = @($o.aufgaben) }
  elseif ($o.PSObject.Properties['todos']) { $liste = @($o.todos) }  # alter Export
  else { Stop-Fehler "$pfad hat kein Feld 'aufgaben'" }
  $norm = @($liste | Where-Object { $null -ne $_ } | ForEach-Object { ConvertTo-Aufgabe $_ })
  @{ version = $(if ($o.PSObject.Properties['version']) { [int]$o.version } else { 1 }); geaendert = $(if ($o.PSObject.Properties['geaendert']) { [string]$o.geaendert } else { '' }); aufgaben = $norm }
}
function Merge-Listen($a, $b) {
  $map = @{}
  foreach ($t in @($a)) { $map[[string]$t.id] = $t }
  foreach ($t in @($b)) {
    $k = [string]$t.id
    if (-not $map.ContainsKey($k)) { $map[$k] = $t; continue }
    $o = $map[$k]
    if ($t.geaendert -gt $o.geaendert -or ($t.geaendert -eq $o.geaendert -and $t.geloescht -and -not $o.geloescht)) { $map[$k] = $t }
  }
  @($map.Values | Sort-Object { [long]$_.id })
}
function Get-JetztMs { [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }

# ---------- Schreiben (Sicherung, atomar, Spiegel) ----------
function Write-AtomarDatei([string]$ziel, [string]$inhalt) {
  $tmp = $ziel + '.tmp-' + [guid]::NewGuid().ToString('N').Substring(0, 8)
  [IO.File]::WriteAllText($tmp, $inhalt, $utf8)
  for ($i = 1; $i -le 6; $i++) {
    try {
      if (Test-Path -LiteralPath $ziel) { [IO.File]::Replace($tmp, $ziel, [NullString]::Value) } else { [IO.File]::Move($tmp, $ziel) }
      return
    } catch { if ($i -eq 6) { if (Test-Path -LiteralPath $tmp) { [IO.File]::Delete($tmp) }; throw }; Start-Sleep -Milliseconds (200 * $i) }
  }
}
function Save-Liste($liste, [string]$aktionsName) {
  $jetzt = Get-JetztMs
  $grenze = $jetzt - [long]$GRABSTEIN_TAGE * 86400000
  $bereinigt = @($liste | Where-Object { -not ($_.geloescht -and $_.geaendert -lt $grenze) })
  $entfernt = @($liste).Count - $bereinigt.Count
  $fehler = Test-Liste $bereinigt
  if ($fehler.Count -gt 0) { Write-Output 'FEHLER: Validierung fehlgeschlagen, nichts geschrieben:'; $fehler | ForEach-Object { Write-Output ('  - ' + $_) }; exit 1 }
  if (-not (Test-Path -LiteralPath $sicherungOrdner)) { [void](New-Item -ItemType Directory -Path $sicherungOrdner -Force) }
  if (Test-Path -LiteralPath $dateiJson) {
    $stempelDatei = (Get-Date).ToString('yyyyMMdd-HHmmss-fff')
    Copy-Item -LiteralPath $dateiJson -Destination (Join-Path $sicherungOrdner ("todos-$stempelDatei.json")) -Force
    $alt = @(Get-ChildItem -LiteralPath $sicherungOrdner -Filter 'todos-*.json' -File | Sort-Object Name -Descending)
    if ($alt.Count -gt $SICHERUNGEN) { $alt | Select-Object -Skip $SICHERUNGEN | ForEach-Object { [IO.File]::Delete($_.FullName) } }
  }
  $stempel = [DateTimeOffset]::Now.ToString("yyyy-MM-dd'T'HH:mm:sszzz")
  $sichtbar = @($bereinigt | Where-Object { -not $_.geloescht })
  Write-AtomarDatei $dateiJson (Get-DokumentText $bereinigt $stempel)
  $js = "// Spiegel von todos.json (ohne Grabsteine). Nicht von Hand aendern: wird von todos.ps1 erzeugt.`nwindow.NX_TODOS = " + (Get-DokumentText $sichtbar $stempel) + ";`n"
  Write-AtomarDatei $dateiJs $js
  if ($entfernt -gt 0) { Write-Output "($entfernt alte Grabsteine bereinigt)" }
}

# ---------- Anzeige ----------
function Get-Kurz($t) {
  $f = if ($t.due) { $t.due + $(if ($t.zeit) { ' ' + $t.zeit } else { '' }) } else { '-' }
  ('{0,-14} {1,-16} {2,-8} {3}{4}{5}' -f $t.id, $f, $t.quelle, $(if ($t.star) { '* ' } else { '' }), $t.text, $(if ($t.hinweis) { '  [' + $t.hinweis + ']' } else { '' }))
}
function Find-Ziel($liste) {
  if ($Id -gt 0) {
    $z = @($liste | Where-Object { $_.id -eq $Id -and -not $_.geloescht })
    if ($z.Count -ne 1) { Stop-Fehler "Aufgabe mit Id $Id nicht gefunden" }
    return $z[0]
  }
  if ($Text) {
    $z = @($liste | Where-Object { -not $_.geloescht -and $_.text -ieq $Text.Trim() })
    if ($z.Count -eq 0) { Stop-Fehler "Keine Aufgabe mit dem Text '$Text' gefunden" }
    if ($z.Count -gt 1) { Stop-Fehler "Text '$Text' ist nicht eindeutig ($($z.Count) Treffer), bitte -Id angeben" }
    return $z[0]
  }
  Stop-Fehler 'Bitte -Id (oder einen exakten -Text) angeben'
}

# ---------- Aktionen ----------
$aktionLesend = ($Aktion -eq 'Liste' -or $Aktion -eq 'Pruefen')
$mutex = $null
if (-not $aktionLesend) {
  $hash = [BitConverter]::ToString((New-Object Security.Cryptography.SHA1Managed).ComputeHash($utf8.GetBytes($Ordner.ToLowerInvariant()))).Replace('-', '').Substring(0, 16)
  try { $mutex = New-Object Threading.Mutex($false, "Global\NobbisTodos_$hash") } catch { $mutex = New-Object Threading.Mutex($false, "Local\NobbisTodos_$hash") }
  try { if (-not $mutex.WaitOne(15000)) { Stop-Fehler 'Die Liste wird gerade von einem anderen Vorgang geschrieben (Zeitueberschreitung).' } } catch [Threading.AbandonedMutexException] { }
}
try {
  $dok = Read-Dokument $dateiJson
  if ($null -eq $dok) {
    if ($Aktion -eq 'Pruefen') { Stop-Fehler 'todos.json fehlt' }
    $dok = @{ version = 1; geaendert = ''; aufgaben = @() }
  }
  $liste = @($dok.aufgaben)

  switch ($Aktion) {
    'Liste' {
      $zeige = @($liste | Where-Object { -not $_.geloescht -and ($Alle -or -not $_.done) } | Sort-Object { if ($_.due) { $_.due } else { '9999' } }, { $_.zeit }, { -$_.star }, { $_.id })
      if ($Json) { Write-Output (Get-DokumentText $zeige $dok.geaendert) }
      else {
        if ($zeige.Count -eq 0) { Write-Output 'Keine Aufgaben.' }
        else { Write-Output ('{0,-14} {1,-16} {2,-8} {3}' -f 'Id', 'Faellig', 'Quelle', 'Aufgabe'); $zeige | ForEach-Object { Write-Output (Get-Kurz $_) } }
        Write-Output ("{0} angezeigt, {1} offen insgesamt" -f $zeige.Count, @($liste | Where-Object { -not $_.geloescht -and -not $_.done }).Count)
      }
    }
    'Hinzufuegen' {
      if (-not $Text) { Stop-Fehler '-Text fehlt' }
      $jetzt = Get-JetztMs
      $nid = $jetzt; while (@($liste | Where-Object { $_.id -eq $nid }).Count -gt 0) { $nid++ }
      $t = ConvertTo-Aufgabe ([ordered]@{ id = $nid; text = $Text; done = $false; star = $(if ($Stern -eq 1) { 1 } else { 0 }); due = $(if ($Faellig) { $Faellig } else { '' }); zeit = $(if ($Zeit) { $Zeit } else { '' }); quelle = $(if ($Quelle) { $Quelle } else { 'manuell' }); hinweis = $(if ($Hinweis) { $Hinweis } else { '' }); created = $jetzt; geaendert = $jetzt; erledigtAm = 0; geloescht = $false })
      Save-Liste (@($liste) + @($t)) $Aktion
      Write-Output ("Hinzugefuegt: {0}" -f (Get-Kurz $t))
    }
    'Aendern' {
      $t = Find-Ziel $liste
      $geaendert = $false
      if ($PSBoundParameters.ContainsKey('Text') -and $Id -gt 0) { $t.text = ($Text -replace '[\r\n]+', ' ').Trim(); $geaendert = $true }
      if ($PSBoundParameters.ContainsKey('Faellig')) { $t.due = $Faellig.Trim(); if ($t.due -eq '') { $t.zeit = '' }; $geaendert = $true }
      if ($PSBoundParameters.ContainsKey('Zeit')) { $t.zeit = $Zeit.Trim(); $geaendert = $true }
      if ($PSBoundParameters.ContainsKey('Quelle')) { $t.quelle = $Quelle.Trim(); $geaendert = $true }
      if ($PSBoundParameters.ContainsKey('Hinweis')) { $t.hinweis = ($Hinweis -replace '[\r\n]+', ' ').Trim(); $geaendert = $true }
      if ($Stern -ge 0) { $t.star = $(if ($Stern -eq 1) { 1 } else { 0 }); $geaendert = $true }
      if (-not $geaendert) { Stop-Fehler 'Nichts zu aendern angegeben (-Text, -Faellig, -Zeit, -Quelle, -Hinweis, -Stern)' }
      $t.geaendert = [Math]::Max((Get-JetztMs), $t.geaendert + 1)
      Save-Liste $liste $Aktion
      Write-Output ("Geaendert: {0}" -f (Get-Kurz $t))
    }
    'Erledigen' {
      $t = Find-Ziel $liste
      $t.done = $true; $jetzt = [Math]::Max((Get-JetztMs), $t.geaendert + 1); $t.erledigtAm = $jetzt; $t.geaendert = $jetzt
      Save-Liste $liste $Aktion
      Write-Output ("Erledigt: {0}" -f (Get-Kurz $t))
    }
    'Wiederoeffnen' {
      $t = Find-Ziel $liste
      $t.done = $false; $t.erledigtAm = 0; $t.geaendert = [Math]::Max((Get-JetztMs), $t.geaendert + 1)
      Save-Liste $liste $Aktion
      Write-Output ("Wieder offen: {0}" -f (Get-Kurz $t))
    }
    'Loeschen' {
      $t = Find-Ziel $liste
      $t.geloescht = $true; $t.geaendert = [Math]::Max((Get-JetztMs), $t.geaendert + 1)
      Save-Liste $liste $Aktion
      Write-Output ("Geloescht (Grabstein): {0}" -f (Get-Kurz $t))
    }
    'Synchronisieren' {
      $neu = $liste
      if ($Quelldatei) {
        $q = Read-Dokument (Resolve-Path -LiteralPath $Quelldatei).Path
        if ($null -eq $q) { Stop-Fehler "Quelldatei nicht gefunden: $Quelldatei" }
        $neu = @(Merge-Listen $liste $q.aufgaben)
        Write-Output ("Zusammengefuehrt: {0} Aufgaben aus der Quelldatei" -f @($q.aufgaben).Count)
      }
      Save-Liste $neu $Aktion
      Write-Output ("Synchronisiert: {0} Aufgaben ({1} offen), Spiegel todos.js neu erzeugt" -f @($neu | Where-Object { -not $_.geloescht }).Count, @($neu | Where-Object { -not $_.geloescht -and -not $_.done }).Count)
    }
    'Pruefen' {
      $fehler = New-Object System.Collections.ArrayList
      if ($dok.version -ne 1) { [void]$fehler.Add("todos.json: Schema-Version $($dok.version) wird nicht unterstuetzt (erwartet 1)") }
      (Test-Liste $liste) | ForEach-Object { [void]$fehler.Add('todos.json: ' + $_) }
      if (-not (Test-Path -LiteralPath $dateiJs)) { [void]$fehler.Add('todos.js (Spiegel) fehlt') }
      else {
        $js = [IO.File]::ReadAllText($dateiJs, $utf8)
        $m = [regex]::Match($js, '(?s)window\.NX_TODOS\s*=\s*(\{.*\})\s*;\s*$')
        if (-not $m.Success) { [void]$fehler.Add('todos.js: Aufbau "window.NX_TODOS = {...};" nicht erkannt') }
        else {
          try { $sp = $m.Groups[1].Value | ConvertFrom-Json } catch { $sp = $null; [void]$fehler.Add('todos.js: JSON-Teil ungueltig: ' + $_.Exception.Message) }
          if ($sp) {
            $spListe = @(@($sp.aufgaben) | Where-Object { $null -ne $_ } | ForEach-Object { ConvertTo-Aufgabe $_ })
            (Test-Liste $spListe) | ForEach-Object { [void]$fehler.Add('todos.js: ' + $_) }
            $soll = @($liste | Where-Object { -not $_.geloescht })
            if ($spListe.Count -ne $soll.Count) { [void]$fehler.Add("Spiegel weicht ab: todos.js hat $($spListe.Count) Aufgaben, todos.json (ohne Grabsteine) $($soll.Count)") }
            else {
              $a = ($soll | Sort-Object { [long]$_.id } | ForEach-Object { Get-AufgabeZeile $_ }) -join "`n"
              $b = ($spListe | Sort-Object { [long]$_.id } | ForEach-Object { Get-AufgabeZeile $_ }) -join "`n"
              if ($a -ne $b) { [void]$fehler.Add('Spiegel weicht inhaltlich von todos.json ab (todos.ps1 -Aktion Synchronisieren ausfuehren)') }
            }
            if ([string]$sp.geaendert -ne [string]$dok.geaendert) { [void]$fehler.Add("Spiegel-Zeitstempel ($($sp.geaendert)) weicht vom Zeitstempel in todos.json ($($dok.geaendert)) ab") }
          }
        }
      }
      if ($fehler.Count -gt 0) { Write-Output ('PRUEFEN: {0} Fehler' -f $fehler.Count); $fehler | ForEach-Object { Write-Output ('  - ' + $_) }; exit 1 }
      Write-Output ("PRUEFEN: OK - {0} Eintraege ({1} offen, {2} Grabsteine), Spiegel identisch" -f $liste.Count, @($liste | Where-Object { -not $_.geloescht -and -not $_.done }).Count, @($liste | Where-Object { $_.geloescht }).Count)
      exit 0
    }
  }
} finally {
  if ($mutex) { try { $mutex.ReleaseMutex() } catch { } ; $mutex.Dispose() }
}
